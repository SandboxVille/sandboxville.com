// Journal fragments: terminal-style probe log entries, per-system, most are
// fixed text. Two (f11, f12) are "dynamic" -- their text is a function of
// live session stats (getLiveStats() in main.js / pause.js), not a fixed
// string, and are re-evaluated every time the journal list renders. That is
// the self-reference beat: the log reports a number about the player's own
// play this sitting, which the in-fiction probe should have no way to know.
// Framing draws only on abstract structural ideas (a process loop that never
// reaches a resolved state; a marker meaning "cannot be verified from in
// here, defer") rendered as in-fiction ship diagnostics. No names, no real
// people, ASCII only.

export const JOURNAL = [
  { id: 'f1', system: 1, unlock: 'arrive',
    text: 'PROBE LOG 0441 -- CREW COMPLEMENT AT LAUNCH: 2. CURRENT COMPLEMENT: 1. NO SEPARATION EVENT LOGGED.' },
  { id: 'f2', system: 1, unlock: 'comms',
    text: 'PROBE LOG 0602 -- DIAGNOSTIC LOOP D-7 HAS NOT RETURNED A RESOLVED STATE IN 214 CYCLES. RE-RUNNING DOES NOT CHANGE THE COUNT.' },
  { id: 'f3', system: 1, unlock: 'occlusion',
    text: 'PROBE LOG 0715 -- A CATALOGUED BODY WAS ABSENT FOR SIX SECONDS. NO OCCULTING MASS WAS LOGGED ON THAT BEARING. FILED AS SENSOR ARTIFACT.' },

  { id: 'f4', system: 2, unlock: 'arrive',
    text: 'PROBE LOG 0900 -- THIS FIX AGREES WITH THE PRIOR FIX ONLY IF THE PRIOR FIX WAS ALSO WRONG. BOTH CANNOT BE RIGHT. FILING BOTH.' },
  { id: 'f5', system: 2, unlock: 'comms',
    text: 'PROBE LOG 0955 -- STATUS MARKER ON D-7: DEFER. CANNOT BE VERIFIED FROM IN HERE. CARRIED FORWARD, UNCHANGED, EVERY CYCLE SINCE.' },
  { id: 'f6', system: 2, unlock: 'ghost',
    text: 'PROBE LOG 1032 -- COMMS RECEIVED A CARRIER WITH NO MESSAGE ON IT, SHAPED LIKE ONE ANYWAY. LOGGED AS NOISE. LOGGED IT TWICE.' },
  { id: 'f7', system: 2, unlock: 'duplicate',
    text: 'PROBE LOG 1101 -- SAME CATALOGUE NUMBER, TWO BEARINGS, BOTH WITHIN TOLERANCE. THE CATALOGUE PERMITS ONE ANSWER. THE SKY DID NOT READ THE CATALOGUE.' },

  { id: 'f8', system: 3, unlock: 'arrive',
    text: 'PROBE LOG 1210 -- COMPLEMENT LOGGED AT LAUNCH, AGAIN: 2. THIS ENTRY IS IDENTICAL TO PROBE LOG 0441. NEITHER IS FLAGGED AS A DUPLICATE.' },
  { id: 'f9', system: 3, unlock: 'comms',
    text: 'PROBE LOG 1244 -- D-7 WAS RUN AGAIN. RESULT: DEFER. THE LOOP IS NOT BROKEN. IT WAS NEVER SUPPOSED TO CLOSE.' },
  { id: 'f10', system: 3, unlock: 'crossing',
    text: 'PROBE LOG 1319 -- SOMETHING CROSSED THE FIELD ON A PATH THAT DID NOT REPEAT. IT COULD NOT BE SIGHTED. IT WAS LOGGED ANYWAY, AS ABSENCE OF DATA.' },

  { id: 'f11', system: 1, unlock: 'nullread',
    dynamic: (stats) => `PROBE LOG 0837 -- BEARING READS NON-ZERO WHERE NOTHING IS CATALOGUED. MEASURED ${stats.nullHits} TIME(S) THIS SESSION. THE PROBE WAS NOT BUILT TO COUNT THAT.` },
  { id: 'f12', system: 3, unlock: 'awareness',
    dynamic: (stats) => `PROBE LOG 1958 -- PAUSES LOGGED: ${stats.pauseCount}  //  NULL READINGS: ${stats.nullHits}  //  THIS ENTRY HAS BEEN OPEN ${stats.openSeconds}S. THAT NUMBER SHOULD NOT MOVE WHILE NOTHING ELSE DOES. IT IS MOVING.` },

  // ---------- CH1 additions: four Act I fragments filling out the design
  // doc's "first differentiation / vigilance / the missing seat / an
  // occluding body that measures closer than it should" beats without ever
  // naming the framework they are structured on.
  { id: 'f13', system: 1, unlock: 'fixed',
    text: 'PROBE LOG 0512 -- BEFORE THE FIRST SIGHTING, NOTHING ON THIS SHIP COULD BE CALLED KNOWN. ONE BEARING CHANGED THAT. IT DID NOT MAKE THE REST OF THE SKY ANY LESS DARK.' },
  { id: 'f14', system: 1, unlock: 'nearer',
    text: 'PROBE LOG 0561 -- LOGGED A CONTACT ON A BEARING NOTHING WAS WATCHING. IT DID NOT CLOSE WHILE I LOOKED AT IT. I HAVE STARTED LOOKING AT MORE THINGS AND TRUSTING THE GAUGES LESS.' },
  { id: 'f15', system: 1, unlock: 'secret',
    text: 'PROBE LOG 0447 -- FOUND A SECOND SET OF PERSONAL EFFECTS LODGED AGAINST THE HULL, OUTSIDE, NOT ON ANY MANIFEST. WHOEVER IT BELONGED TO PACKED FOR A TRIP THAT ENDED BEFORE MINE STARTED.' },
  { id: 'f16', system: 1, unlock: 'giant',
    text: 'PROBE LOG 0678 -- THE BODY IN THE WINDOW MEASURES CLOSER THAN THE FIRST FIX ALLOWED. THE FIX WAS NOT WRONG. THE BODY MOVED. NEITHER OF THOSE SHOULD BE TRUE AT THE SAME TIME.' },

  // ---------- P2 additions: the phase 2 story beats and the three threats.
  // Same voice, same rule: structure only, never the framework's names.
  { id: 'f17', system: 1, unlock: 'photo',
    text: 'PROBE LOG 0433 -- PRE-LAUNCH PHOTO, CREW OF TWO. ONE OF THEM HAS BEEN TORN OUT. THE LOG DOES NOT SAY WHO. THE LOG DOES NOT SAY WHEN.' },
  { id: 'f18', system: 1, unlock: 'tally',
    dynamic: (stats) => `PROBE LOG 0490 -- SLEEP CYCLES LOGGED: ${stats.sleeps || 0}. MARKS SCRATCHED BY THE BUNK: ${11 + (stats.sleeps || 0)}. THE DIFFERENCE HAS NOT CHANGED SINCE YOU FIRST COUNTED. IT WAS ALREADY THERE WHEN YOU WOKE.` },
  { id: 'f19', system: 1, unlock: 'reply',
    text: 'PROBE LOG 0721 -- TRANSMISSION ECHOED IN 11 SECONDS. THAT PUTS THE REFLECTOR 1.6 MILLION KILOMETRES AWAY. NOTHING IS CATALOGUED THERE. THE ECHO ADDED A SIGNATURE WE DID NOT SEND.' },
  { id: 'f20', system: 1, unlock: 'body',
    text: 'PROBE LOG 0730 -- EXTERNAL: ONE SUIT, OCCUPIED, TETHERED TO A HULL THAT MATCHES OURS TO THE RIVET. THE NAME TAPE MATCHES OUR BUNK. FILED UNDER D-7. STATUS: DEFER.' },
  { id: 'f21', system: 1, unlock: 'recorder',
    text: 'PROBE LOG 0744 -- RECORDER RECOVERED. ITS CLOCK RUNS NINE DAYS AHEAD OF OURS. EVERY ENTRY UP TO TODAY MATCHES OUR LOG. THE LAST ONE STOPS MID-SENTENCE. IT SOUNDS CERTAIN. NOT AFRAID. CERTAIN.' },
  { id: 'f22', system: 1, unlock: 'edge',
    text: 'PROBE LOG 0810 -- RANGE 900 M: NO FURTHER DATA. THE STARS PAST THE EDGE ARE THE SAME STARS, DRAWN ONTO IT. UP CLOSE THEY DO NOT LINE UP WITH THE REAL ONES. THEY ARE NOT QUITE FAR ENOUGH AWAY.' },
  { id: 'f23', system: 1, unlock: 'pulse',
    text: 'PROBE LOG 0850 -- THE NULL BEARING BEGAN EMITTING AFTER WE MEASURED IT. BEFORE THAT IT ONLY READ NON-ZERO. IT IS NOT ANSWERING THE MEASUREMENT. IT IS ANSWERING WHOEVER TOOK IT.' },
  { id: 'f24', system: 1, unlock: 'listener',
    text: 'PROBE LOG 0901 -- SOMETHING CROSSED THE SKY AND THE STARS BEHIND IT WENT OUT FOR TWENTY-TWO SECONDS. IT WAS WIDER THAN THE WINDOW. IT WENT QUIET WHEN WE WENT QUIET. WE HAVE BEEN VERY QUIET SINCE.' },
  { id: 'f25', system: 1, unlock: 'unlit',
    text: 'PROBE LOG 0612 -- THE LAMP REACHES ABOUT FORTY METRES. PAST THAT THE DARK IS NOT EMPTY. IT IS OCCUPIED. THE DIFFERENCE MATTERS MORE EACH TIME THE SUIT BATTERY DROPS.' },
  { id: 'f26', system: 1, unlock: 'lattice',
    text: 'PROBE LOG 0999 -- TIRED ENOUGH, THE SKY SHOWS ITS SEAMS: STRAIGHT LINES BETWEEN THE STARS, EVENLY SPACED, LIKE A FRAME SOMETHING WAS STRETCHED OVER. RESTED, THEY ARE GONE. I DO NOT KNOW WHICH OF THOSE IS THE ACCURATE STATE.' },

  // ---------- P3 additions: the flight between the stars, the derelict's
  // interior, and the opening of Act II. Same voice, same rule.
  { id: 'f27', system: 2, unlock: 'starbow',
    text: 'PROBE LOG 1004 -- AT 97% OF LIGHT SPEED THE SKY GATHERS IN FRONT OF THE SHIP LIKE WATER AT A BOW. BEHIND US IT IS BLACK. THE STARS BACK THERE HAVE NOT GONE ANYWHERE. THEIR LIGHT STILL REACHES US, STRETCHED TOO RED TO SEE.' },
  { id: 'f28', system: 2, unlock: 'between',
    text: 'PROBE LOG 1011 -- HALFWAY. THE SUN IS A STAR AMONG STARS NOW. NOTHING ON ANY BEARING IS CLOSER THAN THREE LIGHT YEARS. EVERY MAP I HAVE EVER SEEN WAS A MAP OF THE PARTS WITH SOMETHING IN THEM.' },
  { id: 'f29', system: 2, unlock: 'pace',
    text: 'PROBE LOG 1019 -- A CONTACT HELD STATION AT 260 METRES, AT OUR SPEED, WITH NO DRIVE LIT. TRANSPONDER: KESTREL-4. I LOOKED AWAY TO CHECK THE LOG. WHEN I LOOKED BACK IT WAS GONE. I SHOULD NOT HAVE LOOKED AWAY.' },
  { id: 'f30', system: 2, unlock: 'slip',
    text: 'PROBE LOG 1023 -- THE HEADING NEVER CHANGED. THE DESTINATION DID. THE NAV COMPUTER LOGS NO FAULT. IT LOGS THAT THE COURSE ON FILE WAS NEVER CLEARED, AS IF THAT WERE AN EXPLANATION.' },
  { id: 'f31', system: 2, unlock: 'chart',
    text: 'PROBE LOG 1040 -- THE CHART IS BUILT FROM WHAT WE MEASURED. EVERY MEASUREMENT ON IT WAS TAKEN BY SOMEONE ON THIS SHIP. SO THE CHART IS ONLY AS GOOD AS THE CREW, AND THE CREW IS THE ONE THING ON BOARD I CAN NO LONGER COUNT.' },
  { id: 'f32', system: 2, unlock: 'manifest',
    text: 'PROBE LOG 1066 -- MANIFEST RE-ISSUED FROM AN ORIGIN THE ANTENNA COULD NOT RESOLVE. CREW 2: ABOARD. REPAIRING COMMS DID NOT CORRECT THE DISCREPANCY. IT ONLY MADE IT LEGIBLE.' },
  { id: 'f33', system: 2, unlock: 'twoaboard',
    text: 'PROBE LOG 1070 -- THREE ROOMS. I HAVE STOOD IN ALL OF THEM. LIFE SIGNS: 2. EITHER THE SENSOR IS WRONG, OR I HAVE NOT UNDERSTOOD WHAT IT MEANS BY A ROOM.' },
  { id: 'f34', system: 1, unlock: 'wreckside',
    text: 'PROBE LOG 0752 -- INSIDE THE OTHER SHIP THE LOG IS STILL RUNNING ON ITS LAST CELL. IT WAS KEPT BY CREW 2. IT DESCRIBES A BROKEN KESTREL-4 AT 260 METRES WITH A SUIT FLOATING OUTSIDE IT. THE NAME TAPE ON THE SUIT SAYS CREW 1.' },
  { id: 'f35', system: 1, unlock: 'otherhalf',
    text: 'PROBE LOG 0748 -- THE OTHER HALF OF OUR PHOTO IS PINNED BY THEIR BUNK. THE PERSON IN IT IS ME. THE HALF THAT WAS TORN AWAY FROM THEIR COPY IS THE HALF STILL ON OUR WALL.' },
  { id: 'f36', system: 1, unlock: 'swap',
    text: 'PROBE LOG 0760 -- FROM THEIR WINDOW OUR SHIP IS THE WRECK. FROM OUR WINDOW THEIRS IS. NEITHER VIEW IS FLAGGED. I CAME BACK ACROSS 260 METRES WITHOUT LOOKING AT IT, AND IT WAS WHOLE WHEN I GOT HERE.' },
];

export function fragmentsFor(system) { return JOURNAL.filter(f => f.system === system); }
export function fragmentById(id) { return JOURNAL.find(f => f.id === id); }
export function fragmentText(f, stats) { return f.dynamic ? f.dynamic(stats || {}) : f.text; }

// Deterministic redaction for when COMMS is still broken: same fragment
// always garbles the same way, so it does not look like it is flickering.
export function garble(text, seedStr) {
  let seed = 0; for (let i = 0; i < seedStr.length; i++) seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  return text.split(' ').map(w => (w.length > 3 && rand() < 0.4) ? '[REDACTED]' : w).join(' ');
}
