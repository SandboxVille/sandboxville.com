// HOW TO PLAY (W0, v1): the one place this text lives. The pause menu's
// HOW TO PLAY tab and the title button both render these pages; the EXAMINE
// note by the second bunk reads its lines from DARK_RULES below. Later waves
// extend this module (the field manual in W4, tutorial cards in W8) instead
// of rebuilding it. Each page only talks about what exists in this build.
//
// Pure data and rendering: no game state is imported. The caller passes a
// small context: { flags, tetherKey, pad }.
import { TETHER_MAX, UPGRADE_COST, REFINE_ICE_PER_FUEL, JUMP_FUEL_COST } from '../core/constants.js';

// The rules of the dark (plan 6.2): each line starts smeared and becomes
// legible only once its rule has been witnessed (the learn_* flags).
export const DARK_RULES = [
  { id: 'noise', text: 'NOISE CALLS IT.', learned: ['listener_aware', 'listener'] },
  { id: 'dark', text: 'THE DARK HIDES THEM.', learned: ['unlit'] },
  { id: 'watch', text: 'WHAT YOU DO NOT WATCH COMES CLOSER.', learned: ['nearer', 'nearer_seen', 'nearer_held'] },
];
export function darkRules(flags = {}) {
  return DARK_RULES.map(r => ({ id: r.id, text: r.text, legible: r.learned.some(k => !!flags['learn_' + k]) }));
}
// a smeared line keeps its shape (word lengths) but not its letters
const SMEAR = 'mnuwvrcoeaisz';
export function smear(text, seed = 7) {
  let s = seed >>> 0;
  const rnd = () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
  return text.split('').map(ch => /[A-Z]/.test(ch) ? SMEAR[Math.floor(rnd() * SMEAR.length)] : ch === '.' ? '~' : ch).join('');
}

const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const k = t => `<b class="key">${esc(t)}</b>`;
// 2026-09-27: the interact key follows the device (pad = X, button 2), same as hud.prompt().
const use = ctx => k(ctx && ctx.pad ? 'X' : 'F');

export const PAGES = [
  {
    id: 'alive', title: 'STAY ALIVE',
    body: ctx => `
      <p>Watch the bars at the top left. <b>HEALTH</b> falls when anything below gets dangerous; at zero you die. <b>HUNGER</b> and <b>THIRST</b> drain while you play: eat and drink at the <b>GALLEY</b> (right wall of the console room, ${use(ctx)}). The page FOOD AND WATER says where more comes from.</p>
      <p><b>AIR.</b> Inside, the ship breathes for you. Outside, the suit holds about <b>five minutes</b> of air. Turn back at half. The airlock refills the suit.</p>
      <p><b>WARMTH.</b> Below 0 C the cabin takes your body heat. Main power runs the heater. Fix the power panel first.</p>
      <p><b>MIND.</b> The dark, the distance and the things out here wear it down. At zero you black out, lose time, and lose some of what you carry.</p>
      <p>A <b>lit, warm cabin</b> brings your mind back. The <b>bunk</b> (${use(ctx)}) restores it and <b>saves the game</b>.</p>`,
  },
  {
    id: 'where', title: 'KNOW WHERE YOU ARE',
    body: ctx => `
      <p>Go to the console at the front of the ship. Look out of the window.</p>
      <p>Stars are single points of light. Put the circle in the middle of the screen near one and ${ctx.pad ? k('A') : k('CLICK')} to sight it. It only has to be near.</p>
      <p>Sight <b>three stars</b>. The console works out where you are from them. The Sun does not count: the fix measures from it.</p>
      <p><b>Zoom:</b> hold ${ctx.pad ? k('LT') : k('RIGHT MOUSE')}, or press ${k('1')} to ${k('4')}, or use the wheel. Zoom helps with faint stars.</p>`,
  },
  {
    id: 'outside', title: 'GO OUTSIDE',
    body: ctx => `
      <p>Walk to the <b>airlock</b> at the back of the ship and press ${use(ctx)}. Outside you fly with ${k('W A S D')}, ${k('SPACE')} / ${k('C')} for up and down, ${k('Q')} / ${k('E')} to roll, ${k('SHIFT')} to boost.</p>
      <p><b>THE LINE.</b> You go out clipped to a safety line. It is <b>${TETHER_MAX} M</b> long. The <b>LINE</b> gauge at the top left shows how much you have used. It turns bright past 50 M.</p>
      <p><b>${esc(ctx.tetherKey)}</b> unclips you. Nothing holds you to the ship after that. To clip back on, fly to the hatch and press <b>${esc(ctx.tetherKey)}</b> there. Going inside clips you on again next time.</p>
      <p><b>REEL IN:</b> while clipped on, hold ${use(ctx)} with nothing in front of you. It needs no air or propellant.</p>
      <p><b>DAMPERS</b> (${k('V')}): on, you stop when you let go. Off, you coast. Coasting saves propellant on long trips.</p>
      <p><b>PROPELLANT</b> runs the suit's thrusters. With none left you cannot steer or stop. The airlock refills it.</p>
      <p>${k('L')} helmet lamp. ${k('TAB')} scan for things nearby (it is loud).</p>`,
  },
  {
    id: 'salvage', title: 'SALVAGE AND FIX',
    body: ctx => `
      <p><b>CUT:</b> aim at a rock or plate close by and hold ${use(ctx)}. <b>SALVAGE</b> is metal plates with blinking lights. <b>ORE</b> is the brown rocks. <b>ICE</b> is the pale blue chunks.</p>
      <p><b>REPAIR:</b> fly to the broken part (the marker shows it) and hold ${use(ctx)}. Repairs cost salvage and ore. What you already put in stays in.</p>
      <p><b>REFINE:</b> at the console, SHIP &gt; REFINE turns ${REFINE_ICE_PER_FUEL} ice into 1 fuel. It needs main power.</p>
      <p><b>BUILD:</b> outside, press ${k('B')}. Pick a part with ${k('1')} to ${k('8')} or the wheel, aim at an amber ring on the hull and click. ${k('G')} takes a part back for half its cost.</p>`,
  },
  {
    id: 'fly', title: 'FLY THE SHIP',
    body: ctx => `
      <p><b>THE CHART</b> (${k('N')}) shows the real stars near the ship.</p>
      <p>To fly, the thruster needs <b>50%</b> and you need fuel. In the story, leaving this system takes ${JUMP_FUEL_COST} fuel. In the sandbox, sit in the <b>left chair</b> at the console (${use(ctx)}) or pick a star on the chart.</p>
      <p><b>AT THE HELM:</b> the mouse turns the whole ship. Hold ${k('W')} to burn (gas); let go and the ship coasts. Hold ${k('S')} to <b>brake</b>: the ship turns tail first on its own and burns until it has slowed. Hold ${k('SPACE')} to swing the nose onto the marker. ${k('X')} cuts the drive and goes silent. ${use(ctx)} stands you up. On a controller: RT is the gas, LT the brake, BACK goes dark.</p>
      <p>Half of the fuel you burn going out, you need to stop. The ship carries about twelve years of supplies, so slow is not safe.</p>`,
  },
  {
    id: 'grow', title: 'GROW',
    body: ctx => `
      <p>With main power on, the console (SHIP) sells four scanner upgrades for salvage:</p>
      <p><b>WIDE CONE</b> (${UPGRADE_COST.wideCone}): easier to sight stars. <b>DEEP RANGE</b> (${UPGRADE_COST.deepRange}): see and sight fainter stars. <b>5TH ZOOM TIER</b> (${UPGRADE_COST.zoom5}): zoom much further. <b>DREAD PING</b> (${UPGRADE_COST.dreadPing}): a soft tone before the sky does something.</p>
      <p>New things to build appear as you learn what is out here.</p>`,
  },
  {
    id: 'dark', title: 'THE RULES OF THE DARK',
    body: ctx => {
      const rows = darkRules(ctx.flags).map((r, i) => r.legible
        ? `<div class="darkLine">${esc(r.text)}</div>`
        : `<div class="darkLine smeared" aria-label="a smeared line">${esc(smear(r.text, 11 + i * 17))}</div>`).join('');
      return `
      <p class="dim">A note is taped by the other bunk. The handwriting is not yours. Some of it is too smeared to read.</p>
      <div class="darkNote">${rows}</div>
      <p class="dim">A line gets clearer once you have seen what it means.</p>`;
    },
  },
  {
    id: 'food', title: 'FOOD AND WATER',
    body: ctx => `
      <p>The <b>GALLEY</b> is on the right wall of the console room. Look at a station and press ${use(ctx)}. A ration fills 45% of HUNGER, a water pouch 55% of THIRST. Sleeping costs some of both.</p>
      <p><b>MAKE IT:</b> PRINT MEAL turns 1 ore + 1 salvage + 5 battery into a ration. MELT ICE turns 1 ice + 3 battery into 2 water. Both need main power.</p>
      <p><b>FIND IT:</b> some salvage plates have a <b>sealed ration crate</b> welded to them (the cut prompt says so): +2 rations. Every new place you fly to has its own field. The <b>wreck</b> has its own galley: a locker and a water tank.</p>
      <p><b>LET IT DRIP:</b> fix the galley's WATER RECLAIMER (2 salvage + 1 ore) and it adds a pouch every 2.5 minutes on main power. Each RECYCLER you build on the hull adds condensate too. Both stop at 10 pouches: they top you up, they do not feed you.</p>`,
  },
  {
    id: 'cook', title: 'GROW AND COOK',
    body: ctx => `
      <p><b>PICK:</b> on a planet with air, walk up to a plant and hold ${use(ctx)}. The scan names it and says in plain words if it is <b>EDIBLE</b> or <b>TOXIC</b>. Toxic plants wear bright warning colours and spines.</p>
      <p><b>COOK:</b> the last galley station, ${use(ctx)} opens the recipe list. ${k('1')} to ${k('5')} (or the wheel, then ${use(ctx)}) cooks one: HOT MEAL (ration + water), SALAD (2 plants + water), TEA (plant fibre + ice), PLANT STEW (plant + ration + water). EAT RATION and DRINK WATER serve cooked dishes first.</p>
      <p><b>WELL FED:</b> a cooked dish fills you more than a raw pack, and for a few minutes after, hunger and thirst drain at half speed.</p>
      <p><b>SICK:</b> a toxic plant, raw or cooked (a SPOILED MESS), makes you sick for a minute or two: hunger and thirst drain twice as fast and your health slips. The galley only serves it when nothing else is left.</p>
      <p><b>GROW:</b> outside, build a <b>HYDROPONICS</b> bay (B, part 9). On main power it plants 1 plant fibre with 1 water and grows 3 edible plants in 4 minutes. You can watch the crop grow under its dome.</p>`,
  },
  {
    id: 'base', title: 'BUILD A BASE',
    body: ctx => `
      <p><b>MINE:</b> on a planet, the big rock formations are <b>DEPOSITS</b>: an <b>ORE VEIN</b> (dark rock streaked with copper), an <b>ICE OUTCROP</b> (pale crystals), a <b>SALVAGE WRECK</b> (a half-buried hull) or a <b>CARBON SEAM</b> (black layered slabs). Walk up to one and hold ${use(ctx)}: each pull gives 2 or 3 units, and the deposit shrinks until it is mined out. It does not grow back. The cutter heats up: let go now and then. ${k('TAB')} on the ground marks the deposits around you with what is left in them. Loose rocks, hills and spires are scenery.</p>
      <p><b>BUILD:</b> landed and outside, press ${k('B')}. ${k('1')} to ${k('9')} or the wheel picks a part, ${k('Q')} / ${k('E')} turns it, click places it where the ghost is green. It snaps to the parts already there and follows the ground (not on slopes steeper than about 20 degrees, not next to the ship). Parts are paid from the ship's stores; ${k('G')} takes one back for half its cost.</p>
      <p><b>POWER:</b> an <b>RTG</b> (day and night) or a <b>SOLAR PANEL</b> (daylight only) powers every part wired to it: parts within 14 m of each other join up, and the cable shows on the ground. FLOODLIGHTS light the ground at night; a HEATER lets the suit heater rest nearby.</p>
      <p><b>SHELTER:</b> a pressurised room with a door. On power, inside, the suit's air and power refill and you warm up; the <b>cot</b> sleeps and saves the game. <b>STORAGE CRATE:</b> ${use(ctx)} puts your raw resources in, ${k('G')} takes them out. WALLS and DOORWAYS snap to the shelter and to each other.</p>
      <p>The base stays on that world. Land there again and it is waiting.</p>`,
  },
];

// the whole tab: a row of page buttons, then the page
export function renderHowto(page, ctx) {
  const i = Math.max(0, Math.min(PAGES.length - 1, page | 0));
  const tabs = PAGES.map((p, n) => `<button class="pbtn howtoPage${n === i ? ' on' : ''}" data-howto="${n}">${n + 1} ${esc(p.title)}</button>`).join('');
  return `<h3>HOW TO PLAY</h3><div class="rowBtns howtoPages">${tabs}</div>
    <div class="howtoBody" data-page="${i + 1}"><h3>${i + 1}. ${esc(PAGES[i].title)}</h3>${PAGES[i].body(ctx)}</div>
    <p class="dim">${i < PAGES.length - 1 ? `NEXT: PAGE ${i + 2}, ${esc(PAGES[i + 1].title)}. PICK A PAGE ABOVE.` : 'ESC CLOSES THIS. HOW TO PLAY IS ALWAYS IN THE MENU.'}</p>`;
}

// the EXAMINE note (interaction.js) reads the same lines
export function noteText(flags) {
  const lines = darkRules(flags).map(r => r.legible ? r.text : '(A LINE TOO SMEARED TO READ.)');
  return `A NOTE, TAPED BY THE OTHER BUNK. THE HANDWRITING IS NOT YOURS. ${lines.join(' ')}`;
}
