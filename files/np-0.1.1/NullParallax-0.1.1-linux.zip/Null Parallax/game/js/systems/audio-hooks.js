// Ambient audio-linked cues that are not named "entities" in the design doc
// but exist purely to make the ship feel alive and untrustworthy: hull
// creaks, the gaze-following drone + self-scheduling heartbeat, frame slip,
// and the tether reading zero tension. Every timing/threshold number is
// unchanged from v0.4.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { HULL_A, HULL_B, HULL_R } from '../render/ship.js';
import { renderer } from '../render/scene.js';
import { currentDirOf } from './sensors.js';
import { say, caption } from '../ui/hud.js';
import { unlockFragment } from './journal.js';
import * as audio from '../audio.js';

// playtest: subtitles are now on by default, and creaks and hull ticks captioned every few seconds buried the
// captions that matter (something approaching, a call, knocking). Ambient sounds are captioned at most once a minute.
let ambientT = -1e9;
function ambientCaption(t) { const n = performance.now(); if (n - ambientT > 60000) { ambientT = n; caption(t); } }

export function panTowardFront() { return THREE.MathUtils.clamp((Math.random() * 2 - 1) * 0.7, -0.9, 0.9); }

export function scheduleCreak() {
  setTimeout(() => { if (S.awake && !S.paused) { audio.creak(panTowardFront()); ambientCaption('[metallic creak]'); } scheduleCreak(); }, 7000 + Math.random() * 9000);
}

// ---------- frame slip: the frame you are looking through is not provably
// the one being rendered. First occurrence in the whole run is silent on
// purpose; introduced System 2+; fires more often on EVA.
export function scheduleFrameSlip() {
  const eva = S.mode === 'eva';
  const gap = (eva ? 32000 : 60000) + Math.random() * (eva ? 45000 : 80000);
  setTimeout(fireFrameSlip, gap);
}
export function fireFrameSlip() {
  if (!S.awake || S.paused || S.ended || S.dying) { scheduleFrameSlip(); return; }
  if (S.system >= 2) {
    S.frameSlipCount++;
    if (S.frameSlipCount > 1) { audio.frameSlipTick(); caption('[the view hitches, then snaps back]'); }
    const el = renderer.domElement;
    const dx = (Math.random() * 2 - 1) * 3, dy = (Math.random() * 2 - 1) * 3;
    el.style.transform = `translate(${dx.toFixed(1)}px, ${dy.toFixed(1)}px)`;
    setTimeout(() => { el.style.transform = ''; }, 66);
    if (S.journalOrder.length >= 8) unlockFragment(3, 'awareness');
  }
  scheduleFrameSlip();
}

// ---------- the tether reading zero tension for a moment. Purely
// atmospheric -- nothing is actually released.
// playtest: it fired every 25-50 s of EVA, so by the fourth time it read as a status message, not a scare.
// Now the first two come 25-50 s apart (the first is silent), then the gap widens to 3-6 minutes.
export function scheduleTetherSlack() { const n = S.tetherSlackCount || 0; setTimeout(fireTetherSlack, n < 2 ? 25000 + Math.random() * 25000 : 180000 + Math.random() * 180000); }
export function fireTetherSlack() {
  if (S.mode === 'eva' && S.eva.tethered && !S.paused && !S.dying && !S.ended && !S.cycling) {
    S.tetherSlackCount++;
    if (S.tetherLine) S.tetherLine.material.opacity = 0.05;
    if (S.tetherSlackCount > 1) { audio.tetherCreak(); caption('[tether tension: zero]'); say('TETHER TENSION: ZERO', { delay: 300, hold: 3200 }); }
    setTimeout(() => { if (S.tetherLine) S.tetherLine.material.opacity = 0.5; }, 900);
  }
  scheduleTetherSlack();
}

export function updateHullTick(dt) {
  if (S.mode !== 'eva') return;
  const ab = HULL_B.clone().sub(HULL_A);
  const t = THREE.MathUtils.clamp(S.pos.clone().sub(HULL_A).dot(ab) / ab.lengthSq(), 0, 1);
  const closest = HULL_A.clone().addScaledVector(ab, t);
  const distToHull = S.pos.distanceTo(closest) - HULL_R;
  if (distToHull < 6 && Math.random() < dt * 0.4) { audio.hullTick(); ambientCaption('[hull tick]'); }
}

// ---------- gaze-following drone + heartbeat: proximity to whatever bearing
// is currently unsettled in this system.
export function anomalyDirs() {
  const list = [];
  const sys = S.sys;
  if (sys.nullDir) list.push(sys.nullDir);
  if (S.system === 1 && sys.giantDir) list.push(sys.giantDir);
  if (S.system === 2 && sys.dupCenter) list.push(sys.dupCenter);
  if (S.system === 3 && sys.driftSet.size) {
    const c = new THREE.Vector3();
    sys.driftSet.forEach(i => c.add(currentDirOf(i)));
    c.divideScalar(sys.driftSet.size).normalize();
    list.push(c);
  }
  return list;
}
export function updateGazeAndHeartbeat() {
  const list = anomalyDirs();
  if (!list.length) { S.gazeProx = 0; audio.setGazeProximity(0); audio.setHeartbeatProximity(0); return; }
  let minAngle = Infinity;
  list.forEach(d => { const a = S.fwd.angleTo(d); if (a < minAngle) minAngle = a; });
  const maxAngle = THREE.MathUtils.degToRad(28);
  const prox = THREE.MathUtils.clamp(1 - minAngle / maxAngle, 0, 1);
  S.gazeProx = S.awake && !S.paused ? prox : 0;
  audio.setGazeProximity(prox); audio.setHeartbeatProximity(prox);
}
