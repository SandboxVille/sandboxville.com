# Quarantine Wing

## What this room does

New rooms can be watched here behind glass, with zero permissions, so you can see exactly what a stranger's room tries to do before you ever let it near your files or the internet.

What it lets your AI do: Nothing, until you personally release a room from quarantine.

## Its door label (what it can touch, and nothing more)

- It is an empty glass cell with a terminal; on its own it does nothing.
- It cannot read any files on your computer.
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It gives your AI zero tools.

## What you need first

Node.js version 22 or newer, and a copy of the SandboxVille code on your computer (the folder that has `rooms/`, `tools/`, and `harness/` in it).

## How to add it

1. Unzip this download. You will get a folder called `quarantine-wing/` with one file inside, `room.json`.
2. Copy the `quarantine-wing/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/quarantine-wing/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/quarantine-wing`
   This prints the door sign for the room, plain text, so you can see exactly what it is (and is not) allowed to touch.

This room does not give your AI any tools and does not ask for any files or network access, so once you have read its door sign there is nothing else to turn on.

## How to remove it

Delete the `quarantine-wing/` folder from `rooms/` in your SandboxVille code. Nothing else to undo, it never had access to anything of yours.

## Things to try once it's running

- Read the terminal sign at the glass
- Watch the Security Office wall while a new room sits behind the glass

