import*as e from"three";import{renderer as i}from"./scene.js";const p={low:{post:!1},medium:{post:!0,samples:4,mips:4,bloom:.55,grain:.035,vig:.32},high:{post:!0,samples:4,mips:5,bloom:.7,grain:.04,vig:.34}},n={level:"medium",active:!1,frame:0,forceOff:/[?&]post=0/.test(location.search),fear:0,mind:1},s="varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }";let a=null,l=[],m=null,f=null,y=null,h=null,g=null,d=null,c=null;const S=new e.Vector2;function F(){const t=new e.BufferGeometry;return t.setAttribute("position",new e.Float32BufferAttribute([-1,-1,0,3,-1,0,-1,3,0],3)),t}function U(){h=new e.ShaderMaterial({uniforms:{tSrc:{value:null},uTexel:{value:new e.Vector2},uThr:{value:.72},uKnee:{value:.22}},vertexShader:s,fragmentShader:`uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uThr, uKnee; varying vec2 vUv;
      vec3 pick(vec2 uv){ vec3 c = texture2D(tSrc, uv).rgb; float br = max(c.r, max(c.g, c.b));
        float s = clamp(br - uThr + uKnee, 0.0, 2.0 * uKnee); s = s * s / (4.0 * uKnee + 1e-5);
        return c * (max(s, br - uThr) / max(br, 1e-4)); }
      void main(){
        // 4 taps (one per quadrant) so a single bright pixel does not flicker
        vec2 o = uTexel * 0.5;
        vec3 c = pick(vUv + vec2(-o.x, -o.y)) + pick(vUv + vec2(o.x, -o.y)) + pick(vUv + vec2(-o.x, o.y)) + pick(vUv + vec2(o.x, o.y));
        gl_FragColor = vec4(min(c * 0.25, vec3(8.0)), 1.0);
      }`,depthTest:!1,depthWrite:!1}),g=new e.ShaderMaterial({uniforms:{tSrc:{value:null},uTexel:{value:new e.Vector2}},vertexShader:s,fragmentShader:`uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
      void main(){ vec2 h = uTexel * 0.5;
        vec3 s = texture2D(tSrc, vUv).rgb * 4.0 + texture2D(tSrc, vUv - h).rgb + texture2D(tSrc, vUv + h).rgb
               + texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb + texture2D(tSrc, vUv - vec2(h.x, -h.y)).rgb;
        gl_FragColor = vec4(s / 8.0, 1.0); }`,depthTest:!1,depthWrite:!1}),d=new e.ShaderMaterial({uniforms:{tSrc:{value:null},uTexel:{value:new e.Vector2},uGain:{value:1}},vertexShader:s,fragmentShader:`uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uGain; varying vec2 vUv;
      void main(){ vec2 h = uTexel * 0.5;
        vec3 s = texture2D(tSrc, vUv + vec2(-h.x * 2.0, 0.0)).rgb + texture2D(tSrc, vUv + vec2(-h.x, h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(0.0, h.y * 2.0)).rgb + texture2D(tSrc, vUv + vec2(h.x, h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(h.x * 2.0, 0.0)).rgb + texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(0.0, -h.y * 2.0)).rgb + texture2D(tSrc, vUv + vec2(-h.x, -h.y)).rgb * 2.0;
        gl_FragColor = vec4(s / 12.0 * uGain, 1.0); }`,blending:e.AdditiveBlending,transparent:!0,depthTest:!1,depthWrite:!1}),c=new e.ShaderMaterial({uniforms:{tScene:{value:null},tBloom:{value:null},uRes:{value:new e.Vector2},uBloom:{value:.6},uGrain:{value:.035},uVig:{value:.3},uFrame:{value:0},uCold:{value:1},uFear:{value:0}},vertexShader:s,fragmentShader:`uniform sampler2D tScene, tBloom; uniform vec2 uRes; uniform float uBloom, uGrain, uVig, uFrame, uCold, uFear; varying vec2 vUv;
      float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
      float hash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
      void main(){
        vec3 c = texture2D(tScene, vUv).rgb;
        vec3 b = texture2D(tBloom, vUv).rgb;
        c += b * uBloom;
        // the grade: blacks stay black, low mids go a little colder, saturated reds are left alone
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
        float keep = smoothstep(0.25, 0.6, sat) * step(c.g + c.b, c.r * 1.2);
        vec3 cold = c * vec3(0.93, 0.99, 1.07);
        float midW = smoothstep(0.0, 0.08, l) * (1.0 - smoothstep(0.35, 0.8, l));
        c = mix(c, cold, midW * uCold * (1.0 - keep));
        c = mix(vec3(l), c, 1.0 - 0.18 * uFear);                        // fear drains colour
        // vignette: aspect-correct, soft, tightening with fear
        vec2 q = (vUv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
        float r = length(q);
        float v = smoothstep(0.95 - 0.2 * uFear, 0.28, r);
        c *= mix(1.0, v, uVig + 0.25 * uFear);
        // grain: luminance-weighted (4l(1-l)), a fresh pattern each frame
        float n = hash(gl_FragCoord.xy + vec2(uFrame * 37.0, uFrame * 91.0)) - 0.5;
        float lw = clamp(4.0 * l * (1.0 - l), 0.0, 1.0) + 0.15 * step(0.004, l);
        c += n * uGrain * (1.0 + uFear) * lw;
        // dither last: kills 8-bit banding in the near-black gradients
        c += (ign(gl_FragCoord.xy + uFrame * 5.588238) - 0.5) / 255.0;
        gl_FragColor = vec4(max(c, 0.0), 1.0);
      }`,depthTest:!1,depthWrite:!1})}function D(t,u,v=0){const o=new e.WebGLRenderTarget(t,u,{type:e.HalfFloatType,format:e.RGBAFormat,depthBuffer:!1,samples:v});return o.texture.minFilter=o.texture.magFilter=e.LinearFilter,o.texture.generateMipmaps=!1,o}function T(){a&&a.dispose(),l.forEach(t=>t.dispose()),a=null,l=[]}function w(){T();const t=p[n.level];i.getDrawingBufferSize(S);const u=Math.max(2,S.x),v=Math.max(2,S.y);a=new e.WebGLRenderTarget(u,v,{type:e.UnsignedByteType,format:e.RGBAFormat,depthBuffer:!0,stencilBuffer:!1,samples:t.samples||0}),a.texture.colorSpace=e.SRGBColorSpace,a.texture.internalFormat="RGBA8",a.texture.generateMipmaps=!1,a.isXRRenderTarget=!0;let o=u,r=v;for(let b=0;b<t.mips;b++)o=Math.max(1,o>>1),r=Math.max(1,r>>1),l.push(D(o,r))}function B(){m||(U(),m=new e.Scene,f=new e.Mesh(F(),c),f.frustumCulled=!1,m.add(f),y=new e.OrthographicCamera(-1,1,1,-1,0,1),i.info.autoReset=!1,addEventListener("resize",()=>{n.active&&w()}))}function R(t){n.level=p[t]?t:"medium";const u=p[n.level];return B(),n.active=!!u.post&&!n.forceOff,n.active?w():T(),c.uniforms.uBloom.value=u.bloom||0,c.uniforms.uGrain.value=u.grain||0,c.uniforms.uVig.value=u.vig||0,document.body.classList.toggle("postOn",n.active),n.active}function x(t,u){f.material=t,i.setRenderTarget(u),i.render(m,y)}function G(t,u){if(i.info.reset(),!n.active){i.render(t,u);return}n.frame=(n.frame+1)%4096;const v=i.autoClear;i.setRenderTarget(a),i.render(t,u),i.autoClear=!0,h.uniforms.tSrc.value=a.texture,h.uniforms.uTexel.value.set(1/a.width,1/a.height),x(h,l[0]);for(let r=1;r<l.length;r++)g.uniforms.tSrc.value=l[r-1].texture,g.uniforms.uTexel.value.set(1/l[r-1].width,1/l[r-1].height),x(g,l[r]);i.autoClear=!1;for(let r=l.length-1;r>0;r--)d.uniforms.tSrc.value=l[r].texture,d.uniforms.uTexel.value.set(1/l[r].width,1/l[r].height),x(d,l[r-1]);i.autoClear=!0;const o=c.uniforms;o.tScene.value=a.texture,o.tBloom.value=l[0].texture,o.uRes.value.set(a.width,a.height),o.uFrame.value=n.frame,o.uFear.value=Math.max(0,Math.min(1,n.fear)),x(c,null),i.autoClear=v}export{p as LEVELS,B as initPost,n as post,G as renderFrame,R as setGraphicsLevel};
