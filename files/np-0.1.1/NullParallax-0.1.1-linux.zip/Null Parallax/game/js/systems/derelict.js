// Walking inside the derelict (P3). The other KESTREL-4 is your own ship,
// broken in half. Its fore half still holds the console room and the first
// two metres of the corridor, cut off at the break. You climb in on mag
// boots (the wreck has no gravity; the boots are why you can walk), with the
// helmet lamp and one dying red lamp for light.
//
// Inside:
//   * the same rooms as yours, frozen, with everything reversed: their CREW 1
//     bunk is stripped and their CREW 2 bunk is made; the other half of your
//     torn photo is pinned by their bunk; the wall is covered in tally marks
//   * the Nearer's rule, up close: something comes in through the break after
//     you and closes only while nothing is looking at it. Reading the log
//     means turning your back on it.
//   * the flight recorder's main unit, the console log, still running on its
//     last cell. The discovery: it was kept by CREW 2, and it describes YOUR
//     ship: a KESTREL-4 at 260 m, broken in half, with a suit floating outside
//     it whose name tape says CREW 1. Out of their window, your ship IS broken.
//     Get far enough away without looking at it, and it is whole again.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { EYE_H, OXY_MAX, MOUSE_BASE, PAD_LOOK_RATE } from '../core/constants.js';
import { derelict, DERELICT_POS, SHIP_CENTER } from '../render/world.js';
import { ship } from '../render/scene.js';
import { shipFx } from '../render/ship.js';
import { wallPanel, deckGrate, stencil, makeScreen, glowSprite, hullPlate, wallRelief, grateRelief, normalFromHeight } from '../render/textures.js';
import { segBox, bakeRoot, mergeStatic, whiteColours } from '../render/bake.js';
import { addWreckProps } from '../render/props.js';
import { qFromYawPitch, clamp } from '../core/utils.js';
import { say, flash, prompt, progressBar, caption } from '../ui/hud.js';
import { emit, on } from '../core/events.js';
import { unlockFragment } from './journal.js';
import { doAutosave } from './save-state.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);
// the interior is our own ship's interior, moved into the fore half's frame:
// fore-local = (x, y - 1.1, z + 8)   (the hull axis sits at y 1.1, the hull starts at z -12.5)
const L = (x, y, z) => new THREE.Vector3(x, y - 1.1, z + 8);
const FLOOR = -1.1, EYE = FLOOR + EYE_H;
const ROOMS = [
  { name: 'console', xmin: -1.8, xmax: 1.8, zmin: -1.25, zmax: 2.55 },
  { name: 'corridor', xmin: -0.55, xmax: 0.55, zmin: 2.3, zmax: 4.35 },
];
const ENTRY = new THREE.Vector3(0, EYE, 4.15), BREAK_OUT = new THREE.Vector3(0, -0.3, 8.3), WINDOW_OUT = new THREE.Vector3(0, 0.35, -8.6);
const CONSOLE_L = L(0.5, 1.1, -9.0), RACK_L = L(-1.7, 1.0, -6.4), WINDOW_L = L(0, 1.45, -9.42);
const LOCKER_L = L(1.8, 1.1, -7.3), TANK_L = L(1.8, 0.8, -8.2); // 2026-09-28: their galley, on the same wall as yours
const NEARER_SPEED = 1.2, NEARER_WATCH = THREE.MathUtils.degToRad(38), READ_TIME = 6;

const D = {
  built: false, fore: null, hull: [], screen: null, twin: null, nearer: null, rim: null, bottle: null, debris: [],
  inside: false, Lp: new THREE.Vector3(), yaw: 0, pitch: 0, vel: new THREE.Vector3(), step: 0,
  M: new THREE.Matrix4(), Mq: new THREE.Quaternion(), savedSpin: 0.012,
  nearOn: false, nearP: new THREE.Vector3(), nearCd: 0, contacts: 0,
  swap: false, swapUnseen: 0, readShown: 0,
};
export const isInside = () => D.inside;
export const swapOn = () => D.swap;

// ---------------- building ----------------
function mats() {
  const wT = wallPanel(41, [26, 27, 31]), w2 = wallPanel(47, [22, 24, 28]);
  const fT = deckGrate(13); fT.repeat.set(3, 3);
  return {
    wall: new THREE.MeshStandardMaterial({ map: wT, color: 0x8a8e98, roughness: 0.8, metalness: 0.35, normalMap: normalFromHeight(wallRelief(41), 2.2) }),
    wall2: new THREE.MeshStandardMaterial({ map: w2, color: 0x80848c, roughness: 0.8, metalness: 0.3, normalMap: normalFromHeight(wallRelief(47), 2.2) }),
    floor: new THREE.MeshStandardMaterial({ map: fT, color: 0x7a7c84, roughness: 0.6, metalness: 0.6, normalMap: normalFromHeight(grateRelief(), 3.0, 3, 3) }),
    ceil: new THREE.MeshStandardMaterial({ color: 0x131417, roughness: 0.9 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x0c0d10, roughness: 0.7, metalness: 0.5 }),
    metal: new THREE.MeshStandardMaterial({ color: 0x4a4d54, roughness: 0.55, metalness: 0.45 }),
    fabric: new THREE.MeshStandardMaterial({ color: 0x34332e, roughness: 0.95 }),
    blanket: new THREE.MeshStandardMaterial({ color: 0x28323f, roughness: 0.95 }),
    frost: new THREE.MeshStandardMaterial({ color: 0xa8b8c8, roughness: 0.3, metalness: 0.1, transparent: true, opacity: 0.35 }),
    orange: new THREE.MeshStandardMaterial({ color: 0xc86a1e, roughness: 0.5, metalness: 0.3, emissive: 0x1a0800 }),
  };
}
function tornOtherHalf() {
  // the same photo as yours, torn on the other side: this is the half your copy is missing
  const c = document.createElement('canvas'); c.width = 64; c.height = 96; const g = c.getContext('2d');
  g.fillStyle = '#0c0a08'; g.fillRect(0, 0, 64, 96);
  g.fillStyle = '#3a332a'; g.fillRect(4, 4, 56, 88);
  g.fillStyle = '#6b5a44'; g.fillRect(8, 8, 48, 60);
  g.fillStyle = '#2a2620'; g.fillRect(16, 30, 12, 34); g.fillRect(34, 30, 12, 34);
  g.beginPath(); g.arc(22, 24, 6, 0, 7); g.fill(); g.beginPath(); g.arc(40, 24, 6, 0, 7); g.fill();
  g.fillStyle = '#0c0a08';
  g.beginPath(); g.moveTo(0, 8); g.lineTo(30, 8); g.lineTo(14, 24); g.lineTo(26, 40); g.lineTo(0, 46); g.closePath(); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function tallyWall() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256; const g = c.getContext('2d');
  g.clearRect(0, 0, 512, 256); g.strokeStyle = 'rgba(210,200,180,0.5)'; g.lineWidth = 2;
  let n = 0;
  for (let row = 0; row < 7; row++) for (let x = 8; x < 500; x += 7, n++) {
    const y0 = 10 + row * 35;
    if (n % 5 === 4) { g.beginPath(); g.moveTo(x - 30, y0 + 4); g.lineTo(x + 2, y0 + 26); g.stroke(); x += 6; continue; }
    g.beginPath(); g.moveTo(x, y0 + (n * 7) % 4); g.lineTo(x + 1, y0 + 28); g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function build() {
  if (D.built || !derelict.halves.length) return;
  D.built = true;
  const fore = derelict.halves[0].group; D.fore = fore;
  fore.children.forEach(o => { if (o.isMesh && (o.geometry.type === 'CylinderGeometry' || o.geometry.type === 'SphereGeometry')) D.hull.push(o); });
  // the old glimpse-props at the break are replaced by the real rooms
  fore.children.filter(o => o.isMesh && o.userData.glimpse).forEach(o => fore.remove(o));
  const M = mats();
  const g = new THREE.Group(); fore.add(g); D.interior = g;
  const bx = (mat, cx, cy, cz, sx, sy, sz, parent = g) => { const m = new THREE.Mesh(segBox(sx, sy, sz), mat); m.position.copy(L(cx, cy, cz)); parent.add(m); return m; };
  // ---- console room ----
  bx(M.floor, 0, 0.0, -7.375, 4.2, 0.12, 4.05); bx(M.ceil, 0, 2.3, -7.375, 4.2, 0.12, 4.05);
  bx(M.wall, -2.06, 1.15, -7.375, 0.12, 2.3, 4.05); bx(M.wall, 2.06, 1.15, -7.375, 0.12, 2.3, 4.05);
  bx(M.wall2, 0, 0.45, -9.42, 4.2, 0.9, 0.12); bx(M.wall2, 0, 2.17, -9.42, 4.2, 0.34, 0.12);
  bx(M.wall2, -1.83, 1.45, -9.42, 0.46, 1.1, 0.12); bx(M.wall2, 1.83, 1.45, -9.42, 0.46, 1.1, 0.12);
  // the window frame, bent; the glass is gone
  bx(M.metal, 0, 0.9, -9.38, 3.3, 0.06, 0.08); bx(M.metal, 0, 2.0, -9.38, 3.3, 0.06, 0.08).rotation.z = 0.04;
  bx(M.metal, -1.62, 1.45, -9.38, 0.06, 1.16, 0.08); bx(M.metal, 1.62, 1.45, -9.38, 0.06, 1.16, 0.08);
  bx(M.metal, 1.05, 1.7, -9.34, 0.04, 0.7, 0.06).rotation.z = 0.7; // the centre bar, snapped and bent aside
  for (let i = 0; i < 5; i++) { const s = new THREE.Mesh(new THREE.PlaneGeometry(0.08 + i * 0.02, 0.14), M.frost); s.position.copy(L(-1.2 + i * 0.55, 1.2 + (i % 2) * 0.35, -9.2 + i * 0.12)); s.rotation.set(i, i * 1.7, i * 0.4); g.add(s); D.debris.push({ m: s, spin: 0.2 + i * 0.07, bob: i }); }
  bx(M.wall, 1.68, 1.15, -5.32, 0.76, 2.3, 0.12); bx(M.wall, -1.68, 1.15, -5.32, 0.76, 2.3, 0.12); bx(M.wall, 0, 2.2, -5.32, 2.6, 0.2, 0.12);
  bx(M.dark, 0, 0.42, -8.95, 3.0, 0.84, 0.7);
  // chairs: one still at the helm, one torn loose and floating at the ceiling
  const cbox = (parent, mat, x, y, z, sx, sy, sz) => { const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat); m.position.set(x, y, z); parent.add(m); return m; };
  const chair = (x, y, z, rx, rz) => { const c = new THREE.Group(); c.position.copy(L(x, y, z)); c.rotation.set(rx, 0, rz); g.add(c); cbox(c, M.fabric, 0, 0.5, 0, 0.5, 0.08, 0.5); cbox(c, M.fabric, 0, 0.85, 0.24, 0.5, 0.62, 0.08); cbox(c, M.metal, 0, 0.25, 0, 0.06, 0.5, 0.06); return c; };
  chair(-0.72, 0, -7.95, 0, 0); D.debris.push({ m: chair(0.9, 1.3, -6.6, 1.9, 0.6), spin: 0.05, bob: 2, big: true });
  // the console screen: the log, still running on its last cell
  D.screen = makeScreen(512, 256);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.55), new THREE.MeshBasicMaterial({ map: D.screen.tex, toneMapped: false }));
  scr.position.copy(L(0.5, 1.18, -9.05)); scr.rotation.set(-0.35, 0.18, 0); g.add(scr);
  drawScreen(0);
  // the rack, with an O2 bottle still clipped to it
  bx(M.dark, -1.85, 1.1, -6.6, 0.3, 1.9, 1.2);
  D.bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.5, 10), M.orange); D.bottle.position.copy(RACK_L); g.add(D.bottle);
  // their galley: a locker door hanging open, and the water tank under it (upkeep, 2026-09-28)
  D.locker = bx(M.metal, 1.9, 1.1, -7.3, 0.22, 0.7, 0.55); D.lockerDoor = bx(M.dark, 1.62, 1.1, -7.05, 0.04, 0.66, 0.5); D.lockerDoor.rotation.y = 0.9;
  D.tank = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.7, 12), M.metal); D.tank.rotation.x = Math.PI / 2; D.tank.position.copy(TANK_L); g.add(D.tank);
  // ---- the corridor, as far as the break ----
  bx(M.floor, 0, 0.0, -4.425, 2.6, 0.12, 1.85); bx(M.ceil, 0, 2.15, -4.425, 2.6, 0.12, 1.85);
  bx(M.wall2, -1.32, 1.08, -4.425, 0.12, 2.15, 1.85); bx(M.wall2, 1.32, 1.08, -4.425, 0.12, 2.15, 1.85);
  // bunks, reversed: their CREW 1 is stripped, their CREW 2 is made
  const bunk = (x, made) => {
    const dir = Math.sign(x);
    bx(M.dark, x, 0.45, -4.4, 0.62, 0.1, 1.9); bx(M.dark, x, 1.45, -4.4, 0.62, 0.06, 1.9);
    bx(M.metal, x - dir * 0.3, 0.7, -5.33, 0.04, 0.5, 0.04);
    if (made) { bx(M.fabric, x, 0.55, -4.4, 0.56, 0.1, 1.82); bx(M.blanket, x, 0.62, -4.1, 0.56, 0.06, 1.1); bx(M.fabric, x, 0.64, -5.05, 0.4, 0.08, 0.3); bx(M.frost, x, 0.66, -4.3, 0.58, 0.02, 1.3); }
    else { for (let i = 0; i < 6; i++) bx(M.metal, x, 0.52, -5.2 + i * 0.32, 0.56, 0.03, 0.05); bx(M.fabric, x - dir * 0.26, 0.9, -4.0, 0.04, 0.4, 0.05).rotation.z = 1.2; }
  };
  bunk(-0.95, false); bunk(0.95, true);
  const tag = (x, txt, worn, rotY) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.12), new THREE.MeshStandardMaterial({ map: stencil(txt, { w: 256, h: 64, font: 'bold 34px monospace', worn, seed: 17 }), transparent: true, roughness: 0.8 })); m.position.copy(L(x, 1.62, -4.4)); m.rotation.y = rotY; g.add(m); };
  tag(-1.255, 'CREW 1', 3.5, Math.PI / 2); tag(1.255, 'CREW 2', 0.3, -Math.PI / 2);
  const photo = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.33), new THREE.MeshStandardMaterial({ map: tornOtherHalf(), roughness: 0.9 })); photo.position.copy(L(1.255, 1.35, -5.0)); photo.rotation.y = -Math.PI / 2; g.add(photo);
  const tally = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 0.65), new THREE.MeshBasicMaterial({ map: tallyWall(), transparent: true })); tally.position.copy(L(-1.255, 1.2, -4.2)); tally.rotation.y = Math.PI / 2; g.add(tally);
  // the break: the floor and walls end in torn metal
  for (let i = 0; i < 7; i++) { const p = bx(M.metal, -1.1 + i * 0.37, 0.05 + (i % 3) * 0.7, -3.5, 0.35, 0.05, 0.3 + (i % 2) * 0.3); p.rotation.set(0.4 * (i % 2 ? 1 : -1), 0.3 * i, 0.2 * i); }
  // things that float
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.1, 8), M.metal); cup.position.copy(L(0.2, 1.6, -7.2)); g.add(cup); D.debris.push({ m: cup, spin: 0.4, bob: 1 });
  const glove = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.12, 3, 6), new THREE.MeshStandardMaterial({ color: 0x8a8477, roughness: 0.85 })); glove.position.copy(L(-0.4, 1.3, -4.6)); g.add(glove); D.debris.push({ m: glove, spin: 0.25, bob: 3 }); // (a shade off the suit colour: tests find the body by it)
  // the one lamp: move the dying red lamp into the console room
  if (derelict.lamp) derelict.lamp.position.copy(L(0.6, 2.0, -7.0));
  // gfx pass: the same fixtures and cable runs as yours, dead; torn cable at the break.
  // Then baked occlusion (the lamp's shadows kept faint: your helmet lamp does the real work here)
  addWreckProps(g, M, L);
  const moving = new Set(D.debris.map(d => d.m)); moving.add(D.bottle);
  const inMoving = o => { for (let q = o; q && q !== g; q = q.parent) if (moving.has(q)) return true; return false; };
  D.bake = bakeRoot(g, derelict.lamp ? [{ pos: derelict.lamp.position.clone(), range: 12, weight: 1 }] : [], { shadowFloor: 0.6, aoStrength: 0.85, skipOccluder: inMoving });
  whiteColours(g);
  D.merged = mergeStatic(g, o => !inMoving(o) && !o.material.transparent);
  // the thing that comes in after you: an absence the lamp does not light
  const ng = new THREE.Group(); ng.visible = false; fore.add(ng); D.nearer = ng;
  const blk = new THREE.MeshBasicMaterial({ color: 0x000000 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 1.05, 4, 10), blk); body.position.y = 0.8; ng.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 12, 8), blk); head.position.y = 1.62; ng.add(head);
  const sh = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8), blk); sh.scale.set(1.45, 0.45, 0.7); sh.position.y = 1.33; ng.add(sh);
  [-1, 1].forEach(side => { const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.7, 3, 6), blk); a.position.set(side * 0.36, 0.95, 0); a.rotation.z = side * 0.08; ng.add(a); });
  // a faint cold edge, so the absence has an outline you can learn to see (the same rim the Nearer wears outside)
  const rimMat = new THREE.ShaderMaterial({
    uniforms: { uK: { value: 0.6 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform float uK; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 4.0); gl_FragColor = vec4(vec3(0.55, 0.6, 0.72) * f * uK, 1.0); }`,
  });
  [[new THREE.CapsuleGeometry(0.28, 1.08, 4, 12), 0.8], [new THREE.SphereGeometry(0.205, 12, 8), 1.62]].forEach(([geo, y]) => { const r = new THREE.Mesh(geo, rimMat); r.position.y = y; r.renderOrder = 3; ng.add(r); });
  D.rim = rimMat;
  buildTwin();
}

// your own ship, as it looks from their window
function buildTwin() {
  const g = new THREE.Group(); g.visible = false; ship.add(g); D.twin = g;
  const mat = new THREE.MeshStandardMaterial({ map: hullPlate(31), color: 0xa0a0a8, roughness: 0.65, metalness: 0.35, side: THREE.DoubleSide, emissive: 0x1a1e26 }); // faint starlight on the plates
  const half = (len, capNeg, pos, rot) => {
    const h = new THREE.Group(); h.position.copy(pos); h.rotation.set(rot[0], rot[1], rot[2]); g.add(h);
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(3.3, 3.3, len, 22, 1, true), mat); cyl.rotation.x = Math.PI / 2; h.add(cyl);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(3.3, 22, 10, 0, Math.PI * 2, 0, Math.PI / 2), mat); cap.rotation.x = capNeg ? -Math.PI / 2 : Math.PI / 2; cap.position.z = capNeg ? -len / 2 : len / 2; h.add(cap);
    for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2; const p = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.8 + (i % 3) * 0.5), mat); p.position.set(Math.cos(a) * 3.3, Math.sin(a) * 3.3, (capNeg ? 1 : -1) * (len / 2 + 0.3)); p.rotation.set(0.4 * (i % 2 ? 1 : -1), 0, a + Math.PI / 2); h.add(p); }
    const name = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 1.2), new THREE.MeshStandardMaterial({ map: stencil('KESTREL-4', { w: 1024, h: 220, font: 'bold 150px monospace', worn: 0.4, seed: 5 }), transparent: true, roughness: 0.7 }));
    name.position.set(3.32, 1.2, 0); name.rotation.y = Math.PI / 2; h.add(name);
    return h;
  };
  half(9, true, new THREE.Vector3(0, 1.1, -8.5), [0.04, -0.06, -0.15]);
  half(8, false, new THREE.Vector3(-1.4, 3.2, 5.5), [0.3, 0.35, -0.8]);
  const red = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite(), color: 0xff3010, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  red.scale.set(7, 7, 1); red.position.set(0.4, 1.4, -4.2); g.add(red); D.twinRed = red;
  // the running lights still blink along the torn edge
  [[2.8, 2.6, -3.6], [-2.6, -0.4, -3.8], [-1.0, 5.6, 1.6]].forEach(([x, y, z]) => { const b = new THREE.Sprite(red.material.clone()); b.material.color.setHex(0xffb347); b.scale.set(3, 3, 1); b.position.set(x, y, z); g.add(b); D.twinBlink = (D.twinBlink || []).concat(b); });
}

// hide or show a group's meshes and sprites without touching its lights (the light count never changes)
function showMeshes(group, v) { if (!group) return; group.traverse(o => { if (o.isMesh || o.isSprite || o.isLine || o.isPoints) o.visible = v; }); }
function setSwap(on) {
  if (D.swap === on) return;
  D.swap = on; S.shipSwapped = on; shipFx.swapped = on;
  if (D.twin) D.twin.visible = on;
  showMeshes(shipFx.exterior, !on); showMeshes(shipFx.interiorGroup, !on); showMeshes(shipFx.modulesGroup, !on);
}

function blinkTwin() { const t = performance.now() / 1000; (D.twinBlink || []).forEach((b, i) => { b.material.opacity = Math.sin(t * 2.2 + i * 1.9) > 0.55 ? 0.95 : 0.05; }); if (D.twinRed) D.twinRed.material.opacity = Math.random() < 0.04 ? 0.1 : 0.8; }

// ---------------- the screen ----------------
const LOG = [
  'KESTREL-4  //  SYSTEM 1  //  LOG: CREW 2',
  'CREW: 2.  AWAKE: 1.',
  'TRANSPONDER: KESTREL-4, 260 M.',
  'IT IS BROKEN IN HALF.',
  'ONE SUIT OUTSIDE IT. TAPE: CREW 1.',
  'I KNOW WHAT IT IS NOW. IT IS SIMPLE. IT IS',
];
function drawScreen(k) {
  const scr = D.screen; if (!scr) return;
  const g = scr.g;
  g.fillStyle = '#020506'; g.fillRect(0, 0, 512, 256);
  if (k <= 0) { g.fillStyle = 'rgba(255,90,60,0.8)'; g.font = 'bold 20px monospace'; g.fillText('LOW CELL  //  HOLD TO READ', 16, 40); scr.tex.needsUpdate = true; return; }
  const n = Math.min(LOG.length, Math.ceil(k * LOG.length));
  g.font = 'bold 18px monospace';
  for (let i = 0; i < n; i++) { g.fillStyle = i === 0 ? '#6fd0ff' : i >= 3 ? '#ff7a5a' : '#9fdcff'; g.fillText(LOG[i], 14, 34 + i * 36); }
  scr.tex.needsUpdate = true;
}

// ---------------- entering and leaving ----------------
function foreMatrix() {
  derelict.group.updateMatrix(); D.fore.updateMatrix();
  D.M.multiplyMatrices(derelict.group.matrix, D.fore.matrix);
  D.Mq.setFromRotationMatrix(D.M);
  return D.M;
}
export function breakPoint() { return foreMatrix() && new THREE.Vector3(0, -0.2, 8.3).applyMatrix4(D.M); } // just outside the hull capsule at the open end
function toShip(v) { return v.clone().applyMatrix4(D.M); }
function toLocal(v) { return v.clone().applyMatrix4(D.M.clone().invert()); }

export function enter() {
  if (!D.built) build();
  const f = $('fader');
  if (f) { f.querySelector('div').textContent = 'MAG BOOTS ON'; f.style.transition = 'none'; f.style.display = 'flex'; f.style.opacity = 1; setTimeout(() => { f.style.transition = 'opacity 1.2s ease'; f.style.opacity = 0; setTimeout(() => { f.style.display = 'none'; f.style.transition = ''; }, 1300); }, 500); }
  // freeze the wreck, and turn it so the broken window looks at your ship
  D.savedSpin = derelict.spin || D.savedSpin; derelict.spin = 0;
  const foreFwd = new THREE.Vector3(0, 0, -1).applyEuler(D.fore.rotation);
  const toUs = SHIP_CENTER.clone().sub(derelict.group.position).normalize();
  derelict.group.quaternion.setFromUnitVectors(foreFwd, toUs);
  foreMatrix();
  D.hull.forEach(m => m.visible = false);
  D.inside = true; S.mode = 'derelict'; derelict.lampLevel = 5; D.contacts = 0; D.nearCd = 0;
  S.eva.tethered = false;
  D.Lp.copy(ENTRY); D.yaw = 0; D.pitch = -0.05; D.vel.set(0, 0, 0);
  if (!S.eva.lamp && S.eva.power > 0) S.eva.lamp = true;
  S.P.derelict.inside = true;
  setSwap(true);
  applyPose();
  audio.clank();
  say('MAG BOOTS ON. THE DECK IS COLD ENOUGH TO FEEL THROUGH THE SOLES.', { delay: 700, hold: 14000 });
  if (!S.P.flags.derelictInsideSaid) { S.P.flags.derelictInsideSaid = true; say('IT IS YOUR SHIP. THE SAME ROOMS. EVERYTHING IN THEM IS THE OTHER WAY ROUND.', { delay: 3600, hold: 16000 }); }
  emit('derelictEnter');
}
function leave(how) {
  const out = how === 'window' ? WINDOW_OUT : BREAK_OUT;
  S.mode = 'eva';
  S.pos.copy(toShip(out));
  const outDir = new THREE.Vector3(0, 0, how === 'window' ? -1 : 1).applyQuaternion(D.Mq);
  S.vel.copy(outDir).multiplyScalar(1.4);
  S.q.copy(D.Mq).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), how === 'window' ? 0 : Math.PI));
  D.inside = false; D.nearOn = false; D.nearer.visible = false; audio.setNearer(0, 0); derelict.lampLevel = 14;
  D.hull.forEach(m => m.visible = true);
  D.swapUnseen = 0;
  audio.clank();
  if (how === 'window') say('YOU PULL YOURSELF THROUGH THE BROKEN WINDOW, OUT PAST THE NOSE.', { hold: 10000 });
  emit('derelictLeave', how);
  doAutosave(true);
}
// put the camera where the boots are
function applyPose() {
  S.pos.copy(toShip(D.Lp));
  S.q.copy(D.Mq).multiply(qFromYawPitch(D.yaw, D.pitch, 0, new THREE.Quaternion()));
}
export function reset() {
  derelict.lampLevel = 14;
  D.inside = false; D.nearOn = false; if (D.nearer) D.nearer.visible = false;
  D.hull.forEach(m => m.visible = true);
  setSwap(false);
  if (derelict.spin === 0) derelict.spin = D.savedSpin || 0.012;
}

// ---------------- per frame ----------------
const _v = new THREE.Vector3();
function clampRooms(p) {
  let best = null, bd = Infinity;
  for (const r of ROOMS) {
    const cx = Math.max(r.xmin, Math.min(r.xmax, p.x)), cz = Math.max(r.zmin, Math.min(r.zmax, p.z));
    if (cx === p.x && cz === p.z) return false;
    const d = (cx - p.x) ** 2 + (cz - p.z) ** 2; if (d < bd) { bd = d; best = [cx, cz]; }
  }
  if (best) { p.x = best[0]; p.z = best[1]; } return true;
}
function localFwd() { return new THREE.Vector3(0, 0, -1).applyQuaternion(qFromYawPitch(D.yaw, D.pitch, 0, new THREE.Quaternion())); }
function lookingAtLocal(pt, maxD, deg) { _v.copy(pt).sub(D.Lp); const d = _v.length(); if (d > maxD) return false; return _v.normalize().angleTo(localFwd()) < THREE.MathUtils.degToRad(deg); }

export function update(dt, mouse, ax, fEdge, fHeld) {
  // the rooms inside the wreck are only drawn when you are close enough to see into the break (no lights in there to disturb)
  if (D.interior && derelict.group) D.interior.visible = D.inside || (S.mode !== 'interior' && S.pos.distanceTo(derelict.group.position) < 90);
  if (!D.inside) { outsideSwap(dt); return; }
  const st = S.settings, inv = st.invertY ? -1 : 1, zoomK = Math.min(1, S.fov / S.ZOOMS[0]);
  // look
  D.yaw -= (mouse.dx * MOUSE_BASE * st.sensitivity + (ax.padRX * PAD_LOOK_RATE * st.padLook + ax.kLookX * 1.8) * dt) * zoomK;
  D.pitch = clamp(D.pitch - (mouse.dy * MOUSE_BASE * st.sensitivity * inv + (ax.padRY * PAD_LOOK_RATE * st.padLook * inv + ax.kLookY * 1.8) * dt) * zoomK, -1.45, 1.45);
  // walk on mag boots: slower than at home, and every step clanks
  const f = new THREE.Vector3(-Math.sin(D.yaw), 0, -Math.cos(D.yaw)), r = new THREE.Vector3(Math.cos(D.yaw), 0, -Math.sin(D.yaw));
  const want = f.multiplyScalar(ax.moveF).add(r.multiplyScalar(ax.moveX));
  if (want.lengthSq() > 1) want.normalize();
  const speed = 1.9 * (S.P.life.warmth < 30 ? 0.72 : 1);
  D.vel.lerp(want.multiplyScalar(speed), Math.min(1, dt * (want.lengthSq() > 0.01 ? 12 : 14)));
  D.Lp.addScaledVector(D.vel, dt); D.Lp.y = EYE;
  if (clampRooms(D.Lp)) D.vel.multiplyScalar(0.5);
  const sp = D.vel.length();
  if (sp > 0.3) { const prev = D.step; D.step += dt * sp * 2.1; if (Math.floor(prev / Math.PI) !== Math.floor(D.step / Math.PI)) { audio.footstep(0.6); audio.bump(0.12); S.noise += 0.6; } }
  D.Lp.y = EYE + Math.abs(Math.sin(D.step)) * (st.headBob && sp > 0.3 ? 0.02 : 0);
  S.exerting = false;
  applyPose();
  // floating things drift
  const t = performance.now() / 1000;
  for (const d of D.debris) { d.m.rotation.x += d.spin * dt * 0.3; d.m.rotation.y += d.spin * dt; if (!d.big) d.m.position.y += Math.sin(t * 0.4 + d.bob) * 0.0008; }
  updateNearer(dt);
  blinkTwin();
  interact(dt, fEdge, fHeld);
}

// ---------------- F inside ----------------
function interact(dt, fEdge, fHeld) {
  const P = S.P, A = P.derelict;
  // out through the break
  if (D.Lp.z > 4.05) { prompt('F: PUSH OFF, BACK OUT THROUGH THE BREAK'); progressBar(null); if (fEdge) leave('break'); return; }
  // the console: hold F to read
  if (D.Lp.distanceTo(CONSOLE_L) < 1.9 && lookingAtLocal(CONSOLE_L, 2.4, 40) && !A.read) {
    prompt(D.readT > 0 ? 'HOLD F: READING THE LOG...' : 'HOLD F: READ THE LOG (IT IS STILL RUNNING ON ITS LAST CELL)');
    if (fHeld) {
      if (!D.nearOn && !D.nearSpawned) { D.nearSpawned = true; setTimeout(() => spawnNearer(true), 900); }
      D.readT = (D.readT || 0) + dt;
      S.noise += 0.4 * dt;
      drawScreen(D.readT / READ_TIME);
      if (D.readT >= READ_TIME) readDone();
    }
    progressBar(Math.min(100, (D.readT || 0) / READ_TIME * 100));
    return;
  }
  progressBar(null);
  // out through the broken window
  if (D.Lp.z < -0.75 && Math.abs(D.Lp.x) < 1.4) { prompt(A.read ? 'F: CLIMB OUT THROUGH THE BROKEN WINDOW' : 'F: CLIMB OUT THROUGH THE BROKEN WINDOW (THE LOG IS STILL UNREAD)'); if (fEdge) leave('window'); return; }
  // the O2 bottle
  if (!A.bottle && D.Lp.distanceTo(RACK_L) < 1.5) {
    prompt('F: TAKE THE O2 BOTTLE');
    if (fEdge) { A.bottle = true; D.bottle.visible = false; S.eva.oxygen = Math.min(OXY_MAX, S.eva.oxygen + 40); audio.pickup('fuel'); say('SUIT O2 +40%. YOUR BRAND OF BOTTLE. HALF USED, THE WAY YOU LEAVE THEM.', { hold: 10000 }); }
    return;
  }
  // their galley locker and water tank: once each
  if (!A.locker && D.Lp.distanceTo(LOCKER_L) < 1.6 && lookingAtLocal(LOCKER_L, 1.9, 35)) {
    prompt('F: SEARCH THEIR GALLEY LOCKER');
    if (fEdge) { A.locker = true; P.res.meals += 3; P.res.water += 1; audio.pickup('scrap'); say('THEIR GALLEY LOCKER: 3 RATION PACKS AND A WATER POUCH, STILL SEALED. +3 RATIONS, +1 WATER. THE LABELS ARE IN YOUR HANDWRITING.', { hold: 12000 }); }
    return;
  }
  if (!A.tank && D.Lp.distanceTo(TANK_L) < 1.6 && lookingAtLocal(TANK_L, 1.9, 35)) {
    prompt('F: DRAIN THEIR WATER TANK INTO POUCHES');
    if (fEdge) { A.tank = true; P.res.water += 4; audio.pickup('fuel'); say('THEIR WATER TANK STILL HOLDS SOME. IT FROZE AND THAWED MANY TIMES. +4 WATER.', { hold: 10000 }); }
    return;
  }
  // look closer
  const ex = [
    { id: 'dBunk2', p: L(0.95, 0.7, -4.4), text: 'THEIR CREW 2 BUNK IS MADE. THE BLANKET IS FROZEN TO THE FRAME. SOMEONE SLEPT HERE FOR A LONG TIME.' },
    { id: 'dBunk1', p: L(-0.95, 0.7, -4.4), text: 'THEIR CREW 1 BUNK IS STRIPPED TO THE FRAME. THE STRAPS WERE CUT, NOT UNBUCKLED. LIKE YOURS WAS, ACROSS THE CORRIDOR, AT HOME.' },
    { id: 'dPhoto', p: L(1.255, 1.35, -5.0), text: 'THE OTHER HALF OF YOUR PHOTO. THE PERSON IN IT IS YOU. THE HALF TORN AWAY FROM THIS ONE IS THE HALF STILL PINNED ON YOUR WALL.', frag: 'otherhalf' },
    { id: 'dTally', p: L(-1.255, 1.2, -4.2), text: 'THE WALL BY THEIR BUNK IS COVERED IN TALLY MARKS. YOU STOP COUNTING AT FOUR HUNDRED.' },
    { id: 'dChair', p: L(0.9, 1.3, -6.6), text: 'THE SECOND CHAIR HAS BEEN TORN OFF ITS MOUNT. IT FLOATS AT THE CEILING, TURNING. NOBODY WAS IN IT.' },
  ];
  for (const e of ex) {
    if (lookingAtLocal(e.p, 1.9, 30)) {
      prompt('F: LOOK CLOSER');
      if (fEdge) { say(e.text, { hold: 14000 }); if (e.frag) unlockFragment(1, e.frag); P.flags['ex_' + e.id] = true; emit('examined', e.id); }
      return;
    }
  }
  prompt('');
}

function readDone() {
  const A = S.P.derelict; if (A.read) return;
  A.read = true; D.readT = READ_TIME; drawScreen(1);
  audio.dip(1600);
  say('THE LOG ON THIS CONSOLE WAS KEPT BY CREW 2.', { delay: 400, hold: 22000 });
  say('IT DESCRIBES A KESTREL-4 AT 260 METRES, BROKEN IN HALF, WITH ONE SUIT FLOATING OUTSIDE IT.', { delay: 3200, hold: 24000 });
  say('THE NAME TAPE ON THAT SUIT SAYS CREW 1. THE LAST LINE IS THE SAME AS YOUR RECORDER\'S. WORD FOR WORD.', { delay: 7000, hold: 26000 });
  say('LOOK OUT OF THEIR WINDOW.', { delay: 11200, hold: 22000 });
  setTimeout(() => { S.P.life.sanity = Math.max(5, S.P.life.sanity - 12); unlockFragment(1, 'wreckside'); }, 7000);
  emit('derelictRead');
}

// ---------------- the Nearer, up close ----------------
function spawnNearer(first) {
  if (!D.inside) return;
  D.nearOn = true; D.nearP.set(0, FLOOR, 4.3); D.nearer.visible = true; D.nearer.position.copy(D.nearP); D.nearHold = first ? 2.2 : 0.8;
  audio.knock(0, 2);
  if (first) {
    caption('[something scrapes against the torn edge]', 3000);
    say('SOMETHING CAME IN THROUGH THE BREAK. IT IS STANDING WHERE YOU WERE.', { delay: 400, hold: 16000 });
    say('IT ONLY MOVES WHILE NOTHING IS LOOKING AT IT.', { delay: 3600, hold: 16000 });
  }
}
function updateNearer(dt) {
  if (!D.nearOn) { if (D.nearCd > 0) { D.nearCd -= dt; if (D.nearCd <= 0) spawnNearer(false); } audio.setNearer(0, 0); return; }
  const to = D.Lp.clone().setY(FLOOR).sub(D.nearP); const dist = to.length();
  const eye = D.nearP.clone().setY(EYE - 0.1);
  const dirToIt = eye.sub(D.Lp).normalize();
  const watched = dirToIt.angleTo(localFwd()) < NEARER_WATCH;
  if (D.nearHold > 0) D.nearHold -= dt; // it stands where you were, for a moment, first
  else if (!watched && dist > 0.01) {
    const step = Math.min(dist, NEARER_SPEED * dt);
    D.nearP.addScaledVector(to.normalize(), step);
    clampRooms(D.nearP);
  }
  D.nearer.position.copy(D.nearP);
  D.nearer.rotation.set(0, Math.atan2(D.Lp.x - D.nearP.x, D.Lp.z - D.nearP.z), 0); // (lookAt would take world coordinates)
  if (D.rim) D.rim.uniforms.uK.value = watched ? 0.9 : 0.55;
  // pan: which side of your view it is on
  const right = new THREE.Vector3(Math.cos(D.yaw), 0, -Math.sin(D.yaw));
  audio.setNearer(clamp((7 - dist) / 6.5, 0, 1), clamp(dirToIt.dot(right) * 1.2, -1, 1));
  if (dist < 0.95) contact();
}
function contact() {
  D.contacts++; D.nearOn = false; D.nearer.visible = false; D.nearCd = 14;
  audio.shove(); caption('[a hard shove from somewhere unwatched]');
  S.eva.oxygen = Math.max(0, S.eva.oxygen - 22); S.P.life.sanity = Math.max(1, S.P.life.sanity - 20);
  if (!S.P.flags.learn_nearer) { S.P.flags.learn_nearer = true; S.P.unlocks.mast = true; }
  if (D.contacts >= 2 || S.eva.oxygen <= 0) { emit('derelictKilled'); return; }
  say('IT WAS CLOSER THAN THE LAST TIME YOU LOOKED. IT IS GONE AGAIN. IT WILL COME BACK IN THROUGH THE BREAK.', { hold: 14000 });
}

// ---------------- outside again: your ship is whole when nobody is watching it ----------------
function outsideSwap(dt) {
  if (!D.swap) return;
  blinkTwin();
  if (S.mode !== 'eva') { if (S.mode === 'interior') setSwap(false); return; }
  const fromWreck = S.pos.distanceTo(derelict.group.position);
  const toShip = SHIP_CENTER.clone().sub(S.pos);
  const lookingAtShip = toShip.clone().normalize().angleTo(new THREE.Vector3(0, 0, -1).applyQuaternion(S.q)) < THREE.MathUtils.degToRad(55);
  if (fromWreck > 45 && !lookingAtShip) D.swapUnseen += dt; else D.swapUnseen = 0;
  const tooClose = toShip.length() < 70;
  if (D.swapUnseen > 1.5 || tooClose) {
    setSwap(false);
    if (derelict.spin === 0) derelict.spin = D.savedSpin || 0.012;
    audio.dip(900);
    say(tooClose ? 'YOU BLINKED. YOUR SHIP IS WHOLE.' : 'YOUR SHIP IS WHOLE AGAIN. YOU DID NOT SEE IT CHANGE.', { delay: 300, hold: 16000 });
    unlockFragment(1, 'swap');
    S.P.derelict.escaped = true;
    emit('swapEnded');
  }
}

// ---------------- the objective line ----------------
export function objective() {
  const P = S.P, A = P.derelict;
  if (D.inside) {
    // playtest: inside the wreck there was no marker at all; the rooms are small, but the lamp is narrow and it is dark
    foreMatrix();
    if (!A.read) return { text: 'READ THE LOG ON THEIR CONSOLE: HOLD F.', sub: D.nearOn ? 'SOMETHING IS IN HERE. LOOK BACK AT IT. IT ONLY MOVES WHILE NOTHING IS LOOKING' : 'THE CONSOLE IS AT THE FRONT, UNDER THE BROKEN WINDOW', target: toShip(CONSOLE_L), label: 'THEIR CONSOLE' };
    return { text: 'GET OUT: THE BROKEN WINDOW IS RIGHT IN FRONT OF THE CONSOLE (F).', sub: D.nearOn ? 'DO NOT TAKE YOUR EYES OFF IT FOR LONG' : 'OR BACK OUT THROUGH THE BREAK', target: toShip(WINDOW_L), label: 'BROKEN WINDOW' };
  }
  if (D.swap) return { text: 'GO BACK TO YOUR SHIP.', sub: 'IT IS 260 M AWAY. IT IS BROKEN IN HALF.', target: SHIP_CENTER, label: 'KESTREL-4' };
  return null;
}
// where the break is, for the objective marker outside
export function breakTarget() { if (!D.built) build(); return breakPoint(); }

// test surface (positions in the fore half's own frame, metres)
export function debug() {
  return { swapUnseen: D.swapUnseen, inside: D.inside, pos: D.Lp.toArray(), yaw: D.yaw, near: D.nearOn, nearPos: D.nearP.toArray(), nearDist: D.nearOn ? D.Lp.clone().setY(FLOOR).distanceTo(D.nearP) : null, contacts: D.contacts, readT: D.readT || 0, swap: D.swap, read: !!S.P.derelict.read, bottle: !!S.P.derelict.bottle, twinVisible: !!(D.twin && D.twin.visible), exteriorHidden: !!(shipFx.exterior && shipFx.exterior.children.some(o => o.isMesh && !o.visible)) };
}
export function debugTp(x, z) { D.Lp.set(x, EYE, z); clampRooms(D.Lp); D.vel.set(0, 0, 0); applyPose(); }
export function debugLook(yawDeg, pitchDeg) { D.yaw = THREE.MathUtils.degToRad(yawDeg); D.pitch = THREE.MathUtils.degToRad(pitchDeg); applyPose(); }
export function debugLookAt(x, y, z) { const d = new THREE.Vector3(x, y, z).sub(D.Lp).normalize(); D.yaw = Math.atan2(-d.x, -d.z); D.pitch = Math.asin(clamp(d.y, -1, 1)); applyPose(); }
export function debugSpawn() { spawnNearer(true); D.nearHold = 0; }
export function debugBreak() { return breakPoint().toArray(); }
export const POINTS = { console: () => CONSOLE_L.toArray(), rack: () => RACK_L.toArray(), locker: () => LOCKER_L.toArray(), tank: () => TANK_L.toArray(), window: () => WINDOW_L.toArray(), photo: () => L(1.255, 1.35, -5.0).toArray() };

on('loaded', () => reset());
on('newGame', () => reset());
on('death', () => { D.nearOn = false; });
void flash;
