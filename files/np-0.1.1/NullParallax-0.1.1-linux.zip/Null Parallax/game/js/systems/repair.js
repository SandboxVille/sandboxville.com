// Repairs, refining, upgrades, the signal home, jumps and endings.
// Repairs cost real resources now (salvage and ore cut from the field),
// paid unit by unit as the repair bar fills, so a half-finished repair
// keeps what you already put into it.
import { S } from '../core/state.js';
import { JUMP_FUEL_COST, UPGRADE_COST, REPAIR_COST, REFINE_ICE_PER_FUEL } from '../core/constants.js';
import { JOURNAL } from '../journal-data.js';
import { unlockFragment } from './journal.js';
import { applyUpgradeEffects } from './sensors.js';
import { spawnInterior } from './movement.js';
import { doAutosave } from './save-state.js';
import { arriveAt } from './flow.js';
import { showChapterComplete } from './chapter.js';
import { setTriggerEnding } from './ending-bridge.js';
import * as flight from './flight.js';
import { systemData } from './catalogue.js';
import { emit } from '../core/events.js';
import { flash } from '../ui/hud.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);

function paidRec(name) {
  if (!S.P.flags['paid_' + name]) S.P.flags['paid_' + name] = 0;
  return S.P.flags;
}
function unitsFor(name, p) { const c = REPAIR_COST[name]; return { salvage: Math.ceil(p / 100 * c.salvage - 1e-9), ore: Math.ceil(p / 100 * c.ore - 1e-9) }; }
export function remainingCost(name) {
  const c = REPAIR_COST[name]; const f = S.P.flags;
  const ps = Math.max(f['paidS_' + name] || 0, Math.floor(S.P.repair[name] / 100 * c.salvage));
  const po = Math.max(f['paidO_' + name] || 0, Math.floor(S.P.repair[name] / 100 * c.ore));
  return { salvage: Math.max(0, c.salvage - ps), ore: Math.max(0, c.ore - po) };
}
// advance a repair by `amt` points if the player can pay for it; returns points actually added
export function repair(name, amt) {
  if (!(name in S.P.repair) || S.P.repair[name] >= 100) return 0;
  const f = S.P.flags; void paidRec;
  const c = REPAIR_COST[name];
  const cur = S.P.repair[name];
  let paidS = Math.max(f['paidS_' + name] || 0, Math.floor(cur / 100 * c.salvage));
  let paidO = Math.max(f['paidO_' + name] || 0, Math.floor(cur / 100 * c.ore));
  let target = Math.min(100, cur + amt);
  // how far can we go with what we carry?
  const maxS = paidS + S.P.res.salvage, maxO = paidO + S.P.res.ore;
  const capS = c.salvage ? maxS / c.salvage * 100 : 100;
  const capO = c.ore ? maxO / c.ore * 100 : 100;
  target = Math.min(target, capS, capO);
  if (target <= cur + 1e-6) return 0;
  const need = unitsFor(name, target);
  const dS = Math.max(0, need.salvage - paidS), dO = Math.max(0, need.ore - paidO);
  S.P.res.salvage -= dS; S.P.res.ore -= dO;
  f['paidS_' + name] = paidS + dS; f['paidO_' + name] = paidO + dO;
  S.P.repair[name] = target;
  if (name === 'comms' && target >= 40) unlockFragment(S.P.system, 'comms');
  if (target >= 100) { emit('repaired', name); audio.powerUp(); doAutosave(true); }
  return target - cur;
}

export function buyUpgrade(name) {
  const cost = UPGRADE_COST[name];
  if (!cost || S.P.upgrades[name] || S.P.repair.power < 100 || S.P.res.salvage < cost) return false;
  S.P.res.salvage -= cost; S.P.upgrades[name] = true; applyUpgradeEffects(); doAutosave(true); return true;
}

export function refineFuel() {
  if (S.P.repair.power < 100) { flash('THE REFINERY NEEDS MAIN POWER.', 2400); return false; }
  if (S.P.res.ice < REFINE_ICE_PER_FUEL) { flash(`NEEDS ${REFINE_ICE_PER_FUEL} ICE PER FUEL. ICE FLOATS PALE BLUE IN THE FIELD.`, 2800); return false; }
  S.P.res.ice -= REFINE_ICE_PER_FUEL; S.P.res.fuel += 1; S.noise += 2; audio.servo(); doAutosave(); emit('refined'); return true;
}

export function jumpReady() { return S.P.repair.thrusters >= 50 && S.P.res.fuel >= JUMP_FUEL_COST; }
export function resolveReady() { return S.P.repair.thrusters >= 50 && S.P.journalOrder.length >= JOURNAL.length; }

export function getRepairCtx() {
  return {
    system: S.P.system, power: S.P.repair.power, comms: S.P.repair.comms, thrusters: S.P.repair.thrusters,
    res: S.P.res, upgrades: S.P.upgrades, canJump: jumpReady(), canResolve: resolveReady(), jumpFuelCost: JUMP_FUEL_COST,
    canCollapse: S.P.system === 3 && resolveReady() && S.P.stats.nullHits >= 1,
    mode: S.mode, storyStep: S.P.storyStep, signalSent: !!S.P.flags.signalSent,
    here: S.P.place ? { name: S.P.place.name || 'HIP ' + S.P.place.hip, distLy: Math.hypot(S.P.place.x, S.P.place.y, S.P.place.z) } : (systemData(S.P.system) || {}).target || null,
    next: S.P.mode === 'campaign' && S.P.system < 3 ? ((systemData(S.P.system + 1) || {}).target || null) : null,
    flying: !!S.P.flight, sandbox: S.P.mode === 'sandbox',
  };
}

// the signal home: the loudest thing you can do
export function sendSignal() {
  if (S.P.repair.comms < 100) { flash('THE ANTENNA IS NOT REPAIRED.', 2400); return false; }
  audio.transmit();
  const first = !S.P.flags.signalSent;
  S.noise += first ? 25 : 60; // the first call home is a story beat; after that, it is the loudest thing you can do
  S.P.flags.signalSent = true;
  emit('signal', first);
  doAutosave(true);
  return true;
}

export function doJump() {
  const P = S.P;
  // v0.5 campaign: no jump from the ground
  if (P.landing && P.landing.phase !== 'orbit') { flash('TAKE OFF FIRST: THE HELM (LEFT CHAIR), G.', 2800); return; }
  // P3: a flight already plotted -> back to the helm
  if (P.flight) { flight.enterHelm(); return; }
  // W0: the sandbox chair opens the chart with 1 fuel or more (the chart itself says what each star needs)
  if (P.mode === 'sandbox') {
    if (P.repair.thrusters >= 50 && P.res.fuel >= 1) emit('openChart');
    else flash(P.repair.thrusters < 50 ? 'THE THRUSTER NEEDS 50% (REPAIR IT OUTSIDE).' : 'NO FUEL. REFINE ICE AT THE CONSOLE (SHIP > REFINE).', 2800);
    return;
  }
  if (!jumpReady()) return;
  // P3: leaving System 1 is flown by hand, all 8.85 light years of it
  if (P.mode === 'campaign' && P.system === 1) {
    emit('jump', P.system);
    const go = () => { flight.plan(flight.routesFor()[0]); flight.enterHelm(); doAutosave(true); };
    if (!P.chapter1Shown) { P.chapter1Shown = true; doAutosave(true); showChapterComplete(go); return; }
    go(); return;
  }
  // the rest of the campaign (System 2 -> 3, and RUN) is still the console jump
  P.res.fuel -= JUMP_FUEL_COST;
  emit('jump', P.system);
  if (P.system < 3) arriveAt(P.system + 1);
  else triggerEnding('RUN');
}
export function helmReady() { return !!S.P.flight || jumpReady(); }
export function doResolve() { if (resolveReady()) triggerEnding('RESOLVE'); }

export const ENDINGS = {
  STAY: { title: 'NULL PARALLAX', lines: ['The drift closed the distance one arithmetic step at a time.', 'Nothing was ever fixed. Nothing ever explained itself.', 'The last log entry is a bearing, and then nothing after it.'] },
  RUN: { title: 'NULL PARALLAX', lines: ['THRUSTERS fired. The system fell away behind the hull.', 'DIAGNOSTIC D-7: STILL UNRESOLVED. CARRIED FORWARD.', 'Whatever the sky was doing back there, it is still doing it. It will be there when the next one wakes.'] },
  RESOLVE: { title: 'NULL PARALLAX', lines: ['Position held. The anomaly was allowed to close the last distance.', 'DIAGNOSTIC D-7: RESOLVED.', 'Every star you sighted was real. So was this. So was the edge.'] },
  COLLAPSE: { title: 'NULL PARALLAX', lines: ['The bearing was held instead of explained.', 'A reading that should have been zero stayed exactly what it was for as long as it was watched.', 'DIAGNOSTIC D-7: the marker for "defer" is gone. Nothing replaced it. Nothing needed to.'] },
};
export function triggerEnding(kind) {
  if (S.ended) return; S.ended = true; S.endingKind = kind;
  spawnInterior('airlock');
  const e = $('end'); const cfg = ENDINGS[kind];
  e.querySelector('h2').textContent = cfg.title;
  const body = e.querySelector('#endBody'); body.innerHTML = cfg.lines.map(l => `<div>${l}</div>`).join('');
  e.style.display = 'flex'; requestAnimationFrame(() => e.style.opacity = 1);
  audio.fadeOut(2.5);
}
setTriggerEnding(triggerEnding);
