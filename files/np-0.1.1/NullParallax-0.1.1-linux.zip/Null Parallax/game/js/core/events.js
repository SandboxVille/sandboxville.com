// A tiny event bus. Systems announce what happened ('fix', 'null',
// 'repaired', 'built', 'harvested', ...) and the story/journal/threat
// systems listen, so no module has to import another just to notify it.
const map = new Map();
export function on(name, fn) { if (!map.has(name)) map.set(name, []); map.get(name).push(fn); }
export function emit(name, data) {
  const list = map.get(name); if (!list) return;
  for (const fn of list) { try { fn(data); } catch (e) { console.warn('[event ' + name + ']', e); } }
}
