// Planet surface rendering (v0.5 slice A): a chunked terrain mesh around the
// player in three LOD rings, a sky dome, the resource nodes and a little
// flora, and the planet as seen from orbit. Nothing here is baked: every
// vertex comes from gen/planet.js heightAt(), built a few chunks per frame.
//
// No scene lights are added (scene.js keeps the light count fixed so shaders
// never recompile mid-game). The ground uses its own small shader with a sun
// direction uniform; the ship and the props are lit by the existing
// hemisphere light, which landing.js turns toward the sun while landed.
//
// Coordinates: chunks are built in planet-surface metres. terrain.group sits
// in the scene at -origin, so world = planet - origin (a floating origin: the
// ship stays near world 0 and float precision stays fine).
import * as THREE from 'three';
import { scene } from './scene.js';
import { heightAt, groundAt, nodesInCell, floraInCell, plantsInCell, plantSpecies, faunaInCell, groundColor, CELL } from '../gen/planet.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { noiseGLSL } from '../core/utils.js';

const SEGS = 16;
const LEVELS = [
  { size: CELL, ring: 2 },        // 32 m chunks, 2 m spacing, +-80 m
  { size: CELL * 4, ring: 2 },    // 128 m chunks, 8 m spacing, +-320 m
  { size: CELL * 16, ring: 3 },   // 512 m chunks, 32 m spacing, +-1.8 km
];
const SKIRT = [3, 10, 40];
const BUILD_BUDGET_MS = 5;

export const terrain = {
  group: null, planet: null, site: null, origin: new THREE.Vector2(), taken: new Set(),
  levels: LEVELS.map(() => ({ chunks: new Map(), cx: 1e9, cz: 1e9, mat: null })),
  sky: null, orbit: null, props: null, nodes: [], built: 0, active: false,
  sunDir: new THREE.Vector3(0.3, 0.8, 0.2), day: 1,
};

// ---------- the ground shader ----------
function groundMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      uSun: { value: new THREE.Vector3(0, 1, 0) }, uSunCol: { value: new THREE.Color(1, 1, 1) }, uAmb: { value: new THREE.Color(0.2, 0.2, 0.2) },
      uFog: { value: new THREE.Color(0, 0, 0) }, uFogD: { value: 0.0005 }, uHoleMin: { value: new THREE.Vector2(1, 1) }, uHoleMax: { value: new THREE.Vector2(-1, -1) },
      uCam: { value: new THREE.Vector3() }, uLamp: { value: 0 }, uLampDir: { value: new THREE.Vector3(0, 0, -1) },
      uPL: { value: [new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4()] },
    },
    vertexShader: `
      attribute vec3 color;
      uniform vec2 uHoleMin, uHoleMax;
      varying vec3 vCol; varying vec3 vN; varying vec3 vW; varying vec2 vP;
      void main() {
        vec3 p = position;
        // the next finer ring covers this area: sink this one out of the way (no seams, no z-fight)
        if (p.x > uHoleMin.x && p.x < uHoleMax.x && p.z > uHoleMin.y && p.z < uHoleMax.y) p.y -= 400.0;
        vCol = color; vN = normal; vP = position.xz;
        vec4 w = modelMatrix * vec4(p, 1.0); vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }`,
    fragmentShader: `
      uniform vec3 uSun, uSunCol, uAmb, uFog, uCam, uLampDir; uniform float uFogD, uLamp; uniform vec4 uPL[4];
      varying vec3 vCol; varying vec3 vN; varying vec3 vW; varying vec2 vP;
      ${noiseGLSL}
      void main() {
        vec3 n = normalize(vN);
        float grain = fbm(vec3(vP * 0.35, 0.0)) * 0.35 + 0.82;
        float lam = max(dot(n, uSun), 0.0);
        vec3 col = vCol * grain * (uSunCol * lam + uAmb * (0.55 + 0.45 * n.y));
        vec3 toCam = uCam - vW; float d = length(toCam);
        // the helmet lamp, in the dark: a soft cone down the view
        if (uLamp > 0.0) { float c = max(dot(-toCam / d, uLampDir), 0.0); col += vCol * uLamp * smoothstep(0.86, 0.97, c) * 6.0 / (1.0 + d * d * 0.02); }
        // a base's floodlights (surface build): warm pools of light on the ground at night
        for (int i = 0; i < 4; i++) {
          if (uPL[i].w <= 0.0) continue;
          vec3 L = uPL[i].xyz - vW; float dl = length(L);
          col += vCol * vec3(1.0, 0.93, 0.8) * uPL[i].w * max(dot(n, L / dl), 0.0) * 9.0 / (1.0 + dl * dl * 0.06) * smoothstep(24.0, 12.0, dl);
        }
        float f = 1.0 - exp(-d * uFogD);
        col = mix(col, uFog, clamp(f, 0.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
}

// ---------- one chunk ----------
const _c0 = new THREE.Color(), _c1 = new THREE.Color(), _gc = [0, 0, 0];
function buildChunk(L, i, j) {
  const pl = terrain.planet, site = terrain.site, size = LEVELS[L].size, n = SEGS, st = size / n;
  const x0 = i * size, z0 = j * size;
  // heights on a grid with a one-sample border, for normals
  const W = n + 3, H = new Float32Array(W * W);
  for (let b = 0; b < W; b++) for (let a = 0; a < W; a++) H[b * W + a] = groundAt(pl, x0 + (a - 1) * st, z0 + (b - 1) * st, site);
  const vN = (n + 1) * (n + 1), vS = 4 * n + 4; // grid + one skirt vertex per edge vertex (corners twice)
  const pos = new Float32Array((vN + vS) * 3), nor = new Float32Array((vN + vS) * 3), col = new Float32Array((vN + vS) * 3);
  _c0.setRGB(...pl.tint[0]); _c1.setRGB(...pl.tint[1]);
  const frosty = pl.tempC < -60;
  for (let b = 0; b <= n; b++) for (let a = 0; a <= n; a++) {
    const k = b * (n + 1) + a, h = H[(b + 1) * W + a + 1];
    const hx = H[(b + 1) * W + a + 2] - H[(b + 1) * W + a], hz = H[(b + 2) * W + a + 1] - H[b * W + a + 1];
    let nx = -hx, ny = 2 * st, nz = -hz; const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    pos[k * 3] = x0 + a * st; pos[k * 3 + 1] = h; pos[k * 3 + 2] = z0 + b * st;
    nor[k * 3] = nx; nor[k * 3 + 1] = ny; nor[k * 3 + 2] = nz;
    // flats and hollows take the base tint, slopes and heights the second; frost settles on the flats of cold worlds
    let m = Math.min(1, Math.max(0, (1 - ny) * 3.2 + (h / (pl.amp + 1)) * 0.6));
    if (frosty) m = Math.min(1, Math.max(0, (ny - 0.8) * 4 + h / (pl.amp + 1)));
    groundColor(pl, h, ny, m, _gc); col[k * 3] = _gc[0]; col[k * 3 + 1] = _gc[1]; col[k * 3 + 2] = _gc[2];
  }
  // skirts: a curtain hanging from every edge vertex, hiding cracks against a coarser neighbour
  const edge = [];
  for (let a = 0; a <= n; a++) edge.push(a);                         // b = 0
  for (let b = 0; b <= n; b++) edge.push(b * (n + 1) + n);           // a = n
  for (let a = n; a >= 0; a--) edge.push(n * (n + 1) + a);           // b = n
  for (let b = n; b >= 0; b--) edge.push(b * (n + 1));               // a = 0
  edge.forEach((src, e) => {
    const k = vN + e;
    pos[k * 3] = pos[src * 3]; pos[k * 3 + 1] = pos[src * 3 + 1] - SKIRT[L]; pos[k * 3 + 2] = pos[src * 3 + 2];
    for (let q = 0; q < 3; q++) { nor[k * 3 + q] = nor[src * 3 + q]; col[k * 3 + q] = col[src * 3 + q] * 0.8; }
  });
  const idx = [];
  for (let b = 0; b < n; b++) for (let a = 0; a < n; a++) {
    const p = b * (n + 1) + a;
    idx.push(p, p + n + 1, p + 1, p + 1, p + n + 1, p + n + 2);
  }
  // skirt quads along each side (4 sides x (n+1) vertices; consecutive pairs within a side)
  for (let s = 0; s < 4; s++) for (let a = 0; a < n; a++) {
    const e = s * (n + 1) + a, top0 = edge[e], top1 = edge[e + 1], bot0 = vN + e, bot1 = vN + e + 1;
    idx.push(top0, top1, bot0, top1, bot1, bot0, top0, bot0, top1, top1, bot0, bot1); // both windings: seen from either side
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeBoundingSphere();
  const m = new THREE.Mesh(g, terrain.levels[L].mat);
  m.matrixAutoUpdate = false;
  terrain.built++;
  return m;
}

// ---------- props: resource nodes and flora (instanced) ----------
const NODE_LOOK = {
  ore: { geo: () => new THREE.DodecahedronGeometry(0.9, 0), color: 0x8a7050, rough: 0.8, metal: 0.4, glow: 0.3 },
  ice: { geo: () => new THREE.OctahedronGeometry(0.9, 0), color: 0xbfe6ff, rough: 0.15, metal: 0.0, glow: 0.45 },
  salvage: { geo: () => new THREE.BoxGeometry(1.8, 0.35, 1.2), color: 0xa0a6ae, rough: 0.5, metal: 0.8, glow: 0.3 },
  carbon: { geo: () => new THREE.IcosahedronGeometry(0.8, 0), color: 0x4a4c5a, rough: 0.9, metal: 0.1, glow: 0.25 },
  fibre: { geo: () => new THREE.ConeGeometry(0.55, 1.6, 5), color: 0x8fc050, rough: 0.9, metal: 0.0, glow: 0.3 },
};
const MAX_NODES = 96, MAX_FLORA = 700;
// v0.5 slice B: pickable plants. Edible ones are a squat leafy bulb; toxic ones
// are a taller bulb bristling with spines (and wear warning colours, per species).
function plantGeo(bad) {
  const parts = [];
  const body = new THREE.IcosahedronGeometry(0.42, 1); body.scale(1, bad ? 1.25 : 0.75, 1); body.translate(0, bad ? 0.55 : 0.34, 0); parts.push(body);
  const n = bad ? 14 : 5;
  for (let i = 0; i < n; i++) {
    const a = i / n * Math.PI * 2;
    const g = bad ? new THREE.ConeGeometry(0.045, 0.7, 4) : new THREE.ConeGeometry(0.24, 0.8, 4);
    if (!bad) g.scale(1, 1, 0.22);
    g.translate(0, bad ? 0.27 : 0.4, 0);
    g.rotateZ(bad ? 0.5 + (i % 4) * 0.4 : 1.25);
    g.rotateY(a);
    g.translate(0, bad ? 0.45 + (i % 3) * 0.18 : 0.1, 0);
    parts.push(g);
  }
  return mergeGeometries(parts.map(g => { const q = g.index ? g.toNonIndexed() : g; q.deleteAttribute('uv'); return q; }));
}
function buildProps() {
  const g = new THREE.Group(); g.name = 'planetProps';
  const inst = {};
  for (const k in NODE_LOOK) {
    const d = NODE_LOOK[k];
    const im = new THREE.InstancedMesh(d.geo(), new THREE.MeshStandardMaterial({ color: d.color, roughness: d.rough, metalness: d.metal, emissive: d.color, emissiveIntensity: d.glow, flatShading: true }), MAX_NODES);
    im.count = 0; im.frustumCulled = false; g.add(im); inst[k] = im;
  }
  const flora = [
    new THREE.InstancedMesh(new THREE.ConeGeometry(0.35, 1.4, 5).translate(0, 0.7, 0), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, flatShading: true }), MAX_FLORA),
    new THREE.InstancedMesh(new THREE.CylinderGeometry(0.08, 0.14, 3.2, 5).translate(0, 1.6, 0),new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, flatShading: true }), MAX_FLORA),
  ];
  const caps = new THREE.InstancedMesh(new THREE.SphereGeometry(0.55, 7, 5), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6, emissive: 0x000000, flatShading: true }), MAX_FLORA);
  for (const f of [...flora, caps]) { f.count = 0; f.frustumCulled = false; g.add(f); }
  const fauna = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7, flatShading: true }), 80);
  fauna.count = 0; fauna.frustumCulled = false; g.add(fauna);
  const plants = {};
  for (const k of ['plant', 'badplant']) {
    const im = new THREE.InstancedMesh(plantGeo(k === 'badplant'), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: k === 'badplant' ? 0.35 : 0.8, emissive: k === 'badplant' ? 0x3a1206 : 0x0c160a, flatShading: true }), MAX_NODES);
    im.count = 0; im.frustumCulled = false; g.add(im); plants[k] = im;
  }
  return { group: g, inst, flora, caps, plants, fauna, cx: 1e9, cz: 1e9, plan: null, faunaPlan: null };
}
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _p = new THREE.Vector3(), _e = new THREE.Euler(), _col = new THREE.Color();
function refreshProps(cx, cz) {
  const pr = terrain.props, pl = terrain.planet, R = 3;
  pr.cx = cx; pr.cz = cz;
  const counts = {}; for (const k in pr.inst) counts[k] = 0;
  terrain.nodes = [];
  let nf = [0, 0], nc = 0;
  const pcount = { plant: 0, badplant: 0 }, species = plantSpecies(pl);
  let nfa = 0;
  const floraCol = pl.atmo === 'toxic' ? [0xb0c040, 0x60a080] : pl.atmo === 'thin' ? [0x8a7a5a, 0x9a8a6a] : [0x4f8a3a, 0x7aa050];
  for (let j = cz - R; j <= cz + R; j++) for (let i = cx - R; i <= cx + R; i++) {
    for (const nd of nodesInCell(pl, i, j)) {
      if (terrain.taken.has(nd.id) || counts[nd.type] >= MAX_NODES) continue;
      const y = groundAt(pl, nd.x, nd.z, terrain.site);
      if (terrain.site && Math.hypot(nd.x - terrain.site.x, nd.z - terrain.site.z) < 16) continue; // not under the ship
      const s = nd.size;
      _e.set(0, (nd.x * 7.3 + nd.z) % 6.28, nd.type === 'salvage' ? 0.25 : 0); _q.setFromEuler(_e);
      _m.compose(_p.set(nd.x, y + (nd.type === 'salvage' ? 0.15 : nd.type === 'fibre' ? 0.7 * s : 0.45 * s), nd.z), _q, _s.setScalar(s));
      pr.inst[nd.type].setMatrixAt(counts[nd.type]++, _m);
      terrain.nodes.push({ ...nd, y });
    }
    for (const nd of plantsInCell(pl, i, j)) {
      const im = pr.plants[nd.type];
      if (terrain.taken.has(nd.id) || pcount[nd.type] >= MAX_NODES) continue;
      if (terrain.site && Math.hypot(nd.x - terrain.site.x, nd.z - terrain.site.z) < 16) continue;
      const y = groundAt(pl, nd.x, nd.z, terrain.site);
      _q.setFromEuler(_e.set(0, (nd.x * 3.1 + nd.z) % 6.28, 0));
      _m.compose(_p.set(nd.x, y - 0.05, nd.z), _q, _s.setScalar(nd.size * 1.3));
      im.setMatrixAt(pcount[nd.type], _m); im.setColorAt(pcount[nd.type]++, _col.setRGB(...species[nd.species].col));
      terrain.nodes.push({ ...nd, y, name: species[nd.species].name, scan: species[nd.species].scan });
    }
    for (const a of faunaInCell(pl, i, j)) {
      if (nfa >= 80 || (terrain.site && Math.hypot(a.x - terrain.site.x, a.z - terrain.site.z) < 18)) continue;
      const y = groundAt(pl, a.x, a.z, terrain.site) + (pl.fauna.plan === 'floater' ? 3.5 : 0);
      _q.setFromEuler(_e.set(0, a.r, 0));
      _m.compose(_p.set(a.x, y, a.z), _q, _s.setScalar(a.s * pl.fauna.size));
      pr.fauna.setMatrixAt(nfa++, _m);
    }
    for (const f of floraInCell(pl, i, j)) {
      if (terrain.site && Math.hypot(f.x - terrain.site.x, f.z - terrain.site.z) < 14) continue;
      const y = groundAt(pl, f.x, f.z, terrain.site);
      const k = f.kind; if (nf[k] >= MAX_FLORA) continue;
      _q.setFromEuler(_e.set(0, f.r, 0));
      _m.compose(_p.set(f.x, y - 0.1, f.z), _q, _s.set(f.s, f.s * (k ? 1.2 : 1), f.s));
      pr.flora[k].setMatrixAt(nf[k], _m); pr.flora[k].setColorAt(nf[k], _col.setHex(floraCol[k]).multiplyScalar(0.8 + (f.r % 0.4)));
      nf[k]++;
      if (k === 1 && nc < MAX_FLORA) { _m.compose(_p.set(f.x, y - 0.1 + 3.2 * f.s * 1.2, f.z), _q, _s.setScalar(f.s)); pr.caps.setMatrixAt(nc, _m); pr.caps.setColorAt(nc, _col.setHex(pl.atmo === 'toxic' ? 0xd0f060 : 0xe0a0c0)); nc++; }
    }
  }
  for (const k in pr.inst) { pr.inst[k].count = counts[k]; pr.inst[k].instanceMatrix.needsUpdate = true; }
  for (const k in pr.plants) { const im = pr.plants[k]; im.count = pcount[k]; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true; }
  pr.flora.forEach((f, k) => { f.count = nf[k]; f.instanceMatrix.needsUpdate = true; if (f.instanceColor) f.instanceColor.needsUpdate = true; });
  pr.fauna.count = nfa; pr.fauna.instanceMatrix.needsUpdate = true;
  pr.caps.count = nc; pr.caps.instanceMatrix.needsUpdate = true; if (pr.caps.instanceColor) pr.caps.instanceColor.needsUpdate = true;
}

// ---------- body plans: the flora's shape and the animals', from the planet's seed ----------
function floraGeo(plan) {
  const nonIdx = g => { const q = g.index ? g.toNonIndexed() : g; if (q.attributes.uv) q.deleteAttribute('uv'); return q; };
  switch (plan) {
    case 'fan': { const parts = []; for (let i = 0; i < 5; i++) { const c = new THREE.ConeGeometry(0.22, 1.5, 3); c.scale(1, 1, 0.2); c.translate(0, 0.75, 0); c.rotateZ((i - 2) * 0.32); c.rotateY(i * 0.6); parts.push(nonIdx(c)); } return mergeGeometries(parts); }
    case 'crystal': { const o = new THREE.OctahedronGeometry(0.4, 0); o.scale(0.7, 2.6, 0.7); o.translate(0, 0.9, 0); const o2 = new THREE.OctahedronGeometry(0.25, 0); o2.scale(0.7, 2.0, 0.7); o2.rotateZ(0.5); o2.translate(0.3, 0.5, 0); return mergeGeometries([nonIdx(o), nonIdx(o2)]); }
    case 'bulb': { const parts = []; for (let i = 0; i < 3; i++) { const s = new THREE.IcosahedronGeometry(0.28 + i * 0.07, 1); s.translate(Math.cos(i * 2.1) * 0.3, 0.3 + i * 0.12, Math.sin(i * 2.1) * 0.3); parts.push(nonIdx(s)); } return mergeGeometries(parts); }
    case 'stalk': return new THREE.CylinderGeometry(0.05, 0.12, 2.2, 5).translate(0, 1.1, 0);
    default: return new THREE.ConeGeometry(0.35, 1.4, 5).translate(0, 0.7, 0);
  }
}
function faunaGeo(f) {
  const nonIdx = g => { const q = g.index ? g.toNonIndexed() : g; if (q.attributes.uv) q.deleteAttribute('uv'); return q; };
  const parts = [], L = 0.6 + f.neck * 0.3;
  const body = new THREE.IcosahedronGeometry(0.35, 1);
  switch (f.plan) {
    case 'strider': {
      body.scale(1.3, 0.8, 0.9); body.translate(0, 1.5, 0); parts.push(nonIdx(body));
      const neck = new THREE.CylinderGeometry(0.06, 0.09, L, 5); neck.rotateZ(-0.7); neck.translate(0.55, 1.85, 0); parts.push(nonIdx(neck));
      const head = new THREE.IcosahedronGeometry(0.15, 0); head.translate(0.55 + L * 0.5, 2.0 + L * 0.35, 0); parts.push(nonIdx(head));
      for (let i = 0; i < f.legs; i++) { const leg = new THREE.CylinderGeometry(0.03, 0.05, 1.55, 4); leg.translate(0, 0.78, 0); leg.rotateX((i % 2 ? 1 : -1) * 0.2); leg.translate((Math.floor(i / 2) - (f.legs / 4 - 0.5)) * 0.35, 0, (i % 2 ? 0.18 : -0.18)); parts.push(nonIdx(leg)); }
      break;
    }
    case 'crawler': {
      for (let k = 0; k < 3; k++) { const seg = new THREE.IcosahedronGeometry(0.28, 1); seg.scale(1, 0.6, 0.9); seg.translate(k * 0.45 - 0.45, 0.3, 0); parts.push(nonIdx(seg)); }
      for (let i = 0; i < f.legs; i++) { const leg = new THREE.CylinderGeometry(0.025, 0.035, 0.6, 4); leg.rotateX((i % 2 ? 1 : -1) * 1.0); leg.translate((Math.floor(i / 2) / (f.legs / 2 - 1 || 1) - 0.5) * 1.0, 0.2, (i % 2 ? 0.3 : -0.3)); parts.push(nonIdx(leg)); }
      break;
    }
    case 'hopper': {
      body.scale(0.9, 1.1, 0.8); body.translate(0, 0.7, 0); parts.push(nonIdx(body));
      for (const zz of [-0.18, 0.18]) { const leg = new THREE.CylinderGeometry(0.05, 0.09, 0.8, 4); leg.rotateZ(0.5); leg.translate(-0.15, 0.35, zz); parts.push(nonIdx(leg)); }
      const ear = new THREE.ConeGeometry(0.06, 0.5, 4); ear.translate(0.1, 1.25, 0); parts.push(nonIdx(ear));
      break;
    }
    default: { // floater: a drifting bladder with trailing tendrils
      body.scale(1.2, 0.9, 1.2); parts.push(nonIdx(body));
      for (let i = 0; i < 5; i++) { const t = new THREE.CylinderGeometry(0.015, 0.03, 1.4, 3); t.translate(Math.cos(i * 1.26) * 0.25, -0.9, Math.sin(i * 1.26) * 0.25); parts.push(nonIdx(t)); }
    }
  }
  return mergeGeometries(parts);
}
function setBodyPlans(pl) {
  const pr = terrain.props;
  const plan = pl.floraPlan || 'spike';
  if (pr.plan !== plan) { pr.flora[0].geometry.dispose(); pr.flora[0].geometry = floraGeo(plan); pr.plan = plan; }
  const fk = pl.fauna ? JSON.stringify(pl.fauna) : 'none';
  if (pr.faunaPlan !== fk) {
    pr.faunaPlan = fk;
    if (pl.fauna) { pr.fauna.geometry.dispose(); pr.fauna.geometry = faunaGeo(pl.fauna); pr.fauna.material.color.setRGB(...pl.fauna.col); }
    pr.fauna.count = 0;
  }
}

// ---------- sky dome ----------
function buildSkyDome() {
  const mat = new THREE.ShaderMaterial({
    uniforms: { uSky: { value: new THREE.Color() }, uSun: { value: new THREE.Vector3(0, 1, 0) }, uDay: { value: 1 }, uDens: { value: 0 }, uHaze: { value: new THREE.Color() },
      uMoon: { value: [new THREE.Vector4(), new THREE.Vector4(), new THREE.Vector4()] }, uMoonCol: { value: [new THREE.Color(), new THREE.Color(), new THREE.Color()] },
      uRingN: { value: new THREE.Vector3(0, 0, 1) }, uRing: { value: 0 }, uAurora: { value: 0 }, uTime: { value: 0 } },
    vertexShader: `varying vec3 vD; void main(){ vD = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p; }`,
    fragmentShader: `
      uniform vec3 uSky, uSun, uHaze; uniform float uDay, uDens; varying vec3 vD;
      uniform vec4 uMoon[3]; uniform vec3 uMoonCol[3]; uniform vec3 uRingN; uniform float uRing, uAurora, uTime;
      ${noiseGLSL}
      void main() {
        vec3 d = normalize(vD);
        float up = clamp(d.y, -0.2, 1.0);
        float horizon = pow(1.0 - max(up, 0.0), 4.0);
        vec3 col = mix(uSky, uHaze, horizon * 0.8) * (0.04 + 0.5 * uDay);
        float sd = max(dot(d, uSun), 0.0);
        float disc = smoothstep(0.9993, 0.9997, sd);
        float glow = pow(sd, 90.0) * 0.8 + pow(sd, 8.0) * 0.25 * uDens;
        float a = clamp(uDens * 1.25, 0.0, 1.0) * (0.2 + 0.8 * uDay);
        if (d.y < 0.0) a = max(a, uDens);
        col += vec3(1.0, 0.95, 0.85) * (disc * 2.0 + glow * 0.5);
        float extra = 0.0;
        // rings: a banded arc across the sky, lit by the sun
        if (uRing > 0.5 && d.y > -0.02) {
          float rb = dot(d, uRingN);
          float band = smoothstep(0.16, 0.13, abs(rb - 0.06)) * (0.55 + 0.45 * sin(rb * 180.0)) * smoothstep(-0.02, 0.06, d.y);
          col = mix(col, vec3(0.85, 0.8, 0.72) * (0.08 + 0.9 * uDay), band * 0.7); extra = max(extra, band * 0.7);
        }
        // moons: discs lit from the sun's side
        for (int i = 0; i < 3; i++) {
          vec4 mo = uMoon[i]; if (mo.w <= 0.0) continue;
          vec3 m = normalize(mo.xyz); float c = dot(d, m); if (c < cos(mo.w)) continue;
          vec3 t = (d - m * c) / sin(mo.w); float r2 = dot(t, t);
          vec3 nrm = normalize(t - m * sqrt(max(0.0, 1.0 - r2)));
          float lit = max(dot(nrm, uSun), 0.0);
          float edge = smoothstep(1.0, 0.92, r2);
          col = mix(col, uMoonCol[i] * (0.03 + 1.1 * lit) * (0.85 + 0.3 * fbm(t * 6.0 + float(i))), edge); extra = max(extra, edge);
        }
        // aurora: green curtains low in the night sky
        if (uAurora > 0.5 && d.y > 0.0) {
          float az = atan(d.z, d.x);
          float cur = smoothstep(0.45, 0.8, fbm(vec3(az * 3.0, uTime * 0.03, 1.7))) * smoothstep(0.02, 0.12, d.y) * smoothstep(0.55, 0.2, d.y);
          float k = cur * (1.0 - uDay) * 0.9;
          col += vec3(0.25, 1.0, 0.55) * k; extra = max(extra, k);
        }
        gl_FragColor = vec4(col, clamp(a + disc + glow * 0.6 + extra, 0.0, 1.0));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    side: THREE.BackSide, transparent: true, depthWrite: false,
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(4200, 32, 16), mat);
  m.frustumCulled = false; m.renderOrder = 10; // after the stars, so a daytime sky hides them
  return m;
}

// ---------- the planet from orbit ----------
function buildOrbitSphere() {
  const mat = new THREE.ShaderMaterial({
    uniforms: { uA: { value: new THREE.Color() }, uB: { value: new THREE.Color() }, uSky: { value: new THREE.Color() }, uSun: { value: new THREE.Vector3(1, 0.3, 0) }, uDens: { value: 0 }, uSeed: { value: 0 }, uCrat: { value: 0 } },
    vertexShader: `varying vec3 vN; varying vec3 vO; varying vec3 vV; void main(){ vO = normalize(position); vN = normalize(mat3(modelMatrix) * normal); vec4 w = modelMatrix * vec4(position, 1.0); vV = normalize(cameraPosition - w.xyz); gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: `
      uniform vec3 uA, uB, uSky, uSun; uniform float uDens, uSeed, uCrat; varying vec3 vN; varying vec3 vO; varying vec3 vV;
      ${noiseGLSL}
      void main() {
        vec3 p = vO * 3.0 + uSeed;
        float n = fbm(p), m = fbm(p * 3.1 + 7.0);
        vec3 col = mix(uA, uB, smoothstep(0.35, 0.65, n * 0.7 + m * 0.3));
        col *= 0.8 + 0.4 * fbm(p * 11.0);
        if (uCrat > 0.5) col *= 0.85 + 0.3 * smoothstep(0.55, 0.7, fbm(p * 7.0));
        float lam = max(dot(normalize(vN), uSun), 0.0);
        float rim = pow(1.0 - max(dot(normalize(vN), normalize(vV)), 0.0), 3.0);
        vec3 c = col * (0.03 + 1.1 * lam) + uSky * rim * uDens * (0.2 + lam) * 1.6;
        gl_FragColor = vec4(c, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(1, 96, 64), mat);
  m.frustumCulled = false;
  return m;
}

// ---------- lifecycle ----------
function ensure() {
  if (terrain.group) return;
  terrain.group = new THREE.Group(); terrain.group.name = 'terrain';
  terrain.levels.forEach(lv => { lv.mat = groundMaterial(); });
  terrain.props = buildProps(); terrain.group.add(terrain.props.group);
  terrain.sky = buildSkyDome();
  terrain.orbit = buildOrbitSphere();
}

export function setPlanet(pl, site, taken) {
  ensure();
  const same = terrain.planet && terrain.planet.seed === pl.seed && JSON.stringify(terrain.site) === JSON.stringify(site || null);
  terrain.planet = pl; terrain.site = site ? { ...site } : null; terrain.taken = new Set(taken || []);
  if (!same) clearChunks();
  terrain.props.cx = 1e9;
  for (const lv of terrain.levels) {
    const u = lv.mat.uniforms; u.uFog.value.setRGB(...pl.sky).lerp(new THREE.Color(0.02, 0.02, 0.025), pl.density ? 0 : 1);
    u.uFogD.value = pl.atmo === 'none' ? 0.00012 : pl.atmo === 'thin' ? 0.0006 : pl.atmo === 'toxic' ? 0.0016 : 0.0009;
  }
  // weather: the air's fog thickens with dust, fog banks or haze
  const wf = { clear: 1, dust: 2.0, fog: 2.3, haze: 1.5, aurora: 1 }[pl.weather] || 1;
  for (const lv of terrain.levels) { const u = lv.mat.uniforms; u.uFogD.value *= wf; if (pl.weather === 'dust') u.uFog.value.lerp(new THREE.Color(0.55, 0.4, 0.26), 0.6); }
  const su = terrain.sky.material.uniforms;
  for (let i = 0; i < 3; i++) {
    const mo = pl.moons && pl.moons[i];
    if (mo) { su.uMoon.value[i].set(Math.cos(mo.el) * Math.cos(mo.az), Math.sin(mo.el), Math.cos(mo.el) * Math.sin(mo.az), mo.size); su.uMoonCol.value[i].setRGB(...mo.col); }
    else su.uMoon.value[i].set(0, 1, 0, 0);
  }
  su.uRing.value = pl.rings ? 1 : 0; su.uRingN.value.set(Math.sin(pl.ringTilt || 0) * Math.cos(pl.ringAz || 0), Math.cos(pl.ringTilt || 0), Math.sin(pl.ringTilt || 0) * Math.sin(pl.ringAz || 0)).normalize();
  su.uAurora.value = pl.weather === 'aurora' ? 1 : 0;
  setBodyPlans(pl);
  su.uSky.value.setRGB(...pl.sky); su.uDens.value = pl.density; su.uHaze.value.setRGB(...pl.sky).lerp(new THREE.Color(1, 0.95, 0.9), 0.2);
}
function clearChunks() {
  for (const lv of terrain.levels) { for (const m of lv.chunks.values()) { terrain.group.remove(m); m.geometry.dispose(); } lv.chunks.clear(); lv.cx = lv.cz = 1e9; }
}
// show the ground (true) or take it away (false)
export function showSurface(on) {
  ensure();
  terrain.active = on;
  if (on) { if (!terrain.group.parent) scene.add(terrain.group); if (!terrain.sky.parent) scene.add(terrain.sky); }
  else { if (terrain.group.parent) scene.remove(terrain.group); if (terrain.sky.parent) scene.remove(terrain.sky); }
}
export function showOrbit(pl, worldPos, radius, sunW) {
  ensure();
  const o = terrain.orbit;
  if (!pl) { if (o.parent) scene.remove(o); return; }
  if (!o.parent) scene.add(o);
  o.position.copy(worldPos); o.scale.setScalar(radius);
  const u = o.material.uniforms;
  u.uA.value.setRGB(...pl.tint[0]); u.uB.value.setRGB(...pl.tint[1]);
  // VARIETY: from orbit, a sea world shows its sea, an ice sheet is white, a lava world glows in its low ground
  if (pl.terrain === 'archipelago') u.uA.value.setRGB(...pl.seaCol);
  else if (pl.terrain === 'icesheet') { u.uA.value.setRGB(0.7, 0.78, 0.86); u.uB.value.setRGB(0.92, 0.95, 0.98); }
  else if (pl.terrain === 'lava') { u.uA.value.setRGB(0.9, 0.3, 0.05); u.uB.value.setRGB(0.12, 0.1, 0.1); }
  else if (pl.terrain === 'dunes') { u.uA.value.setRGB(0.78, 0.6, 0.38); } u.uSky.value.setRGB(...(pl.density ? pl.sky : [0, 0, 0]));
  u.uDens.value = pl.density; u.uSeed.value = (pl.seed % 1000) / 37; u.uCrat.value = pl.terrain === 'cratered' ? 1 : 0;
  u.uSun.value.copy(sunW);
}
export function orbitVisible() { return !!(terrain.orbit && terrain.orbit.parent); }

// per frame while on (or over) the surface. center: planet-surface metres (x, z) of the viewer.
export function update(center, camW, sun, day, lamp) {
  if (!terrain.active || !terrain.planet) return;
  terrain.group.position.set(-terrain.origin.x, 0, -terrain.origin.y);
  terrain.group.updateMatrixWorld(true);
  terrain.sky.position.copy(camW);
  // chunks: finest ring first, a time budget per frame
  const t0 = performance.now();
  let complete = true;
  LEVELS.forEach((L, li) => {
    const lv = terrain.levels[li];
    const cx = Math.floor(center.x / L.size), cz = Math.floor(center.y / L.size);
    const want = new Set();
    for (let j = cz - L.ring; j <= cz + L.ring; j++) for (let i = cx - L.ring; i <= cx + L.ring; i++) want.add(i + ',' + j);
    for (const [k, m] of lv.chunks) if (!want.has(k)) { terrain.group.remove(m); m.geometry.dispose(); lv.chunks.delete(k); }
    const miss = [...want].filter(k => !lv.chunks.has(k)).map(k => k.split(',').map(Number)).sort((a, b) => Math.hypot(a[0] - cx, a[1] - cz) - Math.hypot(b[0] - cx, b[1] - cz));
    for (const [i, j] of miss) {
      if (performance.now() - t0 > BUILD_BUDGET_MS && terrain.levels[0].chunks.size > 0) { complete = false; break; }
      const m = buildChunk(li, i, j); m.updateMatrix(); terrain.group.add(m); lv.chunks.set(i + ',' + j, m);
    }
    if (miss.length && lv.chunks.size < want.size) complete = false;
    lv.cx = cx; lv.cz = cz; lv.ready = lv.chunks.size === want.size;
  });
  // holes: each coarser ring sinks where the finer ring is fully built (shrunk by one of its own cells)
  for (let li = 1; li < LEVELS.length; li++) {
    const inner = terrain.levels[li - 1], L = LEVELS[li - 1], u = terrain.levels[li].mat.uniforms, cell = LEVELS[li].size / SEGS;
    if (inner.ready) {
      u.uHoleMin.value.set((inner.cx - L.ring) * L.size + cell * 1.01, (inner.cz - L.ring) * L.size + cell * 1.01);
      u.uHoleMax.value.set((inner.cx + L.ring + 1) * L.size - cell * 1.01, (inner.cz + L.ring + 1) * L.size - cell * 1.01);
    } else { u.uHoleMin.value.set(1, 1); u.uHoleMax.value.set(-1, -1); }
  }
  // props follow the finest cells
  const pcx = Math.floor(center.x / CELL), pcz = Math.floor(center.y / CELL);
  if (pcx !== terrain.props.cx || pcz !== terrain.props.cz) refreshProps(pcx, pcz);
  // light
  const pl = terrain.planet;
  const sunCol = new THREE.Color(1.0, 0.95, 0.86).multiplyScalar(0.7 * day);
  const amb = new THREE.Color(...(pl.density ? pl.sky : [0.05, 0.05, 0.06])).multiplyScalar(0.16 * day + 0.01).add(new THREE.Color(0.012, 0.012, 0.016));
  for (const lv of terrain.levels) {
    const u = lv.mat.uniforms; u.uSun.value.copy(sun); u.uSunCol.value.copy(sunCol); u.uAmb.value.copy(amb); u.uCam.value.copy(camW);
    u.uLamp.value = lamp ? lamp.k : 0; if (lamp) u.uLampDir.value.copy(lamp.dir);
    if (pl.density) u.uFog.value.setRGB(...pl.sky).multiplyScalar(0.03 + 0.5 * day);
  }
  const su = terrain.sky.material.uniforms; su.uSun.value.copy(sun); su.uDay.value = day; su.uTime.value = performance.now() / 1000;
  return complete;
}

// surface build: up to four point lights on the ground ([{ x, y, z (world), k }], or null for none)
export function setPointLights(list) {
  for (const lv of terrain.levels) {
    if (!lv.mat) continue;
    const a = lv.mat.uniforms.uPL.value;
    for (let i = 0; i < 4; i++) { const p = list && list[i]; if (p) a[i].set(p.x, p.y, p.z, p.k); else a[i].w = 0; }
  }
}
export function pointLightCount() { const lv = terrain.levels[0]; return lv.mat ? lv.mat.uniforms.uPL.value.filter(v => v.w > 0).length : 0; }
export function reset() { if (terrain.group) clearChunks(); showSurface(false); showOrbit(null); terrain.planet = null; }
export function removeNode(id) { terrain.taken.add(id); if (terrain.props) terrain.props.cx = 1e9; }
export function stats() {
  let tris = 0, n = 0;
  for (const lv of terrain.levels) for (const m of lv.chunks.values()) { tris += m.geometry.index.count / 3; n++; }
  return { chunks: n, tris, built: terrain.built, levels: terrain.levels.map(l => l.chunks.size), ready: terrain.levels.map(l => !!l.ready), nodes: terrain.nodes.length, active: terrain.active };
}
export { heightAt };
