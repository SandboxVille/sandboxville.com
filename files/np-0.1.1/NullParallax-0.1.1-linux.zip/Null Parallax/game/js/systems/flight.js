// Flight (P3): flying the whole of KESTREL-4 between real stars.
//
// You sit at the helm, turn the ship with the mouse or stick, and burn the
// drive with W/S. Everything you see is computed, not painted:
//   * the ship moves by special relativity (proper velocity u = gamma*beta,
//     c = 1 ly/yr); two clocks run, the ship's and Earth's, and they part
//   * the sky is the real catalogue re-seen from wherever the ship is, every
//     frame, with aberration (the stars crowd toward where you are going)
//     and a Doppler shift (ahead burns blue, behind goes red and out)
//   * fuel buys rapidity, and half of what you burn going out you must burn
//     again to stop. Burn too long and you cannot stop: you pass the star
//     and keep going, and nothing out there is in the way for a very long time
//   * the drive heats; past 100% it scrams. It is loud: the Listener hears it
// The one impossible thing is the drive itself (10.7 g, and the fuel lasts
// far longer than it should). The game says so, in the ship's own words.
import * as THREE from 'three';
import { STAR_FRAG } from '../render/sky.js';
import { S } from '../core/state.js';
import { FLIGHT as F, HELM_EYE, EYE_H, MOUSE_BASE, PAD_LOOK_RATE } from '../core/constants.js';
import { catalogue, starPos, starName, systemD, neighbours } from './catalogue.js';
import { scene, camera, ship, renderer } from '../render/scene.js';
import { field, derelict, boundary, DERELICT_POS, SHIP_CENTER } from '../render/world.js';
import { shipFx } from '../render/ship.js';
import { qFromYawPitch, clamp } from '../core/utils.js';
import { say, flash, prompt } from '../ui/hud.js';
import { emit, on } from '../core/events.js';
import { power } from './survival.js';
import { unlockFragment } from './journal.js';
import { held, lastInputDevice } from '../core/input.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);
const V = (a) => new THREE.Vector3(a[0], a[1], a[2]);
const YR_DAYS = 365.25;
const SEC_PER_YR = YR_DAYS * 86400;
const LY_M = 9.4607e15;

// ---------------- transient (not saved) ----------------
const T = {
  warp: 1,             // test hook: multiplies simulated real time
  auto: false,         // test hook: the nav flies itself
  align: false,        // align assist held this frame
  omega: new THREE.Vector3(),
  recedeV: 0, recedeS: 0, // departure cinematic, metres
  adriftT: 0, lastR: Infinity,
  unwatchedT: 0,
  contactT: 0, contactOn: false,
  latticeFlash: 0,
  phase: '', phaseText: '', lastGuide: null,
  beat: {}, hudT: 0,
};
let arriveHook = null;
export function setArriveHook(fn) { arriveHook = fn; }
export const isFlying = () => !!(S.P && S.P.flight);
export const inHelm = () => !!S.helm;
export function testWarp(k) { T.warp = Math.max(0.1, Math.min(200, k || 1)); }
export function testAuto(on) { T.auto = !!on; }

// ---------------- the flight sky: every catalogue star, re-seen each frame ----------------
const sky = { group: null, mat: null, points: null };
function buildSky() {
  if (sky.group) return;
  const C = catalogue();
  const n = C.rows.length;
  const aP = new Float32Array(n * 3), aM1 = new Float32Array(n), aCol = new Float32Array(n * 3), pos = new Float32Array(n * 3);
  const bvCol = bv => { const t = clamp((bv + 0.4) / 2.4, 0, 1); const blue = [0.62, 0.72, 1.0], white = [1.0, 0.97, 0.93], orange = [1.0, 0.76, 0.48], red = [1.0, 0.58, 0.38]; const mix = (a, b, k) => a.map((v, i) => v + (b[i] - v) * k); return t < 0.3 ? mix(blue, white, t / 0.3) : t < 0.6 ? mix(white, orange, (t - 0.3) / 0.3) : mix(orange, red, (t - 0.6) / 0.4); };
  C.rows.forEach((r, i) => {
    aP.set([r.x, r.y, r.z], i * 3); aM1[i] = r.m1; aCol.set(bvCol(r.bv), i * 3);
    pos.set([0, 0, -1], i * 3); // real position computed in the shader
  });
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('aP', new THREE.BufferAttribute(aP, 3));
  g.setAttribute('aM1', new THREE.BufferAttribute(aM1, 1));
  g.setAttribute('aColor', new THREE.BufferAttribute(aCol, 3));
  sky.mat = new THREE.ShaderMaterial({
    uniforms: { uObs: { value: new THREE.Vector3() }, uBeta: { value: new THREE.Vector3() }, uGamma: { value: 1 }, uPR: { value: renderer.getPixelRatio() }, uGain: { value: 0 }, uFade: { value: 1 }, uMagCut: { value: 6.9 } },
    vertexShader: `
      attribute vec3 aP; attribute float aM1; attribute vec3 aColor;
      uniform vec3 uObs, uBeta; uniform float uGamma, uPR, uGain, uFade, uMagCut;
      varying vec3 vCol; varying float vA; varying float vSize;
      void main() {
        vec3 rel = aP - uObs; float d = max(length(rel), 1e-4); vec3 n = rel / d;
        float mag = aM1 + 2.1714724 * log(d);            // 5 log10(d)
        float b = length(uBeta); float D = 1.0; vec3 np = n;
        if (b > 1e-6) {
          vec3 bh = uBeta / b; float c = dot(n, bh);
          // aberration: where the light appears to come from, seen from the moving ship
          np = normalize(n + ((uGamma - 1.0) * c + uGamma * b) * bh);
          D = uGamma * (1.0 + b * c);                   // Doppler factor: > 1 ahead, < 1 behind
        }
        // brightness: the full photon count goes as D^4; the eye's narrow band sees much less of it
        mag -= clamp(6.0 * log(D) * 0.4342945, -5.0, 3.5);
        if (D < 0.45) mag += (0.45 - D) * 30.0;           // shifted out of the visible band behind you
        vec3 col = aColor;
        col = mix(col, vec3(0.55, 0.68, 1.0), clamp((D - 1.0) / 2.5, 0.0, 0.85));
        col = mix(col, vec3(1.0, 0.22, 0.08), clamp((1.0 - D) / 0.55, 0.0, 0.9));
        float m = mag - uGain;
        float s = clamp(1.3 + 0.6 * (6.8 - m), 1.0, 22.0);
        vA = clamp(0.16 + 0.15 * (6.8 - m), 0.0, 1.0) * uFade;
        if (m > uMagCut + 1.2) vA = 0.0;
        vCol = col;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(np * 5000.0, 1.0);
        gl_PointSize = s * uPR; vSize = s * uPR;
      }`,
    fragmentShader: STAR_FRAG,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  sky.points = new THREE.Points(g, sky.mat); sky.points.frustumCulled = false;
  sky.group = new THREE.Group(); sky.group.add(sky.points); sky.group.visible = false;
  scene.add(sky.group);
}
export function skyGroup() { return sky.group; }
export function setSkyPixelRatio(pr) { if (sky.mat) sky.mat.uniforms.uPR.value = pr; }

// ---------------- state helpers ----------------
function gammaOf(u) { return Math.sqrt(1 + u.lengthSq()); }
function flightVec(k) { return V(S.P.flight[k]); }
function setVec(k, v) { S.P.flight[k] = [v.x, v.y, v.z]; }
export function shipFwdWorld(out = new THREE.Vector3()) { return out.set(0, 0, -1).applyQuaternion(ship.quaternion); }

// the position of the observer right now (ly), whether flying or parked in a system
export function hereD() {
  if (isFlying()) return flightVec('pos');
  if (S.P.place) return new THREE.Vector3(S.P.place.x, S.P.place.y, S.P.place.z);
  return systemD(S.P.system);
}

// where a course can go from here (campaign chapter 1 has two; the sandbox has the neighbourhood)
export function routesFor() {
  const P = S.P, from = hereD();
  if (P.mode === 'campaign' && P.system === 1) {
    const s2 = systemD(2), sol = new THREE.Vector3();
    return [
      { id: 'filed', label: 'THE COURSE ON FILE: SIRIUS', why: 'ENTERED BY: CREW 2', to: s2, hip: 32349, dest: { kind: 'system', n: 2 }, dist: from.distanceTo(s2) },
      { id: 'home', label: 'HOME: THE SUN', why: 'THE CONSOLE ACCEPTS THE COURSE', to: sol.clone().addScaledVector(from.clone().normalize(), 0.05), hip: 0, dest: { kind: 'system', n: 2 }, dist: from.length() },
    ];
  }
  return [];
}

// plan a flight (does not start the drive)
export function plan(route) {
  const P = S.P; const from = hereD();
  let to, hip, dest, id, label;
  if (route && route.to) { to = route.to; hip = route.hip; dest = route.dest; id = route.id; label = route.label; }
  else if (route && typeof route.hip === 'number') {
    const s = starPos(route.hip); if (!s) return false;
    to = s.clone().addScaledVector(s.clone().sub(from).normalize(), -0.08);
    hip = route.hip; dest = { kind: 'star', hip }; id = 'star'; label = starName(hip);
  } else return false;
  const tank = P.res.fuel;
  P.res.fuel = 0; // the tank is loaded into the drive for the trip
  P.flight = {
    v: 1, route: id, label, hip, dest,
    from: [from.x, from.y, from.z], to: [to.x, to.y, to.z],
    pos: [from.x, from.y, from.z], u: [0, 0, 0],
    q: [ship.quaternion.x, ship.quaternion.y, ship.quaternion.z, ship.quaternion.w],
    tau: 0, t: 0, tank, tank0: tank, heat: 0, throttle: 0, scram: 0,
    started: false, departed: false, coastW: 0, slipped: false, beats: {},
    earth0: P.stats.earthYears || 0,
    contact: P.mode === 'campaign' || !(P.stats.flights > 0) || Math.random() < 0.25, // the other ship does not keep pace every time
  };
  T.beat = {}; T.recedeV = 0; T.recedeS = 0; T.adriftT = 0; T.unwatchedT = 0; T.contactOn = false;
  return true;
}
export function selectRoute(i) {
  const fl = S.P.flight; if (!fl || fl.started) return false;
  const r = routesFor()[i]; if (!r) return false;
  fl.route = r.id; fl.label = r.label; fl.hip = r.hip; fl.dest = r.dest; setVec('to', r.to);
  audio.click(1500);
  flash(`COURSE: ${r.label}  //  ${r.dist.toFixed(2)} LY`, 2600);
  return true;
}
// hand what is left in the drive back to the hold (arrival, or a course cancelled before the burn)
function unloadTank() { const fl = S.P.flight; if (!fl) return; S.P.res.fuel += Math.max(0, Math.floor(fl.tank + 1e-6)); fl.tank = 0; }
export function cancelPlan() { const fl = S.P.flight; if (!fl || fl.started) return false; unloadTank(); S.P.flight = null; standUp(true); showSky(false); return true; }

// ---------------- the helm ----------------
export const HELM_POS = new THREE.Vector3(...HELM_EYE);
export function enterHelm() {
  S.mode = 'interior'; S.helm = true;
  const fl0 = S.P.flight;
  if (fl0 && !fl0.started && S.P.res.fuel > 0) { fl0.tank += S.P.res.fuel; fl0.tank0 = fl0.tank; S.P.res.fuel = 0; }
  S.pos.copy(HELM_POS); S.vel.set(0, 0, 0);
  S.yaw = 0; S.pitch = 0.03; S.roll = 0; qFromYawPitch(S.yaw, S.pitch, 0, S.q);
  S.buildMode = false; S.eva.lamp = false;
  T.omega.set(0, 0, 0);
  showSky(true);
  emit('helm');
}
export function standUp(silent) {
  if (!S.helm) return;
  S.helm = false; S.mode = 'interior';
  S.pos.set(-0.72, EYE_H, -7.3); S.yaw = 0; S.pitch = 0; qFromYawPitch(0, 0, 0, S.q);
  if (!silent && isFlying()) flash(`YOU STAND UP. THE DRIVE WINDS DOWN; THE SHIP COASTS ON ITS HEADING. ${lastInputDevice() === 'pad' ? 'X' : 'F'} AT THE CHAIR TO SIT AGAIN.`, 3400);
}

// the flight sky replaces the system sky while the ship is under way
function showSky(on) {
  buildSky();
  const flying = on && isFlying();
  sky.group.visible = flying;
  if (S.sys.group) S.sys.group.visible = !flying;
}

// called after a load: rebuild what a flight in progress looks like
export function resume() {
  if (!isFlying()) { showSky(false); return; }
  const fl = S.P.flight;
  ship.quaternion.set(fl.q[0], fl.q[1], fl.q[2], fl.q[3]).normalize();
  T.beat = {}; T.adriftT = 0; T.unwatchedT = 0; T.contactOn = false;
  if (fl.departed) hideLocal(); else { T.recedeS = 0; T.recedeV = 0; }
  enterHelm();
}
function hideLocal() {
  if (field.group) field.group.visible = false;
  if (derelict.group) derelict.group.visible = false;
  if (boundary.lattice) boundary.lattice.position.copy(SHIP_CENTER).add(new THREE.Vector3(0, 0, 1e6));
}
export function restoreLocal() {
  if (derelict.group) { derelict.group.visible = true; derelict.group.position.copy(DERELICT_POS); }
  if (field.group) { field.group.visible = true; field.group.position.set(0, 0, 0); }
  if (boundary.lattice) boundary.lattice.position.copy(SHIP_CENTER);
}

// ---------------- guidance: one vector says what the drive should do ----------------
// Desired velocity: straight at the destination, no faster than you can still
// stop from (by the nav's cautious plan) and no faster than the tank allows
// with enough left to stop. The error between that and now is where to point.
function guidance() {
  const fl = S.P.flight;
  const pos = flightVec('pos'), to = flightVec('to'), u = flightVec('u');
  const r = to.clone().sub(pos); const R = r.length(); const rh = R > 1e-9 ? r.clone().divideScalar(R) : new THREE.Vector3(0, 0, -1);
  const um = u.length(); const g = Math.sqrt(1 + um * um); const phi = Math.asinh(um); const beta = um / g;
  const phiTank = fl.tank * F.RAPIDITY_PER_FUEL;
  const aPlan = F.A_FULL * F.A_PLAN;
  const gReq = 1 + aPlan * Math.max(0, R - F.ARRIVE_R * 0.5);
  const uReq = Math.sqrt(Math.max(0, gReq * gReq - 1));
  const uCruise = Math.sinh(Math.max(0, (phi + phiTank) / 2));
  // 2026-09-28: going faster than the cruise plan but still able to slow for the final approach, the nav used to
  // ask for BRAKE at once. Braking lowers the ship's rapidity and the tank's by the same amount, so the gap to the
  // plan never closed: a player who obeyed braked the whole tank away, mid-trip, and drifted on at a crawl with
  // nothing left (bot-flown from David's save: 0.107 c, 3.9 ly out, tank 0). Now the extra speed is kept and the
  // brake is asked for at the brake point, where it is needed.
  const phiFinal = Math.asinh(F.FINAL_BETA / Math.sqrt(1 - F.FINAL_BETA * F.FINAL_BETA));
  const slowable = phiTank >= Math.max(0, phi - phiFinal);
  const uDes = Math.min(uReq, um > uCruise && slowable ? um : uCruise);
  const err = rh.clone().multiplyScalar(uDes).sub(u);
  // the same error, as the direction the ship must point in its own frame
  let aim = err.clone();
  if (um > 1e-6) { const bh = u.clone().divideScalar(um); const par = aim.dot(bh); aim.addScaledVector(bh, par / g - par); }
  if (aim.lengthSq() > 1e-12) aim.normalize(); else aim.copy(rh);
  // nothing to correct: keep the nose on the way you are going (the view ahead is the point),
  // or, once inside the brake point, keep it pointed back so the next burn is ready
  const brakingRegime = um > 0.05 && uReq < um * 1.02;
  if (err.length() < 0.05 * Math.max(1, um)) aim.copy(um > 0.05 ? u.clone().divideScalar(brakingRegime ? -um : um) : rh);
  const closing = u.dot(rh);
  const canStop = phiTank >= phi - 0.02;
  const canSlow = slowable;
  return { pos, to, u, r, R, rh, um, g, phi, beta, phiTank, phiFinal, uDes, err, errMag: err.length(), aim, closing, canStop, canSlow, brakingRegime };
}

// the apparent (aberrated) direction of a lab-frame direction n, seen from velocity beta
export function aberrate(n, u) {
  const um = u.length(); if (um < 1e-9) return n.clone();
  const g = Math.sqrt(1 + um * um), b = um / g, bh = u.clone().divideScalar(um), c = n.dot(bh);
  return n.clone().addScaledVector(bh, (g - 1) * c + g * b).normalize();
}

// ---------------- the per-frame update ----------------
const _q = new THREE.Quaternion(), _ax = new THREE.Vector3(), _f = new THREE.Vector3();
const AX_X = new THREE.Vector3(1, 0, 0), AX_Y = new THREE.Vector3(0, 1, 0), AX_Z = new THREE.Vector3(0, 0, 1);
function turnShip(axis, ang) { if (Math.abs(ang) < 1e-9) return; _q.setFromAxisAngle(axis, ang); ship.quaternion.multiply(_q).normalize(); }

// swing the nose toward a world direction at a capped rate; returns the angle still to go (rad)
function swingTo(dirW, rate, dt) {
  const local = dirW.clone().applyQuaternion(ship.quaternion.clone().invert());
  const fwd = new THREE.Vector3(0, 0, -1);
  const ang = fwd.angleTo(local);
  if (ang > 1e-4) {
    _ax.crossVectors(fwd, local);
    if (_ax.lengthSq() < 1e-10) _ax.set(0, 1, 0); else _ax.normalize();
    turnShip(_ax, Math.min(ang, rate * dt));
  }
  return Math.max(0, ang - rate * dt);
}

// 2026-09-28: pedals. David: "the gas and break for the ship are weird ... the ship controls need
// genuinly fixed when treveling". Before this, W / RT pushed a throttle lever that stayed where you
// left it (letting go of RT kept the drive burning), S / LT only pulled the lever back (nothing ever
// slowed the ship), and LT at the helm also zoomed the camera to 12 degrees. Now:
//   GAS   (W, SHIFT, RT): hold to burn along the nose, let go to coast. RT is analog.
//   BRAKE (S, C, LT):     hold to slow down. The ship turns its tail into the motion by itself and
//                         burns once it is within 20 degrees; it stops burning when the ship is stopped.
// Output follows the pedal with a short ramp (0 to 100% in 0.6 s, back to 0 in 0.25 s), so a tap
// is a small nudge and a hold is a full burn. A trigger's pull sets the level (curve PEDAL_EXP).
export const pedal = v => v <= F.PEDAL_DZ ? 0 : Math.pow(Math.min(1, (v - F.PEDAL_DZ) / (1 - F.PEDAL_DZ)), F.PEDAL_EXP);
function helmControls(dt, mouse, ax, gd) {
  const fl = S.P.flight; const st = S.settings; const inv = st.invertY ? -1 : 1;
  const keyF = (held('w') ? 1 : 0) - (held('s') ? 1 : 0), keyX = (held('d') ? 1 : 0) - (held('a') ? 1 : 0);
  const stickF = ax.moveF - keyF, stickX = ax.moveX - keyX;
  const gasIn = Math.max(held('w') || held('shift') ? 1 : 0, pedal(ax.padRT || 0));
  const brakeIn = Math.max(held('s') || held('c') ? 1 : 0, pedal(ax.padLT || 0));
  T.gasIn = gasIn; T.brakeIn = brakeIn;
  const moving = gd && gd.um > F.BRAKE_MIN_U;
  T.braking = !T.auto && brakeIn > 0 && !!gd;
  T.align = !T.braking && (held(' ') || held('gp_a') || T.auto);
  let target = gasIn;
  // turning: mouse is direct, keys/sticks are rates with a little inertia
  const zoomK = Math.min(1, S.fov / S.ZOOMS[0]);
  const yawRate = -(keyX + stickX + ax.kLookX * 0.7 + ax.padRX) * F.TURN_RATE;
  const pitchRate = (stickF * inv - ax.kLookY * inv - ax.padRY * inv) * F.TURN_RATE;
  const rollRate = -ax.roll * F.TURN_RATE * 1.2;
  const omegaT = new THREE.Vector3(pitchRate, yawRate, rollRate);
  if (T.braking) {
    // the brake: tail into the motion, then burn; nothing to do if the ship is already stopped
    if (moving) {
      // tail into the motion; in the nav's braking regime, onto its brake vector (retrograde plus the small
      // sideways fix that keeps the course on the star), so the brake also steers you in
      const retro = gd.u.clone().divideScalar(-gd.um);
      const dir = gd.brakingRegime && gd.aim.dot(retro) > Math.cos(0.6) ? gd.aim : retro;
      const left = swingTo(dir, F.TURN_RATE * 1.3, dt);
      T.brakeOff = left;
      const k = left <= F.BRAKE_FULL ? 1 : left >= F.BRAKE_CONE ? 0 : 1 - (left - F.BRAKE_FULL) / (F.BRAKE_CONE - F.BRAKE_FULL);
      target = brakeIn * k;
    } else {
      target = 0; T.brakeOff = 0;
      if (!T.stillSaid) { T.stillSaid = true; flash('THE SHIP IS NOT MOVING. NOTHING TO BRAKE.', 1800); }
    }
    T.omega.multiplyScalar(0.8);
  } else if (T.align && gd) {
    // align assist: swing the nose toward the guidance vector
    swingTo(gd.aim, F.TURN_RATE * 1.3, dt);
    T.omega.multiplyScalar(0.8);
  } else {
    T.omega.lerp(omegaT, Math.min(1, dt * 4));
    turnShip(AX_X, T.omega.x * dt * zoomK); turnShip(AX_Y, T.omega.y * dt * zoomK); turnShip(AX_Z, T.omega.z * dt);
  }
  if (!T.braking) T.stillSaid = false;
  if (fl && !T.auto) {
    if (fl.scram > 0) target = 0; // it will not relight until it cools
    fl.throttle = clamp(fl.throttle + clamp(target - fl.throttle, -F.GAS_DOWN * dt, F.GAS_UP * dt), 0, 1);
  }
  const k = MOUSE_BASE * st.sensitivity * F.MOUSE_K * zoomK;
  turnShip(AX_Y, -mouse.dx * k); turnShip(AX_X, -mouse.dy * k * inv);
  void PAD_LOOK_RATE;
}
// nobody at the helm: the pedals are released, so the drive winds down (the nav autopilot is a test hook)
function releasePedals(dt) {
  const fl = S.P.flight; T.braking = false; T.gasIn = 0; T.brakeIn = 0; T.align = !!T.auto;
  if (fl && !T.auto) fl.throttle = Math.max(0, fl.throttle - F.GAS_DOWN * dt);
}

export function update(dt, mouse, ax, fEdge) {
  const fl = S.P.flight;
  if (!fl) { if (S.helm) standUp(true); return; }
  showSky(true);
  const seated = !!S.helm;
  let gd = guidance();
  if (seated) {
    helmControls(dt, mouse, ax, gd);
    if (fEdge) { standUp(); }
  } else releasePedals(dt);
  if (S.helm) {
    // gentle shake while the drive burns
    const sh = fl.throttle * (fl.scram > 0 ? 0 : 1) * 0.0025 + (fl.heat > 80 ? 0.002 : 0);
    qFromYawPitch(S.yaw + (Math.random() - 0.5) * sh, S.pitch + (Math.random() - 0.5) * sh, 0, S.q);
    S.pos.copy(HELM_POS);
  }
  if (T.auto) autopilot(gd, dt);
  // simulate (the test warp only speeds up simulated time)
  let left = dt * T.warp;
  while (left > 1e-6) { const h = Math.min(left, 0.05); simStep(h); left -= h; if (!S.P.flight) return; }
  gd = guidance();
  T.lastGuide = gd;
  fl.q = [ship.quaternion.x, ship.quaternion.y, ship.quaternion.z, ship.quaternion.w];
  departure(dt * T.warp);
  beats(gd, dt);
  updateSkyUniforms();
  audio.setDrive(effThrottle(fl), fl.heat / 100);
}

function effThrottle(fl) {
  if (power.goDark || fl.scram > 0 || fl.tank <= 1e-6 || S.P.repair.thrusters < 10) return 0;
  return fl.throttle;
}

function coastWarp(gd) {
  const fl = S.P.flight;
  if (gd.um < 0.05) return F.W_BURN;
  if (!fl.coastW) {
    const aPlan = F.A_FULL * F.A_PLAN;
    const rBrake = (gd.g - 1) / aPlan + F.ARRIVE_R;
    const tToBrake = Math.max(0, gd.R - rBrake) / gd.um; // ship years
    fl.coastW = clamp(tToBrake / F.COAST_SECONDS, F.W_BURN, F.W_MAX);
  }
  return fl.coastW;
}

function simStep(h) {
  const fl = S.P.flight; const gd = guidance();
  const thr = effThrottle(fl);
  const final = gd.R < F.FINAL_R && gd.beta < F.FINAL_BETA && fl.started;
  // how much ship time this slice of real time is worth
  let W;
  const aimOff = shipFwdWorld(_f).angleTo(gd.aim);
  // (a brake burn with the tail already in the motion is not a turn, even when the nav's aim is a little off)
  const needTurn = !(T.braking && T.brakeOff <= F.BRAKE_CONE) && gd.errMag > 0.05 * Math.max(1, gd.um) && aimOff > 0.26;
  if (!fl.departed) W = 1 / SEC_PER_YR;                          // the first seconds happen at 1:1
  else if (final) W = 0.1;
  else if (needTurn) W = F.W_TURN;                                // the nav slows the clock while you turn the ship
  else if (thr > 0.001) { W = F.W_BURN; fl.coastW = 0; }
  else if (gd.um > 1e-6 && gd.closing > 0 && gd.errMag > 0.05 * Math.max(1, gd.um) && gd.u.dot(gd.err) < 0) W = atBrakePoint(gd) ? F.W_HOLD : F.W_BURN; // time to brake
  else W = coastWarp(gd);
  const dtau = h * W; T.lastW = W; T.lastErr = gd.errMag; T.lastUdes = gd.uDes;
  const u = gd.u.clone();
  const u0 = u.clone();
  if (thr > 0.001) {
    const n = shipFwdWorld(_f);
    const alpha = F.A_FULL * thr;
    const um = u.length(), g = Math.sqrt(1 + um * um);
    if (um > 1e-9) { const bh = u.clone().divideScalar(um); const par = n.dot(bh); u.addScaledVector(bh, alpha * dtau * (g * par - par)).addScaledVector(n, alpha * dtau); }
    else u.addScaledVector(n, alpha * dtau);
    const used = alpha * dtau / F.RAPIDITY_PER_FUEL;
    fl.tank = Math.max(0, fl.tank - used);
    if (!fl.started) { fl.started = true; emit('flightStart'); }
    S.noise += thr * F.DRIVE_NOISE * h;
    fl.heat += thr * F.HEAT_UP * h;
    // the brake stops the ship; it never turns a stop into going backwards
    if (T.braking && u0.lengthSq() > 0 && u.dot(u0) <= 0) { u.set(0, 0, 0); fl.throttle = 0; }
  }
  if (final) {
    // the nav computer takes the last of it: straight to the point, then stop
    const uMax = F.FINAL_BETA / Math.sqrt(1 - F.FINAL_BETA * F.FINAL_BETA);
    const want = gd.rh.clone().multiplyScalar(Math.min(uMax, 10 * gd.R));
    const d = want.sub(u); const max = F.A_FULL * dtau;
    if (d.length() > max) d.setLength(max);
    u.add(d);
    if (!T.beat.final) { T.beat.final = true; say('FINAL APPROACH. THE NAV COMPUTER HAS THE LAST OF THE BRAKING.', { hold: 12000 }); }
  }
  fl.heat = clamp(fl.heat - F.HEAT_DOWN * h, 0, 120);
  if (fl.scram > 0) { fl.scram -= h; if (fl.scram <= 0 && fl.heat > F.SCRAM_RESTART) fl.scram = 0.5; }
  if (fl.heat >= 100 && fl.scram <= 0) scram();
  const g2 = Math.sqrt(1 + u.lengthSq());
  const pos = gd.pos.addScaledVector(u, dtau);
  setVec('u', u); setVec('pos', pos);
  fl.tau += dtau; fl.t += g2 * dtau;
  // arrival
  const R2 = flightVec('to').distanceTo(pos), b2 = u.length() / g2;
  if (fl.started && R2 < 0.012 && b2 < 0.03) arrive();
}

// 2026-09-28 (David got stuck on the trip): past the brake point with the drive not burning, the clock used
// to keep running at 3 days a second, so anything that kept you off the drive there (the Listener passing,
// a scram, standing up, not knowing the brake) spent the distance you needed to stop, and the ship sailed
// past. Now the nav holds the clock at the brake point until you brake, as long as a stop is still possible.
function atBrakePoint(gd) {
  if (!S.P.flight.departed || !gd.canSlow) return false;
  const rBrake = (gd.g - 1) / (F.A_FULL * F.A_PLAN) + F.ARRIVE_R;
  return gd.R < rBrake * 1.25;
}

function scram() {
  const fl = S.P.flight;
  fl.scram = F.SCRAM_TIME; fl.throttle = 0;
  S.P.repair.thrusters = Math.max(20, S.P.repair.thrusters - 6);
  audio.alarm(); audio.powerDown();
  say('DRIVE SCRAM. OVERHEAT. THE THRUSTER TOOK DAMAGE. IT WILL NOT RELIGHT UNTIL IT COOLS.', { hold: 12000 });
  if (!S.P.flags.learn_heat) { S.P.flags.learn_heat = true; say('WATCH THE HEAT BAR. EASE OFF BEFORE IT FILLS, OR BURN IN PULSES.', { delay: 2600, hold: 12000 }); }
}

// the first few seconds are real time: the field falls away, the edge goes past
function departure(dt) {
  const fl = S.P.flight;
  if (fl.departed || !fl.started) return;
  const thr = effThrottle(fl);
  const a = F.A_FULL * thr * LY_M / (SEC_PER_YR * SEC_PER_YR); // m/s^2 (about 105 at full)
  T.recedeV += a * dt; T.recedeS += T.recedeV * dt;
  const uw = flightVec('u'); const dirL = (uw.lengthSq() > 1e-30 ? uw.clone().normalize() : shipFwdWorld(new THREE.Vector3())).applyQuaternion(ship.quaternion.clone().invert());
  const off = dirL.multiplyScalar(-T.recedeS);
  if (field.group) field.group.position.copy(off);
  if (derelict.group) derelict.group.position.copy(DERELICT_POS).add(off);
  if (boundary.lattice) boundary.lattice.position.copy(SHIP_CENTER).add(off);
  if (!T.beat.lit) { T.beat.lit = true; say('DRIVE LIT. 10.7 G.', { hold: 10000 }); say('THAT SHOULD CRUSH YOU INTO THE SEAT. YOU FEEL NOTHING AT ALL.', { delay: 2200, hold: 14000 }); }
  if (T.recedeS > 880 && !T.beat.edge) {
    T.beat.edge = true; T.latticeFlash = 1.4; audio.dip(900);
    say('RANGE 900 M. THE SHIP PASSED THROUGH SOMETHING. THE STARS BEHIND IT WERE STILL THERE.', { delay: 300, hold: 16000 });
    if (!S.P.flags.edge) unlockFragment(1, 'edge');
  }
  if (T.recedeS > 2500) {
    fl.departed = true; hideLocal();
    say('TIME COMPRESSION ENGAGED. ONE SECOND OF YOURS IS NOW DAYS OF THE SHIP\'S.', { delay: 400, hold: 14000 });
    emit('departed');
  }
}
// W0: the membrane at the edge flashes the lattice when you push through it
export function flashLattice(k = 1.4) { T.latticeFlash = Math.max(T.latticeFlash, k); }
export function latticeFlash(dt) { T.latticeFlash = Math.max(0, T.latticeFlash - dt); return Math.min(0.6, T.latticeFlash * 0.5); }

function arrive() {
  const fl = S.P.flight; if (!fl) return;
  const to = flightVec('to');
  const info = { dest: fl.dest, route: fl.route, slipped: fl.slipped, tau: fl.tau, t: fl.t, dist: V(fl.from).distanceTo(to), hip: fl.hip, pos: to };
  S.P.stats.earthYears = (S.P.stats.earthYears || 0) + fl.t;
  S.P.stats.shipYears = (S.P.stats.shipYears || 0) + fl.tau;
  S.P.stats.flightDays = (S.P.stats.flightDays || 0) + Math.round(fl.tau * YR_DAYS);
  S.P.stats.flights = (S.P.stats.flights || 0) + 1;
  unloadTank();
  S.P.flight = null;
  standUp(true);
  showSky(false);
  audio.setDrive(0, 0);
  if (arriveHook) arriveHook(info);
  emit('flightArrive', info);
}

// ---------------- what happens on the way ----------------
function beats(gd, dt) {
  const fl = S.P.flight; if (!fl) return;
  const P = S.P;
  const total = V(fl.from).distanceTo(flightVec('to'));
  const done = clamp(V(fl.from).distanceTo(gd.pos) / Math.max(1e-6, total), 0, 1);
  const B = fl.beats;
  const once = (k, fn) => { if (!B[k]) { B[k] = true; fn(); } };
  // the drive is too good
  if (gd.beta > 0.5) once('toogood', () => {
    say(`${Math.round(gd.beta * 100)}% OF THE SPEED OF LIGHT. THE FUEL GAUGE IS FALLING FAR TOO SLOWLY FOR WHAT THE SHIP IS DOING.`, { hold: 16000 });
    say('THE DRIVE IS DOING SOMETHING IT WAS NEVER BUILT TO DO. THE ENERGY IS COMING FROM SOMEWHERE.', { delay: 3400, hold: 18000 });
  });
  if (gd.beta > 0.9) once('starbow', () => {
    say('AT THIS SPEED THE SKY FOLDS FORWARD. THE STARS AHEAD CROWD TOGETHER AND BURN BLUE. BEHIND YOU THEY STRETCH RED AND GO OUT.', { hold: 18000 });
    say('NOTHING IS WRONG WITH THE WINDOW. THIS IS WHAT LIGHT DOES WHEN YOU CHASE IT.', { delay: 4200, hold: 16000 });
    unlockFragment(2, 'starbow');
  });
  // the clocks come apart
  const earthY = Math.floor(fl.t + 1e-9);
  [1, 3, 5, 8].forEach(y => { if (earthY >= y) once('earth' + y, () => {
    const days = Math.round(fl.tau * YR_DAYS);
    const year = Math.floor(2026 + (fl.earth0 || 0) + fl.t);
    if (y === 1) say(`EARTH: +1 YEAR. SHIP: +${days} DAYS. EVERYONE YOU KNOW IS A YEAR OLDER. YOU ARE ${days} DAYS OLDER.`, { hold: 16000 });
    else if (y === 3) say(`EARTH: +3 YEARS. IT IS ${year} AT HOME. YOU HAVE BEEN AWAY ${days} DAYS.`, { hold: 16000 });
    else if (y === 5) { const d = gd.pos.length(); say(`A SIGNAL SENT HOME NOW WOULD ARRIVE IN ${Math.round(year + d)}. ANY ANSWER WOULD REACH THIS POINT IN ${Math.round(year + 2 * d)}. THE SHIP WILL BE GONE.`, { hold: 18000 }); }
    else say(`EARTH: +${y} YEARS. SHIP: ${(fl.tau).toFixed(1)} YEARS. THE GAP ONLY GROWS.`, { hold: 14000 });
  }); });
  // the size of it
  if (done > 0.22 && fl.departed) once('sand', () => {
    const km = total * LY_M / 1.3914e9 / 1e6; // Sun diameters (NASA Sun fact sheet: mean radius 695,700 km), at 1 mm each, in km
    say(`IF THE SUN WERE A GRAIN OF SAND ONE MILLIMETRE ACROSS, THIS TRIP WOULD BE ${Math.round(km).toLocaleString('en-US')} KILOMETRES. BETWEEN THE GRAINS, NOTHING.`, { hold: 18000 });
  });
  if (done > 0.33 && fl.departed) once('voyager', () => {
    const yrs = total / F.VOYAGER_C;
    say(`VOYAGER 1, THE FASTEST THING PEOPLE HAVE EVER SENT OUT OF THE SOLAR SYSTEM, WOULD NEED ABOUT ${Math.round(yrs / 1000) * 1000 > 0 ? (Math.round(yrs / 1000) * 1000).toLocaleString('en-US') : Math.round(yrs)} YEARS FOR THIS TRIP.`, { hold: 18000 });
  });
  if (done > 0.45 && fl.departed) once('alone', () => {
    const nb = neighbours(gd.pos, 30)[0];
    say(`HALFWAY. THE NEAREST CATALOGUED STAR IS ${nb ? nb.d.toFixed(1) : '?'} LIGHT YEARS AWAY. THIS IS WHAT ALMOST ALL OF SPACE IS LIKE.`, { hold: 18000 });
    // the log fragment's numbers are checked for the course on file only (CNS5: nothing within 3.3 ly of its middle)
    if (fl.route === 'filed' || fl.slipped) unlockFragment(2, 'between');
  });
  // the other ship keeps pace
  if (done > 0.56 && fl.departed && gd.beta > 0.3 && fl.contact !== false) once('contact', () => startContact());
  updateContact(dt, gd);
  // the course home does not hold
  if (fl.route === 'home' && !fl.slipped) checkSlip(gd, dt);
  if (B.slipPending && !B.slipTold) { B.slipTold = true; tellSlip(gd); }
  // supplies: the ship carries about twelve years of ship time for one person
  if (fl.tau > F.SUPPLY_YEARS * 0.7) once('supplies', () => {
    audio.alarm();
    const left = F.SUPPLY_YEARS - fl.tau; const need = gd.um > 1e-3 ? gd.R / gd.um : Infinity;
    say(`SUPPLIES FOR ${left.toFixed(1)} MORE YEARS OF SHIP TIME. AT THIS SPEED THE REST OF THE TRIP TAKES ${isFinite(need) ? need.toFixed(0) : 'FOREVER'}.`, { hold: 18000 });
  });
  if (fl.tau > F.SUPPLY_YEARS && !B.outOfYears) { B.outOfYears = true; emit('outOfYears'); }
  // warnings
  if (fl.heat > 80 && !T.heatWarned && effThrottle(fl) > 0) { T.heatWarned = true; flash('DRIVE HEAT ' + Math.round(fl.heat) + '%. EASE OFF.', 2400); audio.blip(520, 0.05); }
  if (fl.heat < 60) T.heatWarned = false;
  // time to brake
  const needBrake = fl.departed && gd.closing > 0 && gd.um > 0.1 && gd.u.clone().normalize().dot(gd.err) < -0.3 * gd.errMag && gd.errMag > 0.05 * gd.um;
  if (needBrake && !T.brakeAlarm && !B.brakeSaid) {
    T.brakeAlarm = true; B.brakeSaid = true; audio.alarm();
    say(S.helm ? `BRAKE POINT. HOLD ${keysFor(lastInputDevice() === 'pad').brk} TO BRAKE: THE SHIP TURNS ITSELF AROUND AND BURNS.` : 'BRAKE POINT. GET BACK TO THE HELM. THE NAV HOLDS THE CLOCK UNTIL YOU BRAKE.', { hold: 14000 });
    once('flip', () => {});
  }
  if (!needBrake) T.brakeAlarm = false;
  // you cannot stop
  if (fl.departed && !gd.canSlow && gd.closing > 0) once('cantstop', () => {
    audio.alarm();
    say('NOT ENOUGH FUEL LEFT TO STOP. YOU WILL GO PAST IT.', { hold: 16000 });
  });
  // adrift: moving away with nothing left to turn around on
  const away = fl.started && fl.departed && gd.um > 0.05 && gd.closing <= 0 && gd.R > F.FINAL_R && gd.phiTank < gd.phi + 0.25;
  const empty = fl.started && fl.departed && fl.tank <= 1e-4 && !(gd.R < F.FINAL_R * 1.5) && gd.closing <= 0.02;
  if (away || empty) {
    T.adriftT += dt;
    if (!B.adrift) { B.adrift = true; audio.alarm(); say('ADRIFT. THE DRIVE CANNOT TURN YOU AROUND.', { hold: 14000 }); say(nextStarLine(gd), { delay: 3000, hold: 18000 }); }
    if (T.adriftT > F.DRIFT_GRACE) { T.adriftT = 0; emit('adrift'); }
  } else { T.adriftT = 0; }
}

function nextStarLine(gd) {
  const pos = gd.pos, dir = gd.u.clone().normalize(); const beta = gd.beta;
  let best = null;
  for (const r of catalogue().rows) {
    if (!r.near) continue;
    const rel = new THREE.Vector3(r.x, r.y, r.z).sub(pos); const along = rel.dot(dir); if (along <= 0.5) continue;
    const miss = Math.sqrt(Math.max(0, rel.lengthSq() - along * along));
    if (miss < 1.0 && (!best || along < best.along)) best = { r, along, miss };
  }
  if (!best) return 'NO STAR IN THE CATALOGUE LIES ON THIS HEADING.';
  const yrs = best.along / Math.max(beta, 1e-3);
  return `THE NEXT CATALOGUED STAR ON THIS HEADING IS ${starName(best.r.hip)}, ${best.along.toFixed(1)} LIGHT YEARS OUT. AT THIS SPEED YOU PASS IT IN ${Math.round(yrs)} YEARS, EARTH TIME, ${best.miss.toFixed(2)} LY OFF THE BOW, AND KEEP GOING.`;
}

// ---------------- the contact: KESTREL-4, 260 m, relative speed zero ----------------
function startContact() {
  if (!derelict.group) return;
  T.contactOn = true; T.contactT = 0;
  derelict.group.visible = true;
  derelict.group.position.set(-38, 10, -252);
  if (derelict.hullMat) derelict.hullMat.emissive.setHex(0x303a4c); // the blue crowd ahead lights its flank
  audio.dip(1200);
  say('PROXIMITY: CONTACT. 260 METRES. RELATIVE SPEED: ZERO.', { delay: 600, hold: 18000 });
  say(`TRANSPONDER: KESTREL-4. IT IS HOLDING ${Math.round((T.lastGuide ? T.lastGuide.beta : 0.9) * 1000) / 10}% OF THE SPEED OF LIGHT, BESIDE YOU, WITH NO DRIVE LIT.`, { delay: 3200, hold: 20000 });
  unlockFragment(2, 'pace');
}
function updateContact(dt, gd) {
  if (!T.contactOn) return;
  T.contactT += dt;
  const d = derelict.group;
  if (!d) return;
  const w = d.position.clone(); ship.localToWorld(w);
  const cw = camera.getWorldPosition(new THREE.Vector3());
  const watched = w.sub(cw).normalize().angleTo(S.fwd) < THREE.MathUtils.degToRad(40);
  // it is gone the moment nothing is looking at it (after it has been seen, or after a while)
  if ((!watched && T.contactT > 9) || T.contactT > 45) {
    T.contactOn = false; d.visible = false; d.position.copy(DERELICT_POS);
    if (derelict.hullMat) derelict.hullMat.emissive.setHex(0x060608);
    say('CONTACT LOST. NOT BEHIND YOU. NOT AHEAD. LOST.', { hold: 14000 });
    S.P.life.sanity = Math.max(5, S.P.life.sanity - 10);
  }
  void gd;
}

// ---------------- the course home does not hold ----------------
function checkSlip(gd, dt) {
  const fl = S.P.flight;
  if (!fl.departed || gd.beta < 0.5) return;
  // it happens while nothing is looking at the Sun: away from the helm, or looking elsewhere
  const sunApp = aberrate(gd.rh, gd.u);
  const watching = S.helm && S.fwd.angleTo(sunApp) < THREE.MathUtils.degToRad(55);
  T.unwatchedT = watching ? 0 : T.unwatchedT + dt;
  if (T.unwatchedT > 2.5) doSlip(gd);
}
function doSlip(gd) {
  const fl = S.P.flight;
  const from = V(fl.from), oldTo = V(fl.to), s2 = systemD(2);
  const f = clamp(from.distanceTo(gd.pos) / Math.max(1e-6, from.distanceTo(oldTo)), 0, 0.9);
  const newPos = from.clone().lerp(s2, f);
  const oldDir = gd.um > 1e-9 ? gd.u.clone().normalize() : oldTo.clone().sub(from).normalize();
  const newDir = s2.clone().sub(newPos).normalize();
  const rot = new THREE.Quaternion().setFromUnitVectors(oldDir, newDir);
  const u = gd.u.clone().applyQuaternion(rot);
  ship.quaternion.premultiply(rot).normalize();
  setVec('pos', newPos); setVec('u', u); setVec('to', s2);
  fl.slipped = true; fl.hip = 32349; fl.dest = { kind: 'system', n: 2 }; fl.coastW = 0;
  fl.beats.slipPending = true;
  fl.slipSolWas = gd.pos.length(); // how far the Sun was a moment ago
}
function tellSlip(gd) {
  const fl = S.P.flight;
  audio.dip(1600);
  const solNow = gd.pos.length();
  say('NAV: COURSE SOL. HEADING HELD THE WHOLE TIME.', { delay: 800, hold: 20000 });
  say(`DISTANCE TO SOL: ${solNow.toFixed(2)} LY, AND RISING. A MOMENT AGO IT WAS ${(fl.slipSolWas || 0).toFixed(2)}.`, { delay: 3600, hold: 22000 });
  say('THE STAR IN THE BRACKET IS BLUE-WHITE. THE SUN IS YELLOW.', { delay: 7200, hold: 22000 });
  say('THE COURSE ON FILE WAS NEVER CLEARED. IT IS THE ONLY COURSE THIS SHIP WILL HOLD.', { delay: 10800, hold: 24000 });
  setTimeout(() => { S.P.life.sanity = Math.max(5, S.P.life.sanity - 15); unlockFragment(2, 'slip'); }, 10800);
  fl.label = 'SIRIUS (THE COURSE ON FILE)';
}

// ---------------- the autopilot (tests, and nothing else) ----------------
function autopilot(gd, dt) {
  const fl = S.P.flight; if (!fl) return;
  const fwd = shipFwdWorld(new THREE.Vector3());
  const aligned = fwd.angleTo(gd.aim) < 0.08;
  const want = gd.errMag > 0.03 * Math.max(1, gd.um) && aligned && !(gd.R < F.FINAL_R && gd.beta < F.FINAL_BETA);
  const target = want ? (fl.heat > 85 ? 0 : fl.heat > 70 ? 0.55 : 1) : 0;
  fl.throttle += clamp(target - fl.throttle, -F.THROTTLE_RATE * 2 * dt, F.THROTTLE_RATE * dt);
}

// ---------------- sky uniforms ----------------
function updateSkyUniforms() {
  if (!sky.mat || !isFlying()) return;
  const fl = S.P.flight; const u = flightVec('u'); const g = gammaOf(u);
  sky.mat.uniforms.uObs.value.set(fl.pos[0], fl.pos[1], fl.pos[2]);
  sky.mat.uniforms.uBeta.value.copy(u).divideScalar(g);
  sky.mat.uniforms.uGamma.value = g;
  sky.mat.uniforms.uGain.value = Math.log2(S.ZOOMS[0] / S.fov) * 0.9;
}
export function placeSkyAt(camW) { if (sky.group && sky.group.visible) sky.group.position.copy(camW); }

// ---------------- sleeping through a coast ----------------
export function coastSleepOK() {
  const fl = S.P.flight; if (!fl || !fl.departed) return false;
  const gd = guidance();
  return effThrottle(fl) <= 0 && gd.um > 0.3 && gd.errMag < 0.08 * Math.max(1, gd.um) && gd.closing > 0;
}
S.canCoastSleep = coastSleepOK;
on('slept', () => {
  const fl = S.P.flight; if (!fl || !fl.departed) return;
  const gd = guidance();
  const aPlan = F.A_FULL * F.A_PLAN;
  const rBrake = (gd.g - 1) / aPlan + F.ARRIVE_R * 2;
  const along = Math.max(0, gd.R - rBrake) * 0.97;
  if (along <= 0 || gd.um < 0.1) return;
  const dtau = along / gd.um;
  const pos = gd.pos.addScaledVector(gd.u, dtau);
  setVec('pos', pos); fl.tau += dtau; fl.t += gd.g * dtau; fl.coastW = 0;
  const days = Math.round(dtau * YR_DAYS);
  fl.sleptDays = (fl.sleptDays || 0) + days;
  say(`YOU SLEPT THROUGH THE COAST. SHIP: +${days} DAYS. EARTH: +${(gd.g * dtau).toFixed(1)} YEARS. THE ALARM WOKE YOU AT THE BRAKE POINT.`, { delay: 1600, hold: 18000 });
});

// ---------------- what the objective line says ----------------
export function objective() {
  const fl = S.P.flight; if (!fl) return null;
  const gd = T.lastGuide || guidance();
  const pad = lastInputDevice() === 'pad';
  const seated = !!S.helm;
  const nm = fl.label || 'THE DESTINATION';
  if (!seated) return { text: fl.started ? `THE SHIP IS UNDER WAY. GET BACK TO THE HELM (THE LEFT CHAIR AT THE CONSOLE, ${pad ? 'X' : 'F'}).` : `SIT AT THE HELM: THE LEFT CHAIR AT THE CONSOLE. PRESS ${pad ? 'X' : 'F'}.`, sub: fl.started ? `${nm}  //  ${gd.R.toFixed(2)} LY` : '', target: HELM_POS.clone().setY(1.0), label: 'HELM' };
  const routes = routesFor();
  if (!fl.started) {
    const K = keysFor(pad);
    const choose = routes.length > 1 ? `   ${pad ? 'D-PAD' : '1 / 2'}: CHOOSE A COURSE` : '';
    return { text: `COURSE: ${nm}, ${gd.R.toFixed(2)} LIGHT YEARS. HOLD ${K.al} TO ALIGN, THEN HOLD ${K.gas} TO BURN.`, sub: `${pad ? 'STICKS' : 'MOUSE / A D / ARROWS'}: TURN THE SHIP   ${K.gas}: GAS   ${K.brk}: BRAKE   ${pad ? 'X' : 'F'}: STAND UP${choose}`, target: null };
  }
  const ph = phaseOf(gd);
  return { text: ph.text, sub: ph.sub, target: null };
}
// the key names for the device in hand (pad: the triggers are the pedals, BACK goes dark)
function keysFor(pad) { return pad ? { al: 'A', gas: 'RT', brk: 'LT', dark: 'BACK' } : { al: 'SPACE', gas: 'W', brk: 'S', dark: 'X' }; }
export function darkKey() { return keysFor(lastInputDevice() === 'pad').dark; }
function phaseOf(gd) {
  const fl = S.P.flight; const pad = lastInputDevice() === 'pad';
  const fwd = shipFwdWorld(new THREE.Vector3()); const off = THREE.MathUtils.radToDeg(fwd.angleTo(gd.aim));
  const thr = effThrottle(fl);
  const K = keysFor(pad); const al = K.al, gas = K.gas, brk = K.brk;
  const ls = S.threat && S.threat.listenerState;
  if (fl.scram > 0) return { key: 'SCRAM', text: 'DRIVE SCRAMMED. WAIT FOR IT TO COOL.', sub: `HEAT ${Math.round(fl.heat)}%` };
  // 2026-09-28: the Listener at the helm. Its line used to say "(X)", which on a pad stands you up.
  if (ls === 'coming' || ls === 'passing') {
    if (!power.goDark) return { key: 'QUIET', text: ls === 'coming' ? `IT IS COMING. LET GO OF THE DRIVE AND GO DARK (${K.dark}).` : `IT IS PASSING. GO DARK (${K.dark}). DO NOT BURN.`, sub: 'THE NAV HOLDS THE CLOCK AT THE BRAKE POINT. NOTHING IS LOST BY WAITING' };
    return { key: 'QUIET', text: ls === 'coming' ? 'DARK. IT IS COMING. STAY STILL.' : 'DARK. IT IS PASSING. STAY STILL.', sub: `WHEN IT HAS PASSED: ${K.dark} BRINGS THE POWER BACK` };
  }
  if (power.goDark) return { key: 'DARK', text: `THE SHIP IS DARK. THE DRIVE WILL NOT LIGHT. ${K.dark}: POWER BACK ON.`, sub: `${gd.R.toFixed(2)} LY TO GO` };
  if (gd.R < F.FINAL_R && gd.beta < F.FINAL_BETA) return { key: 'ARRIVING', text: 'FINAL APPROACH. THE NAV COMPUTER IS BRINGING YOU IN.', sub: `${(gd.R).toFixed(3)} LY` };
  if (T.adriftT > 0) return { key: 'ADRIFT', text: 'ADRIFT.', sub: 'THE DRIVE CANNOT TURN YOU AROUND' };
  if (!gd.canSlow && gd.closing > 0) return { key: 'NOSTOP', text: 'NOT ENOUGH FUEL TO STOP. BURN WHAT IS LEFT AGAINST THE MOTION.', sub: `HOLD ${brk}: THE SHIP TURNS AND BRAKES` };
  const coast = gd.errMag < 0.05 * Math.max(1, gd.um) && !gd.brakingRegime;
  if (coast) return { key: 'COAST', text: thr > 0 ? (T.braking ? `ON COURSE. LET GO OF ${brk}.` : `STOP BURNING. CRUISE SPEED REACHED. LET GO OF ${gas}.`) : 'COAST. STOP BURNING; SAVE FUEL FOR BRAKING.', sub: `${gd.R.toFixed(2)} LY TO GO  //  THE BUNK SLEEPS THROUGH IT` };
  // no fuel and too slow: say so, rather than asking for a burn the drive cannot make
  if (fl.tank <= 1e-4 && gd.um > 1e-4 && gd.R / gd.um > F.SUPPLY_YEARS - fl.tau) return { key: 'SLOW', text: 'THE DRIVE IS EMPTY AND THE SHIP IS TOO SLOW. THE SUPPLIES WILL RUN OUT FIRST.', sub: `${(gd.R / gd.um).toFixed(0)} YEARS TO GO  //  ${Math.max(0, F.SUPPLY_YEARS - fl.tau).toFixed(1)} YEARS OF SUPPLIES` };
  const braking = gd.um > 0.05 && gd.u.dot(gd.err) < 0;
  const hold = braking && atBrakePoint(gd) && thr <= 0.001 ? '  //  THE NAV HOLDS THE CLOCK UNTIL YOU BRAKE' : '';
  if (T.braking && braking) return { key: 'BRAKE', text: `BRAKING. KEEP HOLDING ${brk}. WATCH THE HEAT.`, sub: T.brakeOff > F.BRAKE_CONE ? `TURNING TAIL FIRST: ${Math.round(THREE.MathUtils.radToDeg(T.brakeOff))} DEG TO GO` : `DRIVE ${Math.round(fl.throttle * 100)}%  //  HEAT ${Math.round(fl.heat)}%` };
  if (off > 12) return { key: braking ? 'FLIP' : 'ALIGN', text: braking ? `FLIP: HOLD ${brk} TO BRAKE. THE SHIP TURNS ITSELF AROUND.` : `ALIGN: HOLD ${al} TO POINT AT THE MARKER.`, sub: `OFF BY ${Math.round(off)} DEG${hold}` };
  return { key: braking ? 'BRAKE' : 'BURN', text: braking ? `BRAKE: HOLD ${brk} (OR ${gas}) TO SLOW DOWN. WATCH THE HEAT.` : `BURN: HOLD ${gas}. WATCH THE HEAT. HALF OF WHAT YOU BURN NOW YOU NEED TO STOP.`, sub: `DRIVE ${Math.round(fl.throttle * 100)}%  //  HEAT ${Math.round(fl.heat)}%${hold}` };
}

// ---------------- the helm HUD ----------------
const _p = new THREE.Vector3(), _cw = new THREE.Vector3();
function place(el, worldDir, label, onlyOnScreen) {
  camera.getWorldPosition(_cw);
  _p.copy(worldDir).multiplyScalar(4000).add(_cw);
  const fwd = S.fwd;
  const behind = worldDir.dot(fwd) < 0;
  _p.project(camera);
  let x = (_p.x + 1) / 2 * innerWidth, y = (1 - _p.y) / 2 * innerHeight;
  const m = 34; let edge = false;
  if (behind) { x = innerWidth - x; y = innerHeight - y; edge = true; }
  if (x < m || x > innerWidth - m || y < m || y > innerHeight - m) edge = true;
  if (edge && onlyOnScreen) { el.style.display = 'none'; return; }
  if (edge) {
    // pin to the screen edge, pointing the way to turn
    const cx = innerWidth / 2, cy = innerHeight / 2; let dx = x - cx, dy = y - cy; const k = Math.min((cx - m) / Math.max(1e-3, Math.abs(dx)), (cy - m) / Math.max(1e-3, Math.abs(dy)));
    x = cx + dx * k; y = cy + dy * k;
  }
  el.style.display = 'block';
  el.style.transform = `translate(${x.toFixed(0)}px, ${y.toFixed(0)}px)`;
  el.classList.toggle('edge', edge);
  if (label !== undefined) { const s = el.querySelector('span'); if (s && s._t !== label) { s.textContent = label; s._t = label; } }
}
const fmtDays = y => { const d = y * YR_DAYS; return d < 400 ? `${Math.round(d)} DAYS` : `${y.toFixed(2)} YR`; };
function setHTML(el, h) { if (el && el._h !== h) { el.innerHTML = h; el._h = h; } }
const gbar = (v, cls = '') => `<span class="gbar ${cls}"><i style="width:${clamp(v, 0, 100).toFixed(0)}%"></i></span>`;
export function updateHelmHud(dt) {
  const el = $('helm'); if (!el) return;
  const fl = S.P.flight;
  const show = !!fl && !!S.helm && !S.paused;
  document.body.classList.toggle('helmOn', show);
  if (!show) { el.style.display = 'none'; return; }
  el.style.display = 'block';
  const gd = T.lastGuide || guidance();
  // markers: the destination (as you see it now), prograde, retrograde, and where to point
  const tgtApp = aberrate(gd.rh, gd.u);
  place($('hTarget'), tgtApp, `${fl.label || ''}  ${gd.R < 10 ? gd.R.toFixed(2) : gd.R.toFixed(1)} LY`);
  if (gd.um > 0.01) { place($('hPro'), gd.u.clone().normalize(), undefined, true); place($('hRetro'), gd.u.clone().normalize().negate(), undefined, true); }
  else { $('hPro').style.display = 'none'; $('hRetro').style.display = 'none'; }
  place($('hAim'), gd.aim);
  T.hudT -= dt; if (T.hudT > 0) return; T.hudT = 0.12;
  const thr = effThrottle(fl);
  const year = 2026 + (fl.earth0 || 0) + fl.t;
  const ph = phaseOf(gd);
  setHTML($('hPhase'), `${ph.key}`);
  $('hPhase').className = 'ph' + ph.key;
  // the drive gauge (centre, bottom): what the pedals are doing right now, and how fast the ship is going
  const mode = fl.scram > 0 ? 'SCRAM' : power.goDark ? 'DARK' : T.braking ? 'BRAKE' : thr > 0.001 ? 'GAS' : 'COAST';
  const K = keysFor(lastInputDevice() === 'pad');
  const spd = gd.beta < 0.001 && gd.um > 0 ? (gd.beta * 299792.458).toFixed(1) + ' KM/S' : (gd.beta * 100).toFixed(gd.beta > 0.99 ? 2 : 1) + '% C';
  setHTML($('hDrive'), `<div class="dm dm${mode}">${mode}</div><div class="dbar"><i style="width:${(fl.throttle * 100).toFixed(0)}%"></i></div><div class="dv">${Math.round(fl.throttle * 100)}%</div><div class="ds"><b>SPEED</b> ${spd}</div><div class="dk">${K.gas} GAS   ${K.brk} BRAKE   ${K.al} ALIGN</div>`);
  setHTML($('hPanelL'), `
    <div><b>THROTTLE</b> ${gbar(fl.throttle * 100)} ${Math.round(fl.throttle * 100)}%${thr === 0 && fl.throttle > 0 ? ' <em class="warn">OFF</em>' : ''}</div>
    <div><b>HEAT</b> ${gbar(fl.heat, fl.heat > 80 ? 'hot' : '')} ${Math.round(fl.heat)}%${fl.scram > 0 ? ' <em class="warn">SCRAM</em>' : ''}</div>
    <div><b>DRIVE FUEL</b> ${gbar(fl.tank0 > 0 ? fl.tank / fl.tank0 * 100 : 0)} ${fl.tank.toFixed(2)}</div>
    <div><b>TO STOP</b> ${(Math.max(0, gd.phi - gd.phiFinal) / F.RAPIDITY_PER_FUEL).toFixed(2)} OF ${fl.tank.toFixed(2)}: ${gd.canSlow ? '<span class="ok">ENOUGH</span>' : '<em class="warn">NOT ENOUGH</em>'}</div>
    <div class="big"><b>SPEED</b> ${gd.beta < 0.001 && gd.um > 0 ? (gd.beta * 299792.458).toFixed(1) + ' KM/S' : (gd.beta * 100).toFixed(gd.beta > 0.99 ? 2 : 1) + '% C'}</div>
    <div><b>GAMMA</b> ${gd.g.toFixed(gd.g < 10 ? 3 : 1)} <span class="dim">(SHIP TIME RUNS ${gd.g.toFixed(1)}X SLOW)</span></div>`);
  const W = thr > 0.001 || !fl.departed ? (fl.departed ? F.W_BURN : 1 / SEC_PER_YR) : (fl.coastW || F.W_BURN);
  const comp = W * SEC_PER_YR;
  setHTML($('hPanelR'), `
    <div><b>SHIP CLOCK</b> +${fmtDays(fl.tau)}</div>
    <div><b>EARTH</b> +${fl.t.toFixed(fl.t < 10 ? 2 : 1)} YR  <span class="dim">(YEAR ${Math.floor(year)})</span></div>
    <div><b>TO GO</b> ${gd.R.toFixed(gd.R < 1 ? 3 : 2)} LY</div>
    <div><b>SUN</b> ${gd.pos.length().toFixed(2)} LY  <span class="dim">A SIGNAL HOME: ${gd.pos.length().toFixed(1)} YR</span></div>
    <div><b>SUPPLIES</b> <span class="${F.SUPPLY_YEARS - fl.tau < 3 ? 'warn' : ''}">${Math.max(0, F.SUPPLY_YEARS - fl.tau).toFixed(1)} YR LEFT</span></div>
    <div class="dim">TIME x${comp < 10 ? comp.toFixed(1) : Math.round(comp).toLocaleString('en-US')}</div>`);
  const routes = routesFor();
  if (!fl.started) {
    setHTML($('hRoute'), routes.map((r, i) => `<div class="${fl.route === r.id ? 'sel' : ''}">${i + 1}  ${r.label}  //  ${r.dist.toFixed(2)} LY  <span class="dim">${r.why}</span></div>`).join('') + planLine(fl));
  } else setHTML($('hRoute'), '');
}
function planLine(fl) {
  // the honest numbers for the course as plotted, if flown at the nav's plan
  const from = V(fl.from), to = V(fl.to); const Dly = from.distanceTo(to);
  const phiMax = fl.tank * F.RAPIDITY_PER_FUEL / 2;
  if (phiMax <= 0) return '<div class="fuelplan"><em class="warn">NO FUEL: THE DRIVE CANNOT MOVE THE SHIP.</em></div>';
  const A = F.A_FULL; const g = Math.cosh(phiMax), u = Math.sinh(phiMax);
  const accel = (g - 1) / A;
  let tau, t, beta = u / g;
  if (2 * accel >= Dly) { const gm = 1 + A * Dly / 2; const ph = Math.acosh(gm); tau = 2 * ph / A; t = 2 * Math.sinh(ph) / A; beta = Math.tanh(ph); }
  else { const coast = Dly - 2 * accel; tau = 2 * phiMax / A + coast / u; t = 2 * Math.sinh(phiMax) / A + coast / beta; }
  // 2026-09-28 (David: show the trip's fuel before you leave). Out: the burn to top speed. Stop: the brake
  // back down to 60% c, where the nav computer takes over for free (the same sum as TO STOP in flight).
  const ph = Math.atanh(beta), phiFinal = Math.atanh(F.FINAL_BETA);
  const out = ph / F.RAPIDITY_PER_FUEL, stop = Math.max(0, ph - phiFinal) / F.RAPIDITY_PER_FUEL;
  const enough = out + stop <= fl.tank + 1e-6;
  return `<div class="fuelplan">TRIP FUEL: ${out.toFixed(2)} TO SPEED UP + ${stop.toFixed(2)} TO STOP = ${(out + stop).toFixed(2)} OF ${fl.tank.toFixed(2)} LOADED: ${enough ? '<b class="ok">ENOUGH</b>' : '<em class="warn">NOT ENOUGH</em>'}</div>`
    + `<div class="dim">LET GO OF THE GAS WHEN THE HELM SAYS STOP BURNING; EXTRA BURNS AND TURNS COST MORE. ${tau > F.SUPPLY_YEARS ? 'WARNING: SUPPLIES RUN OUT BEFORE ARRIVAL. ' : ''}AT FULL BURN: TOP SPEED ${(beta * 100).toFixed(1)}% C. SHIP TIME ${fmtDays(tau)}. EARTH TIME ${t.toFixed(1)} YEARS.</div>`;
}
export function tripEstimate(fromV, toV, fuel) {
  const Dly = fromV.distanceTo(toV); const phiMax = fuel * F.RAPIDITY_PER_FUEL / 2; const A = F.A_FULL;
  if (phiMax <= 0) return null;
  const g = Math.cosh(phiMax), u = Math.sinh(phiMax); const accel = (g - 1) / A;
  let tau, t, beta = u / g;
  if (2 * accel >= Dly) { const gm = 1 + A * Dly / 2; const ph = Math.acosh(gm); tau = 2 * ph / A; t = 2 * Math.sinh(ph) / A; beta = Math.tanh(ph); }
  else { const coast = Dly - 2 * accel; tau = 2 * phiMax / A + coast / u; t = 2 * Math.sinh(phiMax) / A + coast / beta; }
  return { dist: Dly, beta, tau, t };
}

// ---------------- the console screen, while under way ----------------
export function consoleLines() {
  const fl = S.P.flight; if (!fl) return null;
  const gd = T.lastGuide || guidance();
  return [
    `IN TRANSIT  //  ${fl.label || ''}`.slice(0, 40),
    `SPEED  ${(gd.beta * 100).toFixed(2)}% C   GAMMA ${gd.g.toFixed(2)}`,
    `TO GO  ${gd.R.toFixed(2)} LY`,
    `SHIP   +${fmtDays(fl.tau)}`,
    `EARTH  +${fl.t.toFixed(2)} YR`,
    `HEAT   ${Math.round(fl.heat)}%   FUEL ${fl.tank.toFixed(2)}`,
  ];
}

// test surface
export function debugState() {
  const fl = S.P.flight; if (!fl) return null;
  const gd = guidance();
  return { route: fl.route, label: fl.label, started: fl.started, departed: fl.departed, slipped: fl.slipped, R: gd.R, beta: gd.beta, gamma: gd.g, phi: gd.phi, tank: fl.tank, heat: fl.heat, throttle: fl.throttle, scram: fl.scram, tau: fl.tau, t: fl.t, canStop: gd.canStop, aimOff: THREE.MathUtils.radToDeg(shipFwdWorld(new THREE.Vector3()).angleTo(gd.aim)), phase: phaseOf(gd).key, pos: fl.pos.slice(), to: fl.to.slice(), sunDist: gd.pos.length(), beats: Object.keys(fl.beats), adriftT: T.adriftT, contact: T.contactOn, W: T.lastW, err: T.lastErr, uDes: T.lastUdes, um: gd.um, closing: gd.closing };
}
void renderer; void shipFx; void prompt;
