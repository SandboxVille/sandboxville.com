// Lived-in detail for KESTREL-4, all built from code: ceiling light fixtures
// (the lamps now have bodies), cable runs, conduits, grab bars, the small
// things two people leave lying around, floor path lights, and on the outside
// hull bands, handrails, equipment boxes, RCS blocks and running lights.
//
// Everything here is static: ship.js folds it into one draw call per material
// after the light bake (render/bake.js), so the detail costs almost no draw
// calls. Placement is fixed or seeded (mulberry32), never Math.random.
import * as THREE from 'three';
import { mulberry32 } from '../core/utils.js';
import { segBox } from './bake.js';
import { makeScreen, glowSprite } from './textures.js';

let P = null;
function pmats() {
  if (P) return P;
  P = {
    rubber: new THREE.MeshStandardMaterial({ color: 0x141416, roughness: 0.85, metalness: 0.0 }),
    cableA: new THREE.MeshStandardMaterial({ color: 0x2a2320, roughness: 0.8 }),
    cableB: new THREE.MeshStandardMaterial({ color: 0x1b2430, roughness: 0.8 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x5c4a22, roughness: 0.6, metalness: 0.45 }),
    reel: new THREE.MeshStandardMaterial({ color: 0x6a5a2a, roughness: 0.7, metalness: 0.3 }),
    red: new THREE.MeshStandardMaterial({ color: 0x80160f, roughness: 0.4, metalness: 0.2 }),
    orange: new THREE.MeshStandardMaterial({ color: 0x9a4a16, roughness: 0.55, metalness: 0.3 }),
    ceramic: new THREE.MeshStandardMaterial({ color: 0x8c877c, roughness: 0.35 }),
    bookA: new THREE.MeshStandardMaterial({ color: 0x4a2222, roughness: 0.9 }),
    bookB: new THREE.MeshStandardMaterial({ color: 0x2a3440, roughness: 0.9 }),
    paper: new THREE.MeshStandardMaterial({ color: 0x8e8878, roughness: 0.95 }),
    hullDark: new THREE.MeshStandardMaterial({ color: 0x2e3036, roughness: 0.65, metalness: 0.55 }),
    hullBox: new THREE.MeshStandardMaterial({ color: 0x5d5f66, roughness: 0.6, metalness: 0.45 }),
    foil: new THREE.MeshStandardMaterial({ color: 0x7a6230, roughness: 0.35, metalness: 0.85 }),
    // small practical lights (MeshBasic: they are the light, not lit by it)
    ledG: new THREE.MeshBasicMaterial({ color: 0x40ff80, toneMapped: false }),
    ledA: new THREE.MeshBasicMaterial({ color: 0xffb040, toneMapped: false }),
    path: new THREE.MeshBasicMaterial({ color: 0x9a8a70 }),
    lensWarm: new THREE.MeshBasicMaterial({ color: 0xffd9a0, toneMapped: false }),
    lensOff: new THREE.MeshBasicMaterial({ color: 0x0a0a0a }),
  };
  P.path.userData.strip = true;   // goes red with the emergency lights
  return P;
}

function bx(parent, mat, x, y, z, sx, sy, sz, seg = false) {
  const m = new THREE.Mesh(seg ? segBox(sx, sy, sz) : new THREE.BoxGeometry(sx, sy, sz), mat);
  m.position.set(x, y, z); parent.add(m); return m;
}
function cyl(parent, mat, x, y, z, r, len, axis = 'y', seg = 10) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg), mat);
  m.position.set(x, y, z);
  if (axis === 'x') m.rotation.z = Math.PI / 2; else if (axis === 'z') m.rotation.x = Math.PI / 2;
  parent.add(m); return m;
}
// a cable that sags between clips (points are clip positions)
function cable(parent, mat, pts, r = 0.022, sag = 0.1) {
  const all = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = new THREE.Vector3(...pts[i]), b = new THREE.Vector3(...pts[i + 1]);
    for (let k = 0; k < 6; k++) { const t = k / 6; const p = a.clone().lerp(b, t); p.y -= Math.sin(Math.PI * t) * sag; all.push(p); }
  }
  all.push(new THREE.Vector3(...pts[pts.length - 1]));
  const curve = new THREE.CatmullRomCurve3(all);
  const m = new THREE.Mesh(new THREE.TubeGeometry(curve, all.length * 3, r, 5, false), mat);
  parent.add(m); return m;
}
// a small canvas screen, drawn once
function panelScreen(w, h, draw) {
  const s = makeScreen(w, h); draw(s.g, w, h); s.tex.needsUpdate = true; return s.tex;
}
function grabBar(parent, mat, a, b, standoff = 0.07, nrm = [0, 0, 1]) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), N = new THREE.Vector3(...nrm);
  const len = A.distanceTo(B), mid = A.clone().add(B).multiplyScalar(0.5);
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, len, 8), mat);
  bar.position.copy(mid).addScaledVector(N, standoff);
  bar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), B.clone().sub(A).normalize());
  parent.add(bar);
  [A, B].forEach(p => { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, standoff, 6), mat); s.position.copy(p).addScaledVector(N, standoff / 2); s.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), N); parent.add(s); });
}

// ---------------- inside ----------------
// fixtures: { pos, size: [w, d] } ceiling light housings with a diffuser.
// The lamps (render/ship.js) sit just under the diffuser, so the housing
// shadows the ceiling above it in the bake instead of a bare bulb burning it.
export function addInteriorProps(g, M, fx) {
  const Q = pmats();
  const E = fx.emissives;
  // ---- ceiling light fixtures (one per lamp) ----
  const fixture = (x, ceilY, z, w, d) => {
    bx(g, M.dark, x, ceilY - 0.05, z, w, 0.1, d);
    const lens = bx(g, M.strip, x, ceilY - 0.104, z, w - 0.14, 0.012, d - 0.14); lens.userData.noOcclude = true;
    [-1, 1].forEach(s => bx(g, M.metal, x + s * (w / 2 - 0.02), ceilY - 0.11, z, 0.03, 0.02, d));
  };
  fixture(0, 2.24, -7.2, 0.62, 1.0);
  fixture(0, 2.09, -3.3, 0.5, 0.82);
  fixture(0, 2.09, 0.6, 0.5, 0.8);

  // ---- console room ----
  // cable runs along the top of both walls, clipped every metre or so
  cable(g, Q.cableA, [[-1.94, 2.2, -9.3], [-1.94, 2.2, -8.2], [-1.94, 2.2, -7.0], [-1.94, 2.2, -5.5]], 0.024, 0.09);
  cable(g, Q.cableB, [[-1.9, 2.17, -9.3], [-1.9, 2.17, -8.2], [-1.9, 2.17, -7.0], [-1.9, 2.17, -5.5]], 0.018, 0.13);
  cable(g, Q.rubber, [[-1.97, 2.14, -9.3], [-1.97, 2.14, -7.6], [-1.97, 2.14, -5.5]], 0.03, 0.06);
  cyl(g, M.metal, 1.93, 2.16, -7.4, 0.04, 3.9, 'z');
  for (let z = -9.0; z < -5.6; z += 1.1) bx(g, M.dark, 1.9, 2.12, z, 0.16, 0.14, 0.12);
  // ceiling vent
  bx(g, M.dark, -1.05, 2.23, -8.5, 0.52, 0.02, 0.44);
  for (let i = 0; i < 6; i++) bx(g, M.metal, -1.05, 2.215, -8.68 + i * 0.072, 0.48, 0.012, 0.018);
  // fire extinguisher on the starboard wall, by the aft opening
  cyl(g, Q.red, 1.9, 0.52, -5.75, 0.075, 0.44, 'y', 12);
  cyl(g, M.dark, 1.9, 0.78, -5.75, 0.03, 0.08, 'y', 8);
  bx(g, M.metal, 1.97, 0.5, -5.75, 0.03, 0.08, 0.2);
  // grab bars on both side walls
  grabBar(g, Q.rail, [1.99, 1.35, -8.7], [1.99, 1.35, -7.3], 0.07, [-1, 0, 0]);
  grabBar(g, Q.rail, [-1.99, 1.55, -9.1], [-1.99, 1.55, -8.0], 0.07, [1, 0, 0]);
  // the desk: keyboard at the helm, a mug, a notebook, a pen
  bx(g, M.dark, -0.72, 0.856, -8.75, 0.52, 0.022, 0.17);
  for (let r = 0; r < 3; r++) bx(g, M.metal, -0.72, 0.87, -8.8 + r * 0.045, 0.46, 0.008, 0.03);
  cyl(g, Q.ceramic, -1.25, 0.895, -8.78, 0.042, 0.1, 'y', 12);
  bx(g, Q.paper, 1.1, 0.852, -8.82, 0.21, 0.014, 0.28).rotation.y = 0.22;
  bx(g, M.dark, 1.14, 0.862, -8.78, 0.012, 0.008, 0.15).rotation.y = -0.4;
  // environment panel (live-looking readout) on the starboard wall
  bx(g, M.dark, 1.985, 1.45, -6.35, 0.03, 0.3, 0.44);
  const envTex = panelScreen(256, 176, (c, w, h) => {
    c.fillStyle = '#020a0c'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#6fd0ff'; c.font = 'bold 18px monospace'; c.fillText('CABIN ENV', 14, 28);
    c.font = '15px monospace';
    [['O2', 0.72], ['CO2', 0.18], ['PRESS', 0.86], ['HUM', 0.41]].forEach(([k, v], i) => {
      const y = 56 + i * 30; c.fillStyle = '#4aa8c8'; c.fillText(k, 14, y);
      c.strokeStyle = '#1d4a58'; c.strokeRect(84, y - 12, 150, 12); c.fillStyle = i === 1 ? '#ffb347' : '#6fd0ff'; c.fillRect(86, y - 10, 146 * v, 8);
    });
  });
  const envM = new THREE.MeshBasicMaterial({ map: envTex, toneMapped: false });
  const env = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.26), envM); env.position.set(1.965, 1.45, -6.35); env.rotation.y = -Math.PI / 2; g.add(env);
  E.push(envM);
  // status LEDs by the window frame
  [[-1.5, 0.62], [-1.4, 0.62], [1.4, 0.62]].forEach(([x, y], i) => bx(g, i === 2 ? Q.ledA : Q.ledG, x, y, -9.35, 0.03, 0.02, 0.012));
  E.push(Q.ledG, Q.ledA);

  // ---- corridor ----
  // clamps on the two ceiling pipes
  for (let z = -5.1; z < -1.1; z += 0.8) [-1.15, 1.15].forEach(x => bx(g, M.dark, x, 2.0, z, 0.14, 0.14, 0.05));
  // a loose cable where a panel was opened and never closed
  cable(g, Q.cableB, [[1.2, 2.02, -2.9], [1.02, 1.7, -2.72], [1.18, 1.3, -2.66]], 0.016, 0.05);
  bx(g, M.dark, 1.24, 1.95, -2.85, 0.04, 0.3, 0.36).rotation.y = 0.5;
  // your bunk: a reading lamp under the shelf, and what you keep on the shelf
  bx(g, M.dark, -0.72, 1.395, -5.05, 0.12, 0.05, 0.09);
  bx(g, Q.lensWarm, -0.72, 1.366, -5.05, 0.08, 0.008, 0.06).userData.noOcclude = true;
  bx(g, M.dark, 0.72, 1.395, -5.05, 0.12, 0.05, 0.09);
  bx(g, Q.lensOff, 0.72, 1.366, -5.05, 0.08, 0.008, 0.06);
  E.push(Q.lensWarm);
  bx(g, Q.bookA, -1.12, 1.56, -3.9, 0.16, 0.2, 0.04);
  bx(g, Q.bookB, -1.12, 1.555, -3.855, 0.15, 0.19, 0.035);
  bx(g, Q.bookA, -1.1, 1.53, -3.74, 0.18, 0.14, 0.05).rotation.x = 0.35;
  cyl(g, Q.ceramic, -1.05, 1.53, -4.45, 0.04, 0.09, 'y', 10);
  bx(g, Q.paper, -0.95, 1.487, -4.9, 0.2, 0.012, 0.26).rotation.y = -0.3;
  // locker handles and vents
  for (let i = 0; i < 3; i++) {
    const z = -2.3 + i * 0.5;
    bx(g, M.metal, 0.978, 1.0, z + 0.13, 0.02, 0.22, 0.03);
    for (let k = 0; k < 4; k++) bx(g, M.dark, 0.982, 1.62 + k * 0.05, z, 0.01, 0.018, 0.3);
  }
  // floor path lights, both sides, the length of the ship
  const path = (x, z0, z1) => { for (let z = z0; z < z1 - 0.1; z += 0.34) bx(g, Q.path, x, 0.075, z + 0.1, 0.02, 0.012, 0.2); };
  path(-1.97, -9.2, -5.6); path(1.97, -9.2, -5.6);
  path(-1.245, -5.3, -1.0); path(1.245, -5.3, -1.0);
  path(-1.43, -0.85, 1.95); path(1.43, -0.85, 1.95);
  E.push(Q.path);

  // ---- airlock ----
  grabBar(g, Q.rail, [-0.95, 0.55, 2.09], [-0.95, 1.6, 2.09], 0.07, [0, 0, -1]);
  grabBar(g, Q.rail, [0.95, 0.55, 2.09], [0.95, 1.6, 2.09], 0.07, [0, 0, -1]);
  // chamber pressure readout by the hatch
  bx(g, M.dark, -1.2, 1.45, 2.085, 0.3, 0.24, 0.03);
  const prTex = panelScreen(192, 144, (c, w, h) => {
    c.fillStyle = '#0c0602'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#ffb347'; c.font = 'bold 16px monospace'; c.fillText('CHAMBER', 12, 26);
    c.font = 'bold 30px monospace'; c.fillText('101', 12, 72); c.font = '14px monospace'; c.fillText('KPA', 84, 72);
    c.strokeStyle = '#7a4a10'; c.strokeRect(12, 92, 164, 14); c.fillStyle = '#ffb347'; c.fillRect(14, 94, 160, 10);
    c.fillStyle = '#ff5030'; c.fillText('DO NOT CYCLE', 12, 130);
  });
  const prM = new THREE.MeshBasicMaterial({ map: prTex, toneMapped: false });
  const pr = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.195), prM); pr.position.set(-1.2, 1.45, 2.068); pr.rotation.y = Math.PI; g.add(pr);
  E.push(prM);
  // two spare O2 bottles strapped to the port wall, and the tether reel by the hatch
  [-0.62, -0.36].forEach(z => { cyl(g, Q.orange, -1.34, 0.4, z, 0.085, 0.56, 'y', 12); bx(g, Q.rubber, -1.36, 0.5, z, 0.2, 0.04, 0.2); });
  bx(g, M.dark, -1.42, 0.5, -0.49, 0.04, 0.3, 0.5);
  bx(g, Q.reel, 0.98, 0.3, 1.9, 0.34, 0.36, 0.26);
  cyl(g, M.dark, 0.98, 0.3, 1.76, 0.12, 0.04, 'z', 16);
  // the floor in front of the hatch: a worn yellow-black stripe band
  const st = document.createElement('canvas'); st.width = 256; st.height = 64; const sg = st.getContext('2d');
  sg.fillStyle = '#151515'; sg.fillRect(0, 0, 256, 64);
  for (let i = -2; i < 12; i++) { sg.fillStyle = 'rgba(150,110,36,0.6)'; sg.beginPath(); sg.moveTo(i * 28, 64); sg.lineTo(i * 28 + 14, 64); sg.lineTo(i * 28 + 34, 0); sg.lineTo(i * 28 + 20, 0); sg.fill(); }
  const rnd = mulberry32(71);
  sg.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 260; i++) { sg.fillStyle = `rgba(0,0,0,${0.3 + rnd() * 0.6})`; sg.fillRect(rnd() * 256, rnd() * 64, 1 + rnd() * 6, 1 + rnd() * 3); }
  const stT = new THREE.CanvasTexture(st); stT.colorSpace = THREE.SRGBColorSpace;
  const stripe = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.4), new THREE.MeshStandardMaterial({ map: stT, transparent: true, roughness: 0.8, polygonOffset: true, polygonOffsetFactor: -2 }));
  stripe.rotation.x = -Math.PI / 2; stripe.position.set(0, 0.064, 1.75); g.add(stripe);
}

// ---------------- the wreck inside ----------------
// L maps our interior's coordinates into the wreck's fore-half frame
export function addWreckProps(g, M, L) {
  const Q = pmats();
  const at = (fn, x, y, z, ...rest) => { const m = fn(g, ...rest); m.position.copy(L(x, y, z)); return m; };
  // the fixtures, dead: housings with dark lenses, one hanging by its cable
  [[0, 2.24, -7.2, 0.62, 1.0], [0, 2.09, -4.4, 0.5, 0.82]].forEach(([x, y, z, w, d], i) => {
    const h = new THREE.Mesh(new THREE.BoxGeometry(w, 0.1, d), M.dark); h.position.copy(L(x, y - 0.05 - (i ? 0.25 : 0), z)); if (i) h.rotation.set(0.35, 0, 0.2); g.add(h);
    const lens = new THREE.Mesh(new THREE.BoxGeometry(w - 0.14, 0.012, d - 0.14), Q.lensOff); lens.position.copy(h.position).add(new THREE.Vector3(0, -0.055, 0)); lens.rotation.copy(h.rotation); g.add(lens);
  });
  const c = (pts, mat, r, sag) => { const q = pts.map(p => { const v = L(p[0], p[1], p[2]); return [v.x, v.y, v.z]; }); return cable(g, mat, q, r, sag); };
  c([[-1.94, 2.2, -9.3], [-1.94, 2.2, -8.2], [-1.94, 2.2, -7.0], [-1.94, 2.2, -5.5]], Q.cableA, 0.024, 0.09);
  c([[-1.9, 2.17, -9.3], [-1.9, 2.17, -8.2], [-1.6, 1.4, -7.6]], Q.cableB, 0.018, 0.2);
  // torn runs hanging out at the break
  c([[0.9, 2.05, -3.6], [0.7, 1.5, -3.4], [0.85, 0.9, -3.3]], Q.rubber, 0.03, 0.05);
  c([[-0.6, 2.05, -3.6], [-0.4, 1.7, -3.35], [-0.55, 1.3, -3.2]], Q.cableA, 0.02, 0.05);
  c([[-1.15, 2.0, -5.2], [-1.15, 2.0, -4.3], [-1.0, 1.6, -3.6]], Q.cableB, 0.016, 0.1);
  // the fire extinguisher, still in its bracket; the grab bars
  const ex = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.44, 12), Q.red); ex.position.copy(L(1.9, 0.52, -5.75)); g.add(ex);
  grabBar(g, Q.rail, L(1.99, 1.35, -8.7).toArray(), L(1.99, 1.35, -7.3).toArray(), 0.07, [-1, 0, 0]);
  grabBar(g, Q.rail, L(-1.99, 1.55, -9.1).toArray(), L(-1.99, 1.55, -8.0).toArray(), 0.07, [1, 0, 0]);
}

// ---------------- outside ----------------
// the hull as a lathe with rings every ~0.45 m (the stock capsule has none
// along its straight part, so baked shadow and AO had nowhere to live) and a
// rounder silhouette (48 sides instead of 20). v runs along the surface by
// arc length, so the plates keep one size from the nose to the tail.
export function hullLathe(R, len, radial = 48, step = 0.45) {
  const pts = [], half = len / 2, capN = Math.max(6, Math.round((Math.PI / 2 * R) / step));
  for (let i = 0; i <= capN; i++) { const a = -Math.PI / 2 + (i / capN) * Math.PI / 2; pts.push(new THREE.Vector2(Math.cos(a) * R, -half + Math.sin(a) * R)); }
  const n = Math.max(2, Math.round(len / step));
  for (let i = 1; i < n; i++) pts.push(new THREE.Vector2(R, -half + len * i / n));
  for (let i = 0; i <= capN; i++) { const a = (i / capN) * Math.PI / 2; pts.push(new THREE.Vector2(Math.cos(a) * R, half + Math.sin(a) * R)); }
  pts[0].x = 0.0001; pts[pts.length - 1].x = 0.0001;
  const g = new THREE.LatheGeometry(pts, radial);
  // re-map v by arc length
  const L = [0]; for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + pts[i].distanceTo(pts[i - 1]));
  const uv = g.attributes.uv, tot = L[L.length - 1];
  for (let k = 0; k < uv.count; k++) { const j = k % pts.length; uv.setY(k, L[j] / tot); }
  return g;
}

// hull: { R, axisY, z0, z1 } ; avoid: [{ a (deg), z, r (m) }] keep-clear spots
export function addHullGreebles(g, M, fx, hull, avoid) {
  const Q = pmats();
  const { R, axisY, z0, z1 } = hull;
  const rnd = mulberry32(9107);
  const onHull = (deg, z, lift = 0) => { const a = THREE.MathUtils.degToRad(deg); return { p: new THREE.Vector3(Math.cos(a) * (R + lift), axisY + Math.sin(a) * (R + lift), z), n: new THREE.Vector3(Math.cos(a), Math.sin(a), 0) }; };
  const clear = (deg, z, pad) => avoid.every(o => {
    let da = Math.abs(((deg - o.a) % 360 + 540) % 360 - 180);
    const arc = THREE.MathUtils.degToRad(da) * R;
    return Math.hypot(arc, z - o.z) > o.r + pad;
  });
  // flat structural bands instead of bright hoops
  for (let i = 0; i < 6; i++) {
    const z = THREE.MathUtils.lerp(z0 + 0.8, z1 - 0.8, i / 5);
    const band = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.035, R + 0.035, 0.24, 64, 1, true), Q.hullDark);
    band.rotation.x = Math.PI / 2; band.position.set(0, axisY, z); band.userData.noOcclude = true; g.add(band);
    [-0.12, 0.12].forEach(dz => { const lip = new THREE.Mesh(new THREE.TorusGeometry(R + 0.035, 0.018, 4, 64), Q.hullDark); lip.position.set(0, axisY, z + dz); lip.userData.bakeFlat = true; lip.userData.noOcclude = true; g.add(lip); });
  }
  // equipment boxes and small tanks, seeded, kept off the hatch, the name and every hardpoint
  const orient = (m, n, spin = 0) => { m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), n); if (spin) m.rotateY(spin); };
  let placed = 0;
  for (let tries = 0; tries < 400 && placed < 34; tries++) {
    const deg = rnd() * 360, z = THREE.MathUtils.lerp(z0 + 0.3, z1 - 0.3, rnd());
    if (!clear(deg, z, 0.9)) continue;
    const kind = rnd();
    if (kind < 0.62) {
      const w = 0.25 + rnd() * 0.6, h = 0.07 + rnd() * 0.18, d = 0.3 + rnd() * 0.9;
      const { p, n } = onHull(deg, z, h / 2);
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), rnd() < 0.3 ? Q.foil : Q.hullBox);
      m.position.copy(p); orient(m, n); g.add(m);
      // most boxes get a smaller box or a vent on top
      if (rnd() < 0.6) { const { p: p2 } = onHull(deg, z, h + 0.03); const t = new THREE.Mesh(new THREE.BoxGeometry(w * 0.5, 0.06, d * 0.4), Q.hullDark); t.position.copy(p2); orient(t, n); g.add(t); }
    } else {
      const r = 0.1 + rnd() * 0.1, len = 0.6 + rnd() * 0.8;
      const { p } = onHull(deg, z, r + 0.02);
      const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 12), rnd() < 0.5 ? Q.hullBox : Q.orange);
      m.position.copy(p); m.rotation.x = Math.PI / 2; g.add(m);
      [-len * 0.3, len * 0.3].forEach(dz => { const { p: ps, n } = onHull(deg, z + dz, r * 0.5); const s = new THREE.Mesh(new THREE.BoxGeometry(r * 2.3, r, 0.05), Q.hullDark); s.position.copy(ps); orient(s, n); g.add(s); });
    }
    placed++;
  }
  // handrails: the spacewalk path from the hatch along the flank (standoffs every 0.8 m)
  const rail = (deg, za, zb) => {
    const a = onHull(deg, za, 0.12), b = onHull(deg, zb, 0.12);
    const len = a.p.distanceTo(b.p);
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, len, 8), Q.rail);
    bar.position.copy(a.p).add(b.p).multiplyScalar(0.5); bar.rotation.x = Math.PI / 2; g.add(bar);
    for (let z = za; z <= zb + 1e-3; z += 0.8) { const s = onHull(deg, z, 0.06); const st = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.12, 6), Q.rail); st.position.copy(s.p); orient(st, s.n); g.add(st); }
  };
  rail(22, -0.6, 3.4); rail(-22, -0.6, 3.4); rail(58, -9.4, -2.2); rail(-40, -7.6, -1.6);
  // RCS blocks: four at the nose, four at the tail, each with three nozzles
  [z0 + 0.6, z1 - 0.6].forEach(z => [45, 135, 225, 315].forEach(deg => {
    if (!clear(deg, z, 0.2)) return;
    const { p, n } = onHull(deg, z, 0.12);
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.24, 0.34), Q.hullBox); b.position.copy(p); orient(b, n); g.add(b);
    const t = new THREE.Vector3(0, 0, 1), s = new THREE.Vector3().crossVectors(n, t);
    [[t, 0.2], [t.clone().negate(), 0.2], [s, 0.2]].forEach(([d]) => {
      const c = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.1, 8, 1, true), Q.hullDark);
      c.position.copy(p).addScaledVector(d, 0.2); c.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), d); g.add(c);
    });
  }));
  // running lights: red to port, green to starboard, white on top; blink in updateNavLights
  fx.navLights = [];
  const nav = (deg, z, color, phase) => {
    const { p, n } = onHull(deg, z, 0.1);
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), new THREE.MeshBasicMaterial({ color, toneMapped: false }));
    m.position.copy(p); g.add(m);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite(), color, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 }));
    s.scale.set(1.1, 1.1, 1); s.position.copy(p).addScaledVector(n, 0.05); g.add(s);
    fx.navLights.push({ m, s, color: new THREE.Color(color), phase });
  };
  nav(180, z0 + 1.6, 0xff2a18, 0.0); nav(0, z0 + 1.6, 0x30ff60, 0.0); nav(90, z1 - 1.2, 0xe8f0ff, 0.5);
}

// blink pattern: a short double flash every 2.4 s, only while the ship has power
export function updateNavLights(fx, t, powered) {
  if (!fx.navLights) return;
  for (const L of fx.navLights) {
    const ph = ((t / 2.4 + L.phase) % 1 + 1) % 1;
    const on = powered && (ph < 0.05 || (ph > 0.11 && ph < 0.16)) ? 1 : 0;
    L.m.material.color.copy(L.color).multiplyScalar(on ? 1 : 0.05);
    L.s.material.opacity = on * 0.9;
  }
}
