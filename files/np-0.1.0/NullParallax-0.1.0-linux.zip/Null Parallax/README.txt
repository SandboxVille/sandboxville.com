NULL PARALLAX 0.1.0 (early tester build)
by SandboxVille

What it is
----------
Null Parallax is a space survival game. You wake up alone on a small
survey probe that is drifting between the stars. Build and repair the ship,
go outside on a safety line, land on planets made fresh for each star,
and cook and grow food to stay alive. Every star in the sky is a real star.

How to start
------------
  Windows: double-click "Start Null Parallax.bat". Node.js is included.
  Mac:     double-click "Start Null Parallax.command".
           (The first time, right-click it and choose Open.)
  Linux:   run ./start-null-parallax.sh in a terminal.
  Mac and Linux need Node.js 18 or newer from https://nodejs.org
  The start file tells you how to get it if it is missing.

A small window opens and your browser shows the game. Keep that window
open while you play. Close it to stop the game.

The game runs only on your own computer, at http://127.0.0.1:47823/
(the next free port if that one is busy). Nothing else on your network can
reach it. The first start needs the internet, to load the 3D library.
Chrome or Edge work best.

Controls (keyboard and mouse; a controller works too)
--------
  W A S D      walk, or fly when outside
  Mouse        look
  SPACE / C    up / down when outside
  Q / E        roll when outside
  SHIFT        boost
  F            use, pick up, hold to cut
  TAB          scan for things nearby
  B            build mode
  L            helmet lamp
  N            star chart
  J            journal
  ESC          pause and free the mouse

Your saves
----------
Saves live in your browser, for the address the game runs at. Use the same
browser each time. If you clear your browser data for that address, or the
game starts on a different port, you will not see your old saves there.

Known rough edges
-----------------
  - Animals on planets do not move yet.
  - During descent to a planet you cannot steer left or right.
  - Lava does not glow at night.
  - This is an early tester build. Things will change.

License: see LICENSE.txt.
