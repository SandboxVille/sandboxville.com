let i=null;function t(n){i=n}function e(n){i&&i(n)}export{t as setTriggerEnding,e as triggerEndingCall};
