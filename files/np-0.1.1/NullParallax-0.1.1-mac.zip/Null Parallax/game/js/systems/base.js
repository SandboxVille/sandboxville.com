


















import * as THREE from 'three';
import { S } from '../core/state.js';
import { groundAt } from '../gen/planet.js';
import { terrain, setPointLights } from '../render/terrain.js';
import { ship } from '../render/scene.js';
import { HATCH_EXT } from '../render/ship.js';
import { glowSprite } from '../render/textures.js';
import { flatBasis } from '../core/utils.js';
import * as landing from './landing.js';
import { surfStore, mineInteract } from './mining.js';
import { meshFor, M as BM, canAfford, costText } from './build.js';
import { sleep } from './survival.js';
import { GROW_SECONDS, HYDRO_YIELD } from './galley.js';
import { prompt, progressBar, flash, say } from '../ui/hud.js';
import { emit, on } from '../core/events.js';
import { doAutosave } from './save-state.js';
import { held, lastInputDevice } from '../core/input.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { OXY_MAX, SUIT_POWER_MAX, SUIT_HEAT_DRAIN, PLAYER_R, EYE_H } from '../core/constants.js';
import * as audio from '../audio.js';

export const BASE_PARTS = {
  floodlight: { label: 'FLOODLIGHT', cost: { salvage: 2, ore: 1 }, power: 0.6, r: 0.6, desc: 'Lights about 20 m of ground, all night, while the base grid powers it.' },
  heater: { label: 'HEATER', cost: { salvage: 3, ore: 2 }, power: 1.0, r: 0.7, desc: 'Warms the air around it: within 9 m the suit heater rests and you warm up.' },
  rtg: { label: 'RTG', cost: { salvage: 5, ore: 3 }, power: -2.5, r: 0.8, desc: 'Power from decay, day and night. Adds 2.5 power to every part wired to it (within 14 m).' },
  solar: { label: 'SOLAR PANEL', cost: { salvage: 3, ore: 1 }, power: -1.5, r: 1.2, desc: 'Up to 1.5 power in full daylight, none at night. Wires to parts within 14 m.' },
  hydro: { label: 'HYDROPONICS DOME', cost: { salvage: 3, ore: 2, ice: 1 }, power: 0.7, r: 1.1, desc: 'On base power: 1 water + 1 plant fibre grow into 3 edible plants in 4 minutes.' },
  storage: { label: 'STORAGE CRATE', cost: { ore: 3, salvage: 1 }, power: 0, r: 0.8, desc: 'Holds 80 units of raw resources. F puts yours in, G takes them out.' },
  shelter: { label: 'SHELTER', cost: { salvage: 6, ore: 6, ice: 2 }, power: 0.8, r: 2.1, desc: 'A pressurised room with a door. On power: suit air and power refill inside, you warm up, the cot sleeps and saves.' },
  wall: { label: 'WALL', cost: { ore: 2 }, power: 0, r: 0.2, desc: 'A 4 m wall panel. Snaps edge to edge with other walls and the shelter.' },
  doorway: { label: 'DOORWAY', cost: { ore: 2, salvage: 1 }, power: 0, r: 0.2, desc: 'A 4 m wall panel with a door in it. Snaps like a wall.' },
};
export const BASE_ORDER = ['floodlight', 'heater', 'rtg', 'solar', 'hydro', 'storage', 'shelter', 'wall', 'doorway'];
export const WIRE = 14, SLOPE_MAX = 0.36, CRATE_CAP = 80, MAX_PARTS = 60;
export const STASH = ['ore', 'ice', 'salvage', 'carbon', 'fibre'];
const WALLISH = p => p === 'wall' || p === 'doorway' || p === 'shelter';
const FOOT = { shelter: 2.1, wall: 2, doorway: 2, solar: 1.1 };
const PRIO = ['shelter', 'hydro', 'heater', 'floodlight'];
const SH = { W: 4, H: 2.8, FLOOR: 0.15, DOOR: 1.3, DOOR_H: 2.2 };
S.buildSurfaceN = BASE_ORDER.length;

// ---------------- meshes (local +Y up, the front faces +Z) ----------------
const MAT = {
  hab: new THREE.MeshStandardMaterial({ color: 0x9aa0a8, roughness: 0.55, metalness: 0.45 }),
  habDark: new THREE.MeshStandardMaterial({ color: 0x4a4f57, roughness: 0.6, metalness: 0.5 }),
  floor: new THREE.MeshStandardMaterial({ color: 0x3a3d42, roughness: 0.85, metalness: 0.3 }),
  found: new THREE.MeshStandardMaterial({ color: 0x55504a, roughness: 0.95, metalness: 0.05 }),
  cell: new THREE.MeshStandardMaterial({ color: 0x1b2a58, roughness: 0.25, metalness: 0.6, emissive: 0x050a1a }),
  crate: new THREE.MeshStandardMaterial({ color: 0x4b5a48, roughness: 0.7, metalness: 0.4 }),
  cloth: new THREE.MeshStandardMaterial({ color: 0x5a6a7a, roughness: 0.95, metalness: 0 }),
  cable: new THREE.LineBasicMaterial({ color: 0x8a7650 }),
};
const glowTex = glowSprite();
function partMesh(part) {
  const g = new THREE.Group();
  const box = (x, y, z, sx, sy, sz, mat, parent = g) => { const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat); m.position.set(x, y, z); parent.add(m); return m; };
  const cyl = (x, y, z, r1, r2, h, mat, seg = 10) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, seg), mat); m.position.set(x, y, z); g.add(m); return m; };
  const lamp = (x, y, z, s, col) => { const m = new THREE.Mesh(new THREE.BoxGeometry(s, s, s), new THREE.MeshBasicMaterial({ color: col, toneMapped: false })); m.position.set(x, y, z); g.add(m); return m; };
  switch (part) {
    case 'floodlight': {
      for (let i = 0; i < 3; i++) { const a = i * 2.094; const leg = cyl(Math.cos(a) * 0.35, 0.55, Math.sin(a) * 0.35, 0.04, 0.05, 1.2, BM.metal, 5); leg.rotation.set(Math.sin(a) * 0.45, 0, -Math.cos(a) * 0.45); }
      cyl(0, 1.7, 0, 0.06, 0.07, 2.4, BM.metal);
      const head = box(0, 3.0, 0.1, 0.8, 0.45, 0.4, BM.dark); head.rotation.x = 0.45;
      const lens = new THREE.Mesh(new THREE.PlaneGeometry(0.66, 0.32), new THREE.MeshBasicMaterial({ color: 0xfff1d6, toneMapped: false })); lens.position.set(0, 2.92, 0.32); lens.rotation.x = 0.45; g.add(lens);
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0xfff1d6, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      s.scale.set(3, 3, 1); s.position.set(0, 2.9, 0.45); g.add(s);
      g.userData = { glow: s, lens, lampY: 2.9 };
      break;
    }
    case 'heater': { box(0, 0.12, 0, 1.2, 0.24, 1.0, MAT.found); const h = meshFor('heater'); h.scale.setScalar(1.3); h.position.y = 0.2; g.add(h); g.userData.coils = []; h.traverse(o => { if (o.isMesh && o.material === BM.orange) g.userData.coils.push(o); }); break; }
    case 'rtg': { box(0, 0.1, 0, 1.3, 0.2, 1.3, MAT.found); const h = meshFor('rtg'); h.scale.setScalar(1.4); h.position.y = 0.15; g.add(h); break; }
    case 'solar': {
      cyl(0, 0.7, 0, 0.07, 0.09, 1.4, BM.metal);
      const pan = new THREE.Group(); pan.position.set(0, 1.45, 0); pan.rotation.x = -0.55; g.add(pan);
      box(0, 0, 0, 2.3, 0.06, 1.5, BM.dark, pan); box(0, 0.035, 0, 2.2, 0.02, 1.4, MAT.cell, pan);
      for (let i = -2; i <= 2; i++) box(i * 0.44, 0.05, 0, 0.02, 0.01, 1.4, BM.metal, pan);
      box(0, 0.05, 0, 2.2, 0.01, 0.02, BM.metal, pan);
      break;
    }
    case 'hydro': { box(0, 0.12, 0, 1.9, 0.24, 1.4, MAT.found); const h = meshFor('hydro'); h.scale.setScalar(1.5); h.position.y = 0.2; g.add(h); g.userData = { ...h.userData }; break; }
    case 'storage': {
      box(0, 0.45, 0, 1.4, 0.9, 1.0, MAT.crate);
      for (const x of [-0.6, 0, 0.6]) box(x, 0.45, 0.51, 0.08, 0.92, 0.04, BM.metal);
      box(0, 0.93, 0, 1.44, 0.07, 1.04, BM.orange);
      g.userData.fill = lamp(0.55, 0.75, 0.53, 0.1, 0x40ff80);
      // what it holds shows as a heap inside the open-topped tray on the lid
      const heap = new THREE.Mesh(new THREE.DodecahedronGeometry(0.3, 0), new THREE.MeshStandardMaterial({ color: 0x8a7050, roughness: 0.9, flatShading: true })); heap.position.set(-0.2, 1.0, 0); heap.scale.set(1.4, 0.5, 1); g.add(heap); g.userData.heap = heap;
      break;
    }
    case 'shelter': {
      const W = SH.W, H = SH.H, t = 0.2, hw = W / 2;
      box(0, -0.75, 0, W + 0.3, 1.8, W + 0.3, MAT.found);                         // foundation, sunk into the ground
      box(0, SH.FLOOR / 2, 0, W, SH.FLOOR, W, MAT.floor);
      box(0, H / 2, -hw + t / 2, W, H, t, MAT.hab);                                   // back
      box(-hw + t / 2, H / 2, 0, t, H, W, MAT.hab); box(hw - t / 2, H / 2, 0, t, H, W, MAT.hab);
      const side = (W - SH.DOOR) / 2;
      box(-(SH.DOOR / 2 + side / 2), H / 2, hw - t / 2, side, H, t, MAT.hab); box(SH.DOOR / 2 + side / 2, H / 2, hw - t / 2, side, H, t, MAT.hab);
      box(0, (SH.DOOR_H + H) / 2, hw - t / 2, SH.DOOR, H - SH.DOOR_H, t, MAT.hab);   // over the door
      box(0, H + 0.1, 0, W + 0.3, 0.2, W + 0.3, MAT.habDark);                         // roof
      for (const x of [-hw, hw]) for (const z of [-hw, hw]) box(x, H / 2, z, 0.28, H + 0.1, 0.28, MAT.habDark);
      box(0, SH.DOOR_H + 0.05, hw + 0.02, SH.DOOR + 0.2, 0.1, 0.1, MAT.habDark);        // door frame
      for (const x of [-SH.DOOR / 2 - 0.05, SH.DOOR / 2 + 0.05]) box(x, SH.DOOR_H / 2, hw + 0.02, 0.1, SH.DOOR_H, 0.1, MAT.habDark);
      // inside: a cot, a light panel in the ceiling, the air unit with its lamp, a stripe
      box(-1.3, 0.35, -0.75, 0.95, 0.4, 2.0, MAT.habDark); box(-1.3, 0.6, -0.75, 0.85, 0.12, 1.9, MAT.cloth); box(-1.3, 0.7, -1.5, 0.6, 0.12, 0.35, MAT.cloth);
      const ceil = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.04, 0.6), new THREE.MeshBasicMaterial({ color: 0xfff1d6, toneMapped: false })); ceil.position.set(0, H - 0.03, 0); g.add(ceil);
      box(1.72, 1.3, -1.0, 0.3, 0.9, 0.6, BM.panel);
      const air = lamp(1.56, 1.55, -1.0, 0.08, 0x40ff80);
      box(0, 1.0, -hw + 0.21, 3.4, 0.08, 0.02, BM.orange);
      const over = lamp(0, SH.DOOR_H + 0.25, hw + 0.08, 0.14, 0xffb347);
      g.userData = { ceil, air, over, lampY: H - 0.3 };
      break;
    }
    case 'wall': case 'doorway': {
      const W = 4, H = SH.H, t = 0.2;
      box(0, -0.45, 0, W, 1.1, 0.5, MAT.found);
      if (part === 'wall') box(0, H / 2, 0, W, H, t, MAT.hab);
      else {
        const side = (W - SH.DOOR) / 2;
        box(-(SH.DOOR / 2 + side / 2), H / 2, 0, side, H, t, MAT.hab); box(SH.DOOR / 2 + side / 2, H / 2, 0, side, H, t, MAT.hab);
        box(0, (SH.DOOR_H + H) / 2, 0, SH.DOOR, H - SH.DOOR_H, t, MAT.hab);
      }
      for (const x of [-2, 2]) box(x, H / 2, 0, 0.26, H + 0.08, 0.3, MAT.habDark);
      box(0, H + 0.04, 0, W, 0.08, 0.3, MAT.habDark);
      break;
    }
  }
  return g;
}
// frame time: a part is built from many boxes; the ones that never change are merged, one mesh per material
function mergeStatic(g) {
  const keep = new Set();
  const u = g.userData;
  for (const k in u) { const v = u[k]; for (const o of Array.isArray(v) ? v : [v]) if (o && o.isObject3D) o.traverse(x => keep.add(x)); }
  g.updateMatrixWorld(true);
  const byMat = new Map(), gone = [];
  g.traverse(o => {
    if (!o.isMesh || keep.has(o)) return;
    const q = (o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone()).applyMatrix4(o.matrixWorld);
    for (const a of Object.keys(q.attributes)) if (a !== 'position' && a !== 'normal') q.deleteAttribute(a);
    if (!byMat.has(o.material)) byMat.set(o.material, []);
    byMat.get(o.material).push(q); gone.push(o);
  });
  for (const o of gone) { o.parent.remove(o); o.geometry.dispose(); }
  for (const [mat, list] of byMat) { const m = new THREE.Mesh(mergeGeometries(list), mat); g.add(m); }
  return g;
}
// colliders in the part's own frame: boxes { x, z, hx, hz } (walls, the cot), or a circle radius
function collidersFor(part) {
  const hw = SH.W / 2, t = 0.1, side = (SH.W - SH.DOOR) / 2;
  switch (part) {
    case 'shelter': return [{ x: 0, z: -hw + t, hx: hw, hz: t }, { x: -hw + t, z: 0, hx: t, hz: hw }, { x: hw - t, z: 0, hx: t, hz: hw }, { x: -(SH.DOOR / 2 + side / 2), z: hw - t, hx: side / 2, hz: t }, { x: SH.DOOR / 2 + side / 2, z: hw - t, hx: side / 2, hz: t }, { x: -1.3, z: -0.75, hx: 0.48, hz: 1.0 }];
    case 'wall': return [{ x: 0, z: 0, hx: 2, hz: 0.12 }];
    case 'doorway': return [{ x: -(SH.DOOR / 2 + side / 2), z: 0, hx: side / 2, hz: 0.12 }, { x: SH.DOOR / 2 + side / 2, z: 0, hx: side / 2, hz: 0.12 }];
    default: return null;
  }
}

// ---------------- the live base ----------------
const B = { group: null, wires: null, built: [], key: '', dirty: true, ghost: null, ghostPart: null, gridT: 0, o: { x: 0, z: 0 }, crate: null, inside: null };
export const state = { reason: '', target: null, ok: false, removeTarget: null, rot: 0 };
function ensure() {
  if (B.group) return;
  B.group = new THREE.Group(); B.group.name = 'base';
  B.wires = new THREE.LineSegments(new THREE.BufferGeometry(), MAT.cable); B.wires.frustumCulled = false; B.group.add(B.wires);
}
const toLocal = (rec, x, z) => { const dx = x - rec.x, dz = z - rec.z, c = Math.cos(rec.r), s = Math.sin(rec.r); return [dx * c - dz * s, dx * s + dz * c]; };
const toPlanet = (rec, lx, lz) => { const c = Math.cos(rec.r), s = Math.sin(rec.r); return [rec.x + lx * c + lz * s, rec.z - lx * s + lz * c]; };
function baseY(pl, part, x, z, r) {
  const site = terrain.site, f = FOOT[part];
  if (!f) return groundAt(pl, x, z, site);
  let h = -1e9; const c = Math.cos(r), s = Math.sin(r);
  const pts = part === 'wall' || part === 'doorway' ? [[0, 0], [f, 0], [-f, 0]] : [[0, 0], [f, f], [-f, f], [f, -f], [-f, -f]];
  for (const [a, b] of pts) h = Math.max(h, groundAt(pl, x + a * c + b * s, z - a * s + b * c, site));
  return h;
}
export function parts() { const st = surfStore(false); return st ? st.base : []; }
function rebuild() {
  ensure();
  for (const b of B.built) { B.group.remove(b.group); b.group.traverse(o => { if (o.geometry) o.geometry.dispose(); }); }
  B.built = [];
  const pl = landing.planet();
  for (const rec of parts()) {
    const g = mergeStatic(partMesh(rec.part)), y = baseY(pl, rec.part, rec.x, rec.z, rec.r);
    g.position.set(rec.x, y, rec.z); g.rotation.y = rec.r; B.group.add(g);
    B.built.push({ rec, group: g, y, on: false, grid: null, cols: collidersFor(rec.part) });
  }
  B.dirty = false; B.gridT = 0.25;
  computeGrid(true);
}

// the grid: parts within WIRE of each other are wired together; each group's generators feed its loads in order
function computeGrid(cables) {
  const n = B.built.length, par = [...Array(n).keys()];
  const find = i => { while (par[i] !== i) i = par[i] = par[par[i]]; return i; };
  const edges = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
    const a = B.built[i].rec, b = B.built[j].rec, d = Math.hypot(a.x - b.x, a.z - b.z);
    if (d < WIRE) edges.push([d, i, j]);
  }
  edges.sort((a, b) => a[0] - b[0]);
  const tree = [];
  for (const [, i, j] of edges) { const a = find(i), b = find(j); if (a !== b) { par[a] = b; tree.push([i, j]); } }
  const day = landing.dayLevel(), grids = new Map();
  B.built.forEach((b, i) => { const k = find(i); if (!grids.has(k)) grids.set(k, { gen: 0, use: 0, need: 0, members: [] }); grids.get(k).members.push(b); });
  for (const g of grids.values()) {
    for (const b of g.members) { if (b.rec.part === 'rtg') g.gen += 2.5; else if (b.rec.part === 'solar') g.gen += 1.5 * day; }
    const loads = g.members.filter(b => BASE_PARTS[b.rec.part].power > 0).sort((a, b) => PRIO.indexOf(a.rec.part) - PRIO.indexOf(b.rec.part));
    for (const b of g.members) { b.grid = g; b.on = BASE_PARTS[b.rec.part].power <= 0 && (b.rec.part !== 'solar' || day > 0.05); }
    for (const b of loads) { const w = BASE_PARTS[b.rec.part].power; g.need += w; if (g.use + w <= g.gen + 1e-6) { g.use += w; b.on = true; } else b.on = false; }
    for (const b of g.members) if (b.rec.part === 'rtg') b.on = true;
  }
  B.tree = tree.length;
  if (!cables) return;
  // cables: the spanning tree, laid along the ground (only when the base changes)
  const pl = landing.planet(), pts = [];
  for (const [i, j] of tree) {
    const a = B.built[i].rec, b = B.built[j].rec;
    for (let k = 0; k < 6; k++) {
      const t0 = k / 6, t1 = (k + 1) / 6;
      for (const t of [t0, t1]) { const x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t; pts.push(x, groundAt(pl, x, z, terrain.site) + 0.07, z); }
    }
  }
  B.wires.geometry.dispose(); B.wires.geometry = new THREE.BufferGeometry(); B.wires.geometry.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
}

// ---------------- per frame ----------------
on('loaded', () => { B.dirty = true; B.key = ''; });
export function update(dt) {
  if (B.crate && (S.mode !== 'eva' || !landing.onSurface() || Math.hypot(B.crate.rec.x - landing.planetXZ(S.pos).x, B.crate.rec.z - landing.planetXZ(S.pos).z) > 3.2)) B.crate = null;
  const onS = landing.onSurface() && terrain.group && terrain.planet;
  if (S.buildSurface && !(onS && S.mode === 'eva')) exitBuild();
  if (!onS) { if (B.group && B.group.parent) B.group.parent.remove(B.group); B.key = ''; B.inside = null; setPointLights(null); return; }
  ensure();
  if (B.group.parent !== terrain.group) terrain.group.add(B.group);
  const key = landing.L().hip + ':' + landing.L().pi + ':' + JSON.stringify(terrain.site) + ':' + parts().length;
  if (key !== B.key || B.dirty) { B.key = key; rebuild(); }
  const o = landing.planetXZ(new THREE.Vector3()); B.o = o;
  B.gridT -= dt; if (B.gridT <= 0) { B.gridT = 0.25; computeGrid(); }
  const p = landing.planetXZ(S.pos), P = S.P;
  // the shelter: inside, on power, the room looks after the suit
  B.inside = null;
  for (const b of B.built) if (b.rec.part === 'shelter') { const [lx, lz] = toLocal(b.rec, p.x, p.z); if (Math.abs(lx) < 1.85 && Math.abs(lz) < 1.85) B.inside = b; }
  if (S.mode === 'eva' && !S.dying && !S.sleeping) {
    if (B.inside && B.inside.on) {
      S.eva.oxygen = Math.min(OXY_MAX, S.eva.oxygen + 6 * dt); S.eva.power = Math.min(SUIT_POWER_MAX, S.eva.power + 4 * dt);
      P.life.warmth = Math.min(100, P.life.warmth + 2 * dt);
      if (!P.flags.shelterSaid) { P.flags.shelterSaid = true; say('INSIDE THE SHELTER: PRESSURISED. THE SUIT TOPS UP ITS AIR AND POWER FROM THE ROOM. THE COT SLEEPS AND SAVES THE GAME.', { hold: 14000 }); }
    }
    for (const b of B.built) if (b.rec.part === 'heater' && b.on && Math.hypot(b.rec.x - p.x, b.rec.z - p.z) < 9) {
      const k = S.suitK ? S.suitK.heat : 1;
      S.eva.power = Math.min(SUIT_POWER_MAX, S.eva.power + SUIT_HEAT_DRAIN * k * dt * (S.settings.difficulty === 'story' ? 0.5 : 1));
      P.life.warmth = Math.min(100, P.life.warmth + 0.6 * dt); break;
    }
  }
  // hydroponics on base power (grows while you are on this world)
  if (!S.dying && !S.sleeping) for (const b of B.built) if (b.rec.part === 'hydro' && b.on) {
    const r = b.rec, R = P.res;
    if (!r.on) { if (R.water >= 1 && R.fibre >= 1) { R.water--; R.fibre--; r.on = true; r.g = 0; } continue; }
    r.g = Math.min(1, (r.g || 0) + dt / GROW_SECONDS);
    if (r.g >= 1) { r.on = false; r.g = 0; R.plant += HYDRO_YIELD; flash(`BASE HYDROPONICS: CROP READY. +${HYDRO_YIELD} EDIBLE PLANTS (${R.plant})`, 3200); }
  }
  visuals();
  lights();
  updateBuild(dt);
}
function visuals() {
  const t = performance.now() / 1000;
  for (const b of B.built) {
    const u = b.group.userData, on = b.on;
    if (b.rec.part === 'floodlight') { u.glow.material.opacity = on ? 0.9 : 0; u.lens.material.color.setHex(on ? 0xfff1d6 : 0x222222); }
    else if (b.rec.part === 'shelter') { u.ceil.material.color.setHex(on ? 0xfff1d6 : 0x202020); u.air.material.color.setHex(on ? 0x40ff80 : 0xff3020); u.over.material.color.setHex(on ? 0xffb347 : (Math.sin(t * 4) > 0 ? 0xff3020 : 0x200404)); }
    else if (b.rec.part === 'hydro') { if (u.lamp) u.lamp.material.color.setHex(on ? 0xff60d0 : 0x1a0a16); const k = b.rec.on ? 0.12 + 0.88 * (b.rec.g || 0) : 0; if (u.crop) for (const c of u.crop) { c.visible = k > 0; c.scale.setScalar(Math.max(0.01, k)); } }
    else if (b.rec.part === 'storage') { const n = crateCount(b.rec); u.fill.material.color.setHex(n >= CRATE_CAP ? 0xffb347 : n > 0 ? 0x40ff80 : 0x303030); u.heap.visible = n > 0; u.heap.scale.set(1.4, 0.2 + 0.8 * n / CRATE_CAP, 1); }
    else if (b.rec.part === 'heater') for (const c of u.coils || []) c.material = on ? HOT : BM.orange;
  }
}
const HOT = new THREE.MeshStandardMaterial({ color: 0xff7a30, emissive: 0xff4a10, emissiveIntensity: 0.9, roughness: 0.5 });

// light: the pooled point lights (ship children) go to the nearest powered floodlights, the ground shader gets up to four
const _lp = [];
function lights() {
  const p = landing.planetXZ(S.pos);
  const on = B.built.filter(b => b.on && b.rec.part === 'floodlight').map(b => ({ b, d: Math.hypot(b.rec.x - p.x, b.rec.z - p.z) })).sort((a, c) => a.d - c.d);
  B.floods = on;
  _lp.length = 0;
  for (const { b } of on.slice(0, 4)) {
    const [fx, fz] = toPlanet(b.rec, 0, 0.5);
    _lp.push({ x: fx - terrain.origin.x, y: b.y + 2.9, z: fz - terrain.origin.y, k: 1.6 });
  }
  setPointLights(_lp);
}
export function applyLights(pool) {
  if (!landing.onSurface() || !B.built.length) return;
  const sh = ship.position.y, cand = [];
  if (B.inside && B.inside.on) cand.push({ x: B.inside.rec.x, y: B.inside.y + SH.H - 0.3, z: B.inside.rec.z, i: 6, dist: 7 });
  for (const { b } of (B.floods || [])) { const [fx, fz] = toPlanet(b.rec, 0, 0.7); cand.push({ x: fx, y: b.y + 2.8, z: fz, i: 40, dist: 34 }); }
  pool.forEach((l, i) => { const c = cand[i]; if (!c) { l.distance = 34; return; } l.position.set(c.x - B.o.x, c.y - sh, c.z - B.o.z); l.intensity = c.i; l.distance = c.dist; });
}

// walls, the shelter and the other parts push you out; the shelter's floor holds you up
function collide(pos) {
  if (!B.built.length || !landing.onSurface()) return;
  const o = landing.planetXZ(new THREE.Vector3()); const px = pos.x + o.x, pz = pos.z + o.z;
  const feet = pos.y - EYE_H + ship.position.y;
  let dx = 0, dz = 0;
  for (const b of B.built) {
    const rec = b.rec, R0 = Math.hypot(rec.x - px, rec.z - pz);
    if (R0 > 5 || feet > b.y + SH.H + 0.2) continue;
    if (b.cols) {
      let [lx, lz] = toLocal(rec, px + dx, pz + dz);
      for (const c of b.cols) {
        const qx = lx - c.x, qz = lz - c.z, ex = c.hx + PLAYER_R - Math.abs(qx), ez = c.hz + PLAYER_R - Math.abs(qz);
        if (ex > 0 && ez > 0) { if (ex < ez) lx += Math.sign(qx || 1) * ex; else lz += Math.sign(qz || 1) * ez; }
      }
      const [nx, nz] = toPlanet(rec, lx, lz); dx = nx - px; dz = nz - pz;
    } else {
      const r = BASE_PARTS[rec.part].r + PLAYER_R, ax = px + dx - rec.x, az = pz + dz - rec.z, d = Math.hypot(ax, az);
      if (d < r && d > 1e-5) { dx += ax / d * (r - d); dz += az / d * (r - d); }
    }
  }
  pos.x += dx; pos.z += dz;
}
function floor(x, z) {
  let h = -Infinity;
  for (const b of B.built) if (b.rec.part === 'shelter') { const [lx, lz] = toLocal(b.rec, x, z); if (Math.abs(lx) < 2.05 && Math.abs(lz) < 2.05) h = Math.max(h, b.y + SH.FLOOR); }
  return h;
}

// ---------------- F and G on the ground ----------------
export function crateCount(rec) { let n = 0; for (const k in (rec.store || {})) n += rec.store[k] || 0; return n; }
function crateText(rec) { const s = rec.store || {}; const bits = STASH.filter(k => s[k] > 0).map(k => `${s[k]} ${k.toUpperCase()}`); return bits.length ? bits.join(', ') : 'EMPTY'; }
function baseInteract(dt, fHeld, fEdge, p, nodeD) {
  B.crate = null;
  if (!B.built.length) return false;
  if (B.inside) {
    const b = B.inside, [lx, lz] = toLocal(b.rec, p.x, p.z);
    if (Math.hypot(lx + 1.3, lz + 0.75) < 1.45) {
      if (!b.on) prompt('THE COT. THE SHELTER HAS NO POWER: THE AIR IS NOT HELD. WIRE AN RTG OR A SOLAR PANEL WITHIN 14 M.');
      else { prompt('F: SLEEP ON THE COT (SAVES THE GAME)'); if (fEdge) sleep(() => doAutosave(true)); }
    } else prompt(b.on ? 'SHELTER: PRESSURISED. SUIT AIR AND POWER REFILLING. THE COT (BACK LEFT) SLEEPS AND SAVES.' : 'SHELTER: NO POWER. THE AIR IS NOT HELD. WIRE AN RTG OR A SOLAR PANEL WITHIN 14 M.');
    progressBar(null); return true;
  }
  let best = null, bd = 1e9;
  for (const b of B.built) { if (WALLISH(b.rec.part)) continue; const d = Math.hypot(b.rec.x - p.x, b.rec.z - p.z) - BASE_PARTS[b.rec.part].r; if (d < bd) { bd = d; best = b; } }
  if (!best || bd > 1.5 || nodeD < bd) return false;
  const rec = best.rec, def = BASE_PARTS[rec.part];
  const g = best.grid, gridTxt = g ? `GRID ${g.gen.toFixed(1)} MADE / ${g.need.toFixed(1)} WANTED` : '';
  if (rec.part === 'storage') {
    B.crate = best;
    const n = crateCount(rec);
    prompt(`STORAGE CRATE: ${crateText(rec)} (${n}/${CRATE_CAP})  //  F: PUT YOUR RAW RESOURCES IN  //  G: TAKE ALL OUT`);
    if (fEdge) putIn(rec);
  } else if (rec.part === 'hydro') {
    prompt(`HYDROPONICS DOME: ${!best.on ? 'NO POWER' : rec.on ? Math.floor((rec.g || 0) * 100) + '% GROWN' : 'IDLE: NEEDS 1 WATER + 1 PLANT FIBRE IN THE STORES'}  //  ${gridTxt}`);
  } else if (def.power > 0) {
    prompt(`${def.label}: ${best.on ? 'ON' : 'NO POWER'}  //  ${gridTxt}${best.on ? '' : `. ${g && g.gen > 0 ? 'THE GRID CANNOT CARRY IT: ADD AN RTG OR A SOLAR PANEL.' : 'WIRE AN RTG OR A SOLAR PANEL WITHIN 14 M.'}`}`);
  } else if (rec.part === 'rtg' || rec.part === 'solar') {
    prompt(`${def.label}: ${rec.part === 'solar' ? `MAKING ${(1.5 * landing.dayLevel()).toFixed(1)} (DAYLIGHT)` : 'MAKING 2.5, DAY AND NIGHT'}  //  ${gridTxt}`);
  } else return false;
  progressBar(null);
  return true;
}
function putIn(rec) {
  const R = S.P.res; rec.store = rec.store || {};
  let room = CRATE_CAP - crateCount(rec), moved = 0;
  for (const k of STASH) { const n = Math.min(R[k] || 0, room); if (n > 0) { R[k] -= n; rec.store[k] = (rec.store[k] || 0) + n; room -= n; moved += n; } }
  if (!moved) { flash(room <= 0 ? 'THE CRATE IS FULL (80). BUILD ANOTHER, OR TAKE SOME OUT (G).' : 'NOTHING TO PUT IN: NO ORE, ICE, SALVAGE, CARBON OR FIBRE IN THE STORES.', 2600); return; }
  audio.clank(); flash(`STORED ${moved}. CRATE: ${crateText(rec)}`, 2600); emit('stashed', moved); doAutosave(true);
}
function takeOut(rec) {
  const R = S.P.res, s = rec.store || {}; let moved = 0;
  for (const k of STASH) if (s[k] > 0) { R[k] = (R[k] || 0) + s[k]; moved += s[k]; s[k] = 0; }
  if (!moved) { flash('THE CRATE IS EMPTY.', 1800); return; }
  audio.clank(); flash(`TOOK ${moved} FROM THE CRATE INTO THE SHIP'S STORES.`, 2600); emit('unstashed', moved); doAutosave(true);
}
// G on the ground (outside build mode): take everything out of the crate you are at
export function gKey() { if (!B.crate || S.buildMode || S.mode !== 'eva') return false; takeOut(B.crate.rec); return true; }

// ---------------- build mode on the ground ----------------
const BASE_CARD = 'BUILD A BASE (FIRST TIME)|1-9 OR THE WHEEL PICKS A PART. Q / E TURNS IT. CLICK PLACES IT WHERE THE GHOST IS GREEN (RED: TOO STEEP, SOMETHING IN THE WAY, OR TOO CLOSE TO THE SHIP). PARTS ARE PAID FROM THE SHIP\'S STORES: MINE THE BIG DEPOSITS FOR THEM.|POWER: AN RTG (DAY AND NIGHT) OR A SOLAR PANEL (DAYLIGHT) FEEDS EVERY PART WIRED TO IT: PARTS WITHIN 14 M OF EACH OTHER JOIN UP.|A SHELTER IS A ROOM YOU WALK INTO: ON POWER IT REFILLS THE SUIT, WARMS YOU, AND ITS COT SLEEPS AND SAVES. A STORAGE CRATE KEEPS RESOURCES HERE (F IN, G OUT). WALLS AND DOORWAYS SNAP TO IT.|G TAKES A PART BACK FOR HALF ITS COST. THE BASE STAYS ON THIS WORLD FOR WHEN YOU COME BACK.';
let cardEl = null, cardT = 0;
function showCard() {
  if (!cardEl) {
    cardEl = document.createElement('div'); cardEl.id = 'baseCard';
    cardEl.style.cssText = 'position:fixed;right:18px;top:18vh;width:min(420px,40vw);padding:10px 12px;background:rgba(6,10,14,.84);border:1px dashed #ffb347;color:#ffe0b0;font:12px/1.45 monospace;letter-spacing:.03em;z-index:31;pointer-events:none';
    const [t, ...lines] = BASE_CARD.split('|');
    cardEl.innerHTML = `<b style="color:#ffb347">${t}</b>` + lines.map(l => `<div style="margin-top:5px">${l}</div>`).join('');
    document.body.appendChild(cardEl);
  }
  cardEl.style.display = 'block'; cardT = performance.now();
}
function hideCard() { if (cardEl) cardEl.style.display = 'none'; }
export function toggle() {
  if (S.buildMode) { exitBuild(); audio.click(900); return; }
  if (!landing.onSurface() || S.mode !== 'eva') { flash('BUILD A BASE FROM OUTSIDE, ON THE GROUND.', 2200); return; }
  S.buildMode = true; S.buildSurface = true; S.buildPart = Math.min(S.buildPart, BASE_ORDER.length - 1);
  state.rot = 0;
  if (!S.P.flags.baseCard) { S.P.flags.baseCard = true; showCard(); }
  audio.click(1200);
}
function exitBuild() { S.buildMode = false; S.buildSurface = false; hideGhost(); hideCard(); }
function hideGhost() { if (B.ghost) { if (B.ghost.parent) B.ghost.parent.remove(B.ghost); B.ghost = null; B.ghostPart = null; } }
export const currentPart = () => BASE_ORDER[Math.min(S.buildPart, BASE_ORDER.length - 1)];

// where the ghost goes: ahead of you on the ground, turned, snapped to the nearest part
export function aimPoint(part) {
  const { f } = flatBasis(S.yaw), p = landing.planetXZ(S.pos);
  const pitch = S.pitch;
  let dist = pitch < -0.07 ? Math.min(14, Math.max(2.5, EYE_H / Math.tan(-pitch))) : 9;
  dist = Math.max(dist, BASE_PARTS[part].r + 1.4, WALLISH(part) ? 3.2 : 0);
  return { x: p.x + f.x * dist, z: p.z + f.z * dist, r: S.yaw + state.rot };
}
export function snap(part, x, z, r) {
  // walls and doorways line up with the shelter and each other first; everything else with its nearest part
  let nb = null, nd = 1e9;
  const pool = WALLISH(part) && parts().some(rec => WALLISH(rec.part) && Math.hypot(rec.x - x, rec.z - z) < 8) ? parts().filter(rec => WALLISH(rec.part)) : parts();
  for (const rec of pool) { const d = Math.hypot(rec.x - x, rec.z - z); const lim = rec.part === 'shelter' ? 8 : 6; if (d < lim && d < nd) { nd = d; nb = rec; } }
  if (!nb) return { x, z, r, snapped: null };
  const k = Math.round((r - nb.r) / (Math.PI / 2)), rr = nb.r + k * Math.PI / 2;
  const step = WALLISH(part) && WALLISH(nb.part) ? 2 : 1;
  let [lx, lz] = toLocal(nb, x, z); lx = Math.round(lx / step) * step; lz = Math.round(lz / step) * step;
  const [sx, sz] = toPlanet(nb, lx, lz);
  return { x: sx, z: sz, r: rr, snapped: nb.id };
}
// is there room here: '' if it fits, or the reason in plain words
export function check(part, x, z, r) {
  const pl = landing.planet(), site = terrain.site, def = BASE_PARTS[part];
  if (parts().length >= MAX_PARTS) return `THIS BASE IS AT ITS LIMIT (${MAX_PARTS} PARTS).`;
  const f = FOOT[part] || 0.7, c = Math.cos(r), s = Math.sin(r);
  let lo = 1e9, hi = -1e9;
  for (const [a, b] of [[0, 0], [f, f], [-f, f], [f, -f], [-f, -f], [f, 0], [-f, 0], [0, f], [0, -f]]) { const h = groundAt(pl, x + a * c + b * s, z - a * s + b * c, site); lo = Math.min(lo, h); hi = Math.max(hi, h); }
  const slope = (hi - lo) / (2 * f);
  if (slope > SLOPE_MAX) return `TOO STEEP HERE (${Math.round(Math.atan(slope) * 57.3)} DEG, THE LIMIT IS ${Math.round(Math.atan(SLOPE_MAX) * 57.3)}). FIND FLATTER GROUND.`;
  if (pl.terrain === 'archipelago' && lo <= 0.3) return 'THAT IS THE SEA. BUILD ON DRY GROUND.';
  if (pl.terrain === 'lava' && lo <= pl.lavaLevel + 0.2) return 'THAT IS LAVA. BUILD ON ROCK.';
  if (site) { const lx = x - site.x, lz = z - site.z, m = f + 0.4; if ((Math.abs(lx) < 3.6 + m && lz > -11.5 - m && lz < 5 + m) || Math.hypot(lx - HATCH_EXT.x, lz - HATCH_EXT.z) < 4.2 + f) return 'TOO CLOSE TO THE SHIP. KEEP CLEAR OF THE LEGS, THE HULL AND THE LADDER.'; }
  for (const rec of parts()) {
    const d = Math.hypot(rec.x - x, rec.z - z);
    if (d > 9) continue;
    const a = part, b = rec.part;
    if ((a === 'wall' || a === 'doorway') && (b === 'wall' || b === 'doorway')) { if (d < 1.0) return `A ${BASE_PARTS[b].label} IS ALREADY THERE.`; continue; }
    if (WALLISH(a) && WALLISH(b)) {
      // walls may run along the shelter's edges, never through it (and a shelter never sits on a wall)
      const sh = a === 'shelter' ? { x, z, r } : rec, wl = a === 'shelter' ? rec : { x, z, r };
      if (a === 'shelter' && b === 'shelter') { if (d < 3.95) return 'ANOTHER SHELTER IS IN THE WAY.'; continue; }
      for (const t of [-1.6, 0, 1.6]) { const [px, pz] = toPlanet(wl, t, 0); const [lx, lz] = toLocal(sh, px, pz); if (Math.abs(lx) < 1.85 && Math.abs(lz) < 1.85) return 'THAT WOULD CUT THROUGH THE SHELTER.'; }
      continue;
    }
    if (WALLISH(a) || WALLISH(b)) {
      const wall = WALLISH(a) ? { x, z, r, part: a } : rec, o = WALLISH(a) ? { x: rec.x, z: rec.z, rr: BASE_PARTS[b].r } : { x, z, rr: def.r };
      const [lx, lz] = toLocal(wall, o.x, o.z);
      if (wall.part === 'shelter') { if (Math.abs(lx) < 2 + o.rr && Math.abs(lz) < 2 + o.rr) return 'SOMETHING IS IN THE WAY.'; }
      else if (Math.abs(lx) < 2 + o.rr && Math.abs(lz) < 0.15 + o.rr) return 'SOMETHING IS IN THE WAY.';
      continue;
    }
    if (d < (def.r + BASE_PARTS[b].r) * 0.9) return 'SOMETHING IS IN THE WAY.';
  }
  return '';
}
function aimPart() {
  const { f } = flatBasis(S.yaw), p = landing.planetXZ(S.pos);
  let best = null, bs = 1e9;
  for (const b of B.built) {
    const dx = b.rec.x - p.x, dz = b.rec.z - p.z, d = Math.hypot(dx, dz);
    if (d > 12 || d < 0.01) continue;
    const ang = Math.acos(Math.max(-1, Math.min(1, (dx * f.x + dz * f.z) / d)));
    const lim = Math.max(0.2, Math.atan2(Math.max(BASE_PARTS[b.rec.part].r, WALLISH(b.rec.part) ? 1.8 : 0), d));
    if (ang > lim) continue;
    const sc = ang + d * 0.01; if (sc < bs) { bs = sc; best = b; }
  }
  return best;
}
function updateBuild(dt) {
  if (!S.buildSurface) { hideGhost(); return; }
  if (cardEl && cardEl.style.display !== 'none' && performance.now() - cardT > 40000) hideCard();
  const part = currentPart(), def = BASE_PARTS[part];
  if (held('q') || held('gp_rollL')) state.rot += 1.6 * dt; if (held('e') || held('gp_rollR')) state.rot -= 1.6 * dt;
  const a = aimPoint(part), sn = snap(part, a.x, a.z, a.r);
  const why = check(part, sn.x, sn.z, sn.r);
  state.target = sn; state.removeTarget = aimPart();
  state.ok = !why && canAfford(def.cost);
  state.reason = why ? why : !canAfford(def.cost) ? `NEEDS ${costText(def.cost)}. MINE THE BIG DEPOSITS (HOLD F).` : `CLICK TO BUILD ${def.label}${sn.snapped ? ' (SNAPPED)' : ''}${state.removeTarget ? `   G: TAKE BACK THE ${BASE_PARTS[state.removeTarget.rec.part].label}` : ''}`;
  if (!B.ghost || B.ghostPart !== part) {
    hideGhost();
    B.ghost = partMesh(part); B.ghostPart = part; B.group.add(B.ghost);
    B.ghost.traverse(o => { if (o.isSprite) o.visible = false; });
  }
  const mat = state.ok ? BM.ghostOk : BM.ghostBad;
  B.ghost.traverse(o => { if (o.isMesh) o.material = mat; });
  B.ghost.position.set(sn.x, baseY(landing.planet(), part, sn.x, sn.z, sn.r), sn.z); B.ghost.rotation.y = sn.r;
}
let idSeq = 0;
export function place() {
  if (!S.buildSurface) return false;
  const part = currentPart(), def = BASE_PARTS[part], t = state.target;
  if (!t) return false;
  const why = check(part, t.x, t.z, t.r);
  if (why) { flash(why, 2400); audio.blip(220, 0.03); return false; }
  if (!canAfford(def.cost)) { flash(`NEEDS ${costText(def.cost)}. MINE THE BIG DEPOSITS: HOLD F AT A VEIN, OUTCROP, WRECK OR SEAM.`, 3000); audio.blip(220, 0.03); return false; }
  for (const k in def.cost) S.P.res[k] -= def.cost[k];
  const rec = { id: 'b' + Date.now().toString(36) + (idSeq++), part, x: +t.x.toFixed(3), z: +t.z.toFixed(3), r: +(((t.r % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2)).toFixed(4) };
  if (part === 'storage') rec.store = {};
  if (part === 'hydro') { rec.g = 0; rec.on = false; }
  surfStore().base.push(rec);
  B.dirty = true;
  audio.clank(); S.noise += 3;
  const gen = part === 'rtg' || part === 'solar';
  flash(`${def.label} BUILT. ${def.desc.toUpperCase()}`, 3600);
  if (def.power > 0 && !parts().some(r => r.part === 'rtg' || r.part === 'solar') && !S.P.flags.baseGridSaid) { S.P.flags.baseGridSaid = true; say(`THE ${def.label} NEEDS POWER FROM THE BASE GRID: BUILD AN RTG (PART 3) OR A SOLAR PANEL (PART 4) WITHIN ${WIRE} M OF IT.`, { hold: 14000 }); }
  if (gen && !S.P.flags.baseGenSaid) { S.P.flags.baseGenSaid = true; say(`BASE GRID: EVERY PART WITHIN ${WIRE} M OF ANOTHER IS WIRED TO IT. THE CABLE SHOWS ON THE GROUND.`, { hold: 12000 }); }
  emit('baseBuilt', part);
  doAutosave(true);
  return true;
}
export function removeAimed() {
  if (!S.buildSurface) return false;
  const b = state.removeTarget; if (!b) { flash('AIM AT A PART OF THE BASE TO TAKE IT BACK.', 2000); return false; }
  if (b === B.inside) { flash('STEP OUT OF THE SHELTER FIRST.', 2200); return false; }
  const st = surfStore(), rec = b.rec, cost = BASE_PARTS[rec.part].cost;
  st.base = st.base.filter(r => r.id !== rec.id);
  for (const k in cost) S.P.res[k] = (S.P.res[k] || 0) + Math.floor(cost[k] / 2);
  const kept = crateCount(rec); if (kept) for (const k of STASH) S.P.res[k] = (S.P.res[k] || 0) + (rec.store[k] || 0);
  B.dirty = true; state.removeTarget = null;
  audio.clank();
  flash(`${BASE_PARTS[rec.part].label} TAKEN BACK. HALF ITS PARTS RECOVERED.${kept ? ` ITS ${kept} STORED UNITS WENT BACK TO THE SHIP.` : ''}`, 2800);
  emit('baseRemoved', rec.part); doAutosave(true);
  return true;
}

landing.surfaceHooks.interact = (dt, fHeld, fEdge, p, nodeD) => baseInteract(dt, fHeld, fEdge, p, nodeD) || mineInteract(dt, fHeld, fEdge, p, nodeD);
landing.surfaceHooks.collide = collide;
landing.surfaceHooks.floor = floor;

// ---------------- test surface ----------------
export function debug() {
  const p = landing.onSurface() ? landing.planetXZ(S.pos) : { x: 0, z: 0 }, o = B.o;
  return {
    mode: !!S.buildSurface, part: S.buildSurface ? currentPart() : null, reason: state.reason, ok: state.ok, target: state.target, inside: B.inside ? B.inside.rec.id : null, wires: B.tree || 0,
    card: !!(cardEl && cardEl.style.display !== 'none'), ghost: !!B.ghost, lights: _lp.length,
    parts: B.built.map(b => ({ id: b.rec.id, part: b.rec.part, x: b.rec.x, z: b.rec.z, r: b.rec.r, local: [b.rec.x - o.x, b.rec.z - o.z], y: b.y - ship.position.y, on: b.on, d: Math.hypot(b.rec.x - p.x, b.rec.z - p.z), gen: b.grid ? b.grid.gen : 0, use: b.grid ? b.grid.use : 0, store: b.rec.store ? { ...b.rec.store } : null, g: b.rec.g })),
  };
}
// test hook: put a part at local (ship-frame) x, z without paying, checked the same way
export function testPlace(part, lx, lz, r = 0, force = false) {
  const o = landing.planetXZ(new THREE.Vector3()), x = lx + o.x, z = lz + o.z;
  const why = check(part, x, z, r); if (why && !force) return why;
  const rec = { id: 'bT' + (idSeq++), part, x, z, r }; if (part === 'storage') rec.store = {}; if (part === 'hydro') { rec.g = 0; rec.on = false; }
  surfStore().base.push(rec); B.dirty = true; return rec.id;
}
export function testCheck(part, lx, lz, r = 0) { const o = landing.planetXZ(new THREE.Vector3()); return check(part, lx + o.x, lz + o.z, r); }
