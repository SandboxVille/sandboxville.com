// KESTREL-4: the walkable interior and the exterior hull. Built once; the
// same physical body persists across systems, only the sky changes.
//
// P2 rebuild: the interior is now furnished and readable (panelled walls,
// deck grating, a real window, live console screen, two bunks and two suit
// hooks for a crew of two, one of each conspicuously unused). The exterior
// gains plating, a name stencil, work lights, and twelve hull HARDPOINTS
// that the part-snap building system attaches modules to.
import * as THREE from 'three';
import { ship } from './scene.js';
import { wallPanel, deckGrate, hullPlate, stencil, tornPhoto, makeScreen, glowSprite, wallRelief, grateRelief, normalFromHeight, hullSet } from './textures.js';
import { addInteriorProps, addHullGreebles, updateNavLights, hullLathe } from './props.js';
import { segBox, bakeRoot, mergeStatic, whiteColours } from './bake.js';
import { TETHER_MAX } from '../core/constants.js';

// walkable floor boxes (ship frame, metres). The clamp in movement.js keeps
// the player inside their union.
export const ROOMS = [
  { name: 'console', xmin: -1.8, xmax: 1.8, zmin: -8.95, zmax: -5.6 },
  { name: 'corridor', xmin: -0.62, xmax: 0.62, zmin: -5.9, zmax: -0.6 },
  { name: 'airlock', xmin: -1.2, xmax: 1.2, zmin: -0.75, zmax: 1.85 },
];
export const HULL_A = new THREE.Vector3(0, 1.1, -12.5), HULL_B = new THREE.Vector3(0, 1.1, 5.5), HULL_R = 3.3;
export const HATCH_INT = new THREE.Vector3(0, 1.0, 1.9);
export const HATCH_EXT = new THREE.Vector3(3.9, 1.1, 1.0);
export const ANTENNA_POS = new THREE.Vector3(0, 5.3, -11.0);
export const THRUSTER_POS = new THREE.Vector3(0, 1.1, 7.2);
export const PANEL_POS = new THREE.Vector3(-4.2, 1.1, -4.5);
export const SECRET_POS = new THREE.Vector3(0.6, -3.6, -5.0);
export const CONSOLE_POS = new THREE.Vector3(0, 1.0, -8.6);
export const BUNK_POS = new THREE.Vector3(-0.95, 0.7, -4.4);

export function nodeList() {
  return [
    { key: 'power', label: 'POWER PANEL', pos: PANEL_POS },
    { key: 'comms', label: 'ANTENNA', pos: ANTENNA_POS },
    { key: 'thrusters', label: 'THRUSTER', pos: THRUSTER_POS },
  ];
}

// ---------- hull hardpoints: where built modules snap on ----------
export const HARDPOINTS = (() => {
  const defs = [[90, -7], [90, -2], [90, 3], [0, -8], [0, -3.5], [180, -9], [180, 0.5], [270, -8], [270, 1], [135, -5.5], [45, -5.5], [315, -3.5]];
  return defs.map(([deg, z], i) => {
    const a = THREE.MathUtils.degToRad(deg);
    const n = new THREE.Vector3(Math.cos(a), Math.sin(a), 0);
    return { id: 'h' + i, pos: new THREE.Vector3(n.x * HULL_R, 1.1 + n.y * HULL_R, z), normal: n };
  });
})();

// live references the game loop animates
export const shipFx = {
  lamps: [],           // { light, base, color }
  emissives: [],       // materials that glow with ship power
  screen: null,        // { canvas, g, tex } -- the console status screen
  hatchLight: null, beacon: null, fixtureMarkers: {}, secretGlint: null,
  workLights: [], window: null, tally: null,
};

// the fixtures' diffuser: bright cells behind a dark louver grid (drawn once)
function louverTex() {
  const c = document.createElement('canvas'); c.width = 64; c.height = 128; const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, 64, 128);
  const gr = g.createRadialGradient(32, 64, 4, 32, 64, 80); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.35)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 128);
  g.fillStyle = 'rgba(0,0,0,0.78)';
  for (let x = 0; x <= 64; x += 16) g.fillRect(x - 1.5, 0, 3, 128);
  for (let y = 0; y <= 128; y += 16) g.fillRect(0, y - 1.5, 64, 3);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

let MAT = null;
function mats() {
  if (MAT) return MAT;
  const wallT = wallPanel(3), wallT2 = wallPanel(9, [34, 36, 40]);
  const wallN = normalFromHeight(wallRelief(3), 2.2), wallN2 = normalFromHeight(wallRelief(9), 2.2);
  const floorT = deckGrate(); floorT.repeat.set(3, 3);
  const floorN = normalFromHeight(grateRelief(), 3.0, 3, 3);
  const hull = hullSet(3, 4, 3);
  MAT = {
    wall: new THREE.MeshStandardMaterial({ map: wallT, color: 0xb8bcc6, roughness: 0.72, metalness: 0.35, normalMap: wallN, normalScale: new THREE.Vector2(0.9, 0.9) }),
    wall2: new THREE.MeshStandardMaterial({ map: wallT2, color: 0xb0b4bc, roughness: 0.75, metalness: 0.3, normalMap: wallN2, normalScale: new THREE.Vector2(0.9, 0.9) }),
    floor: new THREE.MeshStandardMaterial({ map: floorT, color: 0x9a9ca4, roughness: 0.55, metalness: 0.6, normalMap: floorN }),
    ceil: new THREE.MeshStandardMaterial({ color: 0x1c1d22, roughness: 0.9, metalness: 0.2 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x0f1013, roughness: 0.7, metalness: 0.5 }),
    metal: new THREE.MeshStandardMaterial({ color: 0x55585f, roughness: 0.5, metalness: 0.45 }),
    trim: new THREE.MeshStandardMaterial({ color: 0x5a4a2a, roughness: 0.5, metalness: 0.6 }),
    fabric: new THREE.MeshStandardMaterial({ color: 0x3b3a34, roughness: 0.95 }),
    blanket: new THREE.MeshStandardMaterial({ color: 0x2c3a4a, roughness: 0.95 }),
    suit: new THREE.MeshStandardMaterial({ color: 0x847f72, roughness: 0.88, metalness: 0.05 }),
    hull: new THREE.MeshStandardMaterial({ map: hull.map, color: 0xd4d4da, roughness: 1.0, roughnessMap: hull.roughnessMap, metalness: 0.35, normalMap: hull.normalMap, normalScale: new THREE.Vector2(1, 1) }),
    // the ceiling fixtures' diffusers: brighter than white so they bloom when the finish is on
    // (not tone-mapped: ACES turns a hot red toward peach; unmapped, the emergency red stays red, and
    // values over 1 give the bloom more to work with when the finish is on)
    strip: new THREE.MeshBasicMaterial({ map: louverTex(), color: new THREE.Color(1.35, 1.1, 0.82), toneMapped: false }),
    red: new THREE.MeshBasicMaterial({ color: 0xff3020 }),
    amber: new THREE.MeshBasicMaterial({ color: 0xffb347 }),
    // P3: an unlit tint, not a mirror: the lamp reflections sat on top of the stars like smudges
    glass: new THREE.MeshBasicMaterial({ color: 0x1a2430, transparent: true, opacity: 0.08, depthWrite: false }),
  };
  return MAT;
}

function box(parent, mat, cx, cy, cz, sx, sy, sz) {
  const m = new THREE.Mesh(segBox(sx, sy, sz), mat);
  m.position.set(cx, cy, cz); parent.add(m); return m;
}
function addLamp(parent, color, intensity, dist, x, y, z, kind) {
  const l = new THREE.PointLight(color, intensity, dist, 1.6);
  l.position.set(x, y, z); parent.add(l);
  shipFx.lamps.push({ light: l, base: intensity, kind });
  return l;
}

function buildInterior(M) {
  const g = new THREE.Group(); ship.add(g);
  // ---- console room: z -9.4 .. -5.35, walls at x = +-2.04 ----
  box(g, M.floor, 0, 0.0, -7.375, 4.2, 0.12, 4.05);
  box(g, M.ceil, 0, 2.3, -7.375, 4.2, 0.12, 4.05);
  box(g, M.wall, -2.06, 1.15, -7.375, 0.12, 2.3, 4.05);
  box(g, M.wall, 2.06, 1.15, -7.375, 0.12, 2.3, 4.05);
  // fore wall with the window hole (x -1.6..1.6, y 0.9..2.0)
  box(g, M.wall2, 0, 0.45, -9.42, 4.2, 0.9, 0.12);
  box(g, M.wall2, 0, 2.17, -9.42, 4.2, 0.34, 0.12);
  box(g, M.wall2, -1.83, 1.45, -9.42, 0.46, 1.1, 0.12);
  box(g, M.wall2, 1.83, 1.45, -9.42, 0.46, 1.1, 0.12);
  // window frame + faint glass
  const fr = M.metal;
  box(g, fr, 0, 0.9, -9.38, 3.3, 0.06, 0.08); box(g, fr, 0, 2.0, -9.38, 3.3, 0.06, 0.08);
  box(g, fr, -1.62, 1.45, -9.38, 0.06, 1.16, 0.08); box(g, fr, 1.62, 1.45, -9.38, 0.06, 1.16, 0.08);
  box(g, fr, 0, 1.45, -9.38, 0.04, 1.1, 0.06);
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.1), M.glass);
  glass.position.set(0, 1.45, -9.4); g.add(glass); shipFx.window = glass;
  // aft shoulders (console room is wider than the corridor) + header
  box(g, M.wall, 1.68, 1.15, -5.32, 0.76, 2.3, 0.12);
  box(g, M.wall, -1.68, 1.15, -5.32, 0.76, 2.3, 0.12);
  box(g, M.wall, 0, 2.2, -5.32, 2.6, 0.2, 0.12);
  // desk under the window, two chairs (one pushed back: nobody sat in it)
  box(g, M.dark, 0, 0.42, -8.95, 3.0, 0.84, 0.7);
  box(g, M.trim, 0, 0.85, -8.62, 3.0, 0.04, 0.06);
  const chair = (x, z, rot) => {
    const c = new THREE.Group(); c.position.set(x, 0, z); c.rotation.y = rot; g.add(c);
    box(c, M.dark, 0, 0.47, 0, 0.5, 0.05, 0.5); box(c, M.fabric, 0, 0.52, -0.01, 0.46, 0.07, 0.44);
    box(c, M.dark, 0, 0.86, 0.25, 0.48, 0.66, 0.05); box(c, M.fabric, 0, 0.84, 0.215, 0.42, 0.5, 0.05);
    box(c, M.fabric, 0, 1.26, 0.235, 0.26, 0.14, 0.06);
    [-1, 1].forEach(sx => { box(c, M.dark, sx * 0.25, 0.68, -0.02, 0.05, 0.04, 0.36); box(c, M.dark, sx * 0.25, 0.6, 0.12, 0.04, 0.16, 0.04); });
    box(c, M.metal, 0, 0.25, 0, 0.07, 0.42, 0.07);
    for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2; const leg = box(c, M.dark, Math.sin(a) * 0.16, 0.06, Math.cos(a) * 0.16, 0.05, 0.04, 0.34); leg.rotation.y = a; }
  };
  chair(-0.72, -7.95, 0.0); chair(0.9, -7.2, 0.7); // the left chair is the helm (P3)
  // the live status screen (drawn by ui/hud.js) + two static side screens
  shipFx.screen = makeScreen(512, 256);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.55), new THREE.MeshBasicMaterial({ map: shipFx.screen.tex, toneMapped: false }));
  scr.position.set(0.5, 1.18, -9.05); scr.rotation.x = -0.35; scr.rotation.y = 0.18; g.add(scr); // right of the helm, so the pilot sees out
  const side = (x, txt) => {
    const t = stencil(txt, { w: 256, h: 128, font: 'bold 26px monospace', color: 'rgba(120,220,255,0.9)', worn: 0.05 });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.3), new THREE.MeshBasicMaterial({ map: t, color: 0x6fd0ff, toneMapped: false, transparent: true }));
    m.position.set(x, 1.1, -9.1); m.rotation.x = -0.35; g.add(m); shipFx.emissives.push(m.material);
  };
  side(1.28, 'NAV / NO LOCK'); side(-1.28, 'D-7: DEFER');
  // equipment rack on the port wall with status LEDs
  box(g, M.dark, -1.85, 1.1, -6.6, 0.3, 1.9, 1.2);
  for (let i = 0; i < 10; i++) { const led = box(g, i % 3 === 0 ? M.red : M.amber, -1.69, 0.5 + (i % 5) * 0.3, -6.2 - Math.floor(i / 5) * 0.5, 0.02, 0.03, 0.05); led.userData.led = i; shipFx.emissives.push(led.material); }
  // ceiling light fixtures: see props.js (the diffusers use M.strip)
  M.strip.userData.strip = true;
  shipFx.emissives.push(M.strip);

  // ---- corridor: z -5.35 .. -0.95, walls at x = +-1.3 ----
  box(g, M.floor, 0, 0.0, -3.15, 2.6, 0.12, 4.4);
  box(g, M.ceil, 0, 2.15, -3.15, 2.6, 0.12, 4.4);
  box(g, M.wall2, -1.32, 1.08, -3.15, 0.12, 2.15, 4.4);
  box(g, M.wall2, 1.32, 1.08, -3.15, 0.12, 2.15, 4.4);
  // bunks recessed into the walls: yours made, theirs stripped to the frame
  const bunk = (x, made) => {
    const dir = Math.sign(x);
    box(g, M.dark, x, 0.45, -4.4, 0.62, 0.1, 1.9);
    box(g, M.dark, x, 1.45, -4.4, 0.62, 0.06, 1.9);  // shelf above
    box(g, M.metal, x - dir * 0.3, 0.7, -5.33, 0.04, 0.5, 0.04);
    box(g, M.metal, x - dir * 0.3, 0.7, -3.47, 0.04, 0.5, 0.04);
    const madeG = new THREE.Group(), bareG = new THREE.Group(); g.add(madeG, bareG);
    box(madeG, M.fabric, x, 0.55, -4.4, 0.56, 0.1, 1.82);
    box(madeG, M.blanket, x, 0.62, -4.1, 0.56, 0.06, 1.1).rotation.z = 0.03;
    box(madeG, M.fabric, x, 0.64, -5.05, 0.4, 0.08, 0.3);
    // bare frame slats and one strap hanging loose
    for (let i = 0; i < 6; i++) box(bareG, M.metal, x, 0.52, -5.2 + i * 0.32, 0.56, 0.03, 0.05);
    box(bareG, M.fabric, x - dir * 0.26, 0.3, -4.0, 0.04, 0.4, 0.05).rotation.z = 0.2;
    madeG.visible = made; bareG.visible = !made;
    return { madeG, bareG };
  };
  bunk(-0.95, true);
  const b2 = bunk(0.95, false); shipFx.bunk2Made = b2.madeG; shipFx.bunk2Bare = b2.bareG; // P3: Act II makes it
  // name tags above each bunk: yours is worn, theirs has been scratched out
  const tagA = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.12), new THREE.MeshStandardMaterial({ map: stencil('CREW 1', { w: 256, h: 64, font: 'bold 34px monospace' }), transparent: true, roughness: 0.8, emissive: 0x201810, emissiveMap: null }));
  tagA.position.set(-1.255, 1.62, -4.4); tagA.rotation.y = Math.PI / 2; g.add(tagA);
  const tagB = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.12), new THREE.MeshStandardMaterial({ map: stencil('CREW 2', { w: 256, h: 64, font: 'bold 34px monospace', worn: 3.5, seed: 5 }), transparent: true, roughness: 0.8, emissive: 0x201810 }));
  tagB.position.set(1.255, 1.62, -4.4); tagB.rotation.y = -Math.PI / 2; g.add(tagB);
  // the torn photo, where you would see it every walk to the airlock
  const photo = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.33), new THREE.MeshStandardMaterial({ map: tornPhoto(), roughness: 0.9 }));
  photo.position.set(-1.25, 1.35, -2.6); photo.rotation.y = Math.PI / 2; g.add(photo);
  // tally marks scratched by the bunk (redrawn by the survival system after each sleep)
  const tallyCanvas = document.createElement('canvas'); tallyCanvas.width = 256; tallyCanvas.height = 128;
  const tallyTex = new THREE.CanvasTexture(tallyCanvas); tallyTex.colorSpace = THREE.SRGBColorSpace;
  const tally = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.3), new THREE.MeshBasicMaterial({ map: tallyTex, transparent: true }));
  tally.position.set(-1.255, 1.05, -3.4); tally.rotation.y = Math.PI / 2; g.add(tally);
  shipFx.tally = { canvas: tallyCanvas, tex: tallyTex };
  drawTally(11);
  // lockers at the aft end, pipes along the ceiling corners, a light strip
  for (let i = 0; i < 3; i++) box(g, M.metal, 1.14, 1.0, -2.3 + i * 0.5, 0.3, 1.9, 0.46);
  [-1.15, 1.15].forEach(x => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 4.4, 8), M.metal); p.rotation.x = Math.PI / 2; p.position.set(x, 2.0, -3.15); g.add(p); });
  // corridor shoulders into the airlock
  box(g, M.wall, 1.42, 1.08, -0.92, 0.2, 2.15, 0.12); box(g, M.wall, -1.42, 1.08, -0.92, 0.2, 2.15, 0.12);

  // ---- airlock: z -0.95 .. 2.14, walls at x = +-1.49 ----
  box(g, M.floor, 0, 0.0, 0.6, 3.1, 0.12, 3.2);
  box(g, M.ceil, 0, 2.15, 0.6, 3.1, 0.12, 3.2);
  box(g, M.wall, -1.51, 1.08, 0.6, 0.12, 2.15, 3.2);
  box(g, M.wall, 1.51, 1.08, 0.6, 0.12, 2.15, 3.2);
  box(g, M.wall2, 0, 1.08, 2.16, 3.1, 2.15, 0.12);
  // the hatch: round door, hazard ring, status light
  const hatch = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.08, 28), M.metal);
  hatch.rotation.x = Math.PI / 2; hatch.position.set(0, 1.05, 2.08); g.add(hatch);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.05, 8, 32), M.trim); ring.position.set(0, 1.05, 2.07); g.add(ring);
  const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.03, 6, 16), M.dark); wheel.position.set(0, 1.05, 2.02); g.add(wheel);
  const hl = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), new THREE.MeshBasicMaterial({ color: 0xff3020 }));
  hl.position.set(0.85, 1.75, 2.06); g.add(hl); shipFx.hatchLight = hl;
  const lbl = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.2), new THREE.MeshBasicMaterial({ map: stencil('AIRLOCK', { w: 512, h: 112 }), transparent: true }));
  lbl.position.set(0, 1.9, 2.09); lbl.rotation.y = Math.PI; g.add(lbl);
  // suit rack: two hooks, one suit. Crew of two.
  box(g, M.metal, -1.38, 1.85, 0.6, 0.12, 0.06, 1.4);
  const suitGroup = new THREE.Group(); suitGroup.position.set(-1.25, 0, 0.25); g.add(suitGroup);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.2, 0.42, 4, 10), M.suit); torso.position.y = 1.25; suitGroup.add(torso);
  const pack = box(suitGroup, M.dark, -0.14, 1.28, 0, 0.14, 0.5, 0.36);
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 10), M.suit); helm.position.set(0, 1.7, 0); suitGroup.add(helm);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 8, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0x0a0a0c, roughness: 0.1, metalness: 0.8 }));
  visor.position.set(0.07, 1.71, 0); visor.rotation.y = Math.PI / 2; suitGroup.add(visor);
  [-0.26, 0.26].forEach(z => { const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.45, 3, 6), M.suit); a.position.set(0.02, 1.15, z); a.rotation.x = z > 0 ? -0.12 : 0.12; suitGroup.add(a); });
  [-0.1, 0.1].forEach(z => { const l = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.5, 3, 6), M.suit); l.position.set(0, 0.68, z); suitGroup.add(l); });
  void pack;
  shipFx.suitOnRack = suitGroup;
  // P3: the second suit. Not there. Until the manifest says it is.
  const suit2 = suitGroup.clone(); suit2.position.set(-1.25, 0, 1.0); suit2.visible = false; g.add(suit2); shipFx.suit2 = suit2;
  const hookB = box(g, M.metal, -1.3, 1.75, 1.0, 0.16, 0.04, 0.04);
  hookB.userData.emptyHook = true;
  // workbench / fabricator on the starboard wall
  box(g, M.dark, 1.25, 0.45, 0.8, 0.45, 0.9, 1.3);
  const fab = makeScreen(256, 128); const fg = fab.g;
  fg.fillStyle = '#001216'; fg.fillRect(0, 0, 256, 128); fg.fillStyle = '#6fd0ff'; fg.font = 'bold 20px monospace'; fg.fillText('FABRICATOR', 20, 40); fg.font = '15px monospace'; fg.fillText('USE THE CONSOLE (R)', 20, 76); fg.fillText('TO REFINE + BUILD', 20, 100); fab.tex.needsUpdate = true;
  const fabScr = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.25), new THREE.MeshBasicMaterial({ map: fab.tex, toneMapped: false }));
  fabScr.position.set(1.44, 1.3, 0.8); fabScr.rotation.y = -Math.PI / 2; g.add(fabScr); shipFx.emissives.push(fabScr.material);
  // W0: the PRE-EVA placard by the hatch (EXAMINE reads it in full: systems/interaction.js)
  {
    const pc = makeScreen(256, 192), pg = pc.g;
    pg.fillStyle = '#23261f'; pg.fillRect(0, 0, 256, 192);
    pg.strokeStyle = 'rgba(255,179,71,0.6)'; pg.lineWidth = 4; pg.strokeRect(6, 6, 244, 180);
    pg.fillStyle = 'rgba(255,190,90,0.92)'; pg.font = 'bold 30px monospace'; pg.fillText('PRE-EVA', 22, 46);
    pg.font = 'bold 20px monospace';
    ['LAMP ........ L', 'AIR ..... 5 MIN', `LINE ..... ${TETHER_MAX} M`, 'T: UNCLIP / CLIP'].forEach((t, i) => pg.fillText(t, 22, 84 + i * 28));
    pc.tex.needsUpdate = true;
    const plac = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.26), new THREE.MeshStandardMaterial({ map: pc.tex, roughness: 0.7, metalness: 0.2, emissive: 0x201810 }));
    plac.position.set(1.44, 1.45, 1.62); plac.rotation.y = -Math.PI / 2; g.add(plac);
  }
  // W0: the note taped by the other bunk. Not your handwriting. (Its lines live in ui/howto.js.)
  {
    const nc = makeScreen(192, 144), ng = nc.g;
    ng.fillStyle = '#d6cfbb'; ng.fillRect(0, 0, 192, 144);
    ng.fillStyle = 'rgba(200,190,160,0.9)'; ng.fillRect(70, 0, 52, 12);
    ng.strokeStyle = 'rgba(40,34,28,0.85)'; ng.lineWidth = 2.2;
    for (let row = 0; row < 3; row++) {
      ng.beginPath(); let x = 14; const y = 42 + row * 34; ng.moveTo(x, y);
      while (x < 176 - row * 18) { x += 5; ng.lineTo(x, y + Math.sin(x * 0.45 + row) * 5 + Math.sin(x * 0.13) * 2); }
      ng.stroke();
    }
    ng.fillStyle = 'rgba(60,50,40,0.25)'; ng.fillRect(18, 70, 120, 12); ng.fillRect(30, 104, 96, 10);
    nc.tex.needsUpdate = true;
    const note = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.18), new THREE.MeshStandardMaterial({ map: nc.tex, roughness: 0.95 }));
    note.position.set(1.255, 1.3, -3.05); note.rotation.y = -Math.PI / 2; note.rotation.z = 0.05; g.add(note);
  }

  // Galley controls face into the console room; no extra dynamic lights. (z must match galley.js stations)
  for (const [z, label] of [[-5.95, 'EAT RATION'], [-6.55, 'DRINK WATER'], [-7.15, 'PRINT MEAL'], [-7.75, 'MELT ICE'], [-8.35, 'RECLAIMER'], [-8.95, 'COOK']]) {
    box(g, new THREE.MeshStandardMaterial({ color: 0x263c40, roughness: 0.7 }), 1.73, 1.1, z, 0.14, 0.7, 0.5);
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.18), new THREE.MeshBasicMaterial({ map: stencil(label, { w: 512, h: 160, font: 'bold 46px monospace', color: '#b9e4d9', worn: 0.02 }), transparent: true }));
    plate.position.set(1.65, 1.35, z); plate.rotation.y = -Math.PI / 2; g.add(plate);
  }
  // gfx pass: fixtures, cables, grab bars, the things two people leave lying around
  addInteriorProps(g, M, shipFx);
  // lamps (fixed count; intensities follow ship power every frame), just under each fixture's diffuser
  addLamp(g, 0xffd4a0, 26, 10, 0, 2.02, -7.2, 'main');
  addLamp(g, 0xffd4a0, 16, 8, 0, 1.9, -3.3, 'main');
  addLamp(g, 0xffd4a0, 14, 8, 0, 1.9, 0.6, 'main');
  const amb = new THREE.AmbientLight(0x1a1e28, 0.9); g.add(amb);
  const hemi = new THREE.HemisphereLight(0x303848, 0x0a0806, 0.5); g.add(hemi);
  shipFx.ambient = amb; shipFx.hemi = hemi;
  // baked light: ambient occlusion plus each lamp's soft shadow, then one draw call per material
  const toggled = new Set([shipFx.bunk2Made, shipFx.bunk2Bare, shipFx.suitOnRack, shipFx.suit2]);
  const inToggled = o => { for (let p = o; p && p !== g; p = p.parent) if (toggled.has(p)) return true; return false; };
  const lamps = shipFx.lamps.map(L => ({ pos: L.light.position.clone(), range: L.light.distance, weight: L.base }));
  shipFx.bakeInterior = bakeRoot(g, lamps, { skipOccluder: o => inToggled(o) });
  whiteColours(g);
  shipFx.mergedInterior = mergeStatic(g, o => !inToggled(o) && !o.material.transparent && o !== shipFx.window);
  return g;
}

export function drawTally(days) {
  if (!shipFx.tally) return;
  const { canvas: c, tex } = shipFx.tally, g = c.getContext('2d');
  g.clearRect(0, 0, 256, 128);
  g.strokeStyle = 'rgba(220,210,190,0.55)'; g.lineWidth = 3;
  let x = 10;
  for (let i = 0; i < days && x < 246; i++) {
    const inGroup = i % 5;
    if (inGroup === 4) { g.beginPath(); g.moveTo(x - 30, 28); g.lineTo(x + 2, 96); g.stroke(); x += 14; continue; }
    g.beginPath(); g.moveTo(x, 24 + (i * 7) % 5); g.lineTo(x + 2, 100); g.stroke(); x += 8;
  }
  tex.needsUpdate = true;
}

function buildExterior(M) {
  const g = new THREE.Group(); ship.add(g);
  const hull = new THREE.Mesh(hullLathe(HULL_R, HULL_B.z - HULL_A.z), M.hull);
  hull.rotation.x = Math.PI / 2; hull.position.set(0, 1.1, (HULL_A.z + HULL_B.z) / 2);
  g.add(hull);
  // hull name stencil on both flanks
  [1, -1].forEach(side => {
    const name = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.3), new THREE.MeshStandardMaterial({ map: stencil('KESTREL-4', { w: 1024, h: 220, font: 'bold 150px monospace' }), transparent: true, roughness: 0.7 }));
    name.position.set(side * (HULL_R + 0.02), 2.4, -5); name.rotation.y = side * Math.PI / 2; g.add(name);
  });
  // pipe runs (the hull bands, rails and boxes are in props.js)
  const ribMat = M.metal;
  for (let i = 1; i < 6; i += 2) {
    const ang = THREE.MathUtils.degToRad(20 + i * 61);
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 16, 6), ribMat);
    p.rotation.x = Math.PI / 2; p.position.set(Math.cos(ang) * (HULL_R + 0.12), 1.1 + Math.sin(ang) * (HULL_R + 0.12), -3.5); g.add(p);
    // clamps that hold it to the hull
    for (let z = -11; z <= 4.1; z += 1.9) { const c = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.2, 0.08), M.dark); c.position.set(Math.cos(ang) * (HULL_R + 0.09), 1.1 + Math.sin(ang) * (HULL_R + 0.09), z); c.rotation.z = ang - Math.PI / 2; g.add(c); }
  }
  // radiator fins aft
  [1, -1].forEach(s => { const f = box(g, M.dark, s * 4.6, 1.1, 3.5, 2.4, 0.05, 2.6); f.rotation.z = s * 0.1; });
  // observation port glow at the nose
  const port = new THREE.Mesh(new THREE.CircleGeometry(1.1, 24), new THREE.MeshBasicMaterial({ color: 0x331a08, toneMapped: false }));
  port.position.set(0, 1.4, HULL_A.z - HULL_R - 0.01); port.rotation.y = Math.PI; g.add(port); shipFx.noseGlow = port.material;

  // fixtures: antenna (comms), thruster (thrusters), power panel (power)
  const fx = (key, grp, markerY) => {
    const mk = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 10), new THREE.MeshBasicMaterial({ color: 0xffb347, toneMapped: false }));
    mk.position.y = markerY; grp.add(mk);
    shipFx.fixtureMarkers[key] = mk;
  };
  // 2026-09-28 (David: the satellite he repaired "still showed as broken looking"): each fixture now has a
  // broken look and a repaired look, driven every frame from S.P.repair by updateFixtures(), so a loaded save
  // shows the right one too. Broken: knocked out of line, a scorch mark, a loose part, sparks, a blinking red
  // lamp. Repaired: in line, clean, whole, a steady green lamp (and the dish sweeps, the bell glows).
  const decal = (r, op = 0.78) => new THREE.Mesh(new THREE.CircleGeometry(r, 20), new THREE.MeshBasicMaterial({ color: 0x050403, transparent: true, opacity: op, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2 }));
  const sparkBall = () => new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 6), new THREE.MeshBasicMaterial({ color: 0x9fd8ff, toneMapped: false }));
  const lampBall = () => new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), new THREE.MeshBasicMaterial({ color: 0x200404, toneMapped: false }));
  const rod = (a, b, r, mat) => { const d = b.clone().sub(a); const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, d.length(), 6), mat); m.position.copy(a).add(b).multiplyScalar(0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); return m; };
  const dishMat = new THREE.MeshStandardMaterial({ color: 0x8a8e96, roughness: 0.45, metalness: 0.5, side: THREE.DoubleSide });
  shipFx.fixtures = {};
  { // antenna: mast + dish (the "satellite")
    const a = new THREE.Group(); a.position.copy(ANTENNA_POS); g.add(a);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 2.0, 8), M.metal); mast.position.y = -0.9; a.add(mast);
    // the dish on a pivot at the top of the mast; its boresight is the pivot's +y
    const pivot = new THREE.Group(); pivot.position.y = 0.12; a.add(pivot);
    const cap = new THREE.SphereGeometry(0.9, 20, 8, 0, Math.PI * 2, 0, 0.9); cap.translate(0, -0.9, 0); cap.rotateX(Math.PI);
    const dish = new THREE.Mesh(cap, dishMat); pivot.add(dish);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.16, 10), M.dark); hub.position.y = -0.04; pivot.add(hub);
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.26, 8), M.dark); horn.rotation.x = Math.PI; horn.position.y = 0.46; pivot.add(horn);
    const rim = 0.9 * Math.sin(0.9), rimY = 0.9 - 0.9 * Math.cos(0.9), feed = new THREE.Vector3(0, 0.46, 0);
    const struts = [0, 1, 2].map(i => { const an = i * Math.PI * 2 / 3 + 0.4; const m = rod(new THREE.Vector3(Math.cos(an) * rim, rimY, Math.sin(an) * rim), feed, 0.018, M.metal); pivot.add(m); return m; });
    // broken only: the snapped third strut hanging off the rim, a scorch on the dish, a cable out of the hub, sparks
    const an2 = 2 * Math.PI * 2 / 3 + 0.4;
    const loose = new THREE.Group(); loose.position.set(Math.cos(an2) * rim, rimY, Math.sin(an2) * rim); pivot.add(loose);
    loose.add(rod(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.06, -0.5, 0.04), 0.018, M.metal));
    const scorch = decal(0.3); scorch.rotation.x = -Math.PI / 2; scorch.position.set(0.18, 0.07, 0.12); pivot.add(scorch);
    const cable = rod(new THREE.Vector3(0.05, 0.02, 0), new THREE.Vector3(0.22, -0.75, 0.1), 0.012, M.dark); a.add(cable);
    const sp = sparkBall(); sp.position.set(0.08, 0.05, 0.05); a.add(sp);
    const lamp = lampBall(); lamp.position.set(0.11, -0.55, 0); a.add(lamp);
    shipFx.fixtures.comms = { group: a, pivot, horn, struts, loose, scorch, cable, sparks: sp, lamp, state: '' };
    fx('comms', a, 1.1);
  }
  { // thruster: engine bell aft (the wide mouth is at +z)
    // (2026-09-28: the bell used to sit at THRUSTER_POS, wholly inside the hull's aft cap (the cap reaches z 8.8),
    // so nobody ever saw it, broken or mended. It now sticks out of the cap; the repair spot is unchanged.)
    const t = new THREE.Group(); t.position.copy(THRUSTER_POS).add(new THREE.Vector3(0, 0, 2.1)); g.add(t);
    const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.2, 1.8, 20, 1, true), new THREE.MeshStandardMaterial({ color: 0x2a2624, roughness: 0.4, metalness: 0.9, side: THREE.DoubleSide }));
    bell.rotation.x = -Math.PI / 2; t.add(bell);
    const throat = new THREE.Mesh(new THREE.CircleGeometry(0.66, 16), new THREE.MeshBasicMaterial({ color: 0x100804 })); throat.position.z = -0.45; t.add(throat);
    shipFx.thrusterThroat = throat.material;
    // broken only: soot round the mouth, a heat shield panel hanging off the collar, sparks at the throat
    const soot = new THREE.Mesh(new THREE.TorusGeometry(1.14, 0.1, 6, 28), new THREE.MeshBasicMaterial({ color: 0x050403, transparent: true, opacity: 0.85, depthWrite: false })); soot.position.z = 0.88; t.add(soot);
    const hang = new THREE.Group(); hang.position.set(0.84, 0.3, -0.2); t.add(hang);
    const panelL = box(hang, M.metal, 0.05, -0.28, 0, 0.04, 0.56, 0.5); panelL.rotation.z = 0.35;
    const panelF = box(t, M.metal, 0.86, 0.0, -0.2, 0.04, 0.56, 0.5); // fitted on the bell
    const sp = sparkBall(); sp.position.set(0.45, 0.3, -0.35); t.add(sp);
    const lamp = lampBall(); lamp.position.set(0, 0.92, -0.3); t.add(lamp);
    shipFx.fixtures.thrusters = { group: t, throat: throat.material, soot, loose: hang, fitted: panelF, sparks: sp, lamp, state: '' };
    fx('thrusters', t, 1.6);
  }
  { // power panel: a bus box on the port flank; broken, its cover hangs open and it arcs
    const p = new THREE.Group(); p.position.copy(PANEL_POS); g.add(p);
    box(p, M.metal, 0.3, 0, 0, 0.6, 1.4, 1.8);
    const hinge = new THREE.Group(); hinge.position.set(-0.05, 0.3, 0.85); p.add(hinge);
    box(hinge, M.dark, 0, 0, -0.55, 0.08, 0.9, 1.1);
    const sparks = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 6), new THREE.MeshBasicMaterial({ color: 0x9fd8ff, toneMapped: false }));
    sparks.position.set(-0.05, -0.2, -0.2); p.add(sparks); shipFx.sparks = sparks;
    const scorch = decal(0.34); scorch.rotation.y = -Math.PI / 2; scorch.position.set(-0.012, -0.28, -0.3); p.add(scorch);
    const lamp = lampBall(); lamp.position.set(-0.04, 0.6, -0.72); p.add(lamp);
    shipFx.fixtures.power = { group: p, cover: hinge, sparks, scorch, lamp, state: '' };
    fx('power', p, 1.1);
  }
  // the off-path secret (kept from Chapter 1): a canister under the hull
  {
    const s = new THREE.Group(); s.position.copy(SECRET_POS); g.add(s);
    s.add(new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.55, 10), new THREE.MeshStandardMaterial({ color: 0x2c2f33, roughness: 0.5, metalness: 0.65 })));
    const glint = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshBasicMaterial({ color: 0x9fd8ff }));
    glint.position.y = 0.34; s.add(glint); shipFx.secretGlint = glint;
    shipFx.secretGroup = s;
  }
  // exterior hatch ring + work light
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.1, 8, 24), M.trim);
  ring.position.set(HULL_R + 0.05, 1.1, 1.0); ring.rotation.y = Math.PI / 2; g.add(ring);
  const hatchDoor = new THREE.Mesh(new THREE.CircleGeometry(0.72, 24), M.metal); hatchDoor.position.set(HULL_R + 0.06, 1.1, 1.0); hatchDoor.rotation.y = Math.PI / 2; g.add(hatchDoor);
  const hatchLamp = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshBasicMaterial({ color: 0x40ff80, toneMapped: false }));
  hatchLamp.position.set(HULL_R + 0.1, 2.1, 1.0); g.add(hatchLamp); shipFx.extHatchLamp = hatchLamp;
  // two exterior work lights (point lights; intensity follows ship power)
  // (on short booms, far enough off the hull that the hatch is lit, not burned white)
  const wl1 = new THREE.PointLight(0xffe0b0, 0, 22, 1.4); wl1.position.set(HULL_R + 1.7, 3.3, -0.4); g.add(wl1);
  const wl2 = new THREE.PointLight(0xffe0b0, 0, 22, 1.4); wl2.position.set(-HULL_R - 1.4, 3.1, -4.5); g.add(wl2);
  [[wl1.position, 0.3], [wl2.position, -0.35]].forEach(([p, lean]) => {
    const base = new THREE.Vector3(Math.sign(p.x) * (HULL_R - 0.05) * Math.cos(lean), 1.1 + (HULL_R - 0.05) * Math.sin(Math.abs(lean)) * 1.8, p.z);
    const len = base.distanceTo(p);
    const boom = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.06, len, 8), M.dark);
    boom.position.copy(base).add(p).multiplyScalar(0.5); boom.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), p.clone().sub(base).normalize()); g.add(boom);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.16, 0.2), M.dark); head.position.copy(p).addScaledVector(p.clone().sub(base).normalize(), 0.12); head.userData.noOcclude = true; g.add(head);
  });
  shipFx.workLights.push(wl1, wl2);
  const halo = new THREE.SpriteMaterial({ map: glowSprite(), color: 0xffd9a0, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  [wl1, wl2].forEach(l => { const s = new THREE.Sprite(halo); s.scale.set(1.2, 1.2, 1); s.position.copy(l.position); g.add(s); });
  shipFx.workHalo = halo;
  // beacon: the one fairness concession for spotting the ship at range
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffb347, toneMapped: false }));
  beacon.position.set(0.8, 4.6, -10.5); g.add(beacon); shipFx.beacon = beacon;
  const bSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite(), color: 0xff9030, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  bSprite.scale.set(3, 3, 1); bSprite.position.copy(beacon.position); g.add(bSprite); shipFx.beaconSprite = bSprite;
  // gfx pass: hull detail, kept clear of the hatch, the fixtures, the name and every hardpoint
  const avoid = [{ a: 0, z: 1.0, r: 1.5 }, { a: 180, z: -4.5, r: 1.6 }, { a: 90, z: -11.0, r: 1.3 }, { a: 90, z: -10.5, r: 1.0 },
    { a: 23, z: -5, r: 3.2 }, { a: 157, z: -5, r: 3.2 }, { a: 270, z: -5.0, r: 1.2 }, { a: 12, z: -0.4, r: 1.2 }, { a: 188, z: -4.5, r: 1.2 },
    ...HARDPOINTS.map(h => ({ a: THREE.MathUtils.radToDeg(Math.atan2(h.normal.y, h.normal.x)), z: h.pos.z, r: 0.9 }))];
  addHullGreebles(g, M, shipFx, { R: HULL_R, axisY: 1.1, z0: HULL_A.z, z1: HULL_B.z }, avoid);
  // hardpoint rings (only visible in build mode)
  const hpMat = new THREE.MeshBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0.8, toneMapped: false });
  shipFx.hardpointRings = HARDPOINTS.map(h => {
    const r = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.04, 6, 18), hpMat);
    r.position.copy(h.pos).addScaledVector(h.normal, 0.05);
    r.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), h.normal);
    r.visible = false; g.add(r); return r;
  });
  // baked ambient occlusion (and the work lights' shadows), then one draw call per material
  const keep = new Set(shipFx.hardpointRings);
  shipFx.bakeExterior = bakeRoot(g, [wl1, wl2].map(l => ({ pos: l.position.clone(), range: 12, weight: 1 })), { aoDist: 1.0, aoStrength: 0.8, shadowFloor: 0.4, skipOccluder: o => keep.has(o) || o === hull });
  whiteColours(g);
  const refs = new Set([shipFx.noseGlow, shipFx.thrusterThroat]);
  shipFx.mergedExterior = mergeStatic(g, o => !keep.has(o) && !o.material.transparent && !o.material.isMeshBasicMaterial && !refs.has(o.material) && o !== shipFx.secretGroup && !(o.parent && o.parent === shipFx.secretGroup));
  return g;
}

export function buildShip() {
  const M = mats();
  shipFx.interiorGroup = buildInterior(M);
  shipFx.exterior = buildExterior(M);
  // legacy globals some older modules/tests poke at
  window.__lamp = shipFx.lamps[0].light;
  window.__shipBeacon = shipFx.beacon;
  window.__secretGlint = shipFx.secretGlint;
}

// ship power -> lighting. level: 'dark' | 'emergency' | 'powered'.
// flicker adds instability when the Listener is near or sanity is low.
const RED = new THREE.Color(0xff2a14), WARM = new THREE.Color(0xffd4a0), CYAN = new THREE.Color(0x7fd8ff);
export function updateShipLights(level, t, flicker = 0, inside = true) {
  const f = (Math.random() < 0.004 + flicker * 0.06) ? 0.15 : 1;
  for (const L of shipFx.lamps) {
    if (!inside) { L.light.intensity = 0; continue; }
    if (L.kind === 'screen') { L.light.intensity = level === 'dark' ? 0 : L.base * (level === 'powered' ? 1 : 0.5) * f; L.light.color.copy(CYAN); continue; }
    if (level === 'powered') { L.light.color.copy(WARM); L.light.intensity = L.base * f; }
    else if (level === 'emergency') { L.light.color.copy(RED); L.light.intensity = L.base * 0.55 * (0.82 + 0.18 * Math.sin(t * 2.1)) * f; }
    else { L.light.intensity = 0; }
  }
  if (shipFx.ambient) {
    if (!inside) { shipFx.ambient.intensity = 0.07; shipFx.ambient.color.setHex(0x3a4660); }
    else { shipFx.ambient.intensity = level === 'powered' ? 0.42 : level === 'emergency' ? 0.5 : 0.14; shipFx.ambient.color.setHex(level === 'emergency' ? 0x2a1210 : 0x1a1e28); }
  }
  if (shipFx.hemi) shipFx.hemi.intensity = !inside ? 0.0 : level === 'powered' ? 0.32 : level === 'emergency' ? 0.18 : 0.04;
  const glow = level === 'powered' ? 1 : level === 'emergency' ? 0.3 : 0;
  for (const m of shipFx.emissives) {
    if (m.userData.base === undefined) m.userData.base = m.color.clone();
    if (level === 'emergency' && m.userData.strip) m.color.setRGB(1.1, 0.07, 0.035).multiplyScalar(0.8 * f);
    else m.color.copy(m.userData.base).multiplyScalar(Math.max(0.03, glow * f));
  }
  for (const w of shipFx.workLights) w.intensity = level === 'powered' && !shipFx.swapped ? 45 * f : 0; // P3: not while your ship is the wreck
  if (shipFx.workHalo) shipFx.workHalo.opacity = level === 'powered' ? 0.9 * f : 0;
  if (shipFx.noseGlow) shipFx.noseGlow.color.setRGB(level === 'powered' ? 0.42 : level === 'emergency' ? 0.26 : 0.02, level === 'powered' ? 0.26 : 0.03, level === 'powered' ? 0.11 : 0.015);
  if (shipFx.beacon) { const b = 0.5 + 0.5 * Math.sin(t * 6); shipFx.beacon.material.color.setRGB(1, 0.4 + b * 0.3, 0.1 + b * 0.2); shipFx.beaconSprite.material.opacity = 0.35 + 0.5 * b; }
  if (shipFx.secretGlint) { const b = 0.5 + 0.5 * Math.sin(t * 4); shipFx.secretGlint.material.color.setRGB(0.55 + b * 0.15, 0.78 + b * 0.1, 1); }
  // (the panel's sparks now follow its repair: updateFixtures)
  updateNavLights(shipFx, t, level === 'powered' && !shipFx.swapped);
}

// 2026-09-28: repaired parts look repaired. rep = S.P.repair (0..100 each); level = ship power; thr = drive output.
// The look eases from broken to repaired with the repair (the dish swings back into line as you work on it),
// and at 100 the damage is gone: no scorch, no loose part, no sparks, a steady green lamp.
const _ease = k => k * k * (3 - 2 * k);
const LAMP_RED = new THREE.Color(0xff2a14), LAMP_GREEN = new THREE.Color(0x3cff7a), LAMP_OFF = new THREE.Color(0x0a0303);
function lampTo(m, fixed, level, t) {
  if (level === 'dark') m.material.color.copy(LAMP_OFF);
  else if (fixed) m.material.color.copy(LAMP_GREEN).multiplyScalar(level === 'powered' ? 1 : 0.5);
  else m.material.color.copy(Math.sin(t * 5) > 0 ? LAMP_RED : LAMP_OFF);
}
export function updateFixtures(rep, t, level, thr = 0) {
  const X = shipFx.fixtures; if (!X || !rep) return;
  const live = level !== 'dark';
  { // the dish
    const f = X.comms, r = Math.max(0, Math.min(100, rep.comms || 0)), fixed = r >= 100, e = _ease(r / 100);
    const sweep = fixed && level === 'powered' ? Math.sin(t * 0.25) * 0.35 : 0;
    f.pivot.rotation.set(THREE.MathUtils.lerp(1.25, -0.5, e), THREE.MathUtils.lerp(0.4, 0, e) + sweep, THREE.MathUtils.lerp(0.95, 0, e));
    f.horn.rotation.z = THREE.MathUtils.lerp(0.9, 0, e); f.horn.position.x = THREE.MathUtils.lerp(0.12, 0, e);
    f.struts[2].visible = fixed; f.loose.visible = !fixed; f.cable.visible = !fixed;
    f.loose.rotation.z = Math.sin(t * 0.9) * 0.12;
    f.scorch.visible = !fixed; f.scorch.material.opacity = 0.78 * (1 - e * 0.6);
    f.sparks.visible = !fixed && live && Math.random() < 0.3 * (1 - e * 0.7);
    lampTo(f.lamp, fixed, level, t);
    f.state = fixed ? 'repaired' : r > 0 ? 'partial' : 'broken';
  }
  { // the bell
    const f = X.thrusters, r = Math.max(0, Math.min(100, rep.thrusters || 0)), fixed = r >= 100, e = _ease(r / 100);
    f.soot.visible = !fixed; f.soot.material.opacity = 0.85 * (1 - e * 0.6);
    f.loose.visible = !fixed; f.fitted.visible = fixed; f.loose.rotation.z = 0.5 + Math.sin(t * 0.7) * 0.1;
    f.sparks.visible = !fixed && live && Math.random() < 0.25 * (1 - e * 0.7);
    const glow = r >= 10 && level === 'powered' ? 0.12 + 0.88 * Math.max(0, Math.min(1, thr)) : 0;
    f.throat.color.setRGB(Math.min(1, 0.06 + glow), 0.03 + glow * 0.55, 0.015 + glow * 0.3, THREE.SRGBColorSpace);
    lampTo(f.lamp, fixed, level, t);
    f.state = fixed ? 'repaired' : r > 0 ? 'partial' : 'broken';
  }
  { // the bus box
    const f = X.power, r = Math.max(0, Math.min(100, rep.power || 0)), fixed = r >= 100, e = _ease(r / 100);
    f.cover.rotation.y = THREE.MathUtils.lerp(1.1, 0, e);
    f.scorch.visible = !fixed; f.scorch.material.opacity = 0.78 * (1 - e * 0.6);
    f.sparks.visible = !fixed && Math.random() < 0.3 * (1 - e * 0.7);
    lampTo(f.lamp, fixed, level, t);
    f.state = fixed ? 'repaired' : r > 0 ? 'partial' : 'broken';
  }
}
// test surface: what each fixture shows right now
export function fixtureInfo() {
  const X = shipFx.fixtures; if (!X) return null;
  const out = {};
  for (const k in X) {
    const f = X[k];
    const dmg = !!((f.scorch && f.scorch.visible) || (f.soot && f.soot.visible) || (f.loose && f.loose.visible) || (f.cable && f.cable.visible) || (f.cover && Math.abs(f.cover.rotation.y) > 0.05));
    out[k] = { state: f.state, sparks: f.sparks.visible, lamp: f.lamp.material.color.getHexString(), damageShown: dmg,
      pose: f.pivot ? [f.pivot.rotation.x, f.pivot.rotation.z] : f.cover ? [f.cover.rotation.y] : null };
  }
  return out;
}
