// Planet generator (v0.5 slice A). Pure and seeded: one integer seed gives
// the same planet, the same ground and the same resource nodes on every visit,
// in every build, so a save stores only the seed and what the player changed.
// No THREE here and no game state: this file is plain math, safe to import
// from anywhere (the landing system, the terrain mesher, the tests).
//
//   planetsAt(hip)            -> the planets of a real catalogue star, [planet]
//   makePlanet(seed, opts)    -> { seed, name, radiusKm, gravity, atmo, tempC, sky, ... }
//   heightAt(pl, x, z)        -> ground height in metres at planet-surface coords (metres)
//   heightHash(pl)            -> a short hex hash of a fixed 64 x 64 sample of the ground
//   nodesInCell(pl, cx, cz)   -> resource nodes in one 32 m cell [{ id, type, x, z }]
//   floraInCell(pl, cx, cz)   -> flora props in one 32 m cell [{ kind, x, z, s, r }]
//   depositsInCell(pl, gx, gz)-> big minable deposits in one 96 m cell (a cluster of 2-4) [{ id, kind, res, x, z, size, rot, total }]
//   planetSeed(hip, i)        -> the seed of a star's i-th planet: a bijection of (hip, i), so no two collide
//   heightSig(pl)             -> a 64-bit signature of the ground (16 x 16 samples), for the uniqueness census
//   scanLine(pl)              -> one line of plain words: what the scanner says about this world
//   groundColor(pl, h, ny, m) -> the ground colour at a height / slope (sea, lava, ice, strata bands)
//
// VARIETY (v0.5): ten terrain families (cratered moons, mesas, hills, ridges, dunes, canyons,
// archipelagos with a sea, ice sheets with crevasses, lava fields, spire fields), weather (clear,
// dust, fog banks, haze, aurora), rings, up to three moons in the sky, strata colour bands, a
// flora body plan and a fauna body plan, all drawn from the seed by a second stream (so adding an
// axis never shifts the others).

export const CELL = 32;               // metres: one node/flora cell (and the finest terrain chunk)
export const ATMOS = ['none', 'thin', 'breathable', 'toxic'];
export const RES_TYPES = ['ore', 'ice', 'salvage', 'carbon', 'fibre'];

// ---------- integer hashing (xmur3 / splitmix style, 32-bit, deterministic) ----------
export function hash32(...xs) {
  let h = 0x811c9dc5 | 0;
  for (let x of xs) {
    x = Math.floor(x) | 0;
    h = Math.imul(h ^ x, 0x01000193);
    h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 12; h = Math.imul(h, 0x297a2d39); h ^= h >>> 15;
  }
  return h >>> 0;
}
const u01 = (...xs) => hash32(...xs) / 4294967296;
export function rng(seed) {
  let s = seed >>> 0;
  return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), 1 | t); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// ---------- value noise + fbm (seeded lattice, quintic fade) ----------
const fade = t => t * t * t * (t * (t * 6 - 15) + 10);
function vnoise(seed, x, z) {
  const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
  const a = u01(seed, ix, iz), b = u01(seed, ix + 1, iz), c = u01(seed, ix, iz + 1), d = u01(seed, ix + 1, iz + 1);
  const ux = fade(fx), uz = fade(fz);
  return (a + (b - a) * ux + (c - a) * uz + (a - b - c + d) * ux * uz) * 2 - 1; // -1..1
}
function fbm(seed, x, z, oct, lac = 2.03, gain = 0.5) {
  let s = 0, a = 1, n = 0;
  for (let i = 0; i < oct; i++) { s += vnoise(seed + i * 101, x, z) * a; n += a; a *= gain; x *= lac; z *= lac; }
  return s / n;
}
function ridged(seed, x, z, oct) {
  let s = 0, a = 1, n = 0;
  for (let i = 0; i < oct; i++) { const v = 1 - Math.abs(vnoise(seed + i * 131, x, z)); s += v * v * a; n += a; a *= 0.5; x *= 2.07; z *= 2.07; }
  return s / n; // 0..1
}

// ---------- the planet itself ----------
const LETTERS = 'bcdefgh';
const SYL = ['KA', 'RO', 'VE', 'TH', 'AL', 'OR', 'UN', 'SE', 'MI', 'DR', 'EX', 'YR', 'OS', 'NA', 'QU', 'IL'];
const TERRAIN = { none: 'cratered', thin: 'mesa', breathable: 'hills', toxic: 'ridges' };
const lerp3 = (a, b, k) => a.map((v, i) => v + (b[i] - v) * k);

export function makePlanet(seed, opts = {}) {
  seed = seed >>> 0;
  const r = rng(seed);
  const radiusKm = Math.round(1500 + r() * r() * 7500);
  const density = 0.55 + r() * 0.7;
  const gravity = +Math.max(1.2, Math.min(16, 9.81 * (radiusKm / 6371) * density * 1.25)).toFixed(2);
  // small worlds cannot hold air; breathable air is rare
  const ra = r();
  let atmo;
  if (radiusKm < 2400) atmo = ra < 0.5 ? 'none' : 'thin';
  else atmo = ra < 0.2 ? 'none' : ra < 0.44 ? 'thin' : ra < 0.72 ? 'toxic' : 'breathable';
  if (opts.atmo && ATMOS.includes(opts.atmo)) atmo = opts.atmo; // test hook: force a class
  let tempC;
  if (atmo === 'breathable') tempC = Math.round(-18 + r() * 50);
  else if (atmo === 'toxic') tempC = Math.round(10 + r() * 160);
  else tempC = Math.round(-175 + r() * 230);
  const tempBand = tempC < -60 ? 'FROZEN' : tempC < -10 ? 'COLD' : tempC < 35 ? 'TEMPERATE' : tempC < 90 ? 'HOT' : 'SCORCHING';
  // sky colour at noon (linear 0..1); airless worlds keep a black sky and their stars
  const SKY = {
    none: [0.0, 0.0, 0.0],
    thin: lerp3([0.42, 0.30, 0.24], [0.30, 0.26, 0.36], r()),
    breathable: lerp3([0.28, 0.48, 0.82], [0.40, 0.62, 0.78], r()),
    toxic: lerp3([0.62, 0.58, 0.22], [0.36, 0.56, 0.30], r()),
  };
  const sky = SKY[atmo].map(v => +v.toFixed(3));
  const density01 = { none: 0, thin: 0.35, breathable: 0.85, toxic: 1 }[atmo];
  // ground tint: two colours the terrain blends between (low/flat -> high/steep)
  const GROUND = {
    none: [[0.34, 0.33, 0.32], [0.55, 0.53, 0.50]],
    thin: [[0.52, 0.30, 0.18], [0.70, 0.52, 0.36]],
    breathable: [[0.18, 0.36, 0.16], [0.42, 0.40, 0.30]],
    toxic: [[0.40, 0.38, 0.14], [0.28, 0.22, 0.18]],
  }[atmo];
  const jig = () => (r() - 0.5) * 0.12;
  const tint = GROUND.map(c => c.map(v => +Math.max(0, Math.min(1, v + jig())).toFixed(3)));
  if (tempC < -60) tint[1] = [0.80, 0.84, 0.88]; // frost on the heights
  // variety: a second stream from the seed, so these axes never shift the ones above
  const rv = rng(hash32(seed, 0xa11e));
  const pickW = (ws) => { let t = 0; for (const k in ws) t += ws[k]; let a = rv() * t; for (const k in ws) { a -= ws[k]; if (a <= 0) return k; } return Object.keys(ws)[0]; };
  const wet = (atmo === 'breathable' || atmo === 'toxic') && tempC > -5 && tempC < 75;
  let terrain = pickW({
    cratered: atmo === 'none' ? 2.2 : 0.35, mesa: atmo === 'thin' ? 1.6 : 0.5, hills: atmo === 'breathable' ? 1.6 : 0.45,
    ridges: atmo === 'toxic' ? 1.5 : 0.5, dunes: (atmo === 'thin' || atmo === 'none') && tempC > -40 ? 1.4 : 0.3,
    canyons: 1.0, archipelago: wet ? 1.8 : 0, icesheet: tempC < -40 ? 2.2 : 0, lava: tempC > 110 ? 2.4 : tempC > 60 ? 0.5 : 0, spires: 0.9,
  });
  if (opts.atmo && !opts.family) terrain = TERRAIN[atmo]; // test hook: a forced air class keeps its classic ground
  if (opts.family) terrain = opts.family;
  // resource weights: what the scanner finds on this world
  const w = { ore: 3 + r() * 3, ice: tempC < -20 ? 4 + r() * 3 : tempC < 30 ? 1 : 0.1, salvage: 0.4 + r() * 1.2, carbon: atmo === 'toxic' ? 3 : 1 + r() * 1.5, fibre: atmo === 'breathable' ? 4 : atmo === 'toxic' ? 1.2 : 0 };
  const flora = atmo === 'breathable' ? 1 : atmo === 'toxic' ? 0.6 : atmo === 'thin' && tempC > -40 ? 0.15 : 0;
  const dayLengthH = +(6 + r() * 54).toFixed(1);
  const name = opts.name || (SYL[Math.floor(r() * 16)] + SYL[Math.floor(r() * 16)] + (r() < 0.5 ? SYL[Math.floor(r() * 16)] : '')).toUpperCase();
  const pl = {
    seed, name, radiusKm, gravity, atmo, tempC, tempBand, sky, density: density01, tint, terrain, weights: w, flora, dayLengthH,
    amp: { cratered: 38, mesa: 62, hills: 34, ridges: 78, dunes: 30, canyons: 70, archipelago: 40, icesheet: 26, lava: 44, spires: 30 }[terrain] * (0.75 + r() * 0.5),
    scale: { cratered: 620, mesa: 520, hills: 430, ridges: 520, dunes: 700, canyons: 640, archipelago: 520, icesheet: 800, lava: 480, spires: 500 }[terrain] * (0.8 + r() * 0.4),
    craterRate: terrain === 'cratered' ? 0.55 + r() * 0.3 : terrain === 'mesa' ? 0.12 : 0.03,
    terrace: 14 + r() * 10,
    sunAz: r() * Math.PI * 2, sunPhase: r(),
  };
  // ---- variety axes (all from rv) ----
  pl.windAz = rv() * Math.PI; pl.duneWL = 26 + rv() * 30;
  pl.seaBias = -0.1 - rv() * 0.35;                       // archipelago: how much of the ground is under the sea
  pl.spireCell = 70 + rv() * 60;
  const wx = { none: ['clear', 'clear', 'clear'], thin: ['clear', 'dust', 'dust'], breathable: ['clear', 'fog', 'aurora'], toxic: ['haze', 'fog', 'haze'] }[atmo];
  pl.weather = wx[Math.floor(rv() * 3)];
  pl.rings = rv() < 0.28;
  pl.ringTilt = 0.2 + rv() * 0.9; pl.ringAz = rv() * Math.PI * 2;
  const nm = rv(); pl.moons = [];
  for (let i = 0, n = nm < 0.35 ? 0 : nm < 0.7 ? 1 : nm < 0.9 ? 2 : 3; i < n; i++) pl.moons.push({ az: rv() * Math.PI * 2, el: 0.12 + rv() * 0.7, size: 0.04 + rv() * rv() * 0.16, col: [0.55 + rv() * 0.4, 0.5 + rv() * 0.4, 0.5 + rv() * 0.45] });
  pl.strata = terrain === 'mesa' || terrain === 'canyons' || rv() < 0.3;
  pl.strataW = 3 + rv() * 9;
  pl.strataCol = [0.3 + rv() * 0.6, 0.25 + rv() * 0.5, 0.2 + rv() * 0.5];
  pl.seaCol = atmo === 'toxic' ? [0.10, 0.30, 0.24] : [0.08, 0.22 + rv() * 0.12, 0.34 + rv() * 0.2];
  pl.floraPlan = pl.flora ? ['spike', 'stalk', 'fan', 'crystal', 'bulb'][Math.floor(rv() * 5)] : null;
  pl.fauna = null;
  if (atmo !== 'none' && (pl.flora || rv() < 0.4)) {
    const plan = ['strider', 'crawler', 'hopper', 'floater'][Math.floor(rv() * 4)];
    pl.fauna = { plan, legs: plan === 'crawler' ? 6 + 2 * Math.floor(rv() * 2) : plan === 'strider' ? 2 + 2 * Math.floor(rv() * 2) : plan === 'hopper' ? 2 : 0,
      size: 0.6 + rv() * 1.6, neck: rv(), col: [0.3 + rv() * 0.6, 0.25 + rv() * 0.55, 0.2 + rv() * 0.6], rate: 0.08 + rv() * 0.25 };
  }
  // resource mixes vary world to world (the weights above set the kind of world, this sets the luck)
  for (const k of RES_TYPES) w[k] *= 0.3 + rv() * 1.9;
  if (rv() < 0.3) w.salvage *= 3.5;             // an old wreck field: salvage-rich
  if (atmo === 'toxic' && rv() < 0.5) w.carbon *= 2.2;
  // the sky: each world its own shade (and dust worlds a browner one)
  if (pl.density) { pl.sky = pl.sky.map(v => +Math.max(0, Math.min(1, v + (rv() - 0.5) * 0.22)).toFixed(3)); if (pl.weather === 'dust') pl.sky = pl.sky.map((v, i) => +(v * 0.7 + [0.2, 0.14, 0.08][i]).toFixed(3)); }
  pl.lavaLevel = -pl.amp * 0.03;
  // what dominates the ground's resources
  let dom = 'ore'; for (const k of RES_TYPES) if (w[k] > w[dom]) dom = k;
  pl.dominant = dom;
  return pl;
}

// A star's i-th planet's seed. (hip, i) -> hip * 8 + i is unique for every catalogue star (HIP < 2^28),
// and fmix32 (murmur3's finaliser) is a bijection on 32 bits, so two planets can never share a seed.
// (Slice A used hash32(hip, i, salt), which is not a bijection: 32-bit collisions were possible.)
export function fmix32(h) {
  h >>>= 0; h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b) >>> 0; h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35) >>> 0; h ^= h >>> 16; return h >>> 0;
}
export function planetSeed(hip, i) { return fmix32(((hip * 8 + i) ^ 0x5eed5eed) >>> 0); }

// the planets of a real star: 1 to 4, seeded by its HIP number (and Sol's, hip 0, too)
export function planetsAt(hip, starName = '') {
  const n = 1 + Math.floor(u01(hip, 7771) * 4);
  const out = [];
  for (let i = 0; i < n; i++) {
    const seed = planetSeed(hip, i);
    const pl = makePlanet(seed);
    pl.alias = pl.name; // keep the generated syllable name before adding the catalogue label
    pl.name = `${(starName || (hip ? 'HIP ' + hip : 'SOL')).toUpperCase()} ${LETTERS[i]}`;
    pl.index = i; pl.hip = hip;
    out.push(pl);
  }
  return out;
}

// ---------- the ground ----------
const CRATER_CELL = 170;
function craterAt(pl, x, z) {
  if (pl.craterRate <= 0.01) return 0;
  const cx = Math.floor(x / CRATER_CELL), cz = Math.floor(z / CRATER_CELL);
  let h = 0;
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
    const gx = cx + dx, gz = cz + dz;
    const s = hash32(pl.seed, gx, gz, 0xc2a7);
    if ((s & 0xffff) / 65536 > pl.craterRate) continue;
    const px = (gx + ((s >>> 16) & 255) / 255) * CRATER_CELL, pz = (gz + ((s >>> 24) & 255) / 255) * CRATER_CELL;
    const rad = 12 + u01(s, 3) * 62;
    const d = Math.hypot(x - px, z - pz) / rad;
    if (d > 1.6) continue;
    // bowl inside, raised rim at d ~ 1, fading ejecta outside
    if (d < 1) h += (d * d - 1) * rad * 0.26 + Math.exp(-((d - 1) ** 2) / 0.02) * rad * 0.07;
    else h += Math.exp(-((d - 1) ** 2) / 0.05) * rad * 0.07;
  }
  return h;
}
export function heightAt(pl, x, z) {
  const s = pl.seed, k = 1 / pl.scale;
  let h;
  switch (pl.terrain) {
    case 'mesa': {
      const b = fbm(s, x * k, z * k, 5) * pl.amp;
      const st = pl.terrace, t = b / st, f = Math.floor(t), fr = t - f;
      const g = fr < 0.72 ? 0 : fade((fr - 0.72) / 0.28);
      h = (f + g) * st * 0.9 + b * 0.1;
      h += fbm(s + 9, x / 38, z / 38, 2) * 1.2; // wind ripples
      break;
    }
    case 'ridges': h = (ridged(s, x * k, z * k, 5) - 0.45) * pl.amp * 1.6 + fbm(s + 3, x * k * 4, z * k * 4, 3) * 6; break;
    case 'hills': h = fbm(s, x * k, z * k, 5) * pl.amp + fbm(s + 5, x / 60, z / 60, 3) * 2.2; break;
    case 'dunes': {
      const ca = Math.cos(pl.windAz), sa = Math.sin(pl.windAz);
      const u = x * ca + z * sa, v = -x * sa + z * ca;
      const w = (u + fbm(s + 11, x / 260, z / 260, 3) * 60) / pl.duneWL, p = w - Math.floor(w);
      const prof = p < 0.72 ? p / 0.72 : (1 - p) / 0.28;       // a long windward slope, a steep slip face
      h = prof * prof * (3 - 2 * prof) * pl.amp * 0.22 * (0.55 + 0.45 * (fbm(s + 13, v / 180, u / 900, 2) + 1) / 2) + fbm(s, x * k, z * k, 4) * pl.amp * 0.5;
      break;
    }
    case 'canyons': {
      const base = fbm(s, x * k, z * k, 4) * pl.amp * 0.25 + pl.amp * 0.4;
      const rr = ridged(s + 21, x * k * 1.6, z * k * 1.6, 4);
      const cut = rr < 0.72 ? 0 : rr > 0.9 ? 1 : fade((rr - 0.72) / 0.18);
      h = base - cut * pl.amp * 1.05 + fbm(s + 23, x / 40, z / 40, 2) * 1.5;
      break;
    }
    case 'archipelago': {
      const e = (fbm(s, x * k, z * k, 5) + pl.seaBias) * pl.amp * 1.4;
      h = e > 0 ? e + fbm(s + 5, x / 50, z / 50, 2) * 1.5 : 0;   // a flat sea at 0 m
      break;
    }
    case 'icesheet': {
      h = fbm(s, x * k, z * k, 3) * pl.amp * 0.45;
      const cr = ridged(s + 31, x / 110, z / 110, 2);
      h -= (cr < 0.9 ? 0 : fade((cr - 0.9) / 0.1)) * 7;             // crevasses
      break;
    }
    case 'lava': {
      h = (ridged(s, x * k, z * k, 4) - 0.62) * pl.amp * 1.2 + fbm(s + 3, x / 30, z / 30, 2) * 1.2;
      h = Math.max(h, pl.lavaLevel);                                // the lava lakes lie flat
      break;
    }
    case 'spires': {
      h = fbm(s, x * k, z * k, 4) * pl.amp * 0.6;
      const C = pl.spireCell, gx = Math.floor(x / C), gz = Math.floor(z / C);
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        const q = hash32(s, gx + dx, gz + dz, 0x5b1e);
        if ((q & 255) > 150) continue;
        const px = (gx + dx + 0.2 + ((q >>> 8) & 255) / 255 * 0.6) * C, pz = (gz + dz + 0.2 + ((q >>> 16) & 255) / 255 * 0.6) * C;
        const rad = 5 + ((q >>> 24) & 15), dd = Math.hypot(x - px, z - pz) / rad;
        if (dd < 1.15) h += (dd < 0.85 ? 1 : fade((1.15 - dd) / 0.3)) * (18 + (q % 53));
      }
      break;
    }
    default: h = fbm(s, x * k, z * k, 5) * pl.amp * 0.8;
  }
  h += craterAt(pl, x, z);
  h += vnoise(s + 77, x / 7, z / 7) * 0.35; // grit
  return h;
}
// the ground a landed ship has flattened a pad into (site = where it touched down)
export function groundAt(pl, x, z, site) {
  const h = heightAt(pl, x, z);
  if (!site) return h;
  const d = Math.hypot(x - site.x, z - site.z);
  if (d > 26) return h;
  const k = d < 14 ? 1 : 1 - fade((d - 14) / 12);
  return h + (site.h - h) * k;
}

// the determinism check: a fixed grid, heights rounded to the centimetre, FNV-1a
export function heightHash(pl, n = 64, step = 37) {
  let h = 0x811c9dc5 >>> 0;
  for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
    const v = Math.round(heightAt(pl, (i - n / 2) * step, (j - n / 2) * step) * 100) | 0;
    h ^= v & 0xff; h = Math.imul(h, 0x01000193) >>> 0;
    h ^= (v >>> 8) & 0xff; h = Math.imul(h, 0x01000193) >>> 0;
    h ^= (v >>> 16) & 0xff; h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

// the census signature: 16 x 16 samples over a 1.5 km square, rounded to the centimetre, two FNV-1a lanes (64 bits)
export function heightSig(pl) {
  let a = 0x811c9dc5 >>> 0, b = 0xcbf29ce4 >>> 0;
  for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) {
    const v = Math.round(heightAt(pl, (i - 8) * 97 + 13, (j - 8) * 97 - 29) * 100) | 0;
    for (let q = 0; q < 4; q++) { const byte = (v >>> (q * 8)) & 0xff; a ^= byte; a = Math.imul(a, 0x01000193) >>> 0; b ^= byte ^ 0x5a; b = Math.imul(b, 0x01000193) >>> 0; b ^= b >>> 13; }
  }
  return a.toString(16).padStart(8, '0') + b.toString(16).padStart(8, '0');
}

// the ground colour: m is the flat (0) to steep / high (1) blend the mesher already uses
export function groundColor(pl, h, ny, m, out) {
  const c0 = pl.tint[0], c1 = pl.tint[1];
  let r = c0[0] + (c1[0] - c0[0]) * m, g = c0[1] + (c1[1] - c0[1]) * m, b = c0[2] + (c1[2] - c0[2]) * m;
  if (pl.strata && ny < 0.93) { // bands on the exposed faces
    const band = 0.5 + 0.5 * Math.sin(h / pl.strataW * Math.PI * 2), k = 0.45 * (1 - ny) * 3 * band;
    const kk = Math.min(0.6, k); r += (pl.strataCol[0] - r) * kk; g += (pl.strataCol[1] - g) * kk; b += (pl.strataCol[2] - b) * kk;
  }
  switch (pl.terrain) {
    case 'archipelago': if (h <= 0.02) { [r, g, b] = pl.seaCol; } else if (h < 1.2) { r = 0.72; g = 0.66; b = 0.48; } break;
    case 'icesheet': { const k = Math.min(1, ny * 1.1); r = 0.5 + 0.22 * k; g = 0.58 + 0.2 * k; b = 0.68 + 0.16 * k; if (h < -2) { r *= 0.55; g *= 0.7; b *= 0.95; } break; }
    case 'lava': if (h <= pl.lavaLevel + 0.05) { r = 1.0; g = 0.34; b = 0.06; } else { r *= 0.45; g *= 0.4; b *= 0.4; } break;
    case 'dunes': r = r * 0.6 + 0.3; g = g * 0.6 + 0.22; b = b * 0.6 + 0.1; break;
  }
  out[0] = r; out[1] = g; out[2] = b;
  return out;
}

const FAMILY_WORDS = { cratered: 'A CRATERED MOON-LIKE WORLD', mesa: 'MESAS AND TERRACES', hills: 'ROLLING HILLS', ridges: 'SHARP RIDGES', dunes: 'A SEA OF DUNES', canyons: 'DEEP CANYONS', archipelago: 'ISLANDS IN A SHALLOW SEA', icesheet: 'AN ICE SHEET WITH CREVASSES', lava: 'LAVA FIELDS', spires: 'A FIELD OF ROCK SPIRES' };
const WEATHER_WORDS = { clear: '', dust: 'DUST STORMS', fog: 'FOG BANKS', haze: 'A THICK HAZE', aurora: 'AURORAS AT NIGHT' };
export function scanLine(pl) {
  const air = { none: 'NO AIR', thin: 'THIN AIR', breathable: 'BREATHABLE AIR', toxic: 'TOXIC AIR' }[pl.atmo];
  const bits = [FAMILY_WORDS[pl.terrain], air, `${pl.tempC} C`, `${(pl.gravity / 9.81).toFixed(2)} G`];
  if (WEATHER_WORDS[pl.weather]) bits.push(WEATHER_WORDS[pl.weather]);
  if (pl.rings) bits.push('RINGS');
  if (pl.moons.length) bits.push(`${pl.moons.length} MOON${pl.moons.length > 1 ? 'S' : ''}`);
  if (pl.flora) bits.push('PLANTS');
  if (pl.fauna) bits.push(`${pl.fauna.plan.toUpperCase()}S (ANIMALS)`);
  bits.push(`MOSTLY ${({ ore: 'ORE', ice: 'ICE', salvage: 'SALVAGE', carbon: 'CARBON', fibre: 'PLANT FIBRE' })[pl.dominant]}`);
  return bits.join(', ') + '.';
}

// fauna: a few animals per cell on worlds with life, placed like the flora (static props with a slow idle)
export function faunaInCell(pl, cx, cz) {
  if (!pl.fauna) return [];
  const s = hash32(pl.seed, cx, cz, 0xfa0a);
  if (u01(s, 0) > pl.fauna.rate) return [];
  return [{ x: (cx + 0.2 + u01(s, 1) * 0.6) * CELL, z: (cz + 0.2 + u01(s, 2) * 0.6) * CELL, r: u01(s, 3) * Math.PI * 2, s: 0.8 + u01(s, 4) * 0.4 }];
}

// ---------- what lies on the ground ----------
function pickType(pl, u) {
  const w = pl.weights; let tot = 0; for (const t of RES_TYPES) tot += w[t];
  let a = u * tot; for (const t of RES_TYPES) { a -= w[t]; if (a <= 0) return t; }
  return 'ore';
}
export function nodesInCell(pl, cx, cz) {
  const s = hash32(pl.seed, cx, cz, 0x40de);
  const n = (s & 7) < 3 ? 0 : (s & 7) < 6 ? 1 : 2;
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = hash32(s, i);
    out.push({ id: `${cx}_${cz}_${i}`, type: pickType(pl, u01(t, 1)), x: (cx + 0.1 + u01(t, 2) * 0.8) * CELL, z: (cz + 0.1 + u01(t, 3) * 0.8) * CELL, size: 0.7 + u01(t, 4) * 0.6 });
  }
  return out;
}
// ---------- big deposits you mine (surface build, 2026-09-29) ----------
// David: "I am seeing stuff on the planet I can not pick up, or mine". Besides the small glowing
// pieces, each world has DEPOSITS: big rock formations that yield several units per pull and shrink
// as you cut them. They sit in clusters of 2-4 (one kind per cluster, from the world's resource mix),
// at most one cluster per 96 m cell. Ids start with 'd' so they never collide with a node's id.
export const DCELL = 96;
export const DEPOSIT = {
  vein: { res: 'ore', label: 'ORE VEIN', per: 3 },
  ice: { res: 'ice', label: 'ICE OUTCROP', per: 3 },
  wreck: { res: 'salvage', label: 'SALVAGE WRECK', per: 2 },
  seam: { res: 'carbon', label: 'CARBON SEAM', per: 3 },
};
const DEP_OF = { ore: 'vein', ice: 'ice', salvage: 'wreck', carbon: 'seam', fibre: 'vein' };
export function depositsInCell(pl, gx, gz) {
  const s = hash32(pl.seed, gx, gz, 0xde90);
  if (u01(s, 0) > 0.55) return [];
  const kind = DEP_OF[pickType(pl, u01(s, 1))];
  const cx = (gx + 0.2 + u01(s, 2) * 0.6) * DCELL, cz = (gz + 0.2 + u01(s, 3) * 0.6) * DCELL;
  const n = 2 + Math.floor(u01(s, 4) * 3), out = [];
  for (let i = 0; i < n; i++) {
    const t = hash32(s, i + 1), a = u01(t, 1) * Math.PI * 2, r = i === 0 ? 0 : 4.5 + u01(t, 2) * 7;
    const x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r;
    const h = heightAt(pl, x, z);
    if ((pl.terrain === 'archipelago' && h <= 0.3) || (pl.terrain === 'lava' && h <= pl.lavaLevel + 0.2)) continue; // not in the sea or the lava
    const size = 0.8 + u01(t, 3) * 0.6;
    out.push({ id: `d${gx}_${gz}_${i}`, kind, res: DEPOSIT[kind].res, x, z, size, rot: u01(t, 5) * Math.PI * 2, total: Math.round((12 + u01(t, 4) * 12) * size) });
  }
  return out;
}
export function floraInCell(pl, cx, cz) {
  if (!pl.flora) return [];
  const s = hash32(pl.seed, cx, cz, 0xf10a);
  const n = Math.floor(u01(s, 0) * 9 * pl.flora);
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = hash32(s, i + 1);
    out.push({ kind: u01(t, 5) < 0.7 ? 0 : 1, x: (cx + u01(t, 1)) * CELL, z: (cz + u01(t, 2)) * CELL, s: 0.6 + u01(t, 3) * 1.1, r: u01(t, 4) * Math.PI * 2 });
  }
  return out;
}

// ---------- plants you can pick (v0.5 slice B) ----------
// Each world with flora has three species, from its seed. Most are edible; one
// (two on a toxic world) is not, and looks it: bright warning colours and
// spines. The scan text says so in plain words. Plants sit in the same 32 m
// cells as the resource nodes, with ids ending in 5..8 so they never collide
// with a node's id (and the landing save's `taken` list keeps them too).
const PLANT_A = ['BLUE', 'SALT', 'PALE', 'RED', 'SOFT', 'BELL', 'MOSS', 'KNOT', 'GLASS', 'SUN', 'DUSK', 'IRON'];
const PLANT_B = ['ROOT', 'POD', 'LEAF', 'BULB', 'FROND', 'CAP', 'BERRY', 'TUBER', 'REED', 'CRESS'];
const BAD_A = ['THORN', 'BLISTER', 'ACID', 'SCALD', 'WEEP', 'GALL'];
const EDIBLE_COL = [[0.36, 0.62, 0.26], [0.55, 0.70, 0.30], [0.30, 0.52, 0.44], [0.72, 0.66, 0.36], [0.48, 0.58, 0.72]];
const TOXIC_COL = [[0.86, 0.20, 0.14], [0.92, 0.46, 0.06], [0.64, 0.18, 0.62], [0.90, 0.80, 0.10]];
const speciesCache = new Map();
export function plantSpecies(pl) {
  if (!pl.flora) return [];
  const key = pl.seed + ':' + pl.atmo;
  if (speciesCache.has(key)) return speciesCache.get(key);
  const r = rng(hash32(pl.seed, 0x9a47));
  const nBad = pl.atmo === 'toxic' ? 2 : 1;
  const out = [];
  for (let i = 0; i < 3; i++) {
    const bad = i >= 3 - nBad;
    const col = bad ? TOXIC_COL[Math.floor(r() * TOXIC_COL.length)] : EDIBLE_COL[Math.floor(r() * EDIBLE_COL.length)];
    const name = (bad ? BAD_A[Math.floor(r() * BAD_A.length)] : PLANT_A[Math.floor(r() * PLANT_A.length)]) + ' ' + PLANT_B[Math.floor(r() * PLANT_B.length)];
    const scan = bad
      ? `${name}: TOXIC. BRIGHT WARNING COLOURS AND SPINES. EATING IT WILL MAKE YOU SICK. COOKED, IT IS STILL SPOILED.`
      : `${name}: EDIBLE. SAFE RAW, BETTER COOKED AT THE GALLEY (SALAD, STEW).`;
    out.push({ i, name, bad, col, scan, weight: bad ? 0.8 : 1 + r() });
  }
  speciesCache.set(key, out);
  return out;
}
export function plantsInCell(pl, cx, cz) {
  if (!pl.flora) return [];
  const sp = plantSpecies(pl);
  const s = hash32(pl.seed, cx, cz, 0x91a7);
  const n = Math.min(4, Math.floor(u01(s, 0) * (1 + pl.flora * 2.2)));
  const tot = sp.reduce((a, b) => a + b.weight, 0);
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = hash32(s, i + 11);
    let a = u01(t, 1) * tot, k = 0;
    while (k < sp.length - 1 && (a -= sp[k].weight) > 0) k++;
    out.push({ id: `${cx}_${cz}_${5 + i}`, type: sp[k].bad ? 'badplant' : 'plant', species: k, x: (cx + 0.1 + u01(t, 2) * 0.8) * CELL, z: (cz + 0.1 + u01(t, 3) * 0.8) * CELL, size: 0.7 + u01(t, 4) * 0.5 });
  }
  return out;
}

// plain-words description for the helm list and the HUD
export function describe(pl) {
  const air = { none: 'NO AIR', thin: 'THIN AIR (NOT BREATHABLE)', breathable: 'BREATHABLE AIR', toxic: 'TOXIC AIR' }[pl.atmo];
  return `${air}, ${pl.tempC} C (${pl.tempBand}), ${(pl.gravity / 9.81).toFixed(2)} G, DAY ${pl.dayLengthH} H`;
}
