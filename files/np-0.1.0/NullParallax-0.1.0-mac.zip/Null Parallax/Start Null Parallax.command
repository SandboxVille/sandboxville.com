#!/bin/bash
# Null Parallax for macOS. Double-click this file to play.
# It needs Node.js 18 or newer. Null Parallax itself installs nothing and never asks for your password.
cd "$(dirname "$0")" || exit 1

NODE=""
for p in ./node/bin/node ./node/*/bin/node ./node-v*/bin/node ./node-v*/*/bin/node; do
  if [ -x "$p" ]; then NODE="$p"; break; fi
done
if [ -z "$NODE" ] && command -v node >/dev/null 2>&1; then NODE="$(command -v node)"; fi
if [ -z "$NODE" ]; then
  for p in /usr/local/bin/node /opt/homebrew/bin/node; do
    if [ -x "$p" ]; then NODE="$p"; break; fi
  done
fi

close_prompt() {
  echo ""
  read -r -p "  Press Enter to close this window. " _ || true
}

need_node() {
  cat <<'EOF'

  Null Parallax needs one free program first. It is called Node.js
  (version 18 or newer).

  How to get it:
    1. Go to  https://nodejs.org
    2. Download the version marked LTS for macOS.
    3. Install it. Click Continue until it says the install worked.
    4. Then start Null Parallax again with "Start Null Parallax.command".

  Not allowed to install programs? Use the version with no installer:
    1. Go to  https://nodejs.org/en/download
    2. Pick macOS, then download the prebuilt binary (.tar.gz or .tar.xz).
    3. Unpack it. Move the folder you get (its name starts with node-v) into
       this Null Parallax folder, next to this file. You do not need to rename it.
    4. Then start Null Parallax again with "Start Null Parallax.command".

EOF
  close_prompt
  exit 1
}

[ -z "$NODE" ] && need_node
if ! "$NODE" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 18 ? 0 : 1)"; then
  echo ""
  echo "  Your Node.js is too old. Null Parallax needs version 18 or newer."
  need_node
fi

echo ""
echo "  Starting Null Parallax ..."
echo "  Your browser opens by itself in a moment."
echo ""
"$NODE" app/serve.mjs --open "$@"
status=$?
echo ""
echo "  Null Parallax stopped. Read the lines above to see why."
close_prompt
exit "$status"
