// The one game-state object. Every module that needs to read or change what
// is happening right now imports S from here instead of holding its own
// module-level `let`s. THREE.js engine handles (renderer/scene/camera/ship
// geometry) live in render/ because they are handles to the render graph,
// not game state.
import * as THREE from 'three';
import { OXY_MAX, PROP_MAX, SUIT_POWER_MAX, BASE_ZOOMS, CABIN_START_C } from './constants.js';

export function defaultSettings() {
  return {
    sensitivity: 1, invertY: false, padLook: 1, fov: 72, headBob: true,
    volume: 0.85, ambience: 1,
    quality: 'medium',                        // low | medium | high
    view: 'helmet',                           // helmet | shoulder (art wave: the over-the-shoulder camera, key O)
    subtitles: true, difficulty: 'survival', // survival | story
    keybinds: { interact: 'f', cut: 't', console: 'r', lamp: 'l', build: 'b' },
  };
}

export function freshProgress() {
  return {
    storyStep: 0, mode: 'campaign',         // campaign | sandbox
    system: 1,
    repair: { power: 0, comms: 0, thrusters: 0 },
    res: { ore: 0, ice: 0, salvage: 0, fuel: 0, meals: 4, water: 6, carbon: 0, fibre: 0, plant: 0, badplant: 0, hotmeal: 0, salad: 0, tea: 0, stew: 0, spoiled: 0 },
    upgrades: { wideCone: false, deepRange: false, zoom5: false, dreadPing: false },
    unlocks: { build: false, mast: false, baffle: false, deepArray: false },
    journalOrder: [],
    modules: [],                             // [{ part, socket, id }]
    harvested: {},                           // chunk id -> remaining health (0 = gone), per system: 'sys:id'
    derelict: { found: false, looted: false, body: false, inside: false, read: false, escaped: false, bottle: false, locker: false, tank: false },
    flags: {},                               // one-shot story/dread flags
    stats: { nullHits: 0, pauseCount: 0, deaths: 0, sleeps: 0, timePlayed: 0, listenerPassings: 0, earthYears: 0, shipYears: 0, flightDays: 0, flights: 0 },
    life: { health: 100, hunger: 100, thirst: 100, warmth: 100, rad: 0, sanity: 100, cabinC: CABIN_START_C, shipO2: 100, battery: 30 },
    nodeCollected: {},
    secretFound: false, chapter1Shown: false,
    flight: null,                            // P3: a flight in progress (systems/flight.js)
    place: null,                             // P3: sandbox, parked at a real star { hip, x, y, z } (ly)
    act2: {},                                // P3: Act II opening state
    legs: [],                                // P3: course history [{ from, to, dist, tau, t, toP, note }]
    visited: [],                             // P3: sandbox, real stars reached (HIP numbers)
    landing: null,                           // v0.5: orbit / landed on a planet of the star you are parked at (systems/landing.js)
    food: { fed: 0, sick: 0, hydro: {} },
    surf: {},                                // surface build: 'hip:planet' -> { mined: { depositId: units left }, base: [{ id, part, x, z, r, store?, g?, on? }] }
    discoveries: {},                         // VARIETY: 'hip:planet' -> { n: your name for it, t: when logged, landed }    // v0.5 slice B: well-fed / sick seconds left, hydroponics bays by module id { g: 0..1 grown, on: planted }
  };
}

export const S = {
  // ---------- run / flow ----------
  awake: false, ended: false, endingKind: null, dying: false, cycling: false, paused: false,
  sleeping: false,
  helm: false,                                // P3: seated at the helm (mode stays 'interior')

  // ---------- player body ----------
  mode: 'interior', pos: new THREE.Vector3(), vel: new THREE.Vector3(),
  q: new THREE.Quaternion(),                  // camera orientation in the ship frame (the truth)
  yaw: 0, pitch: 0, roll: 0,                  // interior look angles (q is rebuilt from these while walking)
  tYaw: 0, tPitch: 0,                         // legacy aliases kept for old test hooks
  bob: 0, bobAmp: 0,
  eva: { oxygen: OXY_MAX, propellant: PROP_MAX, power: SUIT_POWER_MAX, tethered: false, dampers: true, lamp: false },
  zoom: 0, fov: BASE_ZOOMS[0],
  fwd: new THREE.Vector3(0, 0, -1),
  ZOOMS: BASE_ZOOMS.slice(),
  buildMode: false, buildPart: 0,
  exerting: false, noise: 0,

  // ---------- sighting / fix ----------
  revealed: false, revealT: 0, locks: [], fixed: false, solSeen: false, t0: 0, endQueued: false,

  // ---------- progress (the saved part lives in P, aliased below) ----------
  P: freshProgress(),
  settings: defaultSettings(),

  // legacy aliases (getters/setters below keep old modules working)
  sys3EnterTime: null,
  collapsing: false, collapseHoldStart: null,

  // ---------- interaction bookkeeping ----------
  activeRepairNode: null, harvestTarget: null,
  fPrevDown: false,

  // ---------- threat state (transient, not saved) ----------
  threat: {
    dread: 0,                                  // 0..1 escalation
    attention: 0, listenerState: 'idle', listenerT: 0, listenerDir: null, heard: false,
    dark: 0, light: 1,
    approach: null,                            // { dir, dist } the Nearer, on EVA
    hullContactT: 0,
    pulse: { state: 'dormant', t: 0, next: 0 },
    figureT: 25,
  },
  frameSlipCount: 0, tetherSlackCount: 0, crossActive: false,
  tetherLine: null,

  // ---------- per-system mutable rig, rebuilt by sensors.buildSystem() ----------
  sys: {
    group: null, currentData: null, N: 0, dirs: [], mag: null, meta: [], pos: null, col: null,
    starMat: null, starPoints: null, solIndex: -1,
    giant: null, halo: null, giantMat: null, haloMat: null, giantDir: null, giantDist: 1500,
    driftSet: new Set(), driftLog: new Map(), dupCenter: null, dupIndices: [],
    nullDir: null, beaconIndex: -1, holdMs: 6000,
  },
};

// Legacy field aliases: older modules read S.repair / S.scrap / S.journalOrder
// etc. directly. Rather than rewrite every call site, these forward to the
// saved-progress object P so there is exactly one source of truth.
const alias = (name, get, set) => Object.defineProperty(S, name, { get, set, enumerable: false, configurable: true });
alias('system', () => S.P.system, v => { S.P.system = v; });
alias('repair', () => S.P.repair, v => { S.P.repair = v; });
alias('upgrades', () => S.P.upgrades, v => { S.P.upgrades = v; });
alias('journalOrder', () => S.P.journalOrder, v => { S.P.journalOrder = v; });
alias('scrap', () => S.P.res.salvage, v => { S.P.res.salvage = v; });
alias('fuel', () => S.P.res.fuel, v => { S.P.res.fuel = v; });
alias('nodeCollected', () => S.P.nodeCollected, v => { S.P.nodeCollected = v; });
alias('nullHits', () => S.P.stats.nullHits, v => { S.P.stats.nullHits = v; });
alias('pauseCount', () => S.P.stats.pauseCount, v => { S.P.stats.pauseCount = v; });
alias('secretFound', () => S.P.secretFound, v => { S.P.secretFound = v; });
alias('chapter1Shown', () => S.P.chapter1Shown, v => { S.P.chapter1Shown = v; });
alias('approach', () => S.threat.approach, v => { S.threat.approach = v; });
S.beaconSlot = 0;
