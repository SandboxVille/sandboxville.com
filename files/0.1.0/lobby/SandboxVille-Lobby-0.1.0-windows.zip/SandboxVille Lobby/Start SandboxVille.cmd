@echo off
rem SandboxVille Lobby for Windows. Double-click this file to start SandboxVille.
rem It needs Node.js 20 or newer. SandboxVille itself installs nothing and never asks for admin rights.
setlocal
title SandboxVille
cd /d "%~dp0"

set "SBV_NODE="
if exist "%~dp0node\node.exe" set "SBV_NODE=%~dp0node\node.exe"
if defined SBV_NODE goto havenode
for /f "delims=" %%N in ('where node 2^>nul') do if not defined SBV_NODE set "SBV_NODE=%%N"
if not defined SBV_NODE goto nonode

:havenode
"%SBV_NODE%" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 20 ? 0 : 1)"
if errorlevel 1 goto oldnode

echo.
echo   Starting SandboxVille ...
echo   Keep this window open while you play. Close it to stop SandboxVille.
echo   Your browser opens by itself in a moment.
echo.
"%SBV_NODE%" "%~dp0host\world-host.mjs" --open %*
if errorlevel 1 goto crashed
exit /b 0

:crashed
echo.
echo   SandboxVille stopped because of a problem. Read the lines above to see why.
echo.
pause
exit /b 1

:oldnode
echo.
echo   Your Node.js is too old for SandboxVille. It needs version 20 or newer.
echo.
echo   How to get a newer one:
echo     1. Go to  https://nodejs.org
echo     2. Download the version marked LTS for Windows.
echo     3. Open the file you downloaded. Click Next until you see Finish.
echo     4. Close this window. Then double-click "Start SandboxVille.cmd" again.
echo.
pause
exit /b 1

:nonode
echo.
echo   SandboxVille needs one free program first. It is called Node.js.
echo.
echo   How to get it:
echo     1. Go to  https://nodejs.org
echo     2. Download the version marked LTS for Windows.
echo     3. Open the file you downloaded. Click Next until you see Finish.
echo        If Windows asks "Do you want to allow this app to make changes?", click Yes.
echo     4. Close this window. Then double-click "Start SandboxVille.cmd" again.
echo.
echo   Not allowed to install programs on this computer? Use the version with no installer:
echo     1. Go to  https://nodejs.org/en/download
echo     2. Pick Windows, then download the "Standalone Binary (.zip)".
echo     3. Unzip it. Rename the folder you get to:  node
echo     4. Move that  node  folder into this SandboxVille folder, next to this file.
echo     5. Double-click "Start SandboxVille.cmd" again.
echo.
pause
exit /b 1
