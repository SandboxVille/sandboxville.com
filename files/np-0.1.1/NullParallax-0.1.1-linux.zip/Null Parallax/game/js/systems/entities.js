// The named dread entities: the Null Point (+ its COLLAPSE hold-ending), the
// approach ("the Nearer"), the System 1 occluding giant's reveal, the System
// 2 duplicate's slow wobble, the System 3 drift's live repositioning, the
// System 3 beacon's Morse, and the scheduled dread events (occlusion, ghost,
// crossing). Every timing/threshold number is unchanged from v0.4.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { SKY_R, GIANT_R, MORSE, MORSE_UNIT } from '../core/constants.js';
import { randomDir } from '../core/utils.js';
import { camera, crossMesh } from '../render/scene.js';
import { emit } from '../core/events.js';
import { lockRadius, driftedDir } from './sensors.js';
import { canSight } from './movement.js';
import { triggerEndingCall } from './ending-bridge.js';
import { unlockFragment } from './journal.js';
import { say, caption } from '../ui/hud.js';
import { refreshPause } from '../ui/pause-bridge.js';
import { doAutosave } from './save-state.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);

// ---------- Null Point ----------
export function sightNull() {
  const lock = $('lock');
  const first = S.nullHits === 0;
  S.nullHits++;
  const reveal = () => {
    audio.nullPing();
    lock.textContent = 'BEARING READS NON-ZERO  //  NOTHING IS CATALOGUED HERE\nRE-CHECKING DOES NOT CLEAR IT';
    lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 6500);
  };
  if (first) {
    audio.dip(650);
    setTimeout(reveal, 500);
    say('BEARING READS NON-ZERO. NOTHING IS CATALOGUED ON THIS BEARING. RE-CHECKING DOES NOT CLEAR IT.', { delay: 1400, hold: 22000 });
  } else reveal();
  unlockFragment(1, 'nullread');
  if (!S.P.flags.nullWoke) { S.P.flags.nullWoke = true; }
  emit('null', first);
  refreshPause();
  doAutosave();
}

// ---------- COLLAPSE: hold the reticle on the null point, uninterrupted.
// Takes resolveReady() as a parameter (rather than importing repair.js)
// specifically to avoid a repair -> flow -> entities -> repair import cycle;
// repair.js owns what "resolve ready" means, entities.js only owns the hold.
export function doCollapse(resolveReady) {
  if (S.ended || !(S.system === 3 && resolveReady() && S.nullHits >= 1)) return;
  S.collapsing = true; S.collapseHoldStart = null;
  const el = $('collapse'); el.textContent = 'HOLD ON THE NULL BEARING. DO NOT LOOK AWAY.'; el.style.opacity = 1;
}
export function cancelCollapse(msg) {
  if (!S.collapsing) return;
  S.collapsing = false; S.collapseHoldStart = null;
  const el = $('collapse');
  if (msg) { el.textContent = msg; setTimeout(() => { if (!S.collapsing) el.style.opacity = 0; }, 1800); }
  else el.style.opacity = 0;
}
export function updateCollapse() {
  if (!S.collapsing) return;
  if (S.paused || S.ended || S.dying) { cancelCollapse('MEASUREMENT LOST'); return; }
  if (!canSight()) { cancelCollapse('MEASUREMENT LOST'); return; }
  const nullDir = S.sys.nullDir;
  if (!nullDir || S.fwd.angleTo(nullDir) > lockRadius() * 1.3) {
    if (S.collapseHoldStart !== null) cancelCollapse('MEASUREMENT LOST');
    return;
  }
  if (S.collapseHoldStart === null) S.collapseHoldStart = performance.now();
  const held = performance.now() - S.collapseHoldStart;
  const el = $('collapse');
  const holdMs = S.sys.holdMs;
  el.textContent = `HOLDING MEASUREMENT -- ${Math.min(holdMs, held) / 1000 | 0}S / ${holdMs / 1000 | 0}S`;
  el.style.opacity = 1;
  if (held >= holdMs) { S.collapsing = false; el.style.opacity = 0; audio.collapseTone(); triggerEndingCall('COLLAPSE'); }
}

// the Nearer moved to systems/threats.js (P2)

// ---------- System 1: the occluding giant's reveal ----------
export function updateGiant(dt) {
  const sys = S.sys;
  if (!sys.giant) return;
  sys.giantMat.uniforms.uTime.value += dt;
  if (S.awake && !S.revealed && S.t0 && performance.now() - S.t0 > 9000) {
    const gR = Math.asin(Math.min(1, GIANT_R / sys.giantDist));
    const edgeAngle = S.fwd.angleTo(sys.giantDir) - gR;
    if (edgeAngle < THREE.MathUtils.degToRad(S.fov * 0.42)) { S.revealed = true; S.revealT = performance.now(); audio.sting(); unlockFragment(1, 'giant'); }
  }
  if (S.revealed) {
    sys.giantDist = Math.max(1060, sys.giantDist - dt * 3.2);
    sys.giant.position.copy(sys.giantDir).multiplyScalar(sys.giantDist); sys.halo.position.copy(sys.giant.position);
    const w = Math.min(1, 0.35 + (performance.now() - S.revealT) / 9000);
    sys.giantMat.uniforms.uWake.value = w; sys.haloMat.uniforms.uWake.value = w;
  }
}

// ---------- System 3: the drift, repositioned live every frame ----------
export function updateDriftPositions() {
  const sys = S.sys;
  if (S.system === 3 && sys.driftSet.size && sys.starPoints) {
    const posAttr = sys.starPoints.geometry.attributes.position;
    sys.driftSet.forEach(i => { const d = driftedDir(i); posAttr.array[i * 3] = d.x * SKY_R; posAttr.array[i * 3 + 1] = d.y * SKY_R; posAttr.array[i * 3 + 2] = d.z * SKY_R; });
    posAttr.needsUpdate = true;
  }
}

// ---------- System 2: the duplicate's slow independent wobble ----------
export function updateDuplicateWobble() {
  const sys = S.sys;
  if (S.system === 2 && sys.dupIndices.length && sys.starPoints) {
    const posAttr = sys.starPoints.geometry.attributes.position;
    const t = performance.now() / 1000;
    sys.dupIndices.forEach((i, k) => {
      const wobble = 0.06 + k * 0.03;
      const axis = k === 0 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
      const d = sys.dirs[i].clone().applyAxisAngle(axis, Math.sin(t * (0.05 + k * 0.02)) * THREE.MathUtils.degToRad(wobble));
      posAttr.array[i * 3] = d.x * SKY_R; posAttr.array[i * 3 + 1] = d.y * SKY_R; posAttr.array[i * 3 + 2] = d.z * SKY_R;
    });
    posAttr.needsUpdate = true;
  }
}

// ---------- System 3: the beacon, Morse-blinking the last-used save slot ----------
function morseSchedule(n) {
  const code = MORSE[Math.max(0, Math.min(9, n))];
  const seq = [];
  code.split('').forEach(sym => { seq.push({ on: true, dur: (sym === '.' ? 1 : 3) * MORSE_UNIT }); seq.push({ on: false, dur: MORSE_UNIT }); });
  seq.push({ on: false, dur: MORSE_UNIT * 6 });
  return seq;
}
function beaconOn(n, tMs) {
  const sched = morseSchedule(n);
  const total = sched.reduce((s, x) => s + x.dur, 0);
  let t = ((tMs % total) + total) % total;
  for (const seg of sched) { if (t < seg.dur) return seg.on; t -= seg.dur; }
  return false;
}
export function updateBeacon() {
  const sys = S.sys;
  if (S.system !== 3 || sys.beaconIndex < 0 || !sys.starPoints) return;
  const on = beaconOn(S.beaconSlot, performance.now());
  const magAttr = sys.starPoints.geometry.attributes.aMag;
  const baseMag = sys.meta[sys.beaconIndex].mag;
  magAttr.array[sys.beaconIndex] = on ? baseMag - 1.2 : baseMag + 0.8;
  magAttr.needsUpdate = true;
}

// ---------- scheduled dread events: occlusion, ghost, crossing ----------
let dreadTimer = null;
export function scheduleDread() {
  // playtest: one of these every 22-62 s piled wrongness on wrongness (the static line was logged 6 times in 10 minutes).
  // Now 75-150 s apart, so each one has room to land.
  const gap = 75000 + Math.random() * 75000;
  dreadTimer = setTimeout(fireDread, gap);
}
function fireDread() {
  if (!S.awake || S.paused || S.ended || S.dying || performance.now() < (S.quietUntil || 0)) { scheduleDread(); return; }
  const roll = Math.random();
  const doIt = () => {
    if (roll < 0.4) fireOcclusion();
    else if (roll < 0.7) fireGhost();
    else fireCrossing();
  };
  if (S.upgrades.dreadPing) { audio.dreadPing(); setTimeout(doIt, 1500); }
  else doIt();
  scheduleDread();
}
function fireOcclusion() {
  const sys = S.sys;
  const candidates = sys.meta.map((m, i) => i).filter(i => sys.meta[i].type === 'star' && !sys.meta[i].dup && i !== sys.solIndex);
  if (!candidates.length) return;
  const i = candidates[Math.floor(Math.random() * candidates.length)];
  const attr = sys.starPoints.geometry.attributes.aHide;
  attr.array[i] = 1; attr.needsUpdate = true;
  setTimeout(() => { attr.array[i] = 0; attr.needsUpdate = true; }, 3500 + Math.random() * 3000);
  unlockFragment(1, 'occlusion');
}
function fireGhost() {
  audio.signalGhost((Math.random() * 2 - 1) * 0.6);
  caption('[static, shaped like a voice]');
  if (S.repair.comms >= 60) unlockFragment(2, 'ghost');
  else if ((S.ghostSaid = (S.ghostSaid || 0) + 1) <= 2) say('STATIC. SOMETHING SHAPED LIKE A VOICE.', { delay: 200, hold: 8000 });
}
let crossActiveLocal = false;
function fireCrossing() {
  if (crossActiveLocal) return;
  crossActiveLocal = true;
  const a = randomDir(Math.random), b = randomDir(Math.random);
  const dur = 5000 + Math.random() * 2000, t0 = performance.now();
  crossMesh.visible = true;
  function step() {
    const t = Math.min(1, (performance.now() - t0) / dur);
    const d = a.clone().lerp(b, t).normalize();
    const cw = camera.getWorldPosition(new THREE.Vector3());
    crossMesh.position.copy(d).multiplyScalar(SKY_R * 0.4).add(cw);
    crossMesh.lookAt(cw);
    if (t < 1) requestAnimationFrame(step);
    else { crossMesh.visible = false; crossActiveLocal = false; }
  }
  step();
  unlockFragment(3, 'crossing');
}
