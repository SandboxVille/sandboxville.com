// EVA life support: oxygen drain and the death/reload flow. Oxygen is the
// hard limiter (design doc SS3.3/SS5.1) -- hit zero and you die, reloading
// the most recent save; if none exists, you wake back at the airlock with
// nothing lost because nothing was saved to lose.
import { S } from '../core/state.js';
import { OXY_MAX, PROP_MAX, OXY_DRAIN_PER_S, OXY_REPAIR_SURCHARGE } from '../core/constants.js';
import { loadFromSlot } from '../save.js';
import { applySnapshot } from './save-state.js';
import { spawnInterior } from './movement.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);

export function updateLifeSupport(dt) {
  if (S.mode !== 'eva' || S.cycling || S.dying) return;
  const surcharge = S.activeRepairNode ? OXY_REPAIR_SURCHARGE : 0;
  S.eva.oxygen = Math.max(0, S.eva.oxygen - dt * (OXY_DRAIN_PER_S + surcharge));
  if (S.eva.oxygen <= 0) die();
}

export function die() {
  if (S.dying || S.ended) return;
  S.dying = true;
  audio.duck(true); audio.asphyxia();
  const el = $('death'), sub = $('deathSub');
  const slotPref = S.beaconSlot >= 1 && S.beaconSlot <= 3 ? S.beaconSlot : 'auto';
  const d = loadFromSlot(slotPref) || loadFromSlot('auto');
  sub.textContent = d ? 'reloading last save...' : 'no save yet -- waking back at the airlock.';
  el.style.display = 'flex'; requestAnimationFrame(() => el.style.opacity = 1);
  setTimeout(() => {
    if (d) applySnapshot(d);
    else { spawnInterior('airlock'); S.eva.oxygen = OXY_MAX; S.eva.propellant = PROP_MAX; }
    audio.setVolume(S.settings.volume); audio.duck(S.paused);
    el.style.opacity = 0; setTimeout(() => { el.style.display = 'none'; }, 1200);
    S.dying = false;
  }, 2600);
}
