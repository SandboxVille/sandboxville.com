// THE CHART (P3): the real neighbourhood, as a 3D map you can turn, and a
// list of every catalogued star within 25 light years of the ship, nearest
// first: what it is, how far it is from you and from the Sun, how old its
// light is, when Earth's light reaches it, and (in the sandbox) whether the
// drive and the supplies can get you there. Everything on it is real data
// from js/data/neighbourhood.js (Hipparcos). The only fiction on the chart
// is the ship, and the one course that will not hold.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { FLIGHT as F } from '../core/constants.js';
import { catalogue, neighbours, starName, starKind, starNote, starPos, systemD } from '../systems/catalogue.js';
import { hereD, tripEstimate } from '../systems/flight.js';

const YR_DAYS = 365.25;
const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
export const view = { yaw: 0.6, pitch: 0.45, zoom: 1, sel: null, R: 20 };

// what the chart knows, from where the ship is now
export function chartData() {
  const here = hereD();
  const P = S.P;
  const fuel = P.flight ? P.flight.tank : P.res.fuel;
  const list = neighbours(here, 25).filter(n => n.d > 0.02);
  // (the Sun is not in Hipparcos; the catalogue module adds it as HIP 0)
  const rows = list.map(n => {
    const est = fuel > 0 ? tripEstimate(here, new THREE.Vector3(n.r.x, n.r.y, n.r.z), fuel) : null;
    const reach = !!est && est.tau <= F.SUPPLY_YEARS * 0.9;
    return { hip: n.hip, name: starName(n.hip), kind: starKind(n.hip), d: n.d, fromSol: n.hip === 0 ? 0 : n.fromSol, x: n.r.x, y: n.r.y, z: n.r.z, bv: n.r.bv, V: n.r.V, note: starNote(n.hip), est, reach, visited: (P.visited || []).includes(n.hip), named: !!catalogue().names[n.hip] || n.hip === 0 };
  });
  return { here, rows, fuel, sandbox: P.mode === 'sandbox', flying: !!P.flight, thrusters: P.repair.thrusters, history: legs(), missing: catalogue().missing, source: catalogue().source };
}

// the ship's own course history (the first leg is the one nobody logged)
function legs() {
  const P = S.P, out = [];
  out.push({ text: 'LEG 0: SOL TO 4.00 LY TOWARD ALPHA CENTAURI. NOT IN THE LOG. THE PROBE CANNOT FLY THAT FAR. NOTHING RECORDS HOW THE SHIP GOT THERE.', odd: true });
  const h = P.legs || [];
  h.forEach((l, i) => out.push({ text: `LEG ${i + 1}: ${l.from} TO ${l.to}, ${l.dist.toFixed(2)} LY. SHIP ${fmtTime(l.tau)}, EARTH ${l.t.toFixed(1)} YEARS.${l.note ? ' ' + l.note : ''}` }));
  return out;
}
function fmtTime(y) { const d = y * YR_DAYS; return d < 700 ? `${Math.round(d)} DAYS` : `${y.toFixed(1)} YEARS`; }
export function lightLines(r) {
  if (r.hip === 0) return `LIGHT FROM HERE TO THE SUN: ${r.d.toFixed(2)} YEARS. WHAT YOU SEE OF IT LEFT IN ${Math.round(2026 + (S.P.stats.earthYears || 0) - r.d)}.`;
  const nowY = 2026 + (S.P.stats.earthYears || 0);
  const seesEarth = Math.round(nowY - r.fromSol);
  return `ITS LIGHT IS ${r.d < 1.5 ? Math.round(r.d * 12) + ' MONTHS' : r.d.toFixed(1) + ' YEARS'} OLD WHEN IT REACHES YOU. EARTH'S LIGHT TAKES ${r.fromSol.toFixed(1)} YEARS TO REACH IT: IF ANYONE THERE IS LOOKING, THEY SEE EARTH AS IT WAS IN ${seesEarth < 0 ? Math.abs(seesEarth) + ' BCE' : seesEarth}.`;
}

// ---------------- drawing ----------------
function bvCss(bv) { const t = Math.max(0, Math.min(1, (bv + 0.4) / 2.4)); const c = t < 0.3 ? [160 + t / 0.3 * 95, 185 + t / 0.3 * 62, 255 - t / 0.3 * 18] : t < 0.6 ? [255, 247 - (t - 0.3) / 0.3 * 53, 237 - (t - 0.3) / 0.3 * 115] : [255, 194 - (t - 0.6) / 0.4 * 46, 122 - (t - 0.6) / 0.4 * 25]; return `rgb(${c.map(v => v | 0).join(',')})`; }
export function drawChart(canvas, data) {
  const g = canvas.getContext('2d'); if (!g) return;
  const W = canvas.width, H = canvas.height;
  g.fillStyle = '#020304'; g.fillRect(0, 0, W, H);
  const here = data.here;
  const cy = Math.cos(view.yaw), sy = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
  const scale = Math.min(W, H) * 0.45 / view.R * view.zoom;
  // equatorial y is "up"; rotate about it, then tilt
  const proj = (x, y, z) => {
    const rx = x - here.x, ry = y - here.y, rz = z - here.z;
    const x1 = rx * cy - rz * sy, z1 = rx * sy + rz * cy;
    const y2 = ry * cp - z1 * sp, z2 = ry * sp + z1 * cp;
    return [W / 2 + x1 * scale, H / 2 - y2 * scale, z2];
  };
  // range rings on the plane through the ship
  g.lineWidth = 1;
  for (const rr of [5, 10, 15, 20]) {
    g.strokeStyle = rr === 20 ? 'rgba(255,179,71,0.18)' : 'rgba(255,179,71,0.09)';
    g.beginPath();
    for (let i = 0; i <= 64; i++) { const a = i / 64 * Math.PI * 2; const p = proj(here.x + Math.cos(a) * rr, here.y, here.z + Math.sin(a) * rr); i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); }
    g.stroke();
    const lp = proj(here.x + rr, here.y, here.z); g.fillStyle = 'rgba(255,179,71,0.35)'; g.font = '10px monospace'; g.fillText(`${rr} LY`, lp[0] + 3, lp[1] - 3);
  }
  // the course history
  const pts = [[0, 0, 0]];
  const s1 = systemD(1); pts.push([s1.x, s1.y, s1.z]);
  (S.P.legs || []).forEach(l => pts.push(l.toP));
  g.setLineDash([4, 4]); g.strokeStyle = 'rgba(160,160,170,0.5)';
  g.beginPath(); let p = proj(...pts[0]); g.moveTo(p[0], p[1]); p = proj(...pts[1]); g.lineTo(p[0], p[1]); g.stroke(); g.setLineDash([]);
  if (pts.length > 2) { g.strokeStyle = 'rgba(255,179,71,0.6)'; g.beginPath(); p = proj(...pts[1]); g.moveTo(p[0], p[1]); for (let i = 2; i < pts.length; i++) { p = proj(...pts[i]); g.lineTo(p[0], p[1]); } g.stroke(); }
  // a planned course
  if (S.P.flight) { const f = S.P.flight; const a = proj(...f.pos), b = proj(...f.to); g.strokeStyle = 'rgba(111,208,255,0.7)'; g.setLineDash([6, 3]); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); g.setLineDash([]); }
  // the stars, far ones first; labels skip where they would overlap (the selection and the Sun always get theirs)
  const rows = data.rows.map(r => ({ r, p: proj(r.x, r.y, r.z) })).sort((a, b) => a.p[2] - b.p[2]);
  const me0 = proj(here.x, here.y, here.z);
  const boxes = [[me0[0] + 6, me0[1] - 16, 70, 14]];
  const free = (x, y, w, h) => !boxes.some(b => x < b[0] + b[2] && x + w > b[0] && y < b[1] + b[3] && y + h > b[1]);
  const FAMOUS = new Set([71683, 70890, 87937, 32349, 16537, 8102, 37279, 104214, 97649, 91262, 113368, 108870]);
  const labelOrder = rows.slice().sort((a, b) => (b.r.hip === view.sel) - (a.r.hip === view.sel) || (b.r.hip === 0) - (a.r.hip === 0) || FAMOUS.has(b.r.hip) - FAMOUS.has(a.r.hip) || a.r.d - b.r.d);
  const labelled = new Set();
  g.font = '10px monospace';
  for (const { r, p: q } of labelOrder) {
    if (!(r.named || view.sel === r.hip)) continue;
    const txt = r.hip === 0 ? 'SOL (HOME)' : r.name; const w = g.measureText(txt).width + 4;
    if (r.hip === view.sel || r.hip === 0 || free(q[0] + 6, q[1] - 8, w, 12)) { boxes.push([q[0] + 6, q[1] - 8, w, 12]); labelled.add(r.hip); }
  }
  for (const { r, p: q } of rows) {
    const base = proj(r.x, here.y, r.z);
    g.strokeStyle = 'rgba(255,179,71,0.12)'; g.beginPath(); g.moveTo(q[0], q[1]); g.lineTo(base[0], base[1]); g.stroke();
    const M = r.hip === 0 ? 4.83 : r.V + 5 - 5 * Math.log10(Math.max(0.01, r.fromSol) / 3.261564);
    const rad = Math.max(1.2, Math.min(5, 3.4 - (M - 5) * 0.35));
    g.fillStyle = r.hip === 0 ? '#ffe28a' : bvCss(r.bv);
    g.globalAlpha = r.reach || !data.sandbox ? 1 : 0.45;
    g.beginPath(); g.arc(q[0], q[1], rad, 0, Math.PI * 2); g.fill();
    g.globalAlpha = 1;
    if (r.visited) { g.strokeStyle = '#7fe0a0'; g.beginPath(); g.arc(q[0], q[1], rad + 3, 0, Math.PI * 2); g.stroke(); }
    if (view.sel === r.hip) { g.strokeStyle = '#ffd08a'; g.lineWidth = 2; g.strokeRect(q[0] - rad - 5, q[1] - rad - 5, (rad + 5) * 2, (rad + 5) * 2); g.lineWidth = 1; }
    if (labelled.has(r.hip)) { g.fillStyle = r.hip === 0 ? '#ffe28a' : 'rgba(217,212,199,0.8)'; g.font = (r.hip === 0 ? 'bold ' : '') + '10px monospace'; g.fillText(r.hip === 0 ? 'SOL (HOME)' : r.name, q[0] + rad + 4, q[1] + 3); }
  }
  // the ship
  const me = proj(here.x, here.y, here.z);
  g.fillStyle = '#6fd0ff'; g.save(); g.translate(me[0], me[1]); g.rotate(Math.PI / 4); g.fillRect(-4, -4, 8, 8); g.restore();
  g.font = 'bold 10px monospace'; g.fillText('KESTREL-4', me[0] + 8, me[1] - 6);
}
