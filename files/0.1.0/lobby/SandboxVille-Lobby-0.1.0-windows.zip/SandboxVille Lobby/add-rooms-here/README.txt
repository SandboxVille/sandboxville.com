Put the room zips you download here. Do not unzip them.

Then, in SandboxVille, walk to a glowing EMPTY LOT sign and press E, and pick the room.
SandboxVille finds each zip by its fingerprint and checks it before it opens it.
You do not need to restart SandboxVille after you add a zip here.
