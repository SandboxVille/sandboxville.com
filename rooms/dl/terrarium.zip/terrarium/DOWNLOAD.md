# The Terrarium

## What this room does

A glass tank of small animals, each one run by its own little circuit of simulated spiking neurons. They eat, flee, and change over generations while you watch.

What it lets your AI do: It can count the animals and see what each one is doing right now (census), touch the glass at a spot to make nearby animals react (touch), and drop a food scent at a spot to make animals turn toward it (scent). Touch and scent never harm anything, and always ask before they run.

## Its door label (what it can touch, and nothing more)

- Tools for your AI: census (read only), touch, scent. Touch and scent are not destructive and never need extra confirmation, but they are the two tools that reach past just answering questions.
- It cannot read any files on your computer.
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It can keep up to 4 MB of its own private notes.
- It can ask the host what time it is and whether the page is visible (that's all "host: clock, visibility" means); it cannot ask the host anything else.

## What you need first

Node.js 22+ and a copy of the SandboxVille code. No folder and no network needed, this room is fully self-contained.

## How to add it

1. Unzip this download. You will get a folder called `terrarium/` with a `room.json` file inside (and a `view/` folder with its screen code).
2. Copy the whole `terrarium/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/terrarium/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/terrarium`
   This prints the door sign so you can read exactly what the room can touch before you trust it.
4. Run: `node harness/server.mjs --room ./rooms/terrarium --port 8150`
   (pick any free port number; 8150 is just an example)
5. Open the address it prints (something like `http://127.0.0.1:8150`) in your browser.
6. If the room asks for a folder (see "What you need first"), type the folder's path into the FILE ACCESS box and click "grant this folder". The room only ever sees files inside that one folder, and it can only read them, never change or delete them.
7. Click the consent button, then mount the room to start it.

## How to remove it

1. Close the browser tab and stop the server (press Ctrl+C in the terminal it is running in).
2. Delete the `terrarium/` folder from `rooms/` in your SandboxVille code.
3. If you had granted a folder, nothing was ever written into it, the room only ever read from it, so there is nothing to undo there.

## Things to try once it's running

- How is the tank doing?
- Touch the glass
- Drop a scent and watch who turns

