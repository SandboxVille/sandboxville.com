# Security Office

## What this room does

A live wall screen showing every action every room and every AI takes in the building, one line per decision, refusals in red. It reads the real audit log so a human can watch what is happening.

What it lets your AI do: Nothing. This room reads the audit log for you; it grants your AI zero tools.

## Its door label (what it can touch, and nothing more)

- It reads the building's own audit log and shows it on a wall screen, for you to watch.
- It cannot read any files on your computer.
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It gives your AI zero tools.

## What you need first

Node.js version 22 or newer, and a copy of the SandboxVille code on your computer (the folder that has `rooms/`, `tools/`, and `harness/` in it).

## How to add it

1. Unzip this download. You will get a folder called `security-office/` with one file inside, `room.json`.
2. Copy the `security-office/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/security-office/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/security-office`
   This prints the door sign for the room, plain text, so you can see exactly what it is (and is not) allowed to touch.

This room does not give your AI any tools and does not ask for any files or network access, so once you have read its door sign there is nothing else to turn on.

## How to remove it

Delete the `security-office/` folder from `rooms/` in your SandboxVille code. Nothing else to undo, it never had access to anything of yours.

## Things to try once it's running

- Watch the log while your AI works in another room
- Find a refused call and read why

