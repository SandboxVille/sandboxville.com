// The sensor catalogue: building a system's star field from the baked
// Hipparcos data, and the sighting verb itself (trySight). This is the one
// mechanism every dread system in the game is an instance of (design doc
// SS5.5) -- everything else just decides what happens once something is, or
// is not, under the reticle.
//
// Note on the sensors <-> entities import cycle: sensors.trySight defers to
// entities.sightNull when the reticle finds nothing else, and entities'
// per-frame drift/collapse logic needs sensors.driftedDir/lockRadius. Both
// directions only call the other's exports from inside functions invoked
// during gameplay, never at module-evaluation time, so the circular import
// is safe under ES modules (a bundler or browser resolves both files fully
// before either function is ever called).
import * as THREE from 'three';
import { STAR_FRAG } from '../render/sky.js';
import { S } from '../core/state.js';
import { SKY_R, GIANT_R, ZOOM5, BASE_ZOOMS } from '../core/constants.js';
import { dirFromRaDec, mulberry32, randomDir, bvColor, fmtRA, raDec, noiseGLSL, fmtYearFromLy } from '../core/utils.js';
import { emit } from '../core/events.js';
import { buildPrintedSky } from '../render/world.js';
import { scene, camera, ship, renderer } from '../render/scene.js';
import { say } from '../ui/hud.js';
import { unlockFragment } from './journal.js';
import { refreshPause } from '../ui/pause-bridge.js';
import { sightResource } from './inventory.js';
import { sightNull } from './entities.js';
import { doAutosave } from './save-state.js';
import { systemData, placeData } from './catalogue.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);

export function starName(i) {
  const m = S.sys.meta[i];
  if (m.type === 'scrap') return 'SCRAP CLUSTER';
  if (m.type === 'fuel') return 'FUEL CLUSTER';
  const hip = m.hip;
  if (hip === 0) return 'UNCATALOGUED';
  return S.sys.currentData.names[hip] ? `${S.sys.currentData.names[hip]} (HIP ${hip})` : `HIP ${hip}`;
}

export function disposeSystem() {
  const sys = S.sys;
  scene.remove(sys.group);
  if (sys.group) sys.group.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  document.querySelectorAll('.mark').forEach(el => el.remove());
  sys.group = new THREE.Group(); scene.add(sys.group);
  sys.giant = sys.halo = sys.giantMat = sys.haloMat = null; sys.starMat = sys.starPoints = null;
  sys.driftSet = new Set(); sys.driftLog.clear(); sys.dupIndices.length = 0; sys.dupCenter = null;
  sys.nullDir = null; sys.beaconIndex = -1;
}

export function buildSystem(n, opts = {}) {
  disposeSystem();
  const sys = S.sys;
  // P3: System 2 and sandbox places are re-seen from the 3D catalogue (systems/catalogue.js)
  const place = S.P.place;
  sys.currentData = place ? placeData(place) : systemData(n);
  sys.isPlace = !!place;
  sys.dirs = []; sys.meta = [];
  const rawStars = sys.currentData.stars;
  const rnd = mulberry32(place ? 5000 + place.hip : 1000 + n * 97);

  rawStars.forEach((s) => {
    const [x, y, z, m, bv, hip, shift, distLy] = s;
    sys.dirs.push(new THREE.Vector3(x, y, z));
    sys.meta.push({ type: 'star', mag: m, bv, hip, shift, distLy });
    if (hip === 0) sys.solIndex = sys.dirs.length - 1;
  });

  // System 2 anomaly: the duplicate. (P3: the real Sirius now blazes 0.6 ly away in the middle of the two copies.)
  if (n === 2 && !place && sys.currentData.target) {
    sys.dupCenter = dirFromRaDec(sys.currentData.target.ra, sys.currentData.target.dec);
    const up = Math.abs(sys.dupCenter.y) > 0.95 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
    const perp = new THREE.Vector3().crossVectors(sys.dupCenter, up).normalize();
    const ang = THREE.MathUtils.degToRad(2.2);
    const d1 = sys.dupCenter.clone().multiplyScalar(Math.cos(ang)).add(perp.clone().multiplyScalar(Math.sin(ang))).normalize();
    const d2 = sys.dupCenter.clone().multiplyScalar(Math.cos(ang)).add(perp.clone().multiplyScalar(-Math.sin(ang))).normalize();
    [d1, d2].forEach(d => {
      sys.dirs.push(d);
      sys.meta.push({ type: 'star', mag: -1.44, bv: 0.009, hip: 32349, shift: 0, distLy: sys.currentData.target.distLy, dup: true });
      sys.dupIndices.push(sys.dirs.length - 1);
    });
  }

  // resource nodes: same sighting verb as stars, distinct color, static per system
  const savedCollected = S.nodeCollected[n] || null;
  // P2: resources are physical chunks in the field now (render/world.js), not dots in the sky
  rnd(); rnd();
  const nScrap = 0, nFuel = 0;
  const nodeCollected = [];
  for (let i = 0; i < nScrap; i++) {
    sys.dirs.push(randomDir(rnd)); sys.meta.push({ type: 'scrap', collected: savedCollected ? !!savedCollected[nodeCollected.length] : false });
    nodeCollected.push(sys.meta[sys.meta.length - 1].collected);
  }
  for (let i = 0; i < nFuel; i++) {
    sys.dirs.push(randomDir(rnd)); sys.meta.push({ type: 'fuel', collected: savedCollected ? !!savedCollected[nodeCollected.length] : false });
    nodeCollected.push(sys.meta[sys.meta.length - 1].collected);
  }
  S.nodeCollected[n] = nodeCollected;

  // System 3 anomaly: the drift.
  if (n === 3 && !place) {
    const candidates = sys.meta.map((m, i) => ({ i, m })).filter(o => o.m.type === 'star' && !o.m.dup).sort((a, b) => a.m.mag - b.m.mag).slice(0, 5);
    candidates.forEach(c => sys.driftSet.add(c.i));
  }

  // Null point: present in every system from the start.
  sys.nullDir = randomDir(rnd);
  for (let tries = 0; tries < 40; tries++) {
    let minA = Infinity;
    for (let i = 0; i < sys.dirs.length; i++) {
      if (sys.meta[i].type !== 'star') continue;
      const a = sys.dirs[i].angleTo(sys.nullDir);
      if (a < minA) minA = a;
      if (minA < THREE.MathUtils.degToRad(3)) break;
    }
    if (minA >= THREE.MathUtils.degToRad(3)) break;
    sys.nullDir = randomDir(rnd);
  }

  // Beacon: System 3 only.
  if (n === 3 && !place) {
    const beaconCandidates = sys.meta.map((m, i) => ({ i, m })).filter(o => o.m.type === 'star' && !o.m.dup && o.i !== sys.solIndex && !sys.driftSet.has(o.i)).sort((a, b) => a.m.mag - b.m.mag);
    sys.beaconIndex = beaconCandidates.length ? beaconCandidates[Math.min(2, beaconCandidates.length - 1)].i : -1;
  }

  sys.N = sys.dirs.length;
  sys.pos = new Float32Array(sys.N * 3); sys.mag = new Float32Array(sys.N); sys.col = new Float32Array(sys.N * 3);
  const aHide = new Float32Array(sys.N);
  sys.dirs.forEach((d, i) => {
    sys.pos.set([d.x * SKY_R, d.y * SKY_R, d.z * SKY_R], i * 3);
    const m = sys.meta[i];
    if (m.type === 'scrap') { sys.mag[i] = m.collected ? 12 : 5.6; sys.col.set([0.15, 0.75, 1.0], i * 3); }
    else if (m.type === 'fuel') { sys.mag[i] = m.collected ? 12 : 5.3; sys.col.set([1.0, 0.3, 0.66], i * 3); }
    else { sys.mag[i] = m.mag; sys.col.set(bvColor(m.bv), i * 3); }
  });

  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute('position', new THREE.BufferAttribute(sys.pos, 3));
  starGeo.setAttribute('aMag', new THREE.BufferAttribute(sys.mag, 1));
  starGeo.setAttribute('aColor', new THREE.BufferAttribute(sys.col, 3));
  starGeo.setAttribute('aHide', new THREE.BufferAttribute(aHide, 1));
  sys.starMat = new THREE.ShaderMaterial({
    uniforms: { uPR: { value: renderer.getPixelRatio() }, uGain: { value: 0 }, uFade: { value: 0 }, uMagCut: { value: S.upgrades.deepRange ? 6.6 : 5.2 }, uNullDir: { value: new THREE.Vector3(0, 0, -1) }, uLens: { value: 0 } },
    vertexShader: `
      attribute float aMag; attribute vec3 aColor; attribute float aHide;
      uniform float uPR, uGain, uFade, uMagCut, uLens; uniform vec3 uNullDir;
      varying vec3 vCol; varying float vA; varying float vSize;
      void main() {
        // gravitational-lens look around the null bearing: stars pushed outward
        // from an empty point, as if something massive and unseen sits there
        vec3 pos = position;
        float R = length(pos); vec3 d = pos / R;
        float c = dot(d, uNullDir);
        if (uLens > 0.001 && c > 0.985) {
          vec3 perp = d - uNullDir * c; float pl = max(length(perp), 1e-5);
          float ang = asin(clamp(pl, 0.0, 1.0));
          float push = uLens * 0.0009 / max(ang, 0.003);
          push = min(push, 0.05) * smoothstep(0.172, 0.05, ang);
          d = uNullDir * cos(ang + push) + (perp / pl) * sin(ang + push);
          pos = d * R;
        }
        float m = aMag - uGain;
        float s = clamp(1.3 + 0.6 * (6.8 - m), 1.0, 17.0);
        vA = clamp(0.16 + 0.15 * (6.8 - m), 0.0, 1.0) * uFade * (1.0 - aHide);
        if (m > uMagCut + 1.6) vA = 0.0;
        vCol = aColor;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        gl_PointSize = s * uPR; vSize = s * uPR;
      }`,
    fragmentShader: STAR_FRAG,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  sys.starPoints = new THREE.Points(starGeo, sys.starMat);
  sys.starPoints.frustumCulled = false;
  sys.group.add(sys.starPoints);
  // P3: a star brighter than about magnitude -2.5 is not a point any more; it glares (Sirius from
  // 0.6 ly is -7.2, a hundred times brighter than Sirius from Earth; Alpha Centauri A from 0.4 ly is -5.2)
  sys.glares = [];
  sys.meta.forEach((m, i) => {
    if (m.type !== 'star' || m.dup || m.hip === 0 || m.mag > -2.5) return;
    const deg = Math.min(5, 0.9 + 0.45 * (-2.5 - m.mag));
    const c = bvColor(m.bv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glareTex(), color: new THREE.Color(c[0], c[1], c[2]), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: Math.min(1, 0.55 + 0.06 * (-2.5 - m.mag)) }));
    const d = 4000; sp.scale.setScalar(2 * d * Math.tan(THREE.MathUtils.degToRad(deg)));
    sp.position.copy(sys.dirs[i]).multiplyScalar(d); sp.renderOrder = 1;
    sys.group.add(sp); sys.glares.push({ sp, i });
  });
  if (sys.nullDir) sys.starMat.uniforms.uNullDir.value.copy(sys.nullDir);
  buildPrintedSky(starGeo, sys.starMat);

  const solDir = sys.dirs[sys.solIndex].clone();
  if (!opts.keepOrientation) ship.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), solDir);

  if (n === 1 && !place) {
    const acIndex = sys.meta.findIndex(m => m.hip === 71683);
    const acDir = acIndex >= 0 ? sys.dirs[acIndex].clone() : solDir.clone();
    const perp = new THREE.Vector3().crossVectors(acDir, new THREE.Vector3(0, 1, 0)).normalize();
    sys.giantDir = acDir.clone().multiplyScalar(Math.cos(THREE.MathUtils.degToRad(19))).add(perp.multiplyScalar(Math.sin(THREE.MathUtils.degToRad(19)))).normalize();
    sys.giantDist = 1500;
    sys.giantMat = new THREE.ShaderMaterial({
      uniforms: { uLight: { value: acDir.clone() }, uTime: { value: 0 }, uWake: { value: 0.35 } },
      vertexShader: `varying vec3 vN, vW, vO;
        void main(){ vO = position; vN = normalize(mat3(modelMatrix) * normal); vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: `uniform vec3 uLight; uniform float uTime; uniform float uWake; varying vec3 vN, vW, vO; ${noiseGLSL}
        void main(){
          vec3 n = normalize(vN), o = normalize(vO);
          float warp = fbm(o * 3.0 + vec3(0.0, 0.0, uTime * 0.003));
          float bands = 0.5 + 0.5 * sin(o.y * 42.0 + warp * 4.0);
          float storms = fbm(vec3(o.x * 5.0, o.y * 24.0, o.z * 5.0));
          vec3 base = mix(vec3(0.20, 0.17, 0.19), vec3(0.62, 0.50, 0.38), bands);
          base = mix(base, vec3(0.78, 0.66, 0.52), storms * 0.35);
          float ndl = dot(n, uLight);
          vec3 c = base * smoothstep(-0.03, 0.3, ndl) * 3.2 * uWake + base * 0.004;
          vec3 V = normalize(cameraPosition - vW);
          float rim = pow(1.0 - max(dot(n, V), 0.0), 3.0);
          float fwd = pow(max(dot(-V, uLight), 0.0), 5.0);
          c += vec3(1.0, 0.8, 0.58) * rim * fwd * 4.0 * uWake * smoothstep(-0.4, 0.15, ndl);
          gl_FragColor = vec4(c, 1.0);
        }`,
    });
    sys.giant = new THREE.Mesh(new THREE.SphereGeometry(GIANT_R, 128, 96), sys.giantMat);
    sys.giant.rotation.set(0.3, 0.0, 0.42);
    // gfx pass: the atmosphere as a real limb. For each pixel of the shell, the
    // sight line's closest approach to the Body gives an altitude; haze falls off
    // with a scale height, and a forward-scattering phase makes the side where
    // the hidden star sits burn while the rest of the ring stays a thin grey line.
    sys.haloMat = new THREE.ShaderMaterial({
      uniforms: { uLight: { value: acDir.clone() }, uWake: { value: 0.35 }, uR: { value: GIANT_R } },
      vertexShader: `varying vec3 vW; varying vec3 vC; varying float vR; uniform float uR;
        void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; vC = (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz; vR = uR * length(modelMatrix[0].xyz); gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: `uniform vec3 uLight; uniform float uWake; varying vec3 vW; varying vec3 vC; varying float vR;
        void main(){
          vec3 rd = normalize(vW - cameraPosition);
          vec3 oc = vC - cameraPosition;
          float tca = dot(oc, rd);
          float p = length(oc - rd * tca);                 // closest approach of the sight line
          float h = (p - vR) / vR;                         // altitude in Body radii
          if (h < 0.0) discard;
          float H = 0.011;
          float dens = exp(-h / H);
          float mu = dot(rd, uLight);
          float g = 0.78;
          float phase = (1.0 - g * g) / pow(1.0 + g * g - 2.0 * g * mu, 1.5) * 0.18;
          // which side of the disc the star is behind
          vec3 toLimb = normalize(oc - rd * tca) * -1.0;
          float side = smoothstep(-0.6, 0.5, dot(toLimb, normalize(uLight - rd * dot(uLight, rd))));
          vec3 warm = vec3(1.0, 0.58, 0.30), pale = vec3(0.85, 0.82, 0.78);
          vec3 col = mix(warm, pale, smoothstep(0.0, 0.035, h));
          float lum = dens * (0.05 + phase * (0.35 + 0.65 * side) * 2.2);
          gl_FragColor = vec4(col * lum * uWake, 1.0);
        }`,
      side: THREE.BackSide, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    });
    sys.halo = new THREE.Mesh(new THREE.SphereGeometry(GIANT_R * 1.08, 128, 64), sys.haloMat);
    sys.giant.position.copy(sys.giantDir).multiplyScalar(sys.giantDist); sys.halo.position.copy(sys.giant.position);
    sys.group.add(sys.giant, sys.halo);
  }

  S.system = n;
  S.locks = []; S.fixed = false; S.solSeen = false; S.revealed = false; S.revealT = 0;
  S.t0 = performance.now(); S.endQueued = false;
  S.sys3EnterTime = n === 3 ? performance.now() : null;
  applyUpgradeEffects();
}

let _glare = null;
function glareTex() {
  if (_glare) return _glare;
  const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d');
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, 'rgba(255,255,255,1)'); grd.addColorStop(0.08, 'rgba(255,255,255,0.95)'); grd.addColorStop(0.22, 'rgba(255,255,255,0.45)'); grd.addColorStop(0.5, 'rgba(255,255,255,0.12)'); grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
  g.globalCompositeOperation = 'lighter'; g.fillStyle = 'rgba(255,255,255,0.10)'; g.fillRect(0, 62, 128, 4); g.fillRect(62, 0, 4, 128);
  _glare = new THREE.CanvasTexture(c); _glare.colorSpace = THREE.SRGBColorSpace; return _glare;
}

export function applyUpgradeEffects() {
  S.ZOOMS = S.upgrades.zoom5 ? [...BASE_ZOOMS, ZOOM5] : BASE_ZOOMS.slice();
  if (S.zoom > S.ZOOMS.length - 1) S.zoom = S.ZOOMS.length - 1;
  if (S.sys.starMat) S.sys.starMat.uniforms.uMagCut.value = S.upgrades.deepRange ? 6.6 : 5.2;
}

export function lockRadius() { const base = THREE.MathUtils.degToRad(Math.max(0.35, S.fov * 0.035)); return S.upgrades.wideCone ? base * 1.4 : base; }

export function currentDirOf(i) {
  if (S.system === 3 && S.sys.driftSet.has(i)) return driftedDir(i);
  return S.sys.dirs[i];
}
export function driftedDir(i) {
  const base = S.sys.dirs[i];
  const seed = (i * 2654435761) >>> 0;
  const rnd = mulberry32(seed);
  const axis = randomDir(rnd);
  const rate = 0.01 + rnd() * 0.03; // deg per minute
  const minutes = (performance.now() - S.t0) / 60000;
  const ang = THREE.MathUtils.degToRad(rate * minutes);
  return base.clone().applyAxisAngle(axis, ang).normalize();
}

export function addMark(i) {
  const mk = document.createElement('div'); mk.className = 'mark'; document.body.appendChild(mk);
  S.locks.push({ i, el: mk });
}

export function driftRecheck(i) {
  const cur = driftedDir(i);
  const prev = S.sys.driftLog.get(i);
  const lock = $('lock');
  if (!prev) { S.sys.driftLog.set(i, { dir: cur.clone(), tMin: (performance.now() - S.t0) / 60000 }); lock.textContent = `${starName(i)}\nPOSITION LOGGED FOR RE-CHECK`; }
  else {
    const deltaDeg = THREE.MathUtils.radToDeg(cur.angleTo(prev.dir));
    const deltaMin = (performance.now() - S.t0) / 60000 - prev.tMin;
    lock.textContent = `${starName(i)}  //  RE-CHECK\nBEARING DELTA ${deltaDeg.toFixed(4)} DEG OVER ${deltaMin.toFixed(1)} MIN`;
    S.sys.driftLog.set(i, { dir: cur.clone(), tMin: (performance.now() - S.t0) / 60000 });
  }
  lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 6000);
  audio.blip(700, 0.04);
}

export function trySight(canSight) {
  if (!S.awake || S.ended || S.paused || S.dying || S.cycling) return;
  const sys = S.sys;
  if (S.P.flight) {
    audio.blip(220, 0.02);
    const lk = $('lock'); lk.textContent = 'THE SKY IS MOVING. NOTHING OUT THERE HOLDS STILL LONG ENOUGH TO SIGHT.';
    lk.style.opacity = 1; clearTimeout(lk._t); lk._t = setTimeout(() => lk.style.opacity = 0, 2600);
    return;
  }
  if (!canSight) {
    audio.blip(220, 0.02);
    const lock = $('lock'); lock.textContent = 'NO SKY VISIBLE HERE -- GO TO THE CONSOLE WINDOW OR EVA';
    lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 2200);
    return;
  }
  camera.rotation.y = S.yaw; camera.rotation.x = S.pitch; camera.rotation.z = S.roll; camera.updateMatrixWorld(true);
  camera.getWorldDirection(S.fwd);
  const r = lockRadius(), cosR = Math.cos(r);
  const magCut = S.upgrades.deepRange ? 6.2 : 5.2;
  const gR = sys.giant ? Math.asin(Math.min(1, GIANT_R / sys.giantDist)) : -1;
  let best = -1, bestScore = Infinity;
  for (let i = 0; i < sys.N; i++) {
    const d = currentDirOf(i); const c = d.dot(S.fwd); if (c < cosR) continue;
    const m = sys.meta[i];
    const curMag = sys.mag[i];
    if (m.type !== 'scrap' && m.type !== 'fuel') { if (curMag - Math.log2(S.ZOOMS[0] / S.fov) > magCut) continue; }
    else if (m.collected) continue;
    if (sys.giant && d.angleTo(sys.giantDir) < gR) continue;
    const score = Math.acos(Math.min(1, c)) / r + curMag * 0.08;
    if (score < bestScore) { bestScore = score; best = i; }
  }
  const lock = $('lock');
  if (best < 0) {
    if (sys.nullDir && S.fwd.angleTo(sys.nullDir) < r) { sightNull(); return; }
    audio.blip(220, 0.03);
    // deep-field beat: zoomed in on empty sky. Real: the Hubble Ultra Deep Field found ~10,000 galaxies in 3.1 x 3.1 arcmin;
    // the reticle covers at least 0.38 square degrees (~1,400 square arcmin), so a patch this size holds well over a million.
    if (S.zoom >= 2 && (!S.P.flags.deepField || Math.random() < 0.15)) {
      S.P.flags.deepField = true;
      lock.textContent = 'NOTHING CATALOGUED IN THE RETICLE.\nDEEP EXPOSURES FROM EARTH FIND OVER A MILLION GALAXIES IN A PATCH THIS SIZE.\nMANY HOLD BILLIONS OF STARS. YOU ARE LOOKING STRAIGHT AT THEM AND SEEING NOTHING.';
      lock.style.opacity = 1; clearTimeout(lock._t); lock._t = setTimeout(() => lock.style.opacity = 0, 9000); return;
    }
    lock.textContent = 'NOTHING IN RETICLE'; lock.style.opacity = 1; clearTimeout(lock._t); lock._t = setTimeout(() => lock.style.opacity = 0, 1600); return;
  }
  const m = sys.meta[best];
  if (m.type === 'scrap' || m.type === 'fuel') { sightResource(best, m); return; }
  audio.blip(880, 0.05);
  if (m.hip === 0) {
    lock.textContent = `SOL  //  MAG ${m.mag.toFixed(1)}  //  ${m.distLy.toFixed(2)} LY\nTHIS LIGHT LEFT HOME ${m.distLy.toFixed(1)} YEARS AGO${!S.fixed && S.P.storyStep >= 2 ? '\nTHE FIX MEASURES FROM THE SUN. IT NEEDS THREE OTHER STARS.' : ''}`;
    lock.style.opacity = 1; clearTimeout(lock._t); lock._t = setTimeout(() => lock.style.opacity = 0, 8000);
    if (!S.solSeen) {
      S.solSeen = true;
      say('THAT DOT IS THE SUN. EVERY PERSON WHO HAS EVER LIVED IS INSIDE IT.', { delay: 1800, hold: 24000 });
      say(`ITS LIGHT TOOK ${m.distLy < 1.5 ? Math.max(1, Math.round(m.distLy * 12)) + ' MONTHS' : Math.round(m.distLy) + ' YEARS'} TO GET HERE. WHATEVER IS HAPPENING AT HOME RIGHT NOW, YOU WILL NOT SEE IT UNTIL THEN.`, { delay: 5200, hold: 26000 });
      emit('solSeen');
    }
    return;
  }
  const alreadyLocked = S.locks.some(l => l.i === best);
  const isDrift = sys.driftSet.has(best);
  if (alreadyLocked && isDrift) { driftRecheck(best); return; }
  if (alreadyLocked) { lock.textContent = `${starName(best)}\nALREADY SIGHTED`; lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 1800); return; }
  // System 2: the real Sirius and its two copies share one catalogue number
  const siriusLocks = S.system === 2 && !sys.isPlace ? S.locks.filter(l => sys.meta[l.i].hip === 32349).length : 0;
  if (siriusLocks > 0 && (m.dup || (S.system === 2 && !sys.isPlace && m.hip === 32349))) {
    lock.textContent = `${starName(best)}  //  MAG ${m.mag.toFixed(1)}\nSAME CATALOGUE NUMBER, ${siriusLocks >= 2 ? 'THIRD' : 'SECOND'} BEARING`;
    lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 6000);
    addMark(best);
    say(siriusLocks >= 2 ? 'THREE BEARINGS. ONE STAR. THE CATALOGUE PERMITS ONE ANSWER.' : 'THE CATALOGUE PERMITS ONE ANSWER.', { delay: 800, hold: 16000 });
    unlockFragment(2, 'duplicate');
    emit('duplicate', siriusLocks + 1);
    if (S.locks.length === 3 && !S.fixed) computeFix();
    return;
  }
  lock.textContent = `${starName(best)}  //  MAG ${m.mag.toFixed(1)}  //  ${lyText(m.distLy)}\n${lightLine(m.distLy)}`;
  lock.style.opacity = 1; clearTimeout(lock._t); lock._t = setTimeout(() => lock.style.opacity = 0, 6500);
  emit('sighted', best);
  addMark(best);
  if (isDrift) sys.driftLog.set(best, { dir: driftedDir(best).clone(), tMin: (performance.now() - S.t0) / 60000 });
  if (S.locks.length === 3 && !S.fixed) computeFix();
}

export async function computeFix() {
  S.fixed = true;
  emit('fix', S.system);
  unlockFragment(S.system, 'fixed');
  const sys = S.sys;
  const D = new THREE.Vector3(...sys.currentData.D); const dist = D.length(); const [ra, dec] = raDec(D.clone().normalize());
  await say('COMPUTING FIX FROM 3 REFERENCES...', { delay: 1800 });
  await say(`FIX: ${dist.toFixed(2)} LIGHT YEARS FROM SOL`, { delay: 2600, hold: 40000 });
  await say(`BEARING FROM SOL: RA ${fmtRA(ra)}  DEC ${dec.toFixed(1)} DEG`, { delay: 900, hold: 40000 });
  if (sys.currentData.target) await say(`NEAREST CATALOGUED BODY: ${sys.currentData.target.name}, ${(sys.currentData.target.distLy - dist).toFixed(2)} LY FURTHER`, { delay: 1800, hold: 40000 });
  if (S.system >= 2) {
    const off = 0.004 + (S.system * 37 % 11) / 1000;
    await say(`INDEPENDENT ARRAY: ${(dist + off).toFixed(2)} LY  //  PRIMARY ARRAY: ${dist.toFixed(2)} LY  //  NEITHER IS FLAGGED.`, { delay: 1400, hold: 30000 });
  }
}

function lyText(ly) { return ly < 100 ? `${ly.toFixed(1)} LY` : `${Math.round(ly).toLocaleString('en-US')} LY`; }
function lightLine(ly) {
  if (ly < 1.5) return `THIS LIGHT LEFT IT ${Math.max(1, Math.round(ly * 12))} MONTHS AGO. YOU SEE IT AS IT WAS, NOT AS IT IS.`;
  if (ly < 60) return `THIS LIGHT LEFT IT ${ly.toFixed(0)} YEARS AGO. YOU SEE IT AS IT WAS, NOT AS IT IS.`;
  return `THIS LIGHT LEFT IT ${fmtYearFromLy(ly, 2026 + (S.P.stats.earthYears || 0))}. IT MAY NOT LOOK LIKE THIS ANY MORE. NOTHING HERE CAN TELL YOU.`;
}
