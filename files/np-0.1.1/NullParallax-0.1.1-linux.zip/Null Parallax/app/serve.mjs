// Null Parallax: a small web server for this computer only.
// It serves the files in ../game to this computer (127.0.0.1) and nothing else:
// no other network interface, no folder listings, no files outside ../game.
// It uses the same port each time, because the browser keeps your saves per address.
import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { join, resolve, sep, extname, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const GAME = resolve(dirname(fileURLToPath(import.meta.url)), "..", "game");
const FIRST_PORT = 47823, TRIES = 10;
const args = process.argv.slice(2);
const OPEN = args.includes("--open");
const pi = args.indexOf("--port");
const WANT = pi >= 0 ? Number(args[pi + 1]) : 0;

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".glb": "model/gltf-binary",
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8",
  ".wav": "audio/wav", ".ogg": "audio/ogg", ".mp3": "audio/mpeg"
};

function send(res, code, text) {
  res.writeHead(code, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  res.end(text);
}

function makeServer(port) {
  const okHosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`]);
  return http.createServer(async (req, res) => {
    try {
      if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Only GET here.");
      if (!okHosts.has(String(req.headers.host || "").toLowerCase())) return send(res, 403, "Wrong address.");
      let path = decodeURIComponent(new URL(req.url, "http://127.0.0.1").pathname);
      if (path.includes("\0")) return send(res, 400, "Bad path.");
      if (path.endsWith("/")) path += "index.html";
      const file = resolve(GAME, "." + path);
      if (file !== GAME && !file.startsWith(GAME + sep)) return send(res, 403, "Not here.");
      const st = await stat(file).catch(() => null);
      if (!st || !st.isFile()) return send(res, 404, "Not found.");
      const body = await readFile(file);
      res.writeHead(200, { "Content-Type": TYPES[extname(file).toLowerCase()] || "application/octet-stream", "Content-Length": body.length,
        "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
      res.end(req.method === "HEAD" ? undefined : body);
    } catch {
      send(res, 500, "Something went wrong.");
    }
  });
}

function listen(port) {
  return new Promise((ok, fail) => {
    const s = makeServer(port);
    s.once("error", fail);
    s.listen({ port, host: "127.0.0.1", backlog: 128 }, () => ok(s));
  });
}

function openBrowser(url) {
  try {
    if (process.platform === "win32") spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore", windowsHide: true }).unref();
    else if (process.platform === "darwin") spawn("open", [url], { detached: true, stdio: "ignore" }).unref();
    else spawn("xdg-open", [url], { detached: true, stdio: "ignore" }).unref();
  } catch {}
}

const ports = WANT ? [WANT] : Array.from({ length: TRIES }, (_, i) => FIRST_PORT + i);
let server = null, port = 0;
for (const p of ports) {
  try { server = await listen(p); port = p; break; } catch {}
}
if (!server) {
  console.log(`  Could not start: the ports ${ports[0]} to ${ports[ports.length - 1]} are all in use.`);
  console.log("  Close other copies of Null Parallax, then try again.");
  process.exit(1);
}
const url = `http://127.0.0.1:${port}/`;
console.log(`  Null Parallax is running at ${url}`);
if (port !== FIRST_PORT) console.log(`  (Port ${FIRST_PORT} was busy. Saves made on this port stay with this port.)`);
console.log("  Keep this window open while you play. Close it to stop the game.");
if (OPEN) openBrowser(url);
