// Inventory/scrap: resource nodes (sighted with the same verb as a star) and
// the CH1 off-path secret, which is found rather than sighted.
import { S } from '../core/state.js';
import { refreshPause } from '../ui/pause-bridge.js';
import { say } from '../ui/hud.js';
import { unlockFragment } from './journal.js';
import { doAutosave } from './save-state.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);

export function sightResource(i, m) {
  const lock = $('lock');
  m.collected = true;
  const sys = S.sys;
  sys.mag[i] = 12; sys.starPoints.geometry.attributes.aMag.array[i] = 12; sys.starPoints.geometry.attributes.aMag.needsUpdate = true;
  if (m.type === 'scrap') S.scrap++; else S.fuel++;
  S.nodeCollected[S.system] = S.nodeCollected[S.system] || [];
  audio.pickup(m.type);
  lock.textContent = `${m.type === 'scrap' ? 'SCRAP' : 'FUEL'} RECOVERED  //  TOTAL ${m.type === 'scrap' ? S.scrap : S.fuel}`;
  lock.style.opacity = 1; setTimeout(() => lock.style.opacity = 0, 2600);
  refreshPause();
  doAutosave();
}

// CH1: the off-path secret. No mechanical reward -- one bonus journal
// fragment, findable only by flying around the hull instead of through it.
export function foundSecret() {
  if (S.secretFound) return;
  S.secretFound = true;
  audio.pickup('fuel');
  say('PERSONAL EFFECTS CANISTER RECOVERED. NOT ON ANY MANIFEST.', { delay: 100, hold: 6000 });
  unlockFragment(1, 'secret');
  refreshPause();
  doAutosave();
}
