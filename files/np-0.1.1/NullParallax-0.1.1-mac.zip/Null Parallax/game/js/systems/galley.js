








import { S } from '../core/state.js';
import { power, countParts } from './survival.js';
import { flash, say } from '../ui/hud.js';
import { doAutosave } from './save-state.js';
import * as audio from '../audio.js';
import { RECIPES, DISHES, RAW, EAT_ORDER, DRINK_ORDER } from '../data/recipes.js';

export const RECLAIM_COST = { salvage: 2, ore: 1 };
export const RECLAIM_SECONDS = 150, CONDENSATE_SECONDS = 240, WATER_CAP = 10;
const F = () => S.P.flags;

export const stations = [
  { id: 'eat', z: -5.95, label: 'EAT RATION', detail: () => `${S.P.res.meals} PACKS` },
  { id: 'drink', z: -6.55, label: 'DRINK WATER', detail: () => `${S.P.res.water} POUCHES` },
  { id: 'meal', z: -7.15, label: 'PRINT MEAL', detail: () => '1 ORE + 1 SALVAGE + 5 BATTERY' },
  { id: 'water', z: -7.75, label: 'MELT ICE', detail: () => '1 ICE + 3 BATTERY = 2 WATER' },
  { id: 'reclaim', z: -8.35, label: 'WATER RECLAIMER', detail: () => F().reclaimFixed
    ? `WORKING: 1 WATER EVERY ${RECLAIM_SECONDS / 60} MIN ON MAIN POWER (UP TO ${WATER_CAP})`
    : `BROKEN. FIX: ${RECLAIM_COST.salvage} SALVAGE + ${RECLAIM_COST.ore} ORE` },
  // v0.5 slice B: the hot plate. F opens the recipe list (data/recipes.js)
  { id: 'cook', z: -8.95, label: 'COOK', detail: () => cookPanel.open ? 'F: COOK THE HIGHLIGHTED RECIPE  //  1-5: COOK THAT ONE' : `${RECIPES.length} RECIPES  //  ${dishCount()} COOKED DISHES READY` },
];
const dishCount = () => Object.keys(DISHES).reduce((n, k) => n + (k === 'spoiled' ? 0 : S.P.res[k] || 0), 0);
// what EAT RATION / DRINK WATER would serve next: the best cooked dish first, then the raw pack, then a raw
// plant; a spoiled mess or a toxic plant only when nothing else is left (and it makes you sick)
export function nextServing(kind) {
  const R = S.P.res;
  const order = kind === 'eat' ? [...EAT_ORDER, 'meals', 'plant', 'spoiled', 'badplant'] : [...DRINK_ORDER, 'water'];
  return order.find(k => (R[k] || 0) >= 1) || null;
}
function servingLabel(k) { return DISHES[k] ? DISHES[k].label : { meals: 'RATION', water: 'WATER', plant: 'RAW PLANT', badplant: 'TOXIC PLANT' }[k]; }
function eatDetail(kind) {
  const R = S.P.res, n = nextServing(kind);
  const base = kind === 'eat' ? `${R.meals} PACKS` : `${R.water} POUCHES`;
  const cooked = (kind === 'eat' ? EAT_ORDER : DRINK_ORDER).reduce((a, k) => a + (R[k] || 0), 0);
  return base + (cooked ? ` + ${cooked} COOKED` : '') + (n && n !== 'meals' && n !== 'water' ? `  //  NEXT: ${servingLabel(n)}${n === 'spoiled' || n === 'badplant' ? ' (TOXIC: MAKES YOU SICK)' : ''}` : '');
}
stations[0].detail = () => eatDetail('eat');
stations[1].detail = () => eatDetail('drink');

// ---- eating and drinking something: a dish from the table, or a raw thing ----
function consume(k) {
  const P = S.P, R = P.res, L = P.life, Fd = P.food;
  R[k]--;
  if (k === 'meals') { L.hunger = Math.min(100, L.hunger + RAW.meals.hunger); return 'RATION EATEN. HUNGER RESTORED.'; }
  if (k === 'water') { L.thirst = Math.min(100, L.thirst + RAW.water.thirst); return 'WATER DRUNK. THIRST RESTORED.'; }
  if (k === 'plant') { L.hunger = Math.min(100, L.hunger + RAW.plant.hunger); L.thirst = Math.min(100, L.thirst + RAW.plant.thirst); return 'A RAW PLANT. CHEWY, BUT FOOD. COOKED IT WOULD DO MORE.'; }
  if (k === 'badplant') { L.hunger = Math.min(100, L.hunger + 8); Fd.sick = Math.max(Fd.sick, 120); sickSay(); return 'YOU ATE A TOXIC PLANT. YOU FEEL SICK.'; }
  const d = DISHES[k];
  L.hunger = Math.min(100, L.hunger + d.hunger); L.thirst = Math.min(100, L.thirst + d.thirst);
  if (d.sick) { Fd.sick = Math.max(Fd.sick, d.sick); sickSay(); return `${d.label}. IT TASTES WRONG. YOU FEEL SICK.`; }
  if (d.fed) Fd.fed = Math.max(Fd.fed, d.fed);
  return `${d.label}. ${d.kind === 'drink' ? 'THIRST' : 'HUNGER'} RESTORED. WELL FED FOR ${Math.round(d.fed / 6) / 10} MIN: HUNGER AND THIRST DRAIN AT HALF SPEED.`;
}
function sickSay() {
  say('SICK: THAT WAS TOXIC. FOR A MINUTE OR TWO HUNGER AND THIRST DRAIN TWICE AS FAST AND YOUR HEALTH SLIPS. THE SCAN NAMES TOXIC PLANTS: DO NOT EAT THEM.', { hold: 14000 });
  audio.alarm();
}
export function useGalley(id) {
  if (S.mode !== 'interior' || S.helm || S.dying || S.sleeping) return false;
  const R = S.P.res, L = S.P.life;
  if (id === 'eat' || id === 'drink') {
    const stat = id === 'eat' ? 'hunger' : 'thirst';
    if (L[stat] >= 99) { flash('YOU DO NOT NEED THAT YET.', 2000); return false; }
    const k = nextServing(id);
    if (!k) { flash(id === 'eat' ? 'NO RATIONS. PRINT A MEAL, OR SEARCH SALVAGE AND THE WRECK FOR CRATES.' : 'NO WATER. MELT ICE, FIX THE RECLAIMER, OR SEARCH THE WRECK.', 3200); return false; }
    flash(consume(k), k === 'meals' || k === 'water' ? 2400 : 3600);
  } else if (id === 'cook') {
    if (!cookPanel.open) { openCook(); return false; }
    return cook(cookPanel.sel);
  } else if (id === 'reclaim') {
    if (F().reclaimFixed) { flash('THE RECLAIMER IS WORKING. IT ADDS WATER POUCHES ON ITS OWN WHILE MAIN POWER IS ON.', 3200); return false; }
    if (R.salvage < RECLAIM_COST.salvage || R.ore < RECLAIM_COST.ore) { flash(`TO FIX THE RECLAIMER: ${RECLAIM_COST.salvage} SALVAGE + ${RECLAIM_COST.ore} ORE. CUT THEM FROM THE FIELD.`, 3200); return false; }
    R.salvage -= RECLAIM_COST.salvage; R.ore -= RECLAIM_COST.ore; F().reclaimFixed = true; F().reclaimT = 0;
    audio.clank();
    say(`WATER RECLAIMER REPAIRED. WITH MAIN POWER ON IT RECOVERS 1 POUCH EVERY ${RECLAIM_SECONDS / 60} MINUTES FROM THE CABIN AIR.`, { hold: 12000 });
  } else {
    if (!['meal', 'water'].includes(id)) return false;
    const cost = id === 'meal' ? 5 : 3;
    if (power.level !== 'powered' || L.battery < cost) { flash(`GALLEY NEEDS MAIN POWER AND ${cost} BATTERY.`, 3000); return false; }
    if (id === 'meal') {
      if (R.ore < 1 || R.salvage < 1) { flash('PRINTER NEEDS 1 ORE AND 1 SALVAGE.', 3000); return false; }
      R.ore--; R.salvage--; R.meals++;
    } else {
      if (R.ice < 1) { flash('MELTER NEEDS 1 ICE.', 3000); return false; }
      R.ice--; R.water += 2;
    }
    L.battery -= cost;
    flash(id === 'meal' ? 'MEAL PRINTED. COLLECT IT AT EAT RATION.' : 'TWO WATER POUCHES READY AT DRINK WATER.', 3000);
  }
  doAutosave(true); return true;
}

// ---- COOK: the recipe list (v0.5 slice B) ----
export const cookPanel = { open: false, sel: 0, focusT: 0, el: null, html: '' };
export function canCook(r) {
  const R = S.P.res;
  for (const k in r.in) if ((R[k] || 0) < r.in[k]) return false;
  return true;
}
function openCook() {
  cookPanel.open = true; cookPanel.focusT = performance.now();
  const i = RECIPES.findIndex(r => !r.bad && canCook(r)); cookPanel.sel = i < 0 ? 0 : i;
  audio.click(1300); renderCook();
}
export function closeCook() { cookPanel.open = false; renderCook(); }
export function cookFocus() { cookPanel.focusT = performance.now(); }
export function moveSel(d) { if (!cookPanel.open) return false; const n = RECIPES.length; cookPanel.sel = ((cookPanel.sel + d) % n + n) % n; audio.click(1500); renderCook(); return true; }
export function cookKey(n) { if (!cookPanel.open || n < 1 || n > RECIPES.length) return false; cookPanel.sel = n - 1; cook(n - 1); return true; }
export function cook(i) {
  const r = RECIPES[i]; if (!r) return false;
  const R = S.P.res, L = S.P.life;
  if (!canCook(r)) { flash(`${r.label} NEEDS ${inText(r)}.`, 3000); audio.blip(220, 0.03); renderCook(); return false; }
  if (r.battery && (power.level !== 'powered' || L.battery < r.battery)) { flash(`THE HOT PLATE NEEDS MAIN POWER AND ${r.battery} BATTERY.`, 3000); renderCook(); return false; }
  for (const k in r.in) R[k] -= r.in[k];
  if (r.battery) L.battery -= r.battery;
  R[r.id] = (R[r.id] || 0) + 1;
  const first = !F().cooked; if (!r.bad) F().cooked = true;
  flash(r.bad ? `SPOILED MESS. ${r.note}` : `${r.label} READY. ${DISHES[r.id].kind === 'drink' ? 'DRINK WATER' : 'EAT RATION'} SERVES IT FIRST.`, 3600);
  if (first && !r.bad) say(`YOUR FIRST COOKED ${DISHES[r.id].kind === 'drink' ? 'DRINK' : 'MEAL'}. COOKED FOOD FILLS YOU MORE THAN A RAW PACK, AND LEAVES YOU WELL FED: HUNGER AND THIRST DRAIN AT HALF SPEED FOR A FEW MINUTES.`, { hold: 14000 });
  audio.click(900);
  renderCook(); doAutosave(true);
  return true;
}
const NAMES = { meals: 'RATION', water: 'WATER', ice: 'ICE', fibre: 'PLANT FIBRE', plant: 'EDIBLE PLANT', badplant: 'TOXIC PLANT' };
function inText(r) { return Object.entries(r.in).map(([k, v]) => `${v} ${NAMES[k] || k.toUpperCase()}`).join(' + ') + (r.battery ? ` + ${r.battery} BATTERY` : ''); }
function hydroLine() {
  const bays = S.P.modules.filter(m => m.part === 'hydro');
  if (!bays.length) return 'HYDROPONICS: NONE BUILT. OUTSIDE, B THEN PART 9 BUILDS A BAY ON THE HULL. IT GROWS PLANTS FROM PLANT FIBRE AND WATER.';
  return 'HYDROPONICS: ' + bays.map((m, i) => { const h = S.P.food.hydro[m.id]; return `BAY ${i + 1} ${power.shed.has(m.id) || power.level !== 'powered' ? 'NO POWER' : h && h.on ? Math.floor(h.g * 100) + '% GROWN' : 'IDLE (NEEDS 1 WATER + 1 PLANT FIBRE)'}`; }).join(', ');
}
function renderCook() {
  const show = cookPanel.open && !S.paused && S.mode === 'interior';
  if (!cookPanel.el) {
    if (!show) return;
    const el = document.createElement('div'); el.id = 'cookPanel';
    el.style.cssText = 'position:fixed;left:16px;top:250px;width:min(440px,60vw);padding:12px 16px;background:rgba(6,12,12,.84);border:1px solid rgba(120,220,190,.5);color:#d8e6ee;font:13px/1.45 monospace;letter-spacing:.04em;z-index:30;pointer-events:none';
    document.body.appendChild(el); cookPanel.el = el;
  }
  cookPanel.el.style.display = show ? 'block' : 'none';
  if (!show) return;
  const R = S.P.res;
  let h = '';
  if (!F().cooked) h += `<div id="cookHint" style="border:1px dashed #ffb347;padding:8px 10px;margin-bottom:8px;color:#ffe0b0"><b style="color:#ffb347">HOW TO COOK (FIRST TIME)</b><br>EACH RECIPE TURNS WHAT YOU CARRY INTO A DISH. PICK ONE WITH 1-5 (OR THE WHEEL, THEN F). THE DISH WAITS IN THE STORES: EAT RATION AND DRINK WATER SERVE COOKED DISHES FIRST. COOKED FOOD FILLS YOU MORE AND LEAVES YOU <b>WELL FED</b> (HUNGER AND THIRST DRAIN SLOWER). PLANTS COME FROM PLANETS WITH AIR AND FROM A HYDROPONICS BAY. NEVER EAT A TOXIC PLANT.</div>`;
  h += `<div style="color:#8fe0c0">GALLEY  //  COOK</div>`;
  RECIPES.forEach((r, i) => {
    const ok = canCook(r), sel = i === cookPanel.sel;
    h += `<div class="rc" data-r="${r.id}" style="padding:2px 4px;${sel ? 'background:rgba(120,220,190,.18);color:#fff;' : ''}${ok ? '' : 'opacity:.5;'}${r.bad ? 'color:#ff8a70;' : ''}">${i + 1}  <b>${r.label}</b>  <span style="opacity:.8">${inText(r)}</span>${R[r.id] ? `  <i>(HAVE ${R[r.id]})</i>` : ''}${sel ? `<br><span style="opacity:.75">${r.note}</span>` : ''}</div>`;
  });
  h += `<div style="margin-top:6px;opacity:.85">STORES: ${R.meals} RATION, ${R.water} WATER, ${R.ice} ICE, ${R.fibre} FIBRE, ${R.plant} PLANT${R.badplant ? `, <span style="color:#ff8a70">${R.badplant} TOXIC PLANT</span>` : ''}</div>`;
  h += `<div style="opacity:.85">${hydroLine()}</div>`;
  const Fd = S.P.food;
  if (Fd.fed > 0 || Fd.sick > 0) h += `<div>${Fd.fed > 0 ? `<span style="color:#9fffb0">WELL FED ${Math.ceil(Fd.fed)} S</span> ` : ''}${Fd.sick > 0 ? `<span style="color:#ff6a50">SICK ${Math.ceil(Fd.sick)} S</span>` : ''}</div>`;
  h += `<div style="margin-top:6px;opacity:.7">1-5: COOK  //  WHEEL / D-PAD: CHOOSE  //  F: COOK THE HIGHLIGHTED ONE  //  WALK AWAY: CLOSE</div>`;
  if (h !== cookPanel.html) { cookPanel.el.innerHTML = h; cookPanel.html = h; }
}

// ---- hydroponics: each powered bay plants a crop when it can (1 water + 1 plant fibre: the seed stock)
// and grows it over real play time; a grown crop is 3 edible plants in the stores ----
export const GROW_SECONDS = 240, HYDRO_YIELD = 3;
export function updateHydro(dt) {
  const P = S.P, R = P.res, Fd = P.food || (P.food = { fed: 0, sick: 0, hydro: {} });
  const bays = P.modules.filter(m => m.part === 'hydro');
  for (const id in Fd.hydro) if (!bays.some(m => m.id === id)) delete Fd.hydro[id];
  for (const m of bays) {
    const h = Fd.hydro[m.id] || (Fd.hydro[m.id] = { g: 0, on: false });
    if (power.level !== 'powered' || power.shed.has(m.id)) continue;
    if (!h.on) {
      if (R.water >= 1 && R.fibre >= 1) {
        R.water--; R.fibre--; h.on = true; h.g = 0;
        if (!F().hydroSaid) { F().hydroSaid = true; say(`HYDROPONICS: A CROP IS PLANTED FROM 1 PLANT FIBRE AND 1 WATER. ON MAIN POWER IT GROWS IN ${GROW_SECONDS / 60} MINUTES INTO ${HYDRO_YIELD} EDIBLE PLANTS. WATCH IT GROW UNDER THE DOME.`, { hold: 14000 }); }
      }
      continue;
    }
    h.g = Math.min(1, h.g + dt / GROW_SECONDS);
    if (h.g >= 1) { h.on = false; h.g = 0; R.plant += HYDRO_YIELD; flash(`HYDROPONICS: CROP READY. +${HYDRO_YIELD} EDIBLE PLANTS (${R.plant})`, 3200); }
  }
}

// passive water: the reclaimer (inside) and the recyclers' condensate (outside), on main power only
export function update(dt) {
  if (!S.dying && !S.sleeping) updateHydro(dt);
  if (cookPanel.open && (performance.now() - cookPanel.focusT > 300 || S.mode !== 'interior' || S.dying || S.sleeping)) closeCook();
  if (cookPanel.open || (cookPanel.el && cookPanel.el.style.display !== 'none')) renderCook();
  if (S.dying || S.sleeping || power.level !== 'powered') return;
  const R = S.P.res, f = F();
  if (R.water >= WATER_CAP) return;
  if (f.reclaimFixed) {
    f.reclaimT = (f.reclaimT || 0) + dt;
    if (f.reclaimT >= RECLAIM_SECONDS) { f.reclaimT = 0; R.water++; flash(`RECLAIMER: +1 WATER (${R.water})`, 2400); }
  }
  const rec = countParts('recycler');
  if (rec) {
    f.condT = (f.condT || 0) + dt * rec;
    if (f.condT >= CONDENSATE_SECONDS) {
      f.condT = 0; R.water++;
      if (!f.condSaid) { f.condSaid = true; say('CONDENSATE: THE RECYCLER ON THE HULL PULLS WATER OUT OF THE AIR IT CLEANS. +1 WATER. IT KEEPS DOING THAT WHILE MAIN POWER IS ON.', { hold: 12000 }); }
      else flash(`CONDENSATE: +1 WATER (${R.water})`, 2400);
    }
  }
}

// ---- sealed ration crates, welded to some salvage plates (fixed per plate, so a save cannot reroll them) ----
export function crateIn(c) {
  if (!c || c.type !== 'salvage') return false;
  let h = 2166136261;
  for (const ch of String(c.key)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return ((h >>> 0) % 3) === 0;
}
export function crateFound(c) {
  if (!crateIn(c)) return false;
  S.P.res.meals += 2;
  const first = !F().crateSaid; F().crateSaid = true;
  if (first) say('A SEALED RATION CRATE WAS WELDED TO THAT PLATE: +2 RATIONS. SOME SALVAGE STILL CARRIES FOOD. LOOK FOR THE CRATE BEFORE YOU CUT.', { delay: 600, hold: 14000 });
  return true;
}
