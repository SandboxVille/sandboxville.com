# Lobby

## What this room does

This is the room every SandboxVille building starts in. It shows a kiosk with instructions for connecting your AI, and a big STOP button that freezes the whole building at once.

What it lets your AI do: Nothing. The Lobby does not give your AI any tools. It is just where it arrives and checks in before it goes anywhere else.

## Its door label (what it can touch, and nothing more)

- It can show its own kiosk screen and a STOP button.
- It cannot read any files on your computer.
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It gives your AI zero tools.

## What you need first

Node.js version 22 or newer, and a copy of the SandboxVille code on your computer (the folder that has `rooms/`, `tools/`, and `harness/` in it).

## How to add it

1. Unzip this download. You will get a folder called `lobby/` with one file inside, `room.json`.
2. Copy the `lobby/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/lobby/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/lobby`
   This prints the door sign for the room, plain text, so you can see exactly what it is (and is not) allowed to touch.

This room does not give your AI any tools and does not ask for any files or network access, so once you have read its door sign there is nothing else to turn on.

## How to remove it

Delete the `lobby/` folder from `rooms/` in your SandboxVille code. Nothing else to undo, it never had access to anything of yours.

## Things to try once it's running

- Read the plate over each door as you walk by
- Press the STOP button, then look around

