// Procedural canvas textures: wall panels, deck grating, hull plating,
// stencils, the torn photo, and the live console screen. No image files,
// no AI imagery -- every pixel is drawn here from code, once, at startup.
import * as THREE from 'three';
import { mulberry32 } from '../core/utils.js';

function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function tex(c, repeatX = 1, repeatY = 1, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeatX, repeatY);
  t.anisotropy = 4;
  return t;
}
function grime(g, w, h, rnd, n, alpha) {
  for (let i = 0; i < n; i++) {
    const x = rnd() * w, y = rnd() * h, r = 4 + rnd() * 40;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, `rgba(0,0,0,${alpha * rnd()})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
}

// interior wall panel: two panels per tile, seams, rivets, a vent, grime
export function wallPanel(seed = 1, tint = [38, 40, 46]) {
  const c = canvas(512, 512), g = c.getContext('2d'), rnd = mulberry32(seed);
  g.fillStyle = `rgb(${tint[0]},${tint[1]},${tint[2]})`; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 1800; i++) { const v = rnd() * 14 - 7; g.fillStyle = `rgba(${128 + v * 8},${128 + v * 8},${128 + v * 8},0.035)`; g.fillRect(rnd() * 512, rnd() * 512, 2, 2); }
  const panel = (x, y, w, h) => {
    g.fillStyle = 'rgba(255,255,255,0.035)'; g.fillRect(x + 6, y + 6, w - 12, h - 12);
    g.strokeStyle = 'rgba(0,0,0,0.75)'; g.lineWidth = 4; g.strokeRect(x + 2, y + 2, w - 4, h - 4);
    g.strokeStyle = 'rgba(255,255,255,0.06)'; g.lineWidth = 1; g.strokeRect(x + 5, y + 5, w - 10, h - 10);
    g.fillStyle = 'rgba(0,0,0,0.6)';
    [[x + 14, y + 14], [x + w - 14, y + 14], [x + 14, y + h - 14], [x + w - 14, y + h - 14]].forEach(([a, b]) => { g.beginPath(); g.arc(a, b, 3, 0, 7); g.fill(); });
  };
  panel(0, 0, 256, 512); panel(256, 0, 256, 300); panel(256, 300, 256, 212);
  // vent slats
  g.fillStyle = 'rgba(0,0,0,0.55)'; for (let i = 0; i < 8; i++) g.fillRect(300, 340 + i * 18, 170, 7);
  // a stencilled number, half worn off
  g.font = 'bold 34px monospace'; g.fillStyle = 'rgba(210,190,150,0.22)'; g.fillText(`0${1 + Math.floor(rnd() * 9)}-${String.fromCharCode(65 + Math.floor(rnd() * 6))}`, 40, 80);
  // hazard stripe along the bottom
  for (let i = -2; i < 18; i++) { g.fillStyle = i % 2 ? 'rgba(200,150,40,0.35)' : 'rgba(10,10,10,0.5)'; g.beginPath(); g.moveTo(i * 32, 512); g.lineTo(i * 32 + 32, 512); g.lineTo(i * 32 + 56, 488); g.lineTo(i * 32 + 24, 488); g.fill(); }
  grime(g, 512, 512, rnd, 60, 0.25);
  return tex(c);
}

export function deckGrate(seed = 7) {
  const c = canvas(256, 256), g = c.getContext('2d'), rnd = mulberry32(seed);
  g.fillStyle = '#16171a'; g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 16) for (let x = 0; x < 256; x += 16) {
    g.fillStyle = '#060607'; g.fillRect(x + 3, y + 3, 10, 10);
    g.fillStyle = 'rgba(255,255,255,0.05)'; g.fillRect(x + 2, y + 2, 12, 1);
  }
  g.strokeStyle = 'rgba(0,0,0,0.9)'; g.lineWidth = 3; g.strokeRect(1, 1, 254, 254);
  grime(g, 256, 256, rnd, 20, 0.3);
  return tex(c);
}

export function hullPlate(seed = 3) {
  const c = canvas(512, 512), g = c.getContext('2d'), rnd = mulberry32(seed);
  g.fillStyle = '#2b2c30'; g.fillRect(0, 0, 512, 512);
  const rows = 4, cols = 4;
  for (let r = 0; r < rows; r++) for (let q = 0; q < cols; q++) {
    const v = 40 + Math.floor(rnd() * 16);
    g.fillStyle = `rgb(${v},${v},${v + 4})`;
    g.fillRect(q * 128 + 2, r * 128 + 2, 124, 124);
    g.strokeStyle = 'rgba(0,0,0,0.8)'; g.lineWidth = 3; g.strokeRect(q * 128 + 1, r * 128 + 1, 126, 126);
    if (rnd() < 0.2) { g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(q * 128 + 20, r * 128 + 20, 88, 20); }
  }
  // scorch and micrometeorite pitting
  for (let i = 0; i < 300; i++) { g.fillStyle = `rgba(0,0,0,${0.2 + rnd() * 0.4})`; g.fillRect(rnd() * 512, rnd() * 512, 1 + rnd() * 2, 1 + rnd() * 2); }
  grime(g, 512, 512, rnd, 40, 0.35);
  return tex(c, 3, 2);
}

// stencilled text on transparent background (hull name, door labels)
export function stencil(text, { w = 512, h = 128, color = 'rgba(225,205,160,0.85)', font = 'bold 72px monospace', worn = 0.25, seed = 11 } = {}) {
  const c = canvas(w, h), g = c.getContext('2d'), rnd = mulberry32(seed);
  g.font = font; g.fillStyle = color; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, w / 2, h / 2);
  g.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 400 * worn; i++) { g.fillStyle = `rgba(0,0,0,${rnd()})`; g.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 5, 1 + rnd() * 3); }
  const t = tex(c); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}

// deterministic torn photo: two figures, one torn away. No external assets.
export function tornPhoto() {
  const c = canvas(64, 96), g = c.getContext('2d');
  g.fillStyle = '#0c0a08'; g.fillRect(0, 0, 64, 96);
  g.fillStyle = '#3a332a'; g.fillRect(4, 4, 56, 88);
  g.fillStyle = '#6b5a44'; g.fillRect(8, 8, 48, 60);
  g.fillStyle = '#2a2620'; g.fillRect(16, 30, 12, 34); g.fillRect(34, 30, 12, 34);
  g.beginPath(); g.arc(22, 24, 6, 0, 7); g.fill(); g.beginPath(); g.arc(40, 24, 6, 0, 7); g.fill();
  g.fillStyle = '#0c0a08';
  g.beginPath(); g.moveTo(64, 8); g.lineTo(30, 8); g.lineTo(50, 24); g.lineTo(38, 40); g.lineTo(64, 46); g.closePath(); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// the live console screen: a canvas the HUD redraws a few times a second so
// the ship's state is readable in the world, not only in menus.
export function makeScreen(w = 512, h = 256) {
  const c = canvas(w, h), g = c.getContext('2d');
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return { canvas: c, g, tex: t };
}

// a soft round sprite (lamp glows, work-light halos)
export function glowSprite() {
  const c = canvas(64, 64), g = c.getContext('2d');
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,0.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); return t;
}

// rock surface: speckled, used for ore/ice chunks
export function rockTex(seed, base, spec) {
  const c = canvas(256, 256), g = c.getContext('2d'), rnd = mulberry32(seed);
  g.fillStyle = base; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2600; i++) { const s = rnd(); g.fillStyle = s < 0.5 ? 'rgba(0,0,0,0.25)' : spec; g.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 3, 1 + rnd() * 3); }
  grime(g, 256, 256, rnd, 30, 0.4);
  return tex(c);
}

// ---------- gfx pass: relief and hull plating ----------

// a tangent-space normal map from a height canvas (white = raised): 3x3 Sobel
// on a lightly blurred copy, wrapping at the edges so tiles stay seamless
export function normalFromHeight(hc, strength = 2.0, repeatX = 1, repeatY = 1) {
  const w = hc.width, h = hc.height;
  const src = hc.getContext('2d').getImageData(0, 0, w, h).data;
  const H = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) H[i] = (src[i * 4] * 0.299 + src[i * 4 + 1] * 0.587 + src[i * 4 + 2] * 0.114) / 255;
  // one box blur pass (3x3) takes the pixel-stair edge off
  const B = new Float32Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let s = 0;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) s += H[((y + j + h) % h) * w + ((x + i + w) % w)];
    B[y * w + x] = s / 9;
  }
  const c = canvas(w, h), g = c.getContext('2d'), out = g.createImageData(w, h), o = out.data;
  const at = (x, y) => B[((y + h) % h) * w + ((x + w) % w)];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = (at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1)) - (at(x - 1, y - 1) + 2 * at(x - 1, y) + at(x - 1, y + 1));
    const dy = (at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1)) - (at(x - 1, y - 1) + 2 * at(x, y - 1) + at(x + 1, y - 1));
    let nx = -dx * strength, ny = dy * strength, nz = 1;
    const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    const k = (y * w + x) * 4;
    o[k] = (nx * 0.5 + 0.5) * 255; o[k + 1] = (ny * 0.5 + 0.5) * 255; o[k + 2] = (nz * 0.5 + 0.5) * 255; o[k + 3] = 255;
  }
  g.putImageData(out, 0, 0);
  return tex(c, repeatX, repeatY, false);
}

// the hull: large thermal-painted plates in staggered rows, weld seams, rivet
// lines, a few replaced panels, streaks along the length. Returns the colour
// map, a normal map and a roughness map drawn from the same layout.
export function hullSet(seed = 3, repeatX = 3, repeatY = 2, wear = 0) {
  const S = 1024;
  const col = canvas(S, S), g = col.getContext('2d');
  const hgt = canvas(S, S), hg = hgt.getContext('2d');
  const rgh = canvas(S, S), rg = rgh.getContext('2d');
  const rnd = mulberry32(seed);
  g.fillStyle = '#4a4c52'; g.fillRect(0, 0, S, S);
  hg.fillStyle = '#808080'; hg.fillRect(0, 0, S, S);
  rg.fillStyle = '#9a9a9a'; rg.fillRect(0, 0, S, S);
  const rows = 6, rowH = S / rows;
  for (let r = 0; r < rows; r++) {
    const cols = 4, colW = S / cols, off = (r % 2) * colW * 0.5;
    for (let q = -1; q < cols; q++) {
      const x = q * colW + off, y = r * rowH;
      const v = 92 + Math.floor(rnd() * 30), warm = rnd() < 0.15 ? 8 : 0;
      g.fillStyle = `rgb(${v + warm},${v + warm - 1},${v + 3})`;
      g.fillRect(x + 3, y + 3, colW - 6, rowH - 6);
      // slight panel bulge in the height map, seams sunk
      const hv = 128 + Math.floor((rnd() - 0.5) * 18);
      hg.fillStyle = `rgb(${hv},${hv},${hv})`; hg.fillRect(x + 4, y + 4, colW - 8, rowH - 8);
      { const rv = 130 + rnd() * 40 | 0; rg.fillStyle = `rgb(${rv},${rv},${rv})`; } rg.fillRect(x + 3, y + 3, colW - 6, rowH - 6);
      // rivets along the panel edges
      g.fillStyle = 'rgba(20,20,22,0.55)'; hg.fillStyle = '#b8b8b8';
      for (let k = 12; k < colW - 8; k += 22) {
        [[x + k, y + 9], [x + k, y + rowH - 9]].forEach(([a, b]) => { g.fillRect(a - 1, b - 1, 3, 3); hg.beginPath(); hg.arc(a, b, 2.2, 0, 7); hg.fill(); });
      }
      for (let k = 12; k < rowH - 8; k += 22) {
        [[x + 9, y + k], [x + colW - 9, y + k]].forEach(([a, b]) => { g.fillRect(a - 1, b - 1, 3, 3); hg.beginPath(); hg.arc(a, b, 2.2, 0, 7); hg.fill(); });
      }
      // access hatches and doublers on some panels
      if (rnd() < 0.3) {
        const hw = 40 + rnd() * 70, hh = 30 + rnd() * 50, hx = x + 20 + rnd() * (colW - hw - 40), hy = y + 20 + rnd() * (rowH - hh - 40);
        g.strokeStyle = 'rgba(10,10,12,0.8)'; g.lineWidth = 2; g.strokeRect(hx, hy, hw, hh);
        hg.strokeStyle = '#5a5a5a'; hg.lineWidth = 2; hg.strokeRect(hx, hy, hw, hh);
        if (rnd() < 0.5) { g.fillStyle = 'rgba(200,160,60,0.5)'; g.fillRect(hx + 4, hy + 4, 10, 4); }
      }
    }
  }
  // seams: dark in colour, sunk in height, smoother in roughness
  g.strokeStyle = 'rgba(8,8,10,0.9)'; g.lineWidth = 3; hg.strokeStyle = '#303030'; hg.lineWidth = 4;
  for (let r = 0; r <= rows; r++) { const y = r * rowH; g.beginPath(); g.moveTo(0, y); g.lineTo(S, y); g.stroke(); hg.beginPath(); hg.moveTo(0, y); hg.lineTo(S, y); hg.stroke(); }
  for (let r = 0; r < rows; r++) { const colW = S / 4, off = (r % 2) * colW * 0.5; for (let q = 0; q <= 4; q++) { const x = q * colW + off; [g, hg].forEach(c2 => { c2.beginPath(); c2.moveTo(x, r * rowH); c2.lineTo(x, (r + 1) * rowH); c2.stroke(); }); } }
  // micrometeorite pits and streaks along the length (the hull's long axis runs along v)
  for (let i = 0; i < 900; i++) { const x = rnd() * S, y = rnd() * S, s = 1 + rnd() * 2; g.fillStyle = `rgba(0,0,0,${0.15 + rnd() * 0.35})`; g.fillRect(x, y, s, s); hg.fillStyle = 'rgba(40,40,40,0.6)'; hg.fillRect(x, y, s, s); }
  for (let i = 0; i < 70; i++) {
    const x = rnd() * S, y = rnd() * S, len = 60 + rnd() * 260, wd = 2 + rnd() * 10;
    const gr = g.createLinearGradient(x, y, x, y + len);
    gr.addColorStop(0, `rgba(0,0,0,${0.08 + rnd() * 0.18})`); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(x, y, wd, len);
    rg.fillStyle = 'rgba(255,255,255,0.22)'; rg.fillRect(x, y, wd, len * 0.6);
  }
  grime(g, S, S, rnd, 50, 0.3);
  // a wreck: scorch blooms, a darker cast, pitting that went deeper
  if (wear > 0) {
    for (let i = 0; i < 22 * wear; i++) {
      const x = rnd() * S, y = rnd() * S, r = 40 + rnd() * 160;
      const gr = g.createRadialGradient(x, y, 0, x, y, r);
      gr.addColorStop(0, `rgba(12,8,6,${0.5 + rnd() * 0.35})`); gr.addColorStop(0.6, 'rgba(20,14,10,0.25)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
    }
    g.fillStyle = `rgba(10,12,16,${0.25 * wear})`; g.fillRect(0, 0, S, S);
    for (let i = 0; i < 1400 * wear; i++) { const x = rnd() * S, y = rnd() * S, sz = 1 + rnd() * 3; g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(x, y, sz, sz); hg.fillStyle = 'rgba(20,20,20,0.7)'; hg.fillRect(x, y, sz, sz); }
  }
  const map = tex(col, repeatX, repeatY);
  const normalMap = normalFromHeight(hgt, 2.6, repeatX, repeatY);
  const roughnessMap = tex(rgh, repeatX, repeatY, false);
  return { map, normalMap, roughnessMap };
}

// interior walls: the same painted panel layout as wallPanel, as a height map
// (seams and vent slats sunk, rivets raised) for a normal map
export function wallRelief(seed = 1) {
  const c = canvas(512, 512), g = c.getContext('2d'), rnd = mulberry32(seed + 1000);
  g.fillStyle = '#808080'; g.fillRect(0, 0, 512, 512);
  const panel = (x, y, w, h) => {
    g.fillStyle = '#909090'; g.fillRect(x + 6, y + 6, w - 12, h - 12);
    g.strokeStyle = '#2a2a2a'; g.lineWidth = 5; g.strokeRect(x + 2, y + 2, w - 4, h - 4);
    g.fillStyle = '#c8c8c8';
    [[x + 14, y + 14], [x + w - 14, y + 14], [x + 14, y + h - 14], [x + w - 14, y + h - 14]].forEach(([a, b]) => { g.beginPath(); g.arc(a, b, 3.5, 0, 7); g.fill(); });
  };
  panel(0, 0, 256, 512); panel(256, 0, 256, 300); panel(256, 300, 256, 212);
  g.fillStyle = '#303030'; for (let i = 0; i < 8; i++) g.fillRect(300, 340 + i * 18, 170, 7);
  for (let i = 0; i < 400; i++) { { const v = rnd() < 0.5 ? 0 : 255; g.fillStyle = `rgba(${v},${v},${v},0.05)`; } g.fillRect(rnd() * 512, rnd() * 512, 2 + rnd() * 3, 2 + rnd() * 3); }
  return c;
}

// the deck grating as a height map: bars up, holes down
export function grateRelief() {
  const c = canvas(256, 256), g = c.getContext('2d');
  g.fillStyle = '#b0b0b0'; g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 16) for (let x = 0; x < 256; x += 16) { g.fillStyle = '#202020'; g.fillRect(x + 3, y + 3, 10, 10); }
  g.strokeStyle = '#404040'; g.lineWidth = 3; g.strokeRect(1, 1, 254, 254);
  return c;
}
