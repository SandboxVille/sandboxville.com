// Save/state glue: the live progress object S.P <-> a stored save. Loading
// SANITIZES every field against the fresh defaults (wrong type, NaN, out of
// range, unknown module part -> default), so even a save that passes the
// checksum but was written by a buggy build can never put the game into an
// impossible state.
import { S, freshProgress, defaultSettings } from '../core/state.js';
import { OXY_MAX, PROP_MAX, SUIT_POWER_MAX } from '../core/constants.js';
import { saveToSlot, loadFromSlot, readSlot, autosave, saveSettings, loadSettings, resetAutosaveGap } from '../save.js';
import { emit } from '../core/events.js';
// (a copy of landing.js CAMPAIGN_STAR: save-state must not import the landing system)
const CAMPAIGN_STAR = { 1: 71683, 2: 32349, 3: 26602 };

export function snapshot() { return JSON.parse(JSON.stringify(S.P)); }
export function meta() {
  const step = S.P.storyStep;
  const label = S.P.flight ? 'IN TRANSIT' : S.P.mode === 'campaign' && S.P.landing && S.P.landing.phase === 'landed' ? `SYSTEM ${S.P.system} // LANDED` : S.P.mode === 'sandbox' ? (S.P.place ? `SANDBOX // ${S.P.place.name || 'HIP ' + S.P.place.hip}${S.P.landing && S.P.landing.phase === 'landed' ? ' // LANDED' : ''}` : 'SANDBOX') : `SYSTEM ${S.P.system}`;
  return { playTime: Math.round(S.P.stats.timePlayed), summary: `${label}  //  ${storyLabel(step)}` };
}
function storyLabel(step) {
  return ['WAKING', 'CONSOLE', 'FIRST FIX', 'NO POWER', 'POWER ON', 'CALLING HOME', 'THE REPLY', 'THE CONTACT', 'LEAVING', 'ADRIFT', 'AT THE HELM', 'IN TRANSIT', 'ACT II: THE CHART', 'ACT II: THE ANTENNA', 'ACT II: THE MANIFEST', 'TO BE CONTINUED: TWO ABOARD'][Math.min(15, step)] || 'ADRIFT';
}

const num = (v, d, lo = -Infinity, hi = Infinity) => (typeof v === 'number' && isFinite(v)) ? Math.max(lo, Math.min(hi, v)) : d;
const bool = (v, d) => typeof v === 'boolean' ? v : d;
function mergeNums(src, def, lo, hi) {
  const out = { ...def };
  if (src && typeof src === 'object') for (const k in def) out[k] = typeof def[k] === 'number' ? num(src[k], def[k], lo, hi) : bool(src[k], def[k]);
  return out;
}
const KNOWN_PARTS = ['truss', 'floodlight', 'mast', 'heater', 'recycler', 'rtg', 'shield', 'baffle', 'hydro'];

export function sanitize(d) {
  const F = freshProgress();
  if (!d || typeof d !== 'object') return F;
  const P = F;
  P.storyStep = Math.round(num(d.storyStep, 0, 0, 20));
  P.mode = d.mode === 'sandbox' ? 'sandbox' : 'campaign';
  P.system = Math.round(num(d.system, 1, 1, 3));
  P.repair = mergeNums(d.repair, F.repair, 0, 100);
  P.res = mergeNums(d.res, F.res, 0, 9999); for (const k in P.res) P.res[k] = Math.floor(P.res[k]);
  P.upgrades = mergeNums(d.upgrades, F.upgrades);
  P.unlocks = mergeNums(d.unlocks, F.unlocks);
  P.journalOrder = Array.isArray(d.journalOrder) ? [...new Set(d.journalOrder.filter(x => typeof x === 'string' && x.length < 16))] : [];
  P.modules = Array.isArray(d.modules) ? d.modules.filter(m => m && KNOWN_PARTS.includes(m.part) && typeof m.socket === 'string' && typeof m.id === 'string').slice(0, 64) : [];
  P.harvested = {};
  if (d.harvested && typeof d.harvested === 'object') for (const k in d.harvested) if (/^[0-9p]{1,8}:\d+$/.test(k)) P.harvested[k] = num(d.harvested[k], 0, 0, 10);
  P.derelict = mergeNums(d.derelict, F.derelict);
  P.flags = {};
  if (d.flags && typeof d.flags === 'object') for (const k in d.flags) if (typeof d.flags[k] === 'boolean' || typeof d.flags[k] === 'number') P.flags[k] = d.flags[k];
  P.stats = mergeNums(d.stats, F.stats, 0, 1e9);
  P.life = mergeNums(d.life, F.life, -80, 100);
  // 2026-09-28: saves from before hunger and thirst have none: they load full (the defaults). A save taken
  // while starving loads with a little margin, so it can never load straight into a death.
  P.life.health = Math.max(30, P.life.health); P.life.hunger = Math.max(15, P.life.hunger); P.life.thirst = Math.max(15, P.life.thirst);
  P.life.warmth = Math.max(35, P.life.warmth); P.life.sanity = Math.max(30, P.life.sanity); P.life.rad = Math.min(60, Math.max(0, P.life.rad));
  P.nodeCollected = {};
  P.secretFound = bool(d.secretFound, false); P.chapter1Shown = bool(d.chapter1Shown, false);
  P.flight = sanitizeFlight(d.flight);
  P.place = sanitizePlace(d.place);
  P.landing = sanitizeLanding(d.landing, P.place || (P.mode === 'campaign' && CAMPAIGN_STAR[P.system] ? { hip: CAMPAIGN_STAR[P.system] } : null));
  P.food = sanitizeFood(d.food, P.modules);
  P.surf = sanitizeSurf(d.surf);
  P.discoveries = {};
  if (d.discoveries && typeof d.discoveries === 'object') for (const k of Object.keys(d.discoveries).slice(0, 600)) {
    const v = d.discoveries[k];
    if (!/^\d{1,6}:[0-7]$/.test(k) || !v || typeof v !== 'object') continue;
    P.discoveries[k] = { n: typeof v.n === 'string' ? v.n.toUpperCase().replace(/[^A-Z0-9 '\-]/g, '').slice(0, 24) : '', t: num(v.t, 0, 0, 1e9), landed: bool(v.landed, false) };
  }
  P.legs = Array.isArray(d.legs) ? d.legs.filter(l => l && typeof l === 'object' && vec(l.toP) && typeof l.from === 'string' && typeof l.to === 'string').slice(-50).map(l => ({ from: l.from.slice(0, 40), to: l.to.slice(0, 40), dist: num(l.dist, 0, 0, 1e5), tau: num(l.tau, 0, 0, 1e5), t: num(l.t, 0, 0, 1e6), toP: l.toP.slice(), note: typeof l.note === 'string' ? l.note.slice(0, 120) : '' })) : [];
  P.visited = Array.isArray(d.visited) ? [...new Set(d.visited.filter(h => Number.isInteger(h) && h >= 0 && h < 200000))].slice(0, 300) : [];
  P.act2 = {};
  if (d.act2 && typeof d.act2 === 'object') for (const k in d.act2) if (typeof d.act2[k] === 'boolean' || (typeof d.act2[k] === 'number' && isFinite(d.act2[k]))) P.act2[k] = d.act2[k];
  return P;
}

// a flight in progress must be entirely finite numbers, or it is dropped
const vec = (a, n = 3, lim = 1e6) => Array.isArray(a) && a.length === n && a.every(x => typeof x === 'number' && isFinite(x) && Math.abs(x) < lim);
function sanitizeFlight(f) {
  if (!f || typeof f !== 'object') return null;
  if (!vec(f.from) || !vec(f.to) || !vec(f.pos) || !vec(f.u, 3, 1e4) || !vec(f.q, 4, 2)) return null;
  const out = { v: 1, route: ['filed', 'home', 'star'].includes(f.route) ? f.route : 'star', label: typeof f.label === 'string' ? f.label.slice(0, 60) : '',
    hip: Math.round(num(f.hip, 0, 0, 200000)), from: f.from.slice(), to: f.to.slice(), pos: f.pos.slice(), u: f.u.slice(), q: f.q.slice(),
    tau: num(f.tau, 0, 0, 1e5), t: num(f.t, 0, 0, 1e6), tank: num(f.tank, 0, 0, 999), tank0: num(f.tank0, 0, 0, 999), heat: num(f.heat, 0, 0, 120), throttle: num(f.throttle, 0, 0, 1), scram: 0,
    started: bool(f.started, false), departed: bool(f.departed, false), coastW: 0, slipped: bool(f.slipped, false), beats: {}, earth0: num(f.earth0, 0, 0, 1e6), contact: bool(f.contact, true) };
  const dst = f.dest && typeof f.dest === 'object' ? f.dest : null;
  out.dest = dst && dst.kind === 'star' ? { kind: 'star', hip: Math.round(num(dst.hip, 0, 0, 200000)) } : { kind: 'system', n: Math.round(num(dst && dst.n, 2, 1, 3)) };
  if (f.beats && typeof f.beats === 'object') for (const k in f.beats) if (f.beats[k] === true) out.beats[k] = true;
  return out;
}
// v0.5: a landing is the star, the planet's index, the phase, the site and the nodes taken. A descent in
// progress loads as orbit (the save before the burn), and a landing at a star you are not parked at is dropped.
function sanitizeLanding(l, place) {
  if (!l || typeof l !== 'object' || !place) return null;
  const hip = Math.round(num(l.hip, -1, -1, 200000));
  if (hip !== place.hip) return null;
  const out = { hip, pi: Math.round(num(l.pi, 0, 0, 7)), phase: l.phase === 'landed' ? 'landed' : 'orbit', site: null, taken: [], tod: num(l.tod, 0.12, 0, 1), dmg: Math.round(num(l.dmg, 0, 0, 99)), q: vec(l.q, 4, 2) ? l.q.slice() : null };
  if (l.site && typeof l.site === 'object') { const x = num(l.site.x, NaN, -1e6, 1e6), z = num(l.site.z, NaN, -1e6, 1e6), h = num(l.site.h, NaN, -1e4, 1e4); if ([x, z, h].every(isFinite)) out.site = { x, z, h }; }
  if (out.phase === 'landed' && !out.site) out.phase = 'orbit';
  if (Array.isArray(l.taken)) out.taken = [...new Set(l.taken.filter(t => typeof t === 'string' && /^-?\d+_-?\d+_\d$/.test(t)))].slice(-400);
  return out;
}
// v0.5 slice B: well fed / sick timers (seconds) and each hydroponics bay's growth, only for bays that exist
function sanitizeFood(f, modules) {
  const out = { fed: 0, sick: 0, hydro: {} };
  if (!f || typeof f !== 'object') return out;
  out.fed = num(f.fed, 0, 0, 600); out.sick = num(f.sick, 0, 0, 300);
  if (f.hydro && typeof f.hydro === 'object') for (const m of modules) if (m.part === 'hydro' && f.hydro[m.id] && typeof f.hydro[m.id] === 'object') {
    const h = f.hydro[m.id]; out.hydro[m.id] = { g: num(h.g, 0, 0, 1), on: bool(h.on, false) };
  }
  return out;
}
// surface build: per world, the deposits you mined (units left) and the base you built (older saves have none)
const BASE_KINDS = ['floodlight', 'heater', 'rtg', 'solar', 'hydro', 'storage', 'shelter', 'wall', 'doorway'];
const STASH_KEYS = ['ore', 'ice', 'salvage', 'carbon', 'fibre'];
function sanitizeSurf(sf) {
  const out = {};
  if (!sf || typeof sf !== 'object') return out;
  for (const k of Object.keys(sf).slice(0, 200)) {
    const v = sf[k];
    if (!/^\d{1,6}:[0-7]$/.test(k) || !v || typeof v !== 'object') continue;
    const w = { mined: {}, base: [] };
    if (v.mined && typeof v.mined === 'object') for (const id of Object.keys(v.mined).slice(0, 2000)) if (/^d-?\d{1,7}_-?\d{1,7}_\d$/.test(id)) w.mined[id] = Math.round(num(v.mined[id], 0, 0, 999));
    if (Array.isArray(v.base)) for (const b of v.base.slice(0, 60)) {
      if (!b || typeof b !== 'object' || !BASE_KINDS.includes(b.part) || typeof b.id !== 'string' || b.id.length > 32) continue;
      const x = num(b.x, NaN, -1e6, 1e6), z = num(b.z, NaN, -1e6, 1e6); if (!isFinite(x) || !isFinite(z)) continue;
      const rec = { id: b.id, part: b.part, x, z, r: num(b.r, 0, -100, 100) };
      if (b.part === 'storage') { rec.store = {}; if (b.store && typeof b.store === 'object') for (const s of STASH_KEYS) rec.store[s] = Math.floor(num(b.store[s], 0, 0, 80)); }
      if (b.part === 'hydro') { rec.g = num(b.g, 0, 0, 1); rec.on = bool(b.on, false); }
      w.base.push(rec);
    }
    if (Object.keys(w.mined).length || w.base.length) out[k] = w;
  }
  return out;
}
function sanitizePlace(p) {
  if (!p || typeof p !== 'object') return null;
  const x = num(p.x, NaN), y = num(p.y, NaN), z = num(p.z, NaN);
  if (![x, y, z].every(isFinite) || Math.hypot(x, y, z) > 5000) return null;
  return { hip: Math.round(num(p.hip, 0, 0, 200000)), x, y, z, name: typeof p.name === 'string' ? p.name.slice(0, 40) : '' };
}

let hooks = { afterLoad: null };
export function setLoadHook(fn) { hooks.afterLoad = fn; }

export function applySnapshot(d) {
  S.P = sanitize(d);
  S.eva.oxygen = OXY_MAX; S.eva.propellant = PROP_MAX; S.eva.power = SUIT_POWER_MAX;
  if (hooks.afterLoad) hooks.afterLoad();
  emit('loaded');
}

// P3: once the drive is lit, nothing autosaves until the ship arrives: a save mid-flight could
// capture a trip that can no longer stop. Death mid-flight wakes you at the helm, before the burn.
export function doAutosave(force) { if (S.P.flight && S.P.flight.started) return false; if (force) resetAutosaveGap(); return autosave(snapshot, meta); }
export function saveSlot(slot) { return saveToSlot(slot, snapshot(), meta()); }

export function persistSettings() { saveSettings(S.settings); }
export function restoreSettings() {
  const s = loadSettings(); const def = defaultSettings();
  if (!s) return def;
  const out = { ...def };
  out.sensitivity = num(s.sensitivity, def.sensitivity, 0.2, 4);
  out.padLook = num(s.padLook, def.padLook, 0.3, 3);
  out.fov = num(s.fov, def.fov, 55, 100);
  out.volume = num(s.volume, def.volume, 0, 1);
  out.ambience = num(s.ambience, def.ambience, 0, 1.5);
  out.invertY = bool(s.invertY, def.invertY); out.headBob = bool(s.headBob, def.headBob); out.subtitles = bool(s.subtitles, def.subtitles);
  out.quality = ['low', 'medium', 'high'].includes(s.quality) ? s.quality : def.quality;
  out.view = ['helmet', 'shoulder'].includes(s.view) ? s.view : def.view;
  out.difficulty = ['story', 'survival'].includes(s.difficulty) ? s.difficulty : def.difficulty;
  if (s.keybinds && typeof s.keybinds === 'object') for (const k in def.keybinds) if (typeof s.keybinds[k] === 'string' && s.keybinds[k].length <= 12) out.keybinds[k] = s.keybinds[k];
  return out;
}
export { saveToSlot, loadFromSlot, readSlot };
