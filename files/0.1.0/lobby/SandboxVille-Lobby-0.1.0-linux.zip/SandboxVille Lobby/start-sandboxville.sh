#!/bin/bash
# SandboxVille Lobby for Linux. In a terminal, in this folder, run: ./start-sandboxville.sh
# It needs Node.js 20 or newer. SandboxVille itself installs nothing and never asks for your password.
cd "$(dirname "$0")" || exit 1

NODE=""
if [ -x "./node/bin/node" ]; then
  NODE="./node/bin/node"
elif command -v node >/dev/null 2>&1; then
  NODE="$(command -v node)"
else
  for p in /usr/local/bin/node /usr/bin/node; do
    if [ -x "$p" ]; then NODE="$p"; break; fi
  done
fi

close_prompt() {
  echo ""
  read -r -p "  Press Enter to close this window. " _ || true
}

if [ -z "$NODE" ]; then
  cat <<'EOF'

  SandboxVille needs one free program first. It is called Node.js.

  How to get it:
    1. Go to  https://nodejs.org/en/download
    2. Pick Linux and follow the steps there.
       The "nodejs" in your app store or package manager may be too old.
       After you install it, check it with:  node --version
    3. Then run  ./start-sandboxville.sh  again.

  Not allowed to install programs on this computer? Use the version with no installer:
    1. On  https://nodejs.org/en/download  pick Linux, then download the "Linux Binaries".
    2. Unpack it. Rename the folder you get to:  node
    3. Move that  node  folder into this SandboxVille folder, next to this file.
    4. Then run  ./start-sandboxville.sh  again.

EOF
  close_prompt
  exit 1
fi

if ! "$NODE" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 20 ? 0 : 1)"; then
  cat <<'EOF'

  Your Node.js is too old for SandboxVille. It needs version 20 or newer.

  How to get a newer one:
    1. Go to  https://nodejs.org/en/download
    2. Pick Linux and follow the steps there.
       The "nodejs" in your app store or package manager may be too old.
       After you install it, check it with:  node --version
    3. Then run  ./start-sandboxville.sh  again.

  Not allowed to install programs on this computer? Use the version with no installer:
    1. On  https://nodejs.org/en/download  pick Linux, then download the "Linux Binaries".
    2. Unpack it. Rename the folder you get to:  node
    3. Move that  node  folder into this SandboxVille folder, next to this file.
    4. Then run  ./start-sandboxville.sh  again.

EOF
  close_prompt
  exit 1
fi

echo ""
echo "  Starting SandboxVille ..."
echo "  Keep this window open while you play. Close it to stop SandboxVille."
echo "  Your browser opens by itself in a moment."
echo ""
"$NODE" host/world-host.mjs --open "$@"
status=$?
if [ "$status" -ne 0 ]; then
  echo ""
  echo "  SandboxVille stopped because of a problem. Read the lines above to see why."
  close_prompt
fi
exit "$status"
