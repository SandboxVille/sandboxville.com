// Art wave (2026-09-28): the script-built models used by the game (Blender, bpy only,
// procedural, exported as GLB by a pure-Python writer). This module:
//   - loads the five GLBs (assets/art/) after the world is built; the game runs with the old visuals
//     until they arrive, and keeps them if a load fails;
//   - gives the player a body: the EVA astronaut (24 bones, 8 clips). First person shows only the
//     forearms and gloves (look down to see them); the over-the-shoulder view shows the whole suit;
//   - runs the over-the-shoulder camera (key O, or SETTINGS > VIEW). The camera never leaves the air
//     inside the ship and never enters the hull. Game logic always sees the helmet camera: the
//     shoulder offset is applied only for the draw call and undone right after it;
//   - re-skins the threats WITHOUT touching their rules: the Listener (a listening dish on the old
//     listenerBody), the Nearer (a shard lattice on the old approachMesh), CREW 2 (your own suit, black,
//     following the old figure group, which stays in the scene for the tests), and the Null Point
//     (a crossed circle on the null bearing, once it has been measured);
//   - adds the less-blocky kit: structural ribs and filleted corners in the three rooms.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import { S } from '../core/state.js';
import { SKY_R } from '../core/constants.js';
import { scene, camera, ship, approachMesh, approachRim, helmetLamp } from './scene.js';
import { listenerBody, figure } from './world.js';
import { shipFx } from './ship.js';

const BASE = 'assets/art/';
const AV_SCALE = 0.9;          // the suit is 1.90 m; the game's eye sits 1.49 m over the deck
const EYE = 1.50;              // helmet-centre height of the scaled model above its soles
export const art = {
  ready: false, failed: null, loaded: [],
  avatar: null, body: null, arms: null, mixer: null, actions: {}, current: null,
  fig: null, figMats: [], nearer: null, nearerPoses: [], pose: 0, lastDist: null,
  dish: null, nullp: null, kit: null,
  view: 'first', camDist: 0, camOff: new THREE.Vector3(), tris: {}, lastCam: [0, 0, 0],
};

// ---- where the camera may be: the air inside the three rooms (ship frame), shrunk by a margin
const AIR = [
  { x0: -2.04, x1: 2.04, y0: 0.06, y1: 2.24, z0: -9.36, z1: -5.35 },   // console room
  { x0: -1.26, x1: 1.26, y0: 0.06, y1: 2.09, z0: -5.75, z1: -0.55 },   // corridor (reaches into both doorways)
  { x0: -1.49, x1: 1.49, y0: 0.06, y1: 2.09, z0: -0.95, z1: 2.10 },    // airlock
];
const M = 0.16;
function inAir(p) {
  for (const b of AIR) if (p.x > b.x0 + M && p.x < b.x1 - M && p.y > b.y0 + M && p.y < b.y1 - M && p.z > b.z0 + M && p.z < b.z1 - M) return true;
  return false;
}
// outside: the hull is a capsule of radius 3.3 around x=0, y=1.1, z -12.5..5.5
function outOfHull(p) {
  const z = Math.max(-12.5, Math.min(5.5, p.z));
  return Math.hypot(p.x, p.y - 1.1, p.z - z) > 3.3 + 0.35;
}
export function camFree(p) { return S.mode === 'interior' ? inAir(p) : outOfHull(p); }

function load(f) {
  return new Promise((res, rej) => new GLTFLoader().load(BASE + f, g => { art.loaded.push(f); res(g); }, undefined, rej));
}
function tris(o) { let t = 0; o.traverse(m => { if (m.isMesh) t += (m.geometry.index ? m.geometry.index.count : m.geometry.attributes.position.count) / 3; }); return Math.round(t); }

export function loadArt() {
  return Promise.all(['astronaut.glb', 'listener.glb', 'nearer.glb', 'null_point.glb', 'kit_corridor.glb'].map(load))
    .then(([astro, listener, nearer, nullp, kit]) => {
      setupAvatar(astro); setupFigure(astro); setupRack(astro); setupListener(listener); setupNearer(nearer); setupNull(nullp); setupKit(kit);
      art.ready = true;
    })
    .catch(e => { art.failed = String(e && e.message || e); console.warn('art wave: models not loaded, keeping the old visuals:', art.failed); });
}

// ---------------------------------------------------------------- the player's body
function setupAvatar(g) {
  const root = new THREE.Group(); root.name = 'artAvatar';
  const inst = SkeletonUtils.clone(g.scene);
  inst.scale.setScalar(AV_SCALE);
  inst.rotation.y = Math.PI;            // the model faces +Z; the camera looks down -Z
  root.add(inst);
  inst.traverse(o => { if (o.isMesh) { o.frustumCulled = false; } });
  art.body = inst.getObjectByName('Astronaut');
  art.arms = inst.getObjectByName('AstronautArmsFP');
  // the suit's vertex colours are true white fabric; under the cabin lamps that burns out, so the
  // lit materials are toned to sit with the walls (the visor and the lamps and LEDs keep their values)
  const seen = new Set();
  inst.traverse(o => { if (!o.isMesh) return; (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => {
    if (seen.has(m)) return; seen.add(m);
    if (!/visor|emit/.test(m.name)) m.color.multiplyScalar(0.36);
  }); });
  art.mixer = new THREE.AnimationMixer(inst);
  for (const c of g.animations) art.actions[c.name] = art.mixer.clipAction(c);
  for (const n of ['clip_on', 'unclip', 'grab', 'push_off']) if (art.actions[n]) { art.actions[n].setLoop(THREE.LoopOnce); art.actions[n].clampWhenFinished = false; }
  root.visible = false;
  ship.add(root);
  art.avatar = root;
  art.tris.avatar = tris(art.body); art.tris.arms = tris(art.arms);
  play('idle_mag', 0);
}
function play(name, fade = 0.25) {
  const a = art.actions[name]; if (!a || art.current === name) return;
  const prev = art.current && art.actions[art.current];
  a.reset(); a.enabled = true; a.setEffectiveWeight(1); a.play();
  if (prev) prev.crossFadeTo(a, fade, false);
  art.current = name;
}
function oneShot(name) {
  const a = art.actions[name]; if (!a) return;
  a.reset(); a.setEffectiveWeight(1); a.play();
  const base = art.current && art.actions[art.current];
  if (base) { base.setEffectiveWeight(0.15); setTimeout(() => base.setEffectiveWeight(1), a.getClip().duration * 1000); }
}

// is the shoulder view allowed right now? Scares, the helm, sleep and the wreck always use the helmet.
export function thirdAllowed() {
  const T = S.threat;
  if (!S.awake || S.dying || S.ended || S.sleeping || S.helm || S.P.flight || S.collapsing) return false;
  if (S.mode !== 'interior' && S.mode !== 'eva') return false;
  if (T.listenerState === 'coming' || T.listenerState === 'passing' || T.approach) return false;
  if ((T.figureFlicker || 0) > 0 || (T.figureBlack || 0) > 0) return false;
  return true;
}

const _q = new THREE.Quaternion(), _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _prev = new THREE.Vector3();
let prevTether = null, speedS = 0;
function updateAvatar(dt) {
  const root = art.avatar; if (!root) return;
  const show = S.awake && !S.helm && !S.sleeping && (S.mode === 'interior' || S.mode === 'eva');
  root.visible = show;
  if (!show) return;
  if (S.mode === 'eva') {
    root.quaternion.copy(S.q);
    _v.set(0, -EYE, 0).applyQuaternion(S.q);
    root.position.copy(S.pos).add(_v);
  } else {
    root.quaternion.setFromAxisAngle(_v2.set(0, 1, 0), S.yaw || 0);
    root.position.set(S.pos.x, S.pos.y - EYE, S.pos.z);
    // helmet view: the body sits a little forward so the forearms are not inside the near plane
    if (art.view === 'first') { _v.set(0, 0, -0.14).applyQuaternion(root.quaternion); root.position.add(_v); }
  }
  // clip choice from how fast the body is moving
  const sp = dt > 0 ? _prev.distanceTo(root.position) / dt : 0; _prev.copy(root.position);
  speedS += (Math.min(sp, 6) - speedS) * Math.min(1, dt * 6);
  if (S.mode === 'eva') play('float');
  else if (speedS > 0.35) { play('walk_mag'); art.actions.walk_mag.timeScale = Math.max(0.6, Math.min(1.6, speedS / 1.4)); }
  else play('idle_mag');
  const teth = S.eva ? !!S.eva.tethered : null;
  if (prevTether !== null && teth !== prevTether && S.mode === 'eva') oneShot(teth ? 'clip_on' : 'unclip');
  prevTether = teth;
  art.mixer.update(dt);
}

// ---------------------------------------------------------------- the suits on the airlock rack
// The old rack suits were capsules and a ball: the bubble look. Their groups stay (the story shows and
// hides them), their parts are hidden, and each carries a real suit hanging on its hook, facing the room.
function setupRack(g) {
  for (const grp of [shipFx.suitOnRack, shipFx.suit2]) {
    if (!grp) continue;
    grp.children.forEach(c => { c.visible = false; });
    const inst = SkeletonUtils.clone(g.scene);
    inst.name = 'artRackSuit';
    const fp = inst.getObjectByName('AstronautArmsFP'); if (fp) fp.visible = false;
    inst.scale.setScalar(AV_SCALE);
    inst.rotation.y = Math.PI / 2;                 // faces +X, into the airlock; the backpack to the wall
    inst.position.set(0.16, 0.1, 0);               // hanging: boots 10 cm off the deck
    inst.traverse(o => { if (o.isMesh) o.frustumCulled = false; });
    const mx = new THREE.AnimationMixer(inst); const c = THREE.AnimationClip.findByName(g.animations, 'idle_mag');
    if (c) { mx.clipAction(c).play(); mx.setTime(0.1); }
    const head = inst.getObjectByName('head'); if (head) head.rotateX(0.18);   // an empty suit's helmet sags forward
    grp.add(inst);
  }
}

// ---------------------------------------------------------------- CREW 2: your own suit, black
function setupFigure(g) {
  const inst = SkeletonUtils.clone(g.scene);
  inst.name = 'artFigure';
  const black = new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 0.55, metalness: 0.1, transparent: true, opacity: 0 });
  const visor = new THREE.MeshStandardMaterial({ color: 0x040405, roughness: 0.03, metalness: 1.0, transparent: true, opacity: 0 });
  inst.traverse(o => {
    if (!o.isMesh) return;
    o.frustumCulled = false;
    o.material = Array.isArray(o.material) ? o.material.map(m => /visor/.test(m.name) ? visor : black) : (/visor/.test(o.material.name) ? visor : black);
  });
  art.figMats = [black, visor];
  const fp = inst.getObjectByName('AstronautArmsFP'); if (fp) fp.visible = false;
  // hold the idle pose, then the three wrong things: head tilted, forearms long (the float is set in update)
  const mx = new THREE.AnimationMixer(inst); const c = THREE.AnimationClip.findByName(g.animations, 'idle_mag');
  if (c) { mx.clipAction(c).play(); mx.setTime(0.5); }
  const head = inst.getObjectByName('head'); if (head) head.rotateZ(-0.23);
  ['forearm.L', 'forearm.R'].forEach(n => { const b = inst.getObjectByName(n); if (b) b.scale.set(1, 1.1, 1); });
  inst.visible = false;
  ship.add(inst);
  art.fig = inst;
  // the old capsule stays (its transform and opacity drive everything, and the tests read it) but draws nothing
  if (figure.mat) { figure.mat.colorWrite = false; figure.mat.depthWrite = false; }
}
function updateFigure() {
  const f = art.fig, m = figure.mesh; if (!f || !m) return;
  const a = figure.mat ? figure.mat.opacity : 0;
  f.visible = m.visible && a > 0.01;
  if (!f.visible) return;
  f.position.set(m.position.x, 0.09, m.position.z);   // 3 cm off the deck
  f.rotation.set(0, m.rotation.y, 0);                  // upright, facing you
  f.scale.setScalar(AV_SCALE * m.scale.x);
  for (const mt of art.figMats) mt.opacity = Math.min(1, a * 1.1);
}

// ---------------------------------------------------------------- the Listener: a listening dish
function setupListener(g) {
  const m = listenerBody.mesh; if (!m) return;
  const dish = g.scene; dish.name = 'artListener';
  dish.traverse(o => { if (o.isMesh) { o.frustumCulled = false; o.renderOrder = 2; } });
  m.add(dish);
  m.material.colorWrite = false; m.material.depthWrite = false;   // the old ellipsoid stays as the carrier
  if (listenerBody.lights) listenerBody.lights.visible = false;     // the dish carries its own 44 lights
  art.dish = dish;
  art.tris.listener = tris(dish);
}
const _cw = new THREE.Vector3(), _up = new THREE.Vector3(0, 1, 0);
function updateListener() {
  const m = listenerBody.mesh, d = art.dish; if (!m || !d || !m.visible) return;
  // its concave face (+Y) turns toward you as it passes: you look into the focus of an ear
  camera.getWorldPosition(_cw); m.worldToLocal(_cw);
  d.quaternion.setFromUnitVectors(_up, _cw.normalize());
}

// ---------------------------------------------------------------- the Nearer: a frozen shard lattice
function setupNearer(g) {
  const root = new THREE.Group(); root.name = 'artNearer';
  const sc = g.scene; sc.scale.setScalar(0.62); sc.position.y = -0.9;
  root.add(sc);
  for (let p = 0; p < 3; p++) {
    const nodes = [];
    for (let s = 0; s < 3; s++) {
      const o = sc.getObjectByName(`Nearer_p${p}_s${s}`); if (!o) continue;
      o.frustumCulled = false;
      if (s > 0) { o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = [1, 0.42, 0.2][s]; o.material.depthWrite = false; }
      nodes.push(o);
    }
    art.nearerPoses.push(nodes);
  }
  approachMesh.add(root);
  approachMesh.material.colorWrite = false; approachMesh.material.depthWrite = false;
  approachRim.visible = false;
  art.nearer = root;
  showPose(0);
  art.tris.nearerPose = tris(sc) / 3 | 0;
}
function showPose(i) { art.pose = i; art.nearerPoses.forEach((nodes, p) => nodes.forEach(o => { o.visible = p === i; })); }
function updateNearer() {
  const r = art.nearer; if (!r || !approachMesh.visible) { if (r) art.lastDist = null; return; }
  const T = S.threat;
  // it faces you, upright in the ship frame
  r.rotation.set(0, Math.atan2(S.pos.x - approachMesh.position.x, S.pos.z - approachMesh.position.z), 0);
  // a new frozen pose each time it has closed distance unseen
  if (T.approach) {
    if (art.lastDist === null) art.lastDist = T.approach.dist;
    if (art.lastDist - T.approach.dist > 4) { showPose((art.pose + 1) % art.nearerPoses.length); art.lastDist = T.approach.dist; }
  }
}

// ---------------------------------------------------------------- the Null Point: a crossed circle on the bearing
function setupNull(g) {
  const n = g.scene; n.name = 'artNull';
  n.traverse(o => { if (o.isMesh) { o.frustumCulled = false; if (o.material) o.material.fog = false; } });
  n.visible = false;
  scene.add(n);
  art.nullp = n;
}
const _cq = new THREE.Quaternion(), _roll = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), Math.PI / 4);
function updateNull(camW) {
  const n = art.nullp; if (!n) return;
  const dir = S.sys && S.sys.nullDir;
  n.visible = !!(dir && S.awake && !S.P.flight && S.nullHits >= 1);
  if (!n.visible) return;
  const R = SKY_R * 0.9;
  n.position.copy(dir).multiplyScalar(R).add(camW);
  // billboard, and the cross keeps its angle to the helmet however you roll: it is in the measurement
  camera.getWorldQuaternion(_cq); n.quaternion.copy(_cq).multiply(_roll);
  let k = 1;
  if (S.collapsing && S.collapseHoldStart !== null && S.sys.holdMs) k = 1 - 0.55 * Math.min(1, (performance.now() - S.collapseHoldStart) / S.sys.holdMs);
  n.scale.setScalar(R * Math.tan(THREE.MathUtils.degToRad(0.22)) * k);
}

// ---------------------------------------------------------------- less-blocky kit: ribs and filleted corners
function setupKit(g) {
  const src = {}; g.scene.children.forEach(c => { src[c.name] = c; });
  const kit = new THREE.Group(); kit.name = 'artKit';
  const put = (name, x, y, z, sx = 1, sz = 1) => {
    const s = src[name]; if (!s) return;
    const o = s.clone(); o.position.set(x, y, z); o.scale.set(sx, 1, sz); kit.add(o);
  };
  // structural ribs in the corridor, placed clear of the bunks' open sides and the lockers
  for (const z of [-5.28, -3.44, -2.8, -0.99]) put('kit_rib', 0, 0, z);
  // coved ceiling corners and chamfered floor corners, both sides, in all three rooms
  const rooms = [{ dx: 0, dy: 0, z: -3.15, len: 4.4 }, { dx: 0.23, dy: 0, z: 0.6, len: 3.1 }, { dx: 0.78, dy: 0.15, z: -7.375, len: 4.05 }];
  for (const r of rooms) for (const s of [1, -1]) {
    put('kit_fillet_ceiling', s * r.dx, r.dy, r.z, s, r.len);
    put('kit_fillet_floor', s * r.dx, 0, r.z, s, r.len);
  }
  kit.traverse(o => { if (o.isMesh) { o.matrixAutoUpdate = true; } });
  ship.add(kit);
  art.kit = kit;
  art.tris.kit = tris(kit);
}

// ---------------------------------------------------------------- per frame
export function updateArt(dt, camW) {
  if (!art.ready) return;
  updateAvatar(dt); updateFigure(); updateListener(); updateNearer(); updateNull(camW);
}

// the shoulder camera: called right before the draw; endRender() puts the helmet camera back
const _off = new THREE.Vector3(), _pivot = new THREE.Vector3(), _p = new THREE.Vector3(), _p2 = new THREE.Vector3(), _back = new THREE.Vector3();
export function beginRender(dt) {
  if (!art.ready) return false;
  const want = S.settings.view === 'shoulder' && thirdAllowed();
  art.view = want ? 'third' : 'first';
  const body = art.body, arms = art.arms;
  if (!want) {
    art.camDist = 0;
    if (body) body.visible = false;
    if (arms) arms.visible = true;
    return false;
  }
  // a spring arm in two legs: from the helmet out to the right shoulder (0.45 right, 0.25 up), then
  // 1.6 m back. Each leg stops short of the first point that is not free air.
  const sweep = (from, dir, len) => {
    let best = 0;
    for (let i = 1; i <= 20; i++) { _p.copy(from).addScaledVector(dir, len * i / 20); if (!camFree(_p)) break; best = i / 20; }
    return Math.max(0, best * len - 0.08);
  };
  _pivot.copy(S.pos);
  if (!camFree(_pivot)) { art.camDist = 0; if (body) body.visible = false; if (arms) arms.visible = true; return false; }
  _off.set(0.45, 0.25, 0).applyQuaternion(S.q); const sideLen = _off.length(); _off.normalize();
  const side = sweep(_pivot, _off, sideLen);
  _p2.copy(_pivot).addScaledVector(_off, side);
  _back.set(0, 0, 1).applyQuaternion(S.q);
  const back = sweep(_p2, _back, 1.6);
  const best = back / 1.6;
  art.camDist += (best - art.camDist) * Math.min(1, dt * 8);
  if (best < art.camDist) art.camDist = best;          // never ease INTO a wall: pull in at once
  const d = art.camDist * 1.6;
  if (body) body.visible = d > 0.35;                    // too close to see past yourself: hide the suit
  if (arms) arms.visible = !body || !body.visible;
  camera.position.copy(_p2).addScaledVector(_back, d);
  // the helmet lamp rides the camera; for this draw move it back to the helmet so it lights the way, not your back
  _lampOff.copy(_pivot).sub(camera.position).applyQuaternion(_qi.copy(S.q).invert());
  _lampP.copy(helmetLamp.position); _lampT.copy(helmetLamp.target.position);
  helmetLamp.position.add(_lampOff); helmetLamp.target.position.add(_lampOff); lampMoved = true;
  camera.updateMatrixWorld(true);
  art.lastCam = camera.position.toArray();
  return true;
}
const _lampOff = new THREE.Vector3(), _lampP = new THREE.Vector3(), _lampT = new THREE.Vector3(), _qi = new THREE.Quaternion();
let lampMoved = false;
export function endRender() {
  if (lampMoved) { helmetLamp.position.copy(_lampP); helmetLamp.target.position.copy(_lampT); lampMoved = false; }
  camera.position.copy(S.pos);
  camera.updateMatrixWorld(true);
}
