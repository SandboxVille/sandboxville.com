// Baked light for the static rooms: ambient occlusion plus soft visibility to
// each room lamp, stored as vertex colours; and a merge that folds the static
// meshes of a room into one draw call per material.
//
// Computed once at load with analytic ray-box tests (no GPU work, no image
// files) and deterministic: the ray pattern is a fixed Fibonacci set.
//
// Why vertex colours and not shadow maps: the ship turns at the helm, and a
// point-light shadow map is laid out on world axes, so it would have to be
// re-rendered (6 faces per lamp) on every frame the ship turns. Baked in the
// ship's own frame, the shadows turn with the rooms for free, and the light
// count never changes.
import * as THREE from 'three';

const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _n = new THREE.Vector3(), _m = new THREE.Matrix4(), _nm = new THREE.Matrix3();

// a box with enough vertices to hold a soft shadow edge (about 0.25 m apart)
export function segBox(sx, sy, sz, step = 0.34) {
  const s = v => Math.max(1, Math.min(20, Math.ceil(v / step)));
  return new THREE.BoxGeometry(sx, sy, sz, s(sx), s(sy), s(sz));
}

// ---------- occluders: oriented boxes in the root's frame ----------
function obbOf(mesh, invRoot) {
  const g = mesh.geometry;
  if (!g.boundingBox) g.computeBoundingBox();
  const bb = g.boundingBox;
  _m.multiplyMatrices(invRoot, mesh.matrixWorld);
  const e = _m.elements;
  const ax = [new THREE.Vector3(e[0], e[1], e[2]), new THREE.Vector3(e[4], e[5], e[6]), new THREE.Vector3(e[8], e[9], e[10])];
  const sc = ax.map(a => a.length());
  ax.forEach((a, i) => a.divideScalar(sc[i] || 1));
  const c = bb.getCenter(new THREE.Vector3()).applyMatrix4(_m);
  const s = bb.getSize(new THREE.Vector3());
  const h = [Math.max(0.004, s.x / 2 * sc[0]), Math.max(0.004, s.y / 2 * sc[1]), Math.max(0.004, s.z / 2 * sc[2])];
  return { c, ax, h, r: Math.hypot(h[0], h[1], h[2]), mesh };
}

function chainVisible(o, root) { for (let p = o; p && p !== root; p = p.parent) if (!p.visible) return false; return true; }

export function collectOccluders(root, skip = () => false) {
  root.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert();
  const out = [];
  root.traverse(o => {
    if (!o.isMesh || skip(o) || !chainVisible(o, root)) return;
    const t = o.geometry.type;
    if (t === 'PlaneGeometry' || t === 'CircleGeometry') return;            // decals, labels, screens
    if (o.material && (o.material.transparent || o.material.isShaderMaterial)) return;
    if (o.userData.noOcclude) return;
    out.push(obbOf(o, inv));
  });
  return out;
}

// the boxes packed into one typed array for the hot loop (stride 16):
// centre xyz, axis0 xyz, axis1 xyz, axis2 xyz, half-extents xyz, bounding radius squared
const ST = 16;
function packOBB(occ) {
  const F = new Float64Array(occ.length * ST);
  occ.forEach((b, i) => {
    const o = i * ST;
    F[o] = b.c.x; F[o + 1] = b.c.y; F[o + 2] = b.c.z;
    for (let k = 0; k < 3; k++) { F[o + 3 + k * 3] = b.ax[k].x; F[o + 4 + k * 3] = b.ax[k].y; F[o + 5 + k * 3] = b.ax[k].z; }
    F[o + 12] = b.h[0]; F[o + 13] = b.h[1]; F[o + 14] = b.h[2]; F[o + 15] = b.r * b.r;
  });
  return F;
}
function slab(e, f, h, st) { // st = [t0, t1]; false when the ray misses this slab
  if (f > -1e-9 && f < 1e-9) return e >= -h && e <= h;
  let ta = (-h - e) / f, tb = (h - e) / f;
  if (ta > tb) { const s = ta; ta = tb; tb = s; }
  if (ta > st[0]) st[0] = ta;
  if (tb < st[1]) st[1] = tb;
  return st[0] <= st[1];
}
const _st = new Float64Array(2);
// ray (origin o, unit dir d) against packed box i: entry distance in (0, L), or -1
function rayOBB(F, i, ox, oy, oz, dx, dy, dz, L) {
  const o = i * ST;
  const px = ox - F[o], py = oy - F[o + 1], pz = oz - F[o + 2];
  // cheap reject: the segment's closest approach to the bounding sphere
  let tc = -(px * dx + py * dy + pz * dz);
  tc = tc < 0 ? 0 : tc > L ? L : tc;
  const qx = px + dx * tc, qy = py + dy * tc, qz = pz + dz * tc;
  if (qx * qx + qy * qy + qz * qz > F[o + 15]) return -1;
  _st[0] = 1e-4; _st[1] = L;
  if (!slab(F[o + 3] * px + F[o + 4] * py + F[o + 5] * pz, F[o + 3] * dx + F[o + 4] * dy + F[o + 5] * dz, F[o + 12], _st)) return -1;
  if (!slab(F[o + 6] * px + F[o + 7] * py + F[o + 8] * pz, F[o + 6] * dx + F[o + 7] * dy + F[o + 8] * dz, F[o + 13], _st)) return -1;
  if (!slab(F[o + 9] * px + F[o + 10] * py + F[o + 11] * pz, F[o + 9] * dx + F[o + 10] * dy + F[o + 11] * dz, F[o + 14], _st)) return -1;
  return _st[0];
}

// fixed hemisphere pattern around +Z (cosine-weighted Fibonacci spiral)
function hemiPattern(n) {
  const out = [], ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < n; i++) {
    const u = (i + 0.5) / n, r = Math.sqrt(u), phi = i * ga;
    out.push([r * Math.cos(phi), r * Math.sin(phi), Math.sqrt(Math.max(0, 1 - u))]);
  }
  return out;
}
const HEMI = hemiPattern(10);
// the lamp is not a point: three taps across a small disc
const TAPS = [[0, 0, 0], [0.14, 0, 0.07], [-0.12, 0, -0.1]];

// a uniform grid over the occluders' bounding boxes, so a ray only tests the boxes near it
function buildGrid(occ, cell) {
  const map = new Map(), key = (i, j, k) => (i * 73856093) ^ (j * 19349663) ^ (k * 83492791);
  occ.forEach((b, idx) => {
    // the box's own axis-aligned extent (a thin wall only fills the cells along its plane)
    const e = [0, 1, 2].map(k => Math.abs(b.ax[0].getComponent(k)) * b.h[0] + Math.abs(b.ax[1].getComponent(k)) * b.h[1] + Math.abs(b.ax[2].getComponent(k)) * b.h[2]);
    const i0 = Math.floor((b.c.x - e[0]) / cell), i1 = Math.floor((b.c.x + e[0]) / cell);
    const j0 = Math.floor((b.c.y - e[1]) / cell), j1 = Math.floor((b.c.y + e[1]) / cell);
    const k0 = Math.floor((b.c.z - e[2]) / cell), k1 = Math.floor((b.c.z + e[2]) / cell);
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) for (let k = k0; k <= k1; k++) {
      const h = key(i, j, k); let a = map.get(h); if (!a) { a = []; map.set(h, a); } a.push(idx);
    }
  });
  let stamp = 0; const seen = new Int32Array(occ.length);
  // every occluder whose cells touch the axis-aligned box [lo, hi]
  return function query(lx, ly, lz, hx, hy, hz, out) {
    out.length = 0; stamp++;
    const i0 = Math.floor(lx / cell), i1 = Math.floor(hx / cell), j0 = Math.floor(ly / cell), j1 = Math.floor(hy / cell), k0 = Math.floor(lz / cell), k1 = Math.floor(hz / cell);
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) for (let k = k0; k <= k1; k++) {
      const a = map.get(key(i, j, k)); if (!a) continue;
      for (const idx of a) if (seen[idx] !== stamp) { seen[idx] = stamp; out.push(idx); }
    }
    return out;
  };
}

// lamps: [{ pos: Vector3 (root frame), range, weight }]
// opts: aoDist (m), aoStrength, shadowFloor, occluders, skipOccluder(o), skipReceiver(o), flatBelow (m)
export function bakeRoot(root, lamps, opts = {}) {
  const t0 = performance.now();
  const aoDist = opts.aoDist ?? 0.8, aoK = opts.aoStrength ?? 0.9, floor = opts.shadowFloor ?? 0.18;
  const flatBelow = opts.flatBelow ?? 0.18;
  const occ = opts.occluders || collectOccluders(root, opts.skipOccluder);
  const query = buildGrid(occ, 0.5);
  const F = packOBB(occ);
  const receivers = [];
  root.traverse(o => { if (o.isMesh && o.material && o.material.isMeshStandardMaterial && !(opts.skipReceiver && opts.skipReceiver(o))) receivers.push(o); });
  root.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert();
  const t = new THREE.Vector3(), bt = new THREE.Vector3(), sc = new THREE.Vector3();
  const near = [], seg = new THREE.Vector3(), tmp = new THREE.Vector3();
  let rays = 0, flat = 0;
  // light at one point with one normal: [ao, vis] -> the vertex colour
  const shade = (vx, vy, vz, nx, ny, nz, self, lampCands) => {
    if (Math.abs(nx) < 0.9) t.set(1, 0, 0); else t.set(0, 1, 0);
    _n.set(nx, ny, nz); t.cross(_n).normalize(); bt.crossVectors(_n, t);
    const ox = vx + nx * 0.01, oy = vy + ny * 0.01, oz = vz + nz * 0.01;
    query(ox - aoDist, oy - aoDist, oz - aoDist, ox + aoDist, oy + aoDist, oz + aoDist, near);
    let occl = 0;
    for (const h of HEMI) {
      const dx = t.x * h[0] + bt.x * h[1] + nx * h[2], dy = t.y * h[0] + bt.y * h[1] + ny * h[2], dz = t.z * h[0] + bt.z * h[1] + nz * h[2];
      rays++;
      let best = aoDist;
      for (let q = 0; q < near.length; q++) { const bi = near[q]; if (bi === self) continue; const th = rayOBB(F, bi, ox, oy, oz, dx, dy, dz, best); if (th >= 0 && th < best) best = th; }
      if (best < aoDist) occl += 1 - best / aoDist;
    }
    const ao = 1 - aoK * Math.min(1, occl / HEMI.length * 1.7);
    let ws = 0, vs = 0;
    for (let li = 0; li < lamps.length; li++) {
      const L = lamps[li], cand = lampCands[li];
      if (!cand) continue;
      const wx = L.pos.x - vx, wy = L.pos.y - vy, wz = L.pos.z - vz, d = Math.hypot(wx, wy, wz);
      if (d > L.range) continue;
      const ndl = (nx * wx + ny * wy + nz * wz) / d;
      if (ndl <= 0) continue;
      const w = (L.weight ?? 1) * Math.pow(1 - d / L.range, 2) * ndl / Math.max(0.3, d);
      let seen = 0;
      for (const tap of TAPS) {
        const tx = L.pos.x + tap[0] - ox, ty = L.pos.y + tap[1] - oy, tz = L.pos.z + tap[2] - oz;
        const tl = Math.hypot(tx, ty, tz);
        const dx = tx / tl, dy = ty / tl, dz = tz / tl;
        rays++;
        let blocked = false;
        for (let q = 0; q < cand.length; q++) { const bi = cand[q]; if (bi === self) continue; if (rayOBB(F, bi, ox, oy, oz, dx, dy, dz, tl - 0.04) >= 0) { blocked = true; break; } }
        if (!blocked) seen++;
      }
      ws += w; vs += w * seen / TAPS.length;
    }
    const vis = ws > 1e-9 ? vs / ws : (lamps.length ? floor : 1);
    return ao * (floor + (1 - floor) * vis);
  };
  for (const mesh of receivers) {
    const g = mesh.geometry;
    if (g.userData.baked) continue;
    const pos = g.attributes.position, nor = g.attributes.normal;
    if (!nor) continue;
    _m.multiplyMatrices(inv, mesh.matrixWorld); _nm.getNormalMatrix(_m);
    if (!g.boundingSphere) g.computeBoundingSphere();
    const col = new Float32Array(pos.count * 3);
    const radius = g.boundingSphere.radius * _m.getMaxScaleOnAxis();
    const selfIdx = occ.findIndex(b => b.mesh === mesh);
    // per lamp: the occluders anywhere near the sweep from a patch of this mesh to the lamp
    const lampCandsFor = (cx, cy, cz, rad) => lamps.map(L => {
      seg.set(L.pos.x - cx, L.pos.y - cy, L.pos.z - cz); const len = seg.length();
      if (len - rad > L.range) return null;
      const out = [];
      occ.forEach((b, bi) => {
        tmp.set(b.c.x - cx, b.c.y - cy, b.c.z - cz);
        const tt = Math.max(0, Math.min(1, tmp.dot(seg) / (len * len || 1)));
        tmp.set(cx + seg.x * tt - b.c.x, cy + seg.y * tt - b.c.y, cz + seg.z * tt - b.c.z);
        if (tmp.length() < b.r + rad * (1 - tt) + 0.25) out.push(bi);
      });
      return out;
    });
    sc.copy(g.boundingSphere.center).applyMatrix4(_m);
    if (radius < flatBelow || mesh.userData.bakeFlat) {
      // small props: one sample at the centre, facing up, for every vertex
      const k = shade(sc.x, sc.y + radius, sc.z, 0, 1, 0, selfIdx, lampCandsFor(sc.x, sc.y, sc.z, radius));
      col.fill(k); flat++;
    } else {
      // big meshes: vertices in 1 m patches, each patch with its own (shorter) candidate lists
      const patches = new Map(), P = 1.0;
      for (let i = 0; i < pos.count; i++) {
        _v.fromBufferAttribute(pos, i).applyMatrix4(_m);
        const key = Math.floor(_v.x / P) + ',' + Math.floor(_v.y / P) + ',' + Math.floor(_v.z / P);
        let pa = patches.get(key); if (!pa) { pa = []; patches.set(key, pa); } pa.push(i);
      }
      for (const idxs of patches.values()) {
        let cx = 0, cy = 0, cz = 0;
        for (const i of idxs) { _v.fromBufferAttribute(pos, i).applyMatrix4(_m); cx += _v.x; cy += _v.y; cz += _v.z; }
        cx /= idxs.length; cy /= idxs.length; cz /= idxs.length;
        let rr = 0; for (const i of idxs) { _v.fromBufferAttribute(pos, i).applyMatrix4(_m); rr = Math.max(rr, Math.hypot(_v.x - cx, _v.y - cy, _v.z - cz)); }
        const lc = lampCandsFor(cx, cy, cz, rr);
        for (const i of idxs) {
          _v.fromBufferAttribute(pos, i).applyMatrix4(_m);
          _w.fromBufferAttribute(nor, i).applyMatrix3(_nm).normalize();
          const k = shade(_v.x, _v.y, _v.z, _w.x, _w.y, _w.z, selfIdx, lc);
          col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = k;
        }
      }
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    g.userData.baked = true;
    mesh.material.vertexColors = true;
  }
  return { receivers: receivers.length, flat, occluders: occ.length, rays, ms: Math.round(performance.now() - t0) };
}

// every mesh drawn with a vertex-coloured material needs a colour attribute,
// or WebGL reads (0,0,0) and it renders black: give the rest plain white
export function whiteColours(root) {
  root.traverse(o => {
    if (!o.isMesh || !o.material || !o.material.vertexColors || o.geometry.attributes.color) return;
    const a = new Float32Array(o.geometry.attributes.position.count * 3).fill(1);
    o.geometry.setAttribute('color', new THREE.BufferAttribute(a, 3));
  });
}

// ---------- merge: one draw call per material for the static parts of a room ----------
// canMerge(o) decides; meshes whose material is not shared by at least two
// candidates are left alone. Returns the number of meshes folded away.
export function mergeStatic(root, canMerge) {
  root.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert();
  const buckets = new Map();
  root.traverse(o => {
    if (!o.isMesh || !o.material || Array.isArray(o.material) || !canMerge(o) || !chainVisible(o, root)) return;
    const k = o.material.uuid + (o.geometry.attributes.color ? ':c' : '') + (o.geometry.attributes.uv ? ':u' : '');
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k).push(o);
  });
  let folded = 0;
  const touched = new Set();
  for (const list of buckets.values()) {
    if (list.length < 2) continue;
    let nv = 0, ni = 0;
    for (const o of list) { const g = o.geometry; nv += g.attributes.position.count; ni += g.index ? g.index.count : g.attributes.position.count; }
    const hasUv = !!list[0].geometry.attributes.uv, hasCol = !!list[0].geometry.attributes.color;
    const P = new Float32Array(nv * 3), N = new Float32Array(nv * 3), U = hasUv ? new Float32Array(nv * 2) : null, C = hasCol ? new Float32Array(nv * 3) : null;
    const I = nv > 65535 ? new Uint32Array(ni) : new Uint16Array(ni);
    let vo = 0, io = 0;
    for (const o of list) {
      const g = o.geometry, pa = g.attributes.position, na = g.attributes.normal;
      _m.multiplyMatrices(inv, o.matrixWorld); _nm.getNormalMatrix(_m);
      const flip = _m.determinant() < 0;
      for (let i = 0; i < pa.count; i++) {
        _v.fromBufferAttribute(pa, i).applyMatrix4(_m); P.set([_v.x, _v.y, _v.z], (vo + i) * 3);
        if (na) { _n.fromBufferAttribute(na, i).applyMatrix3(_nm).normalize(); N.set([_n.x, _n.y, _n.z], (vo + i) * 3); }
        if (U) { const ua = g.attributes.uv; U[(vo + i) * 2] = ua.getX(i); U[(vo + i) * 2 + 1] = ua.getY(i); }
        if (C) { const ca = g.attributes.color; C[(vo + i) * 3] = ca.getX(i); C[(vo + i) * 3 + 1] = ca.getY(i); C[(vo + i) * 3 + 2] = ca.getZ(i); }
      }
      if (g.index) {
        const ix = g.index.array;
        for (let k = 0; k < ix.length; k += 3) {
          I[io++] = ix[k] + vo;
          if (flip) { I[io++] = ix[k + 2] + vo; I[io++] = ix[k + 1] + vo; } else { I[io++] = ix[k + 1] + vo; I[io++] = ix[k + 2] + vo; }
        }
      } else {
        for (let k = 0; k < pa.count; k += 3) { I[io++] = vo + k; I[io++] = vo + (flip ? k + 2 : k + 1); I[io++] = vo + (flip ? k + 1 : k + 2); }
      }
      vo += pa.count;
    }
    const mg = new THREE.BufferGeometry();
    mg.setAttribute('position', new THREE.BufferAttribute(P, 3));
    mg.setAttribute('normal', new THREE.BufferAttribute(N, 3));
    if (U) mg.setAttribute('uv', new THREE.BufferAttribute(U, 2));
    if (C) mg.setAttribute('color', new THREE.BufferAttribute(C, 3));
    mg.setIndex(new THREE.BufferAttribute(I, 1));
    mg.computeBoundingSphere(); mg.computeBoundingBox();
    const merged = new THREE.Mesh(mg, list[0].material);
    merged.userData.merged = list.length;
    root.add(merged);
    for (const o of list) { if (o.parent !== root) touched.add(o.parent); o.parent.remove(o); }
    folded += list.length - 1;
  }
  // drop the groups the merge emptied (and only those)
  touched.forEach(o => { if (o.children.length === 0 && o.parent) o.parent.remove(o); });
  return folded;
}
