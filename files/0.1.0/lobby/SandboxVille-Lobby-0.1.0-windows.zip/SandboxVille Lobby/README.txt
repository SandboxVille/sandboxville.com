SandboxVille Lobby
==================

SandboxVille is a small 3D building that runs on your own computer. Your AI works in
its rooms, and every door says what that room can touch, and nothing more.

This download is the base: your Lobby and the Security Office. You add other rooms
one at a time, like apps.


START IT

  Windows:  double-click  Start SandboxVille.cmd
  Mac:      double-click  Start SandboxVille.command
  Linux:    in a terminal, in this folder, run  ./start-sandboxville.sh

  A window with text opens. Keep it open while you play. Close it to stop SandboxVille.
  Your browser opens by itself, already paired with SandboxVille.

  SandboxVille needs a free program called Node.js (version 20 or newer).
  If you do not have it, the window tells you how to get it.


THE FIRST TIME

  Windows may show a blue box that says "Windows protected your PC".
  Windows shows this for new files it has not seen many times before.
  Click "More info", then "Run anyway".

  A Mac may say it cannot open the file because it is from an unidentified developer.
  Open System Settings, then Privacy & Security. Scroll down and click "Open Anyway"
  next to Start SandboxVille.command. Then double-click it again.
  (On older Macs: right-click the file, pick Open, then click Open.)


ADD A ROOM

  1. Download a room's zip from sandboxville.com (for example terrarium-0.1.0.zip).
  2. Put the zip, just as it is, in the  add-rooms-here  folder in this folder.
     Do not unzip it.
  3. In SandboxVille, walk to a glowing EMPTY LOT sign and press E.
  4. Pick the room. Read its door sign. If you are happy with it, press PLACE.

  SandboxVille checks every room's fingerprint before it opens it.
  A zip that was changed is refused, and the refusal shows on the Security Office wall.


ONLY YOU CAN BUILD

  The pairing link works once. It ties SandboxVille to your browser.
  Only that browser can place or remove a room. An AI never can.
  Do not share the pairing link.


WHAT STAYS ON YOUR COMPUTER

  SandboxVille runs only on your own computer, at the address 127.0.0.1.
  Your rooms and the Security Office log are saved in the  .sandboxville  folder
  in your user folder. A room you remove goes to a trash folder there.
  Nothing is deleted for good until you delete it yourself.


License: see LICENSE.txt. Third-party parts and their licenses: world/ATTRIBUTION.md.
