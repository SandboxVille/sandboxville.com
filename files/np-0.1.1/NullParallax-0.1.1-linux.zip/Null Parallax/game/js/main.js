// Orchestrator: builds the world, wires input to the systems, runs the game
// loop, and exposes a small test surface (window.NP). Gameplay lives in
// js/systems, presentation in js/ui and js/render.
import * as THREE from 'three';
import * as audio from './audio.js';
import { createPauseMenu } from './pause.js';
import { JOURNAL } from './journal-data.js';
import { readSlot, storageAvailable } from './save.js';
import { S } from './core/state.js';
import * as input from './core/input.js';
import { on, emit } from './core/events.js';
import { qFromYawPitch, sharedBasis, clamp } from './core/utils.js';
import { BOUNDARY_R, BOUNDARY_WARN, JUMP_FUEL_COST } from './core/constants.js';
import { renderer, scene, camera, ship, helmetLamp, lightPool, applyQuality } from './render/scene.js';
import { renderFrame, post as postState } from './render/post.js';
import { initGraphics, setGraphics, updateGraphics, gfx as gfxState } from './render/gfx.js';
import { art, loadArt, updateArt, beginRender, endRender, thirdAllowed, camFree } from './render/art.js';
import { buildShip, updateShipLights, updateFixtures, fixtureInfo, shipFx, HARDPOINTS, HATCH_EXT } from './render/ship.js';
import { field, derelict, boundary, buildDerelict, updateDerelict, buildBoundary, buildListenerBody, buildFigure, buildUnlitShapes, updateFieldMatrices, SHIP_CENTER, DERELICT_POS } from './render/world.js';
import * as movement from './systems/movement.js';
import * as interaction from './systems/interaction.js';
import * as repair from './systems/repair.js';
import * as sensors from './systems/sensors.js';
import * as entities from './systems/entities.js';
import * as audioHooks from './systems/audio-hooks.js';
import * as saveState from './systems/save-state.js';
import * as flow from './systems/flow.js';
import * as survival from './systems/survival.js';
import * as threats from './systems/threats.js';
import * as galley from './systems/galley.js';
import * as build from './systems/build.js';
import * as story from './systems/story.js';
import * as flight from './systems/flight.js';
import * as act2 from './systems/act2.js';
import * as cat from './systems/catalogue.js';
import * as chart from './ui/chart.js';
import * as wreck from './systems/derelict.js';
import * as landing from './systems/landing.js';
import * as mining from './systems/mining.js';
import * as base from './systems/base.js';
import { plantSpecies as plantSpeciesOf, depositsInCell } from './gen/planet.js';
import * as terrainR from './render/terrain.js';
import { unlockFragment, getLiveStats } from './systems/journal.js';
import { say, flash, updateHud } from './ui/hud.js';
import { setPauseMenu, refreshPause } from './ui/pause-bridge.js';

const $ = id => document.getElementById(id);

// ---------------- settings first (they affect everything) ----------------
S.settings = saveState.restoreSettings();
applyQuality(S.settings.quality);

// ---------------- world ----------------
buildShip();
buildDerelict();
wreck.build();
buildBoundary();
const skyAnchor = new THREE.Group(); scene.add(skyAnchor);
buildListenerBody(skyAnchor);
buildFigure();
buildUnlitShapes();
story.initStory();
initGraphics(S.settings.quality);
loadArt(); // art wave: the astronaut, the re-skinned threats and the kit (the old visuals stay until they load)

// ---------------- pause menu ----------------
let menuOpenedAt = 0;
function canSave() { const T = S.threat; return S.awake && !S.dying && !S.ended && !S.P.flight && !landing.busy() && T.listenerState !== 'coming' && T.listenerState !== 'passing' && !T.approach && T.dark < 30; }
const pauseMenu = createPauseMenu({
  getSettings: () => S.settings,
  setSettings: patch => applySettings(patch),
  getJournalIds: () => S.P.journalOrder,
  getCommsRepair: () => S.P.repair.comms,
  getLiveStats,
  getRepair: repair.getRepairCtx,
  getShipStatus: () => ({ level: survival.power.level, gen: survival.power.gen, use: survival.power.use, battery: S.P.life.battery, cabinC: S.P.life.cabinC, shipO2: S.P.life.shipO2, goDark: survival.power.goDark }),
  getMission: mission,
  getHowto: () => ({ flags: S.P.flags, tetherKey: input.tetherKey(), pad: input.lastInputDevice() === 'pad' }),
  buyUpgrade: repair.buyUpgrade, refineFuel: repair.refineFuel, sendSignal: repair.sendSignal,
  doJump: repair.doJump, doResolve: repair.doResolve,
  doCollapse: () => entities.doCollapse(repair.resolveReady),
  toggleDark: () => survival.setGoDark(!survival.power.goDark),
  canSave,
  saveSlot: n => { const ok = saveState.saveSlot(n); if (ok) S.beaconSlot = n; return ok; },
  loadSlot: (slot, data) => { saveState.applySnapshot(data); flow.resumeLoaded(); S.beaconSlot = slot === 'auto' ? 0 : slot; },
  onOpen: () => { S.paused = true; S.P.stats.pauseCount++; menuOpenedAt = performance.now(); audio.duck(true); input.releaseLock(); input.clearHeld(); },
  onResume: () => { S.paused = false; audio.duck(false); input.markResumed(); if (S.awake && input.lastInputDevice() === 'kbm') input.requestLock(); },
  onQuit: () => location.reload(),
  // P3: the chart
  saveBlockReason: () => S.P.flight ? 'The drive is under way: nothing saves until the ship arrives. If you die out there, you wake at the helm, before the burn.' : 'You cannot save while something is hunting you.',
  getChart: () => chart.chartData(), chartView: chart.view, drawChart: (cv, d) => chart.drawChart(cv, d), lightLines: r => chart.lightLines(r),
  plotCourse: hip => {
    const P = S.P;
    if (P.mode !== 'sandbox' || P.flight || hip === 0 || P.repair.thrusters < 50 || P.res.fuel < 1) return false;
    // v0.5: a course leaves orbit; from the ground, take off first
    if (landing.onPlanet()) return false;
    if (landing.phase() === 'orbit') landing.leaveOrbit();
    if (!flight.plan({ hip })) return false;
    flight.enterHelm(); saveState.doAutosave(true);
    say(`COURSE PLOTTED: ${cat.starName(hip)}. HOLD SPACE TO ALIGN, W TO BURN.`, { delay: 400, hold: 14000 });
    return true;
  },
});
setPauseMenu(pauseMenu);
on('openShipMenu', () => pauseMenu.open('ship'));
on('openChart', () => pauseMenu.open('chart'));

// W0: the membrane at the edge gives. The first crossing opens it for good and says so.
on('edgePass', () => {
  const P = S.P;
  flight.flashLattice(); audio.dip(1100);
  if (!P.flags.edgeOpen) {
    P.flags.edgeOpen = true; threats.learn('crossing');
    say('THE EDGE GIVES. YOU ARE THROUGH.', { delay: 300, hold: 20000 });
    say('RANGE: NO DATA. THE SUIT DOES NOT KNOW WHERE THE SHIP IS.', { delay: 2600, hold: 22000 });
    say('ESC: HOW TO PLAY, PAGE 3.', { delay: 5600, hold: 12000 });
  }
});

function applySettings(patch) {
  Object.assign(S.settings, patch);
  if ('volume' in patch) audio.setVolume(S.settings.volume);
  if ('ambience' in patch) audio.setAmbience(S.settings.ambience);
  if ('quality' in patch) { const pr = applyQuality(S.settings.quality); if (S.sys.starMat) S.sys.starMat.uniforms.uPR.value = pr; if (boundary.printed) boundary.printed.material.uniforms.uPR.value = pr; flight.setSkyPixelRatio(pr); setGraphics(S.settings.quality); }
  saveState.persistSettings();
}

// ---------------- the mission page: who, what, why, and the rules learned ----------------
function mission() {
  const P = S.P, F = P.flags;
  const obj = story.objective();
  const threatsList = [
    { key: 'listener_aware', name: 'THE LISTENER', rule: 'It hears what you emit: thrusters, running, cutting, scanning, the signal home, and the ship\'s own power draw. The EM bar on the right is what it hears. When it comes, go quiet: cut power (X), stop moving, stop cutting, and wait. Baffles make the ship quieter.', hint: 'Something far away is paying attention to noise. It has not noticed you yet.' },
    { key: 'unlit', name: 'THE UNLIT', rule: 'It lives where there is no light. Outside your lamp the dark fills up. Keep your helmet lamp on (L), stay near floodlights, never let the ship go dark for long.', hint: 'The dark outside the lamp. You have not been out in it long enough.' },
    { key: 'nearer_seen', key2: 'nearer', name: 'THE NEARER', rule: 'It only moves while nothing is looking at it. Turn and face it and it stops. Watch masts count as looking, for the ship and for the space around it.', hint: 'Something closes distance on the bearings you are not watching.' },
    { key: 'pulse', name: 'THE NULL BEARING', rule: 'Once measured, it surges. When the warning sounds you have 20 seconds: get inside. Shield plates cut what reaches the cabin.', hint: 'A bearing where the instruments read something and the catalogue says nothing.' },
    { key: 'hull', name: 'HULL CONTACT', rule: 'While you are inside, something can hold on to the outside of the hull where no mast is watching. It takes what it touches. Masts make it let go.', hint: '...' },
    { key: 'figure', name: 'CREW 2', rule: 'When your mind is tired, someone stands at the edge of your vision. They are gone when you look. Sleep and light bring your mind back.', hint: '...' },
  ].map(t => ({ name: t.name, rule: t.rule, hint: t.hint, learned: !!(F['learn_' + t.key] || (t.key2 && F['learn_' + t.key2]) || (t.key === 'figure' && F.figureSeen)) }));
  return {
    firstShift: P.mode === 'sandbox' && !P.place ? story.firstShift() : null,
    who: 'You are one of the two crew of KESTREL-4, a small survey probe sent to map the nearest stars. You slept through the trip. You are the only one awake. The other bunk is empty.',
    what: whatHappened(),
    now: obj.text || 'Survive.',
    point: 'Stay alive, get the ship working, and find out what moved you and where "here" is. The ship keeps records. The sky can be measured. Measure it, and do not believe a reading just because it came back the same twice. When you know enough, decide: go home, or go further.',
    threats: threatsList,
    discoveries: landing.discoveryList(),
    survival: 'HEALTH falls when air, warmth, radiation, hunger or thirst become dangerous. HUNGER and THIRST drain slowly during active play. At the GALLEY on the right wall of the console room, use F (X on pad) to eat, drink, print meals (1 ore + 1 salvage + 5 battery), melt ice (1 ice + 3 battery makes 2 water) or COOK (a hot meal, salad, tea or stew fills you more and leaves you WELL FED). Printing needs main power. MORE FOOD AND WATER: sealed ration crates on some salvage plates, the galley of the wreck, the water reclaimer in your galley once fixed, and condensate from recyclers (How to Play: FOOD AND WATER). Sleep costs 12 hunger and 18 thirst. OXYGEN: the suit holds about five minutes. COLD: below 0 C the cabin takes your body heat; main power runs the heater. RADIATION: from the null bearing, once it is measured; hide inside. MIND: the dark, the distance and the things out here wear it down; light, warmth and sleep bring it back. The bunk saves the game. FLYING: half of the fuel you burn going out you need to stop; the drive scrams past 100% heat; the ship carries about twelve years of supplies, so slow is not safe.' + (P.stats.flights ? ` SINCE YOU LEFT, EARTH HAS AGED ${(P.stats.earthYears || 0).toFixed(1)} YEARS. YOU HAVE AGED ${(P.stats.shipYears || 0).toFixed(1)}.` : ''),
  };
}

function whatHappened() {
  const P = S.P;
  if (P.mode === 'campaign' && P.system === 2 && P.storyStep >= 12) {
    const leg = (P.legs || [])[P.legs.length - 1];
    const a2 = P.act2 || {};
    let t = a2.home ? 'You set a course for the Sun and held it. You arrived at Sirius, 8 light years from home.' : `You flew KESTREL-4 ${leg ? leg.dist.toFixed(2) : '8.85'} light years to Sirius, on a course that was on file before you woke.`;
    t += ` On Earth, ${(P.stats.earthYears || 0).toFixed(1)} years have passed. On the ship, ${(P.stats.shipYears || 0).toFixed(1)}.`;
    if (P.storyStep >= 14) t += ' The manifest says two people are aboard. You are the only one you can find.';
    return t;
  }
  if (P.mode === 'campaign' && P.flight) return 'You are flying the whole ship between the stars, by hand. Every star out the window is real and is being re-seen from where the ship is. The clocks on the ship and on Earth are coming apart.';
  if (P.mode === 'sandbox' && P.place) return `You are parked 0.08 light years from ${P.place.name || 'HIP ' + P.place.hip}, a real star, ${Math.hypot(P.place.x, P.place.y, P.place.z).toFixed(2)} light years from the Sun. Every star in the sky is where it really is, seen from here.`;
  return S.fixed || P.storyStep > 2 ? 'The star fix says you are 4.00 light years from the Sun, on the line toward Alpha Centauri. This probe cannot fly that far, not in 11 days, not in 11 years. Something moved you while you slept. Every star you see out the window is real, at its real distance. The ship, the crew and whatever is out here are not.' : 'You do not know where you are yet. Sight three stars through the console window to find out.';
}

// ---------------- title screen ----------------
function startGame(mode) { if (S.awake) return; flow.wake(mode); input.markResumed(); input.requestLock(); }
$('titleNew').addEventListener('click', () => startGame('campaign'));
$('titleSandbox').addEventListener('click', () => startGame('sandbox'));
$('titleSettings').addEventListener('click', () => pauseMenu.open('settings'));
$('titleHowto').addEventListener('click', () => pauseMenu.open('howto'));
$('titleLoad').addEventListener('click', () => pauseMenu.open('save'));
(function setupContinue() {
  const cont = $('titleContinue'), note = $('titleNote');
  if (!storageAvailable()) { note.textContent = 'This browser is blocking saves. Progress lasts this session only.'; return; }
  const r = readSlot('auto');
  if (r.status === 'ok') {
    cont.style.display = 'inline-block';
    cont.textContent = `CONTINUE  (${r.env.summary || 'SYSTEM ' + r.data.system})`;
    cont.addEventListener('click', () => { const again = readSlot('auto'); if (again.status !== 'ok') { note.textContent = 'The autosave could not be read. Start a new game or load a slot.'; return; } saveState.applySnapshot(again.data); flow.resumeLoaded(); input.markResumed(); input.requestLock(); });
  } else if (r.status === 'damaged') {
    cont.style.display = 'inline-block'; cont.disabled = true;
    cont.textContent = 'AUTOSAVE DAMAGED';
    note.textContent = `The autosave is damaged (${r.reason}). It has been left alone and will be kept aside. Start a new game, or LOAD a saved slot.`;
  }
})();
setTimeout(() => { const b = $('titleNew'); if (b && !S.awake) b.focus(); }, 100);

// ---------------- input ----------------
input.initInput(renderer.domElement, {
  isMenuOpen: () => pauseMenu.isOpen(),
  onKeyWhileAsleep: e => { if (pauseMenu.isOpen()) return; if (e.key === 'Enter' && document.activeElement === document.body) startGame('campaign'); },
});
input.initTouch($('touchLayer'), $('tJoyBase'), $('tJoyKnob'), $('tButtons'), () => handlePause());
input.onLockLost(() => { if (S.awake && !S.paused && !S.dying && !S.ended) pauseMenu.open('mission'); });

const titlePadPrev = {};
function titlePad() {
  if (pauseMenu.isOpen()) return;
  const btns = [...document.querySelectorAll('#titleMenu button')].filter(b => b.style.display !== 'none' && !b.disabled);
  if (!btns.includes(document.activeElement)) { btns[0] && btns[0].focus(); return; }
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const p of pads) {
    if (!p) continue;
    const pr = i => !!(p.buttons[i] && p.buttons[i].pressed);
    const edge = i => { const k = p.index + ':' + i, n = pr(i), w = titlePadPrev[k]; titlePadPrev[k] = n; return n && !w; };
    const i = btns.indexOf(document.activeElement);
    if (edge(15) || edge(13)) btns[(i + 1) % btns.length].focus();
    if (edge(14) || edge(12)) btns[(i - 1 + btns.length) % btns.length].focus();
    if (edge(0)) document.activeElement.click();
  }
}

function handlePause() {
  if (S.ended) { location.reload(); return; }
  if (S.dying || !S.awake) { if (!S.awake && pauseMenu.isOpen()) pauseMenu.close(); return; }
  if (pauseMenu.isOpen() && performance.now() - menuOpenedAt < 350) return; // Esc that also released the mouse
  pauseMenu.toggle();
}

let bPressT = 0, scanCd = 0;
const scanMarks = [];
function handleAction(a) {
  const name = typeof a === 'string' ? a : a.a;
  switch (name) {
    case 'primary':
      if (S.buildMode) { if (S.buildSurface) base.place(); else build.place(); }
      else sensors.trySight(movement.canSight());
      return false;
    case 'interact': return true;
    case 'cut': interaction.toggleTether(); break;
    case 'console': pauseMenu.open('ship'); break;
    case 'journal': pauseMenu.open('journal'); break;
    case 'name': landing.nameKey(); break;
    case 'mission': pauseMenu.open('mission'); break;
    case 'chart': pauseMenu.open('chart'); break;
    case 'lamp':
      if (S.mode !== 'eva') { flash('THE LAMP IS ON THE SUIT. IT WORKS OUTSIDE.', 1800); break; }
      if (S.eva.power <= 0) { flash('SUIT POWER EMPTY.', 1800); break; }
      S.eva.lamp = !S.eva.lamp; audio.click(S.eva.lamp ? 1600 : 900); break;
    case 'build': if (landing.gKey()) break; if (S.buildSurface || (landing.onSurface() && S.mode === 'eva')) base.toggle(); else build.toggleBuild(); break;
    case 'remove': if (landing.gKey()) break; if (S.chairOffer && S.mode === 'interior' && !S.helm && landing.enterHelm()) break; if (S.buildSurface) { base.removeAimed(); break; } if (base.gKey()) break; build.removeAimed(); break;
    case 'dampers':
      if (S.mode !== 'eva') break;
      S.eva.dampers = !S.eva.dampers; audio.click(1200);
      flash(S.eva.dampers ? 'DAMPERS ON: YOU STOP WHEN YOU LET GO.' : 'DAMPERS OFF: YOU COAST. SAVES PROPELLANT ON LONG TRIPS.', 2600); break;
    case 'godark': survival.setGoDark(!survival.power.goDark); break;
    case 'view':
      applySettings({ view: S.settings.view === 'shoulder' ? 'helmet' : 'shoulder' }); audio.click(1400);
      flash(S.settings.view === 'shoulder' ? (thirdAllowed() ? 'VIEW: OVER THE SHOULDER. O FOR THE HELMET.' : 'VIEW: OVER THE SHOULDER, WHEN IT IS SAFE. O FOR THE HELMET.') : 'VIEW: HELMET.', 2200); break;
    case 'ping': doScan(); break;
    case 'num':
      if (landing.numKey(a.data)) break;
      if (galley.cookKey(a.data)) break;
      if (S.helm && S.P.flight && !S.P.flight.started && a.data <= 3) { flight.selectRoute(a.data - 1); break; }
      if (S.buildMode) build.selectPart(a.data - 1);
      else if (a.data <= 4) movement.setZoom(a.data - 1);
      else if (a.data === 5 && S.P.upgrades.zoom5) movement.setZoom(4);
      break;
    case 'wheelUp': if (galley.moveSel(-1)) break; if (S.buildMode) build.selectPart(S.buildPart - 1); else movement.setZoom(S.zoom + 1); break;
    case 'wheelDown': if (galley.moveSel(1)) break; if (S.buildMode) build.selectPart(S.buildPart + 1); else movement.setZoom(S.zoom - 1); break;
    case 'padLeft': if (galley.moveSel(-1)) break; if (S.helm && S.P.flight && !S.P.flight.started) { flight.selectRoute(S.P.flight.route === 'home' ? 0 : 1); break; } if (S.buildMode) build.selectPart(S.buildPart - 1); else movement.setZoom(S.zoom - 1); break;
    case 'padRight': if (galley.moveSel(1)) break; if (S.helm && S.P.flight && !S.P.flight.started) { flight.selectRoute(S.P.flight.route === 'home' ? 0 : 1); break; } if (S.buildMode) build.selectPart(S.buildPart + 1); else movement.setZoom(S.zoom + 1); break;
    case 'back':
      if (S.buildMode) { if (S.buildSurface) base.toggle(); else build.toggleBuild(); break; }
      // (W0: B twice also clips you back on at the hatch)
      if (S.mode === 'eva' && (S.eva.tethered || S.pos.distanceTo(HATCH_EXT) <= interaction.CLIP_R)) {
        if (performance.now() - bPressT < 1500) interaction.toggleTether();
        else { bPressT = performance.now(); flash(S.eva.tethered ? 'PRESS B AGAIN TO CUT THE TETHER' : 'PRESS B AGAIN TO CLIP ON', 1500); }
      }
      break;
  }
  return false;
}

// scan: marks nearby resources for a few seconds. Loud.
function doScan() {
  if (scanCd > 0) { flash('SCANNER RECHARGING', 1000); return; }
  scanCd = 5; S.noise += 6; audio.scanPing();
  const now = performance.now();
  scanMarks.length = 0;
  // surface build: on the ground the scan names the big deposits around you and what is left in them
  if (landing.onSurface()) {
    const marks = mining.scanMarks();
    for (const m of marks) scanMarks.push({ pos: m.pos, type: 'dep ' + m.kind, label: m.label, until: now + 12000 });
    flash(marks.length ? `SCAN: ${marks.length} DEPOSITS WITHIN 200 M. NEAREST: ${marks[0].label.replace(/ \d+$/, '')}, ${marks[0].d} M.` : 'SCAN: NO DEPOSITS WITHIN 200 M. WALK ON AND SCAN AGAIN.', 3200);
    emit('scan'); return;
  }
  const near = field.chunks.filter(c => c.hp > 0).map(c => ({ c, d: c.pos.distanceTo(S.pos) })).filter(x => x.d < 90).sort((a, b) => a.d - b.d).slice(0, 18);
  for (const { c } of near) scanMarks.push({ pos: c.pos, type: c.type, until: now + 9000 });
  if (derelict.group && S.P.storyStep >= 7) scanMarks.push({ pos: derelict.group.position, type: 'ship', until: now + 9000 });
  if (S.P.repair.comms >= 100 && S.sys.nullDir) scanMarks.push({ worldDir: S.sys.nullDir.clone(), type: 'null', until: now + 9000 });
  flash(`SCAN: ${near.length} OBJECTS WITHIN 90 M${S.P.repair.comms >= 100 ? '. THE NULL BEARING IS MARKED.' : ''}`, 2600);
  emit('scan');
}
const markPool = [];
function updateScanMarks() {
  const now = performance.now();
  const v = new THREE.Vector3(), cw = camera.getWorldPosition(new THREE.Vector3()), fwd = new THREE.Vector3(); camera.getWorldDirection(fwd);
  let used = 0;
  for (const m of scanMarks) {
    if (now > m.until) continue;
    if (m.worldDir) v.copy(m.worldDir).multiplyScalar(4000).add(cw);
    else { v.copy(m.pos); ship.localToWorld(v); }
    if (v.clone().sub(cw).dot(fwd) <= 0) continue;
    v.project(camera);
    if (Math.abs(v.x) > 1 || Math.abs(v.y) > 1) continue;
    let el = markPool[used];
    if (!el) { el = document.createElement('div'); document.body.appendChild(el); markPool.push(el); }
    el.className = 'scanMark ' + m.type;
    // W0: the KESTREL-4 mark says when it is past the end of the line
    const lab = m.label ? m.label : m.type === 'ship' ? 'KESTREL-4' + (story.pastLine(m.pos) ? `  PAST YOUR LINE: ${input.tetherKey()}` : '') : '';
    if (el._lab !== lab) { el.innerHTML = lab ? `<span>${lab}</span>` : ''; el._lab = lab; }
    el.style.display = 'block';
    el.style.transform = `translate(${((v.x + 1) / 2 * innerWidth).toFixed(0)}px, ${((1 - v.y) / 2 * innerHeight).toFixed(0)}px)`;
    el.style.opacity = Math.min(1, (m.until - now) / 1500);
    used++;
  }
  for (let i = used; i < markPool.length; i++) markPool[i].style.display = 'none';
}

// ---------------- deaths reload the autosave ----------------
survival.setDeathHook(cause => {
  const r = readSlot('auto');
  const deaths = S.P.stats.deaths + 1;
  if (r.status === 'ok') { saveState.applySnapshot(r.data); flow.resumeLoaded(); }
  else { S.awake = false; flow.wake(S.P.mode); }
  S.P.stats.deaths = Math.max(S.P.stats.deaths, deaths);
  // an autosave taken while starving must not reload into the same death, over and over
  { const L = S.P.life; L.health = Math.max(L.health, 60); L.hunger = Math.max(L.hunger, 35); L.thirst = Math.max(L.thirst, 35); }
  S.P.flags['died_' + cause] = true;
  saveState.doAutosave(true);
});

// ---------------- P3: arriving from a flight, and flights that never arrive ----------------
flight.setArriveHook(info => flow.arriveAt(info.dest && info.dest.kind === 'system' ? info.dest.n : S.P.system, Object.assign(info, { name: info.dest && info.dest.kind === 'star' ? cat.starName(info.dest.hip) : '' })));
on('adrift', () => survival.die('drift'));
on('landCrash', () => survival.die('crash'));
on('outOfYears', () => survival.die('years'));
on('derelictKilled', () => survival.die('nearer'));

// ---------------- one-off discoveries checked every frame ----------------
let edgeWarned = false, latticeLogged = false, derelictSeenMsg = false, autoT = 0;
function discoveries(dt) {
  const P = S.P;
  if (S.mode === 'eva' && !landing.onPlanet()) {
    const r = S.pos.distanceTo(SHIP_CENTER);
    if (r > BOUNDARY_WARN && !edgeWarned) { edgeWarned = true; say(`RANGE ${Math.round(r)} M. THE STARS AHEAD ARE STARTING TO DOUBLE.`, { hold: 12000 }); }
    if (S.touchedBoundary && !P.flags.edge) {
      P.flags.edge = true;
      audio.dip(1500);
      say('RANGE: NO FURTHER DATA.', { delay: 400, hold: 20000 });
      say('YOUR GLOVE IS TOUCHING SOMETHING THE INSTRUMENTS SAY IS NOT THERE.', { delay: 3000, hold: 22000 });
      say('THE STARS ON IT ARE THE SAME STARS. UP CLOSE THEY DO NOT LINE UP.', { delay: 6400, hold: 24000 });
      unlockFragment(1, 'edge');
      P.life.sanity = Math.max(5, P.life.sanity - 20);
    }
    // W0: looking back from outside, once
    if (!P.flags.lookedBack && movement.dOut() > 100) {
      tmp.copy(SHIP_CENTER).sub(S.pos).normalize();
      if (sharedBasis(S.q).f.angleTo(tmp) < 0.45) { P.flags.lookedBack = true; say('LOOKING BACK: THE SHIP IS INSIDE A BALL OF PRINTED STARS. FROM OUT HERE THEY ARE BACKWARD.', { hold: 22000 }); }
    }
    if (P.mode === 'sandbox' && !P.flags.fs_visit && derelict.group && S.pos.distanceTo(derelict.group.position) < 40) P.flags.fs_visit = true;
    if (derelict.group && !derelictSeenMsg && S.pos.distanceTo(derelict.group.position) < 40 && P.storyStep >= 6) {
      derelictSeenMsg = true;
      say('THE HULL NUMBER, THE STENCIL, THE SCORCH MARK BY THE HATCH. IT IS YOUR SHIP.', { hold: 16000 });
    }
  }
  if (!latticeLogged && P.life.sanity < 25) { latticeLogged = true; unlockFragment(1, 'lattice'); }
  if (S.threat.pulse.state === 'pulse' && !P.flags.pulseLogged) { P.flags.pulseLogged = true; unlockFragment(1, 'pulse'); }
  if (P.flags.learn_unlit && !P.flags.unlitLogged) { P.flags.unlitLogged = true; unlockFragment(1, 'unlit'); }
  if (P.stats.listenerPassings > 0 && !P.flags.listenerLogged) { P.flags.listenerLogged = true; unlockFragment(1, 'listener'); }
  // quiet periodic autosave while safe inside
  autoT += dt;
  if (autoT > 90 && S.mode === 'interior' && canSave()) { autoT = 0; saveState.doAutosave(); }
}

// ---------------- frame timing (for the perf check) ----------------
const ft = new Float32Array(900); let ftI = 0, ftN = 0, lastNow = performance.now();
const wk = new Float32Array(900); let wkI = 0, wkN = 0;
const PERF = new URLSearchParams(location.search).has('perf');
const glCtx = renderer.getContext();

// ---------------- the loop ----------------
const clock = new THREE.Clock();
const camW = new THREE.Vector3(), tmp = new THREE.Vector3();
function frame() {
  const now = performance.now();
  ft[ftI] = now - lastNow; ftI = (ftI + 1) % ft.length; ftN = Math.min(ft.length, ftN + 1); lastNow = now;
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = now / 1000;
  input.pollGamepads(() => pauseMenu.isOpen(), titlePad);
  if (!S.awake) titlePad();
  const acts = input.takeActions();
  if (!S.awake || S.paused) audio.setDrive(0, 0);
  let fEdge = false;
  for (const a of acts) if (a === 'pause') handlePause();
  const playing = S.awake && !S.paused && !S.dying && !S.ended;
  const mouse = input.takeMouse();
  const ax = input.axes();
  scanCd = Math.max(0, scanCd - dt);
  if (playing) {
    for (const a of acts) if (a !== 'pause' && handleAction(a)) fEdge = true;
    // P3: seated at the helm, the mouse and sticks turn the whole ship
    const seated = S.helm;
    const landHelm = landing.helmActive();
    if (S.P.flight || (seated && !landHelm)) flight.update(dt, mouse, ax, fEdge && seated);
    landing.update(dt, mouse, ax, fEdge && seated);
    // P3: inside the derelict, on mag boots (its own walking, look and F)
    const inWreck = S.mode === 'derelict';
    wreck.update(dt, mouse, ax, fEdge && inWreck, ax.interactHeld);
    if (!S.sleeping && (!seated || (landHelm && landing.phase() !== 'descent')) && !inWreck) movement.updateLook(dt, mouse, ax);
    if (!inWreck) movement.updatePlayer(dt, ax);
    if (!inWreck) interaction.updateInteract(dt, ax.interactHeld, fEdge && !seated);
    mining.update(dt);
    base.update(dt);
    build.updateBuild();
    survival.update(dt);
    galley.update(dt);
    threats.update(dt);
    story.nudges();
    discoveries(dt);
    audioHooks.updateHullTick(dt);
    audio.setThrust(S.mode === 'eva' ? (S.thrusting || 0) : 0);
    const fear = Math.max(S.threat.dark / 100, S.threat.listenerState === 'passing' ? 1 : S.threat.listenerState === 'coming' ? 0.6 : 0, S.threat.approach ? clamp((60 - S.threat.approach.dist) / 60, 0, 1) : 0);
    audio.updateBreath(dt, S.mode === 'eva', 0.22 + fear * 0.35 + (S.exerting ? 0.15 : 0), 0.6 + fear * 0.8);
    if (S.lastImpact) { S.lastImpactT = now; S.lastImpact = 0; }
  } else {
    audio.setThrust(0); audio.updateBreath(dt, false);
  }
  interaction.updateTetherLine();
  interaction.updateSparks(dt);

  // camera
  camera.quaternion.copy(S.q);
  camera.position.copy(S.pos);
  S.ZOOMS[0] = S.settings.fov; S.ZOOMS[1] = S.settings.fov / 2;
  // (2026-09-28: not at the helm, where LT is the brake; it used to zoom the view to 12 degrees while you braked)
  const zi = (ax.zoomHeld || (S.mode === 'interior' && !S.helm && input.held('gp_down'))) && !S.buildMode ? Math.max(S.zoom, 2) : S.zoom;
  const targetFov = S.ZOOMS[Math.min(zi, S.ZOOMS.length - 1)];
  S.fov += (targetFov - S.fov) * Math.min(1, dt * 6);
  if (Math.abs(camera.fov - S.fov) > 0.01) { camera.fov = S.fov; camera.updateProjectionMatrix(); }
  camera.getWorldDirection(S.fwd);
  camera.getWorldPosition(camW);

  // the sky is at infinity: it travels with the eye
  if (S.sys.group) S.sys.group.position.copy(camW);
  flight.placeSkyAt(camW);
  skyAnchor.position.copy(camW);
  if (S.sys.starMat) {
    S.sys.starMat.uniforms.uFade.value = Math.min(1, S.sys.starMat.uniforms.uFade.value + dt / 6);
    S.sys.starMat.uniforms.uGain.value = Math.log2(S.ZOOMS[0] / S.fov) * 0.9;
  }
  // the edge: a printed copy of the sky separates from the real one, and a lattice shows
  const rC = S.mode === 'eva' && !landing.onPlanet() ? S.pos.distanceTo(SHIP_CENTER) : 0;
  const edgeK = clamp((rC - BOUNDARY_WARN) / (BOUNDARY_R - BOUNDARY_WARN), 0, 1);
  // W0: outside, the printed sky becomes a scene: 0.9 at the membrane, easing to 0.35 by 400 m out; the lattice holds at 0.25
  const outR = Math.max(0, rC - BOUNDARY_R);
  if (boundary.printed) {
    boundary.printed.position.copy(SHIP_CENTER); ship.localToWorld(boundary.printed.position);
    const fade = outR > 0 ? 0.9 - 0.55 * Math.min(1, outR / 400) : edgeK * 0.9;
    boundary.printed.material.uniforms.uFade.value = fade;
    boundary.printed.material.uniforms.uGain.value = S.sys.starMat ? S.sys.starMat.uniforms.uGain.value : 0;
    boundary.printed.visible = fade > 0.001;
  }
  if (boundary.lattice) {
    const lowMind = S.P.life.sanity < 25 ? (25 - S.P.life.sanity) / 25 * 0.12 : 0;
    boundary.lattice.material.opacity = Math.max(outR > 0 ? 0.25 : Math.pow(edgeK, 2) * 0.5, lowMind, flight.latticeFlash(dt));
    boundary.lattice.visible = boundary.lattice.material.opacity > 0.002;
  }

  // sky entities
  if (S.awake && !S.P.flight) {
    entities.updateGiant(dt);
    entities.updateDriftPositions();
    entities.updateDuplicateWobble();
    entities.updateBeacon();
    if (playing) audioHooks.updateGazeAndHeartbeat();
    entities.updateCollapse();
  } else if (S.awake) { audio.setGazeProximity(0); audio.setHeartbeatProximity(0); S.gazeProx = 0; }

  // lights
  const figL = threats.figureLights();
  const lvl = !S.awake ? 'emergency' : figL.dark ? 'dark' : survival.power.level;
  const flicker = S.threat.listenerState === 'passing' ? 1 : S.threat.listenerState === 'coming' ? 0.4 : S.P.life.sanity < 40 ? 0.25 : 0;
  updateShipLights(lvl, t, Math.max(flicker, figL.flicker), S.mode === 'interior');
  build.updateModuleVisuals(t, survival.power.shed, lvl);
  const floods = build.floodlightsNear(S.pos, lightPool.length);
  lightPool.forEach((l, i) => {
    const b = floods[i];
    if (b && lvl === 'powered' && !shipFx.swapped && !survival.power.shed.has(b.id)) { l.position.copy(b.lampPos).addScaledVector(b.normal, 0.6); l.intensity = 40 * (Math.random() < flicker * 0.05 ? 0.1 : 1); }
    else l.intensity = 0;
  });
  base.applyLights(lightPool);
  helmetLamp.intensity = ((S.mode === 'eva' || S.mode === 'derelict') && S.eva.lamp && S.eva.power > 0) ? 26 : 0;
  for (const k in shipFx.fixtureMarkers) shipFx.fixtureMarkers[k].visible = !shipFx.swapped && S.P.repair[k] < 100 && (Math.sin(t * 3) > -0.3);
  updateFixtures(S.P.repair, t, lvl, S.P.flight && !survival.power.goDark ? S.P.flight.throttle : 0); // 2026-09-28: repaired parts look repaired
  if (shipFx.extHatchLamp) shipFx.extHatchLamp.material.color.setHex(lvl === 'powered' ? 0x40ff80 : lvl === 'emergency' ? 0xff4020 : 0x100404);

  updateFieldMatrices(dt);
  updateDerelict(dt);
  if (S.awake) updateScanMarks();

  // star lock marks
  for (const l of S.locks) {
    const d = sensors.currentDirOf(l.i);
    tmp.copy(d).multiplyScalar(4000).add(camW).project(camera);
    const vis = tmp.z < 1 && Math.abs(tmp.x) < 1.1 && Math.abs(tmp.y) < 1.1 && d.dot(S.fwd) > 0;
    l.el.style.display = vis ? 'block' : 'none';
    if (vis) { l.el.style.left = ((tmp.x + 1) / 2 * innerWidth) + 'px'; l.el.style.top = ((1 - tmp.y) / 2 * innerHeight) + 'px'; }
  }
  const rr = Math.max(12, Math.tan(sensors.lockRadius()) / Math.tan(THREE.MathUtils.degToRad(S.fov / 2)) * innerHeight / 2);
  const ret = $('reticle'); ret.style.width = ret.style.height = (rr * 2) + 'px'; ret.style.margin = `${-rr}px 0 0 ${-rr}px`;
  $('vignette').style.opacity = (zi >= 2 ? 0.8 : zi === 1 ? 0.35 : 0);
  $('clickToPlay').style.display = (playing && input.needsClick() && input.lockSupported() && !isHeadless) ? 'flex' : 'none';

  if (S.P.system === 3 && S.sys3EnterTime && !S.ended && !S.dying && performance.now() - S.sys3EnterTime > 12 * 60 * 1000 && S.P.journalOrder.length < JOURNAL.length) repair.triggerEnding('STAY');

  updateHud(dt, {
    objective: S.awake ? story.objective() : null, power: survival.power, device: input.lastInputDevice(),
    listenerActive: threats.listenerActive(), parts: S.buildSurface ? base.BASE_ORDER : build.PART_ORDER, PARTS: S.buildSurface ? base.BASE_PARTS : build.PARTS, buildReason: S.buildSurface ? base.state.reason : build.buildState.reason,
    flightLines: flight.consoleLines(),
  });
  flight.updateHelmHud(dt);
  updateGraphics(dt, { camW, fear: playing ? Math.max(S.threat.dark / 100, S.threat.listenerState === 'passing' ? 1 : S.threat.listenerState === 'coming' ? 0.6 : 0, S.threat.approach ? clamp((60 - S.threat.approach.dist) / 60, 0, 1) : 0) : 0 });
  landing.lateUpdate(dt, camW);
  updateArt(dt, camW);
  const shoulder = beginRender(dt);
  renderFrame(scene, camera);
  if (shoulder) endRender();
  if (PERF) { glCtx.finish(); wk[wkI] = performance.now() - now; wkI = (wkI + 1) % wk.length; wkN = Math.min(wk.length, wkN + 1); }
  requestAnimationFrame(frame);
}
const isHeadless = /HeadlessChrome/.test(navigator.userAgent);
requestAnimationFrame(frame);

// ---------------- test hooks (harmless in play) ----------------
function lookAtShipPoint(p) {
  const d = p.clone().sub(S.pos).normalize();
  S.yaw = Math.atan2(-d.x, -d.z); S.pitch = Math.asin(clamp(d.y, -1, 1)); S.roll = 0;
  qFromYawPitch(S.yaw, S.pitch, 0, S.q);
}
function lookWorldDir(w) {
  const d = w.clone().applyQuaternion(ship.quaternion.clone().invert()).normalize();
  S.yaw = Math.atan2(-d.x, -d.z); S.pitch = Math.asin(clamp(d.y, -1, 1)); qFromYawPitch(S.yaw, S.pitch, 0, S.q);
}
window.NP = {
  art: () => ({ ready: art.ready, failed: art.failed, loaded: [...art.loaded], view: art.view, camDist: art.camDist, tris: { ...art.tris }, avatarVisible: !!(art.avatar && art.avatar.visible), bodyVisible: !!(art.body && art.body.visible), armsVisible: !!(art.arms && art.arms.visible), clip: art.current, clips: Object.keys(art.actions), figVisible: !!(art.fig && art.fig.visible), figUp: art.fig ? [art.fig.rotation.x, art.fig.rotation.z] : null, nearerPose: art.pose, nullVisible: !!(art.nullp && art.nullp.visible), kit: art.kit ? art.kit.children.length : 0, dish: !!(art.dish && art.dish.parent), nearer: !!(art.nearer && art.nearer.parent), lastCam: art.lastCam }),
  artCamFree: (x, y, z) => camFree(new THREE.Vector3(x, y, z)),
  artThirdAllowed: () => thirdAllowed(),
  state: S, threat: () => ({ ...S.threat, pulse: { ...S.threat.pulse } }), power: () => ({ ...survival.power, shed: [...survival.power.shed] }),
  startStory: () => startGame('campaign'), startSandbox: () => startGame('sandbox'),
  objective: () => story.objective(), setStep: n => story.setStep(n),
  tp(x, y, z) { S.pos.set(x, y, z); S.vel.set(0, 0, 0); },
  look(yawDeg, pitchDeg) { S.yaw = THREE.MathUtils.degToRad(yawDeg); S.pitch = THREE.MathUtils.degToRad(pitchDeg); qFromYawPitch(S.yaw, S.pitch, 0, S.q); },
  lookAt(x, y, z) { lookAtShipPoint(new THREE.Vector3(x, y, z)); },
  aimAtNull() { if (S.sys.nullDir) lookWorldDir(S.sys.nullDir); },
  aimAtStar(i) { lookWorldDir(sensors.currentDirOf(i)); },
  brightStarsNearView(n = 3) {
    const out = []; const f = S.fwd;
    S.sys.meta.forEach((m, i) => { if (m.type === 'star' && m.hip !== 0 && m.mag < 3.5) out.push({ i, a: S.sys.dirs[i].angleTo(f), mag: m.mag }); });
    return out.sort((a, b) => a.a - b.a).slice(0, n);
  },
  sight: () => sensors.trySight(movement.canSight()),
  forceFix: () => sensors.computeFix(),
  goEva() { if (S.mode !== 'eva') interaction.cycleAirlock(); },
  goInside() { if (S.mode === 'eva') interaction.cycleAirlock(); },
  crates: () => field.chunks.filter(c => c.hp > 0 && galley.crateIn(c)).map(c => ({ key: c.key, pos: c.pos.toArray(), r: c.radius })),
  give(o) { for (const k in o) S.P.res[k] = (S.P.res[k] || 0) + o[k]; },
  repairFull(k) { S.P.res.salvage += 20; S.P.res.ore += 10; let g = 0; while (S.P.repair[k] < 100 && g++ < 500) repair.repair(k, 5); },
  buildAt(part, socketId) { const id = 'mT' + Math.random().toString(36).slice(2, 7); S.P.modules.push({ part, socket: socketId, id }); build.rebuildModules(); emit('built', part); return id; },
  hardpoints: () => HARDPOINTS.map(h => ({ id: h.id, pos: h.pos.toArray() })),
  chunks: type => field.chunks.filter(c => c.hp > 0 && (!type || c.type === type)).map(c => ({ key: c.key, type: c.type, pos: c.pos.toArray(), r: c.radius })),
  derelictPos: () => DERELICT_POS.toArray(),
  hatch: () => HATCH_EXT.toArray(),
  // W0: the edge, as the renderer sees it (fade of the printed sky, lattice opacity, how far out)
  edgeState: () => ({ fade: boundary.printed ? boundary.printed.material.uniforms.uFade.value : null, printedVisible: !!(boundary.printed && boundary.printed.visible), lattice: boundary.lattice ? boundary.lattice.material.opacity : null, dOut: movement.dOut(), open: !!S.P.flags.edgeOpen, openAt: S.edgeOpenAt || 0 }),
  setAttention(v) { S.threat.attention = v; threats.setListenerCooldown(0); }, setDark(v) { S.threat.dark = v; }, setSanity(v) { S.P.life.sanity = v; },
  spawnNearer(dist = 30) { S.threat.approach = { dir: sharedBasis(S.q).f.clone().negate(), dist }; },
  pulseNow() { S.P.flags.nullWoke = true; S.threat.pulse.next = S.P.stats.timePlayed + 21; S.threat.pulse.state = 'dormant'; },
  die: c => survival.die(c),
  pause: tab => pauseMenu.open(tab), closeMenu: () => pauseMenu.close(), menuOpen: () => pauseMenu.isOpen(),
  saveSlot: n => saveState.saveSlot(n), readSlot: s => readSlot(s),
  frameStats() {
    const a = Array.from(ft.slice(0, ftN)).filter(x => x > 0 && x < 1000).sort((x, y) => x - y);
    if (!a.length) return null;
    const q = p => a[Math.min(a.length - 1, Math.floor(p * a.length))];
    const w = Array.from(wk.slice(0, wkN)).sort((x, y) => x - y); const qw = p => w.length ? w[Math.min(w.length - 1, Math.floor(p * w.length))] : null;
    return { n: a.length, median: q(0.5), p95: q(0.95), p99: q(0.99), max: a[a.length - 1], workMedian: qw(0.5), workP95: qw(0.95), workMax: w.length ? w[w.length - 1] : null, calls: renderer.info.render.calls, tris: renderer.info.render.triangles, pr: renderer.getPixelRatio(), w: renderer.domElement.width, h: renderer.domElement.height };
  },
  resetFrameStats() { ftN = 0; ftI = 0; wkN = 0; wkI = 0; },
  keys: input._keys, journalTotal: JOURNAL.length, jumpCost: JUMP_FUEL_COST,
  // P3: flight
  flight: () => flight.debugState(), flightWarp: k => flight.testWarp(k), flightAuto: on => flight.testAuto(on),
  helm() { if (S.P.flight) flight.enterHelm(); else flight.plan(flight.routesFor()[0]) && flight.enterHelm(); },
  routes: () => flight.routesFor().map(r => ({ id: r.id, label: r.label, dist: r.dist })),
  selectRoute: i => flight.selectRoute(i), standUp: () => flight.standUp(),
  aimShipAt(x, y, z) { const d = new THREE.Vector3(x, y, z).normalize(); ship.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), d); },
  shipFwd: () => flight.shipFwdWorld().toArray(), here: () => flight.hereD().toArray(),
  cat: () => { const C = cat.catalogue(); return { n: C.rows.length, near: C.rows.filter(r => r.near).length, source: C.source }; },
  star: hip => { const p = cat.starPos(hip); return p ? { name: cat.starName(hip), pos: p.toArray(), fromSol: p.length(), kind: cat.starKind(hip), note: cat.starNote(hip) } : null; },
  skyStar: hip => { const i = S.sys.meta.findIndex(m => m.hip === hip && !m.dup); return i < 0 ? null : { i, mag: S.sys.meta[i].mag, distLy: S.sys.meta[i].distLy, dir: S.sys.dirs[i].toArray() }; },
  sysD: () => S.sys.currentData ? S.sys.currentData.D.slice() : null,
  act2: () => ({ ...S.P.act2 }), inAct2: () => act2.inAct2(), chartView: () => ({ ...chart.view }),
  // P3: Act II (the real arrival is flown in t_flight.py; this skips the 2-minute flight for the Act II suite)
  testArrive(route = 'filed') { S.P.flight = null; S.helm = false; return flow.arriveAt(2, { dest: { kind: 'system', n: 2 }, route, slipped: route === 'home', tau: 2.1, t: 9.3, dist: 8.85, hip: 32349, pos: cat.systemD(2) }); },
  fixtures: () => fixtureInfo(),
  aboard: () => ({ bunkMade: !!(shipFx.bunk2Made && shipFx.bunk2Made.visible), bunkBare: !!(shipFx.bunk2Bare && shipFx.bunk2Bare.visible), suit2: !!(shipFx.suit2 && shipFx.suit2.visible) }),
  siriusIdx: () => S.sys.meta.map((m, i) => ({ i, m })).filter(o => o.m.hip === 32349).map(o => ({ i: o.i, dup: !!o.m.dup, mag: o.m.mag })),
  // P3: the derelict interior
  wreck: () => wreck.debug(), wreckEnter: () => wreck.enter(), wreckTp: (x, z) => wreck.debugTp(x, z), wreckLook: (y, p) => wreck.debugLook(y, p), wreckLookAt: (x, y, z) => wreck.debugLookAt(x, y, z), wreckSpawn: () => wreck.debugSpawn(), wreckBreak: () => wreck.debugBreak(), wreckPoints: () => ({ console: wreck.POINTS.console(), rack: wreck.POINTS.rack(), photo: wreck.POINTS.photo(), locker: wreck.POINTS.locker(), tank: wreck.POINTS.tank() }),
  // playtest eyes (read-only): where things are on the screen, the way a player sees them.
  // The playtest bot steers with real mouse/keyboard input toward what these report.
  eyes(pts) {
    camera.updateMatrixWorld(true);
    const W = innerWidth, H = innerHeight, cp = camera.getWorldPosition(new THREE.Vector3());
    const inv = camera.matrixWorldInverse;
    const one = (v) => { const c = v.clone().applyMatrix4(inv); const p = v.clone().project(camera); return { x: (p.x + 1) / 2 * W, y: (1 - p.y) / 2 * H, behind: c.z > 0, yaw: Math.atan2(c.x, -c.z), pitch: Math.atan2(c.y, Math.hypot(c.x, c.z)), d: v.distanceTo(cp) }; };
    const out = { fov: camera.fov, W, H };
    if (pts) out.pts = pts.map(q => { const v = new THREE.Vector3(q[0], q[1], q[2]); if (q[3] === 'ship') ship.localToWorld(v); else if (q[3] === 'dir') v.normalize().multiplyScalar(1000).add(cp); return one(v); });
    return out;
  },
  starsOnScreen(magMax = 3.5, n = 40) {
    camera.updateMatrixWorld(true);
    const W = innerWidth, H = innerHeight, cp = camera.getWorldPosition(new THREE.Vector3()), inv = camera.matrixWorldInverse, out = [];
    for (let i = 0; i < S.sys.N; i++) {
      const m = S.sys.meta[i]; if (!m || m.type !== 'star' || S.sys.mag[i] > magMax) continue;
      const v = sensors.currentDirOf(i).clone().multiplyScalar(1000).add(cp); const c = v.clone().applyMatrix4(inv); if (c.z > 0) continue;
      const p = v.project(camera); const x = (p.x + 1) / 2 * W, y = (1 - p.y) / 2 * H;
      if (x < 0 || x > W || y < 0 || y > H) continue;
      out.push({ i, x, y, mag: S.sys.mag[i], hip: m.hip, dup: !!m.dup, yaw: Math.atan2(c.x, -c.z), pitch: Math.atan2(c.y, Math.hypot(c.x, c.z)) });
    }
    return out.sort((a, b) => a.mag - b.mag).slice(0, n);
  },
  // gfx pass: switch the GRAPHICS level from a test, and read what the renderer is holding
  gfx(level, postOff) { if (postOff !== undefined) postState.forceOff = !!postOff; applySettings({ quality: level }); return { level: gfxState.level, post: postState.active, pr: renderer.getPixelRatio() }; },
  gfxInfo: () => ({ level: gfxState.level, post: postState.active, mw: gfxState.mw, programs: renderer.info.programs ? renderer.info.programs.length : null, bakeInterior: shipFx.bakeInterior, bakeExterior: shipFx.bakeExterior, mergedInterior: shipFx.mergedInterior, mergedExterior: shipFx.mergedExterior }),
  // v0.5 slice A: planets and landing
  planets: (hip = S.P.place ? S.P.place.hip : 0) => landing.planetsAt(hip, cat.starName(hip)).map(p => ({ name: p.name, seed: p.seed, atmo: p.atmo, tempC: p.tempC, gravity: p.gravity, terrain: p.terrain, radiusKm: p.radiusKm, dayLengthH: p.dayLengthH, sky: p.sky })),
  planetHash: (seed, atmo) => landing.heightHash(landing.makePlanet(seed, atmo ? { atmo } : {})),
  testPlace(hip) { const p = cat.starPos(hip); if (!p) return false; S.P.place = { hip, x: p.x, y: p.y, z: p.z, name: cat.starName(hip) }; S.P.mode = 'sandbox'; S.P.repair.thrusters = Math.max(S.P.repair.thrusters, 60); S.P.landing = null; flow.beginWorld(); movement.spawnInterior('console'); return true; },
  landing: () => landing.debug(), landHelm: () => landing.enterHelm(), landStand: () => landing.standUp(), orbit: i => landing.enterOrbit(i), descend: () => landing.beginDescent(), landAuto: on => landing.testAuto(on), landFinal: (vy, vf, ang, alt) => landing.testFinal(vy, vf, ang, alt), takeOff: () => landing.takeOff(),
  terrainStats: () => terrainR.stats(), suitFactors: () => landing.suitFactors(),
  planetNodes: () => { const p = landing.planetXZ(S.pos); return terrainR.terrain.nodes.map(n => ({ id: n.id, type: n.type, d: Math.hypot(n.x - p.x, n.z - p.z), local: [n.x - p.x + S.pos.x, n.z - p.z + S.pos.z] })).sort((a, b) => a.d - b.d); },
  groundY: () => landing.onSurface() ? landing.groundLocalY(S.pos) : null,
  // VARIETY: the catalogue-wide census and the variety sample
  census(from, n) {
    const rows = cat.catalogue().rows, out = [];
    for (let r = from; r < Math.min(rows.length, from + n); r++) { const hip = rows[r].hip; for (const p of landing.planetsAt(hip, 'X')) out.push([hip, p.index, p.seed, landing.heightSig(p)]); }
    return { total: rows.length, out };
  },
  worlds(n, stride = 7) {
    const rows = cat.catalogue().rows, out = [];
    for (let r = 0; out.length < n && r < rows.length * stride; r += stride) {
      const hip = rows[r % rows.length].hip;
      for (const p of landing.planetsAt(hip, cat.starName(hip))) { if (out.length >= n) break; out.push({ hip, pi: p.index, name: p.name, alias: p.alias, terrain: p.terrain, atmo: p.atmo, sky: p.sky, dominant: p.dominant, weather: p.weather, rings: p.rings, moons: p.moons.length, fauna: p.fauna ? p.fauna.plan : null, moonAE: p.moons.map(m => [m.az, m.el]), flora: p.floraPlan, strata: p.strata, tempC: p.tempC, scan: landing.scanLine(p) }); }
    }
    return out;
  },
  discoveries: () => landing.discoveryList(), nameWorld: s => { const p = landing.planet(); return p ? landing.setWorldName(p, s) : null; },
  setTod: t => { if (S.P.landing) S.P.landing.tod = t; },
  // surface build: mining and the base
  mining: () => mining.debug(), depositsAt: (hip, pi, gx, gz) => depositsInCell(landing.planetsAt(hip, cat.starName(hip))[pi], gx, gz), mineHeat: v => mining.testHeat(v), surf: () => JSON.parse(JSON.stringify(S.P.surf || {})),
  base: () => base.debug(), basePlace: (part, x, z, r, force) => base.testPlace(part, x, z, r, force), baseCheck: (part, x, z, r) => base.testCheck(part, x, z, r),
  baseSelect: name => { const i = base.BASE_ORDER.indexOf(name); if (i >= 0) S.buildPart = i; return i; }, groundLights: () => terrainR.pointLightCount(),
  surfShow: (baseOn, depOn) => { const g = terrainR.terrain.group; if (!g) return false; g.traverse(o => { if (o.name === 'base') o.visible = baseOn; if (o.name === 'deposits') o.visible = depOn; }); return true; },
  scanList: () => scanMarks.map(m => ({ type: m.type, label: m.label || '' })),
  // v0.5 slice B: food
  food: () => ({ ...S.P.food, hydro: JSON.parse(JSON.stringify(S.P.food.hydro)), panel: galley.cookPanel.open, sel: galley.cookPanel.sel, next: galley.nextServing('eat'), nextDrink: galley.nextServing('drink') }),
  foodTick: dt => { let n = 0; while (dt > 0 && n++ < 10000) { const s = Math.min(1, dt); galley.updateHydro(s); dt -= s; } return true; },
  sanitize: d => saveState.sanitize(d),
  galleyUse: id => galley.useGalley(id), cookRecipe: i => galley.cook(i),
  hydroVis: () => build.moduleList().filter(b => b.part === 'hydro').map(b => ({ id: b.id, crop: b.group.userData.crop[0].visible ? b.group.userData.crop[0].scale.x : 0, lamp: b.group.userData.lamp.material.color.getHex(), pos: b.pos.toArray(), normal: b.normal.toArray() })),
  plantSpecies: () => { const pl = landing.planet(); return pl ? plantSpeciesOf(pl).map(s => ({ name: s.name, bad: s.bad, scan: s.scan })) : []; },
  derelictInfo: () => derelict.group ? { visible: derelict.group.visible, pos: derelict.group.position.toArray(), world: derelict.group.getWorldPosition(new THREE.Vector3()).toArray() } : null,
};
