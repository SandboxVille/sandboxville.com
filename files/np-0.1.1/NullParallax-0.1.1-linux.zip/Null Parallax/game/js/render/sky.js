// The sky's look: the Milky Way behind the Hipparcos stars, and the shared
// star sprite (a pin-sharp core with a soft glow that grows with brightness).
//
// The Milky Way is procedural, laid on the real galactic plane: the band's
// axis is the IAU galactic frame (north galactic pole RA 192.859 Dec +27.128,
// centre RA 266.405 Dec -28.936) turned into the game's sky axes. It is baked
// once into an equirectangular HalfFloat target on the GPU at load (no image
// file, no network), then drawn as one dim sphere that rides with the eye.
// It is identical at every star the ship can reach: the observer moves less
// than 10 ly, and the band is thousands of ly deep.
import * as THREE from 'three';
import { renderer, scene } from './scene.js';
import { dirFromRaDec, noiseGLSL } from '../core/utils.js';

// ---------- the star sprite (used by sensors.js, flight.js and the printed sky) ----------
// vertex side sets gl_PointSize = s * uPR and passes vSize = gl_PointSize.
// fragment side: a core about 1.3 px wide whatever the sprite size, plus a glow
// whose reach grows with the sprite, so bright stars bloom and faint ones stay points.
export const STAR_FRAG = `
  varying vec3 vCol; varying float vA; varying float vSize;
  void main() {
    vec2 p = gl_PointCoord * 2.0 - 1.0; float d2 = dot(p, p);
    if (d2 > 1.0) discard;
    float r = sqrt(d2) * vSize * 0.5;                 // pixels from the centre
    float core = exp(-r * r / 1.7);
    float glowK = clamp((vSize - 3.0) / 14.0, 0.0, 1.0);
    float glow = exp(-r / (0.9 + vSize * 0.16)) * (0.10 + 0.34 * glowK) * (1.0 - d2);
    float spike = glowK * 0.10 * (exp(-abs(p.x) * vSize * 0.9) + exp(-abs(p.y) * vSize * 0.9)) * (1.0 - d2) * (1.0 - d2);
    gl_FragColor = vec4(vCol * (core * 1.25 + glow + spike) * vA, 1.0);
  }`;

// ---------- the Milky Way ----------
const G = (() => {
  const ngp = dirFromRaDec(192.85948, 27.12825);
  const gc = dirFromRaDec(266.40499, -28.93617);
  // make the centre direction exactly perpendicular to the pole
  gc.addScaledVector(ngp, -gc.dot(ngp)).normalize();
  const gy = new THREE.Vector3().crossVectors(ngp, gc).normalize(); // l = 90 deg (towards Cygnus)
  return { ngp, gc, gy };
})();
export const galactic = G;

const VS_FS = `varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

const BAKE_FS = `
  uniform vec3 uNGP, uGC, uGY; varying vec2 vUv;
  ${noiseGLSL}
  const float PI = 3.14159265;
  void main(){
    float lon = (vUv.x * 2.0 - 1.0) * PI, lat = (vUv.y - 0.5) * PI;
    vec3 d = vec3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon));
    float b = asin(clamp(dot(d, uNGP), -1.0, 1.0));
    float l = atan(dot(d, uGY), dot(d, uGC));
    float bd = degrees(b), ld = degrees(l);
    float inner = 0.5 + 0.5 * cos(l);
    float width = mix(3.8, 9.5, pow(inner, 1.5));
    float disk = exp(-(bd * bd) / (width * width));
    float halo = exp(-abs(bd) / 26.0) * 0.10;
    float along = 0.28 + 0.72 * pow(inner, 1.6);
    float bulge = exp(-(ld * ld) / (2.0 * 11.0 * 11.0) - (bd * bd) / (2.0 * 8.0 * 8.0));
    vec3 q = d * 7.0;
    float clouds = fbm(q * 1.3 + vec3(1.7, 0.3, 2.9));
    float fine = n3(q * 9.0);
    float lum = disk * along * (0.45 + 1.1 * clouds * clouds + 0.25 * fine) + bulge * 1.15 + halo * along;
    // dust: the Great Rift and friends, just above the plane in the inner half
    float dn = fbm(q * 2.1 + vec3(5.2, 1.1, 7.7));
    float rift = exp(-pow((bd - 1.2 - 1.6 * sin(l * 2.3)) / (2.2 + 1.8 * inner), 2.0)) * smoothstep(-0.3, 0.7, cos(l * 0.85));
    float ext = rift * (0.45 + 1.6 * smoothstep(0.38, 0.78, dn)) + disk * 0.35 * smoothstep(0.55, 0.85, dn);
    lum *= exp(-1.7 * ext);
    vec3 cold = vec3(0.74, 0.82, 1.0), warm = vec3(1.0, 0.84, 0.62);
    vec3 col = mix(cold, warm, clamp(bulge * 0.9 + inner * disk * 0.35, 0.0, 1.0));
    gl_FragColor = vec4(col * lum, 1.0);
  }`;

const SKY_VS = `varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
const SKY_FS = `
  uniform sampler2D tMW; uniform float uK; varying vec3 vD;
  float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
  void main(){
    vec3 d = normalize(vD);
    vec2 uv = vec2(atan(d.z, d.x) / 6.2831853 + 0.5, asin(clamp(d.y, -1.0, 1.0)) / 3.14159265 + 0.5);
    vec3 c = texture2D(tMW, uv).rgb * uK;
    c += (ign(gl_FragCoord.xy) - 0.5) / 255.0 * step(0.0005, uK);
    gl_FragColor = vec4(max(c, 0.0), 1.0);
  }`;

export const milky = { mesh: null, mat: null, rt: null, k: 0.065 };

export function buildMilkyWay() {
  if (milky.mesh) return milky.mesh;
  const W = 2048, H = 1024;
  milky.rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, depthBuffer: false });
  milky.rt.texture.generateMipmaps = false;
  milky.rt.texture.minFilter = milky.rt.texture.magFilter = THREE.LinearFilter;
  milky.rt.texture.wrapS = THREE.RepeatWrapping;
  const bake = new THREE.ShaderMaterial({ uniforms: { uNGP: { value: G.ngp }, uGC: { value: G.gc }, uGY: { value: G.gy } }, vertexShader: VS_FS, fragmentShader: BAKE_FS, depthTest: false, depthWrite: false });
  const tri = new THREE.BufferGeometry(); tri.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  const q = new THREE.Mesh(tri, bake); q.frustumCulled = false;
  const s = new THREE.Scene(); s.add(q);
  const prev = renderer.getRenderTarget();
  renderer.setRenderTarget(milky.rt);
  renderer.render(s, new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1));
  renderer.setRenderTarget(prev);
  bake.dispose(); tri.dispose();
  milky.mat = new THREE.ShaderMaterial({ uniforms: { tMW: { value: milky.rt.texture }, uK: { value: milky.k } }, vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false, depthTest: true });
  // drawn after the opaque world (renderOrder) so walls and the Body reject it early,
  // but it writes no depth, so the stars (5000 m) still draw over it
  milky.mesh = new THREE.Mesh(new THREE.SphereGeometry(4200, 48, 24), milky.mat);
  milky.mesh.renderOrder = 10; milky.mesh.frustumCulled = false;
  scene.add(milky.mesh);
  return milky.mesh;
}
