// Save/Load: localStorage only. Every read and write is wrapped so a private
// window, a full disk, a hand-edited or half-written save can never break
// the game -- the worst case is "that slot is DAMAGED", never a dead page.
//
// Format (v5): { game, v, savedAt, playTime, summary, sum, data }
//   sum  = a checksum of JSON(data); a mismatch means the slot was damaged
//   data = the progress object P (see core/state.js freshProgress)
// Older saves (the v0.2-v0.4 / Chapter 1 format, keys np_v02_slot_*) are
// migrated on read. A damaged slot is copied to a quarantine key before it
// is ever overwritten, so nothing is silently destroyed.
import { SAVE_VERSION } from './core/constants.js';

const PREFIX = 'np5_';
const OLD_PREFIX = 'np_v02_slot_';
const SETTINGS_KEY = PREFIX + 'settings';
const key = slot => PREFIX + (slot === 'auto' ? 'auto' : 'slot' + slot);

let available = null;
export function storageAvailable() {
  if (available !== null) return available;
  try { const k = '__np_probe__'; localStorage.setItem(k, '1'); localStorage.removeItem(k); available = true; }
  catch (e) { available = false; }
  return available;
}
function getRaw(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function setRaw(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }

export function checksum(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h.toString(36);
}

export function saveToSlot(slot, data, meta = {}) {
  if (!storageAvailable()) return false;
  try {
    const body = JSON.stringify(data);
    const env = { game: 'NULL_PARALLAX', v: SAVE_VERSION, savedAt: Date.now(), playTime: meta.playTime || 0, summary: meta.summary || '', sum: checksum(body), data: JSON.parse(body) };
    // never overwrite a damaged slot without keeping a copy of it first
    const prev = readSlot(slot);
    if (prev.status === 'damaged') setRaw(PREFIX + 'quarantine_' + (slot === 'auto' ? 'auto' : slot) + '_' + Date.now(), prev.raw || '');
    return setRaw(key(slot), JSON.stringify(env));
  } catch (e) { return false; }
}

// returns { status: 'empty' | 'ok' | 'damaged', env, data, raw, reason }
export function readSlot(slot) {
  if (!storageAvailable()) return { status: 'empty' };
  let raw = getRaw(key(slot));
  let legacy = false;
  if (raw == null) {
    const old = getRaw(slot === 'auto' ? OLD_PREFIX + 'auto' : OLD_PREFIX + slot);
    if (old == null) return { status: 'empty' };
    raw = old; legacy = true;
  }
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { status: 'damaged', raw, reason: 'not a save' };
    if (legacy || parsed.game !== 'NULL_PARALLAX') {
      const data = migrateLegacy(parsed);
      if (!data) return { status: 'damaged', raw, reason: 'unrecognised old save' };
      return { status: 'ok', env: { v: 4, savedAt: parsed.savedAt || 0, playTime: 0, summary: `SYSTEM ${data.system} (OLD SAVE)` }, data, raw, migrated: true };
    }
    if (typeof parsed.v !== 'number' || parsed.v > SAVE_VERSION) return { status: 'damaged', raw, reason: 'from a newer version' };
    if (!parsed.data || typeof parsed.data !== 'object') return { status: 'damaged', raw, reason: 'no data' };
    if (parsed.sum && checksum(JSON.stringify(parsed.data)) !== parsed.sum) return { status: 'damaged', raw, reason: 'checksum mismatch' };
    return { status: 'ok', env: parsed, data: parsed.data, raw };
  } catch (e) {
    return { status: 'damaged', raw, reason: 'unreadable' };
  }
}

export function loadFromSlot(slot) { const r = readSlot(slot); return r.status === 'ok' ? r.data : null; }

export function slotSummary(slot) {
  const r = readSlot(slot);
  if (r.status === 'empty') return null;
  if (r.status === 'damaged') return { damaged: true, text: `DAMAGED (${r.reason}) -- cannot load` };
  const d = r.env.savedAt ? new Date(r.env.savedAt) : null;
  const mins = Math.floor((r.env.playTime || 0) / 60);
  return { damaged: false, text: `${r.env.summary || 'SYSTEM ' + (r.data.system || 1)}  //  ${mins} MIN  //  ${d ? d.toLocaleString() : 'unknown time'}` };
}

export function deleteSlot(slot) { try { localStorage.removeItem(key(slot)); return true; } catch (e) { return false; } }

function migrateLegacy(o) {
  if (typeof o.system !== 'number' && !o.repair) return null;
  const n = v => (typeof v === 'number' && isFinite(v)) ? v : 0;
  return {
    storyStep: 9, mode: 'campaign',
    system: Math.max(1, Math.min(3, Math.round(n(o.system) || 1))),
    repair: { power: n(o.repair && o.repair.power), comms: n(o.repair && o.repair.comms), thrusters: n(o.repair && o.repair.thrusters) },
    res: { salvage: Math.round(n(o.scrap)), fuel: Math.round(n(o.fuel)), ore: 0, ice: 0 },
    upgrades: o.upgrades || {},
    journalOrder: Array.isArray(o.journalOrder) ? o.journalOrder.filter(x => typeof x === 'string') : [],
    secretFound: !!o.secretFound, chapter1Shown: !!o.chapter1Shown,
  };
}

let lastAuto = 0;
export function autosave(dataFn, metaFn, minGapMs = 4000) {
  if (!storageAvailable()) return false;
  const t = Date.now();
  if (t - lastAuto < minGapMs) return false;
  lastAuto = t;
  return saveToSlot('auto', dataFn(), metaFn ? metaFn() : {});
}
export function resetAutosaveGap() { lastAuto = 0; }

export function saveSettings(s) { if (storageAvailable()) setRaw(SETTINGS_KEY, JSON.stringify(s)); }
export function loadSettings() {
  const raw = getRaw(SETTINGS_KEY);
  if (!raw) return null;
  try { const o = JSON.parse(raw); return (o && typeof o === 'object' && !Array.isArray(o)) ? o : null; } catch (e) { return null; }
}
