// Journal fragment unlocking. A thin, shared choke point so every system
// that can trigger a log entry (sensors, entities, interaction) does it the
// same way, once, instead of re-implementing the "already have it?" check.
import { S } from '../core/state.js';
import { JOURNAL } from '../journal-data.js';
import { say } from '../ui/hud.js';
import { refreshPause } from '../ui/pause-bridge.js';

export function unlockFragment(sys, trigger) {
  const f = JOURNAL.find(x => x.system === sys && x.unlock === trigger);
  if (!f || S.journalOrder.includes(f.id)) return;
  S.journalOrder.push(f.id);
  say('LOG FRAGMENT RECOVERED', { delay: 400, hold: 6000 });
  refreshPause();
}

export function getLiveStats() { return { pauseCount: S.P.stats.pauseCount, nullHits: S.P.stats.nullHits, sleeps: S.P.stats.sleeps }; }
