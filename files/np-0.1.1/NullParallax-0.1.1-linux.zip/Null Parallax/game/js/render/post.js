// The finish: bloom on bright sources, a cold grade, a vignette and a faint
// film grain, behind the GRAPHICS setting (LOW / MEDIUM / HIGH).
//
// No three.js add-ons and no network: a small hand-rolled chain of full-screen
// triangles. The scene is drawn into one 8-bit MSAA target that holds exactly
// what the screen would have shown (see buildTargets below), so every existing
// material, tone-mapping flag and custom star shader looks the same through
// the finish as without it; the finish only adds light on top and shapes it.
//
// Pass count never changes mid-game: a level switch rebuilds the targets once
// (from the pause menu), and every effect inside a level is a uniform weight.
// Deterministic: grain is a hash of pixel + frame counter, no Math.random.
import * as THREE from 'three';
import { renderer } from './scene.js';

// what each level does (the pixel ratio per level is scene.js applyQuality).
// MSAA on the scene target stands in for the canvas's own antialiasing while
// the finish owns the output.
export const LEVELS = {
  low: { post: false },
  medium: { post: true, samples: 4, mips: 4, bloom: 0.55, grain: 0.035, vig: 0.32 },
  high: { post: true, samples: 4, mips: 5, bloom: 0.7, grain: 0.04, vig: 0.34 },
};

export const post = {
  level: 'medium', active: false, frame: 0, forceOff: /[?&]post=0/.test(location.search),
  // live inputs other systems may push (0..1); all default to calm
  fear: 0, mind: 1,
};

const VS = `varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

let sceneRT = null, mips = [], quadScene = null, quad = null, orthoCam = null;
let mBright = null, mDown = null, mUp = null, mFinish = null;
const size = new THREE.Vector2();

function fsTriangle() {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  return g;
}

function makeMaterials() {
  mBright = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uThr: { value: 0.72 }, uKnee: { value: 0.22 } },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uThr, uKnee; varying vec2 vUv;
      vec3 pick(vec2 uv){ vec3 c = texture2D(tSrc, uv).rgb; float br = max(c.r, max(c.g, c.b));
        float s = clamp(br - uThr + uKnee, 0.0, 2.0 * uKnee); s = s * s / (4.0 * uKnee + 1e-5);
        return c * (max(s, br - uThr) / max(br, 1e-4)); }
      void main(){
        // 4 taps (one per quadrant) so a single bright pixel does not flicker
        vec2 o = uTexel * 0.5;
        vec3 c = pick(vUv + vec2(-o.x, -o.y)) + pick(vUv + vec2(o.x, -o.y)) + pick(vUv + vec2(-o.x, o.y)) + pick(vUv + vec2(o.x, o.y));
        gl_FragColor = vec4(min(c * 0.25, vec3(8.0)), 1.0);
      }`,
    depthTest: false, depthWrite: false,
  });
  // dual-filter blur (Bjorge, SIGGRAPH 2015): 5 taps down, 8 taps up
  mDown = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
      void main(){ vec2 h = uTexel * 0.5;
        vec3 s = texture2D(tSrc, vUv).rgb * 4.0 + texture2D(tSrc, vUv - h).rgb + texture2D(tSrc, vUv + h).rgb
               + texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb + texture2D(tSrc, vUv - vec2(h.x, -h.y)).rgb;
        gl_FragColor = vec4(s / 8.0, 1.0); }`,
    depthTest: false, depthWrite: false,
  });
  mUp = new THREE.ShaderMaterial({
    uniforms: { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uGain: { value: 1 } },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uGain; varying vec2 vUv;
      void main(){ vec2 h = uTexel * 0.5;
        vec3 s = texture2D(tSrc, vUv + vec2(-h.x * 2.0, 0.0)).rgb + texture2D(tSrc, vUv + vec2(-h.x, h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(0.0, h.y * 2.0)).rgb + texture2D(tSrc, vUv + vec2(h.x, h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(h.x * 2.0, 0.0)).rgb + texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb * 2.0
               + texture2D(tSrc, vUv + vec2(0.0, -h.y * 2.0)).rgb + texture2D(tSrc, vUv + vec2(-h.x, -h.y)).rgb * 2.0;
        gl_FragColor = vec4(s / 12.0 * uGain, 1.0); }`,
    blending: THREE.AdditiveBlending, transparent: true, depthTest: false, depthWrite: false,
  });
  mFinish = new THREE.ShaderMaterial({
    uniforms: {
      tScene: { value: null }, tBloom: { value: null }, uRes: { value: new THREE.Vector2() },
      uBloom: { value: 0.6 }, uGrain: { value: 0.035 }, uVig: { value: 0.3 }, uFrame: { value: 0 },
      uCold: { value: 1 }, uFear: { value: 0 },
    },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tScene, tBloom; uniform vec2 uRes; uniform float uBloom, uGrain, uVig, uFrame, uCold, uFear; varying vec2 vUv;
      float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
      float hash(vec2 p){ vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
      void main(){
        vec3 c = texture2D(tScene, vUv).rgb;
        vec3 b = texture2D(tBloom, vUv).rgb;
        c += b * uBloom;
        // the grade: blacks stay black, low mids go a little colder, saturated reds are left alone
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
        float keep = smoothstep(0.25, 0.6, sat) * step(c.g + c.b, c.r * 1.2);
        vec3 cold = c * vec3(0.93, 0.99, 1.07);
        float midW = smoothstep(0.0, 0.08, l) * (1.0 - smoothstep(0.35, 0.8, l));
        c = mix(c, cold, midW * uCold * (1.0 - keep));
        c = mix(vec3(l), c, 1.0 - 0.18 * uFear);                        // fear drains colour
        // vignette: aspect-correct, soft, tightening with fear
        vec2 q = (vUv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
        float r = length(q);
        float v = smoothstep(0.95 - 0.2 * uFear, 0.28, r);
        c *= mix(1.0, v, uVig + 0.25 * uFear);
        // grain: luminance-weighted (4l(1-l)), a fresh pattern each frame
        float n = hash(gl_FragCoord.xy + vec2(uFrame * 37.0, uFrame * 91.0)) - 0.5;
        float lw = clamp(4.0 * l * (1.0 - l), 0.0, 1.0) + 0.15 * step(0.004, l);
        c += n * uGrain * (1.0 + uFear) * lw;
        // dither last: kills 8-bit banding in the near-black gradients
        c += (ign(gl_FragCoord.xy + uFrame * 5.588238) - 0.5) / 255.0;
        gl_FragColor = vec4(max(c, 0.0), 1.0);
      }`,
    depthTest: false, depthWrite: false,
  });
}

function target(w, h, samples = 0) {
  const t = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, format: THREE.RGBAFormat, depthBuffer: false, samples });
  t.texture.minFilter = t.texture.magFilter = THREE.LinearFilter;
  t.texture.generateMipmaps = false;
  return t;
}

function disposeTargets() {
  if (sceneRT) sceneRT.dispose();
  mips.forEach(m => m.dispose());
  sceneRT = null; mips = [];
}

function buildTargets() {
  disposeTargets();
  const L = LEVELS[post.level];
  renderer.getDrawingBufferSize(size);
  const w = Math.max(2, size.x), h = Math.max(2, size.y);
  // The scene target holds DISPLAY values, the same numbers the canvas would get:
  // three 0.160 tone-maps and sRGB-encodes into a target only when it is flagged
  // as an XR target (WebGLPrograms: toneMapping/outputColorSpace). Flagging it
  // keeps every program identical to the direct path, so a level switch never
  // recompiles a scene shader. Pinned to three 0.160.0 (index.html).
  // 8-bit, not HalfFloat: on this Radeon (ANGLE D3D11) a 4x MSAA HalfFloat target
  // cost no measurable work but broke frame pacing (27 ms intervals instead of
  // 16.7, interleaved A/B 2026-09-28); 8-bit MSAA holds 16.7. The values are
  // display values anyway, and the dither in the finish hides the 8-bit steps.
  sceneRT = new THREE.WebGLRenderTarget(w, h, { type: THREE.UnsignedByteType, format: THREE.RGBAFormat, depthBuffer: true, stencilBuffer: false, samples: L.samples || 0 });
  sceneRT.texture.colorSpace = THREE.SRGBColorSpace;
  // sRGB says how to ENCODE into it; the storage must stay plain RGBA8, or three
  // allocates the resolve texture as SRGB8_ALPHA8 while the MSAA renderbuffer is
  // RGBA8, the resolve blit fails and the scene comes out black
  sceneRT.texture.internalFormat = 'RGBA8';
  sceneRT.texture.generateMipmaps = false;
  sceneRT.isXRRenderTarget = true;
  let mw = w, mh = h;
  for (let i = 0; i < L.mips; i++) { mw = Math.max(1, mw >> 1); mh = Math.max(1, mh >> 1); mips.push(target(mw, mh)); }
}

export function initPost() {
  if (quadScene) return;
  makeMaterials();
  quadScene = new THREE.Scene();
  quad = new THREE.Mesh(fsTriangle(), mFinish); quad.frustumCulled = false; quadScene.add(quad);
  orthoCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  // count the whole frame (scene + finish) in renderer.info, not only its last pass
  renderer.info.autoReset = false;
  addEventListener('resize', () => { if (post.active) buildTargets(); });
}

export function setGraphicsLevel(level) {
  post.level = LEVELS[level] ? level : 'medium';
  const L = LEVELS[post.level];
  initPost();
  post.active = !!L.post && !post.forceOff;
  if (post.active) buildTargets(); else disposeTargets();
  mFinish.uniforms.uBloom.value = L.bloom || 0;
  mFinish.uniforms.uGrain.value = L.grain || 0;
  mFinish.uniforms.uVig.value = L.vig || 0;
  document.body.classList.toggle('postOn', post.active);
  return post.active;
}

function pass(mat, dst) {
  quad.material = mat;
  renderer.setRenderTarget(dst);
  renderer.render(quadScene, orthoCam);
}

export function renderFrame(scene, camera) {
  renderer.info.reset();
  if (!post.active) { renderer.render(scene, camera); return; }
  post.frame = (post.frame + 1) % 4096;
  const prevAuto = renderer.autoClear;
  renderer.setRenderTarget(sceneRT);
  renderer.render(scene, camera);
  renderer.autoClear = true;
  // bloom chain: bright pass into mip 0, dual-filter down, then back up (additive)
  mBright.uniforms.tSrc.value = sceneRT.texture;
  mBright.uniforms.uTexel.value.set(1 / sceneRT.width, 1 / sceneRT.height);
  pass(mBright, mips[0]);
  for (let i = 1; i < mips.length; i++) {
    mDown.uniforms.tSrc.value = mips[i - 1].texture;
    mDown.uniforms.uTexel.value.set(1 / mips[i - 1].width, 1 / mips[i - 1].height);
    pass(mDown, mips[i]);
  }
  renderer.autoClear = false;
  for (let i = mips.length - 1; i > 0; i--) {
    mUp.uniforms.tSrc.value = mips[i].texture;
    mUp.uniforms.uTexel.value.set(1 / mips[i].width, 1 / mips[i].height);
    pass(mUp, mips[i - 1]);
  }
  renderer.autoClear = true;
  const U = mFinish.uniforms;
  U.tScene.value = sceneRT.texture; U.tBloom.value = mips[0].texture;
  U.uRes.value.set(sceneRT.width, sceneRT.height);
  U.uFrame.value = post.frame;
  U.uFear.value = Math.max(0, Math.min(1, post.fear));
  pass(mFinish, null);
  renderer.autoClear = prevAuto;
}
