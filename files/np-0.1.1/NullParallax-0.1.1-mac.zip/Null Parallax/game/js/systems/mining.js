











import * as THREE from 'three';
import { S } from '../core/state.js';
import { depositsInCell, DCELL, DEPOSIT, groundAt } from '../gen/planet.js';
import { terrain } from '../render/terrain.js';
import { ship } from '../render/scene.js';
import * as landing from './landing.js';
import { prompt, progressBar, flash, say } from '../ui/hud.js';
import { emit } from '../core/events.js';
import { doAutosave } from './save-state.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import * as audio from '../audio.js';

// ---------------- the per-world record ----------------
export function surfKey() { const l = S.P.landing; return l ? `${l.hip}:${l.pi}` : null; }
export function surfStore(create = true) {
  const k = surfKey(); if (!k) return null;
  const P = S.P; if (!P.surf) P.surf = {};
  let s = P.surf[k];
  if (!s && create) s = P.surf[k] = { mined: {}, base: [] };
  if (s) { s.mined = s.mined || {}; s.base = s.base || []; }
  return s;
}

export const PULL_S = 1.6;                  // seconds of cutting per pull
export const HEAT_RATE = 14, COOL_RATE = 30, HEAT_UNLOCK = 30, PULL_POWER = 0.4;
const ARTICLE = { vein: 'AN', ice: 'AN', wreck: 'A', seam: 'A' };
const MAX_D = 64;

// ---------------- the formations: one merged, vertex-coloured shape per kind, plus a glowing accent ----------------
function prep(g, rgb) {
  const q = g.index ? g.toNonIndexed() : g; if (q.attributes.uv) q.deleteAttribute('uv');
  q.computeVertexNormals();
  const n = q.attributes.position.count, c = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { c[i * 3] = rgb[0]; c[i * 3 + 1] = rgb[1]; c[i * 3 + 2] = rgb[2]; }
  q.setAttribute('color', new THREE.BufferAttribute(c, 3));
  return q;
}
function shapes(kind) {
  const body = [], acc = [];
  const B = (g, rgb) => body.push(prep(g, rgb)), A = g => acc.push(prep(g, [1, 1, 1]));
  switch (kind) {
    case 'vein': {  // a heap of angular dark rock, streaked with copper-bright ore
      B(new THREE.DodecahedronGeometry(1.5, 0).scale(1.3, 0.85, 1.05).translate(0, 0.7, 0), [0.34, 0.3, 0.27]);
      B(new THREE.DodecahedronGeometry(0.95, 0).translate(1.35, 0.4, 0.45), [0.29, 0.26, 0.24]);
      B(new THREE.IcosahedronGeometry(0.75, 0).translate(-1.35, 0.3, -0.55), [0.31, 0.28, 0.25]);
      for (let i = 0; i < 5; i++) {
        const a = i * 1.26;
        A(new THREE.BoxGeometry(2.3 - i * 0.2, 0.13, 0.2).rotateZ(0.35 + i * 0.3).rotateY(a).translate(Math.cos(a) * 0.9, 0.85 + (i % 2) * 0.35, -Math.sin(a) * 0.75));
      }
      for (let i = 0; i < 7; i++) { const a = i * 0.9 + 0.3; A(new THREE.OctahedronGeometry(0.17, 0).translate(Math.cos(a) * 1.55, 0.5 + (i % 3) * 0.35, Math.sin(a) * 1.25)); }
      break;
    }
    case 'ice': {   // a mound of old ice with tall pale hexagonal crystals jutting out of it
      B(new THREE.DodecahedronGeometry(1.4, 0).scale(1.2, 0.55, 1.1).translate(0, 0.3, 0), [0.78, 0.84, 0.9]);
      const H = [3.2, 2.4, 2.0, 1.6, 2.7, 1.3];
      H.forEach((h, i) => {
        const a = i * 1.05, r = i === 0 ? 0 : 0.75;
        B(new THREE.CylinderGeometry(0.28 + (i % 2) * 0.08, 0.36, h, 6).translate(0, h / 2, 0).rotateZ((i % 3 - 1) * 0.28).rotateX(i ? 0.22 : 0).rotateY(a).translate(Math.cos(a) * r, 0.2, Math.sin(a) * r), i % 2 ? [0.62, 0.8, 0.94] : [0.74, 0.88, 0.97]);
        A(new THREE.OctahedronGeometry(0.16, 0).scale(1, 1.8, 1).translate(0, h + 0.1, 0).rotateZ((i % 3 - 1) * 0.28).rotateX(i ? 0.22 : 0).rotateY(a).translate(Math.cos(a) * r, 0.2, Math.sin(a) * r));
      });
      break;
    }
    case 'wreck': { // a half-buried hull section: an open shell with ribs, a fin, loose plates, a hazard stripe
      B(new THREE.CylinderGeometry(1.15, 1.15, 4.4, 12, 1, true, 0, Math.PI * 1.25).rotateZ(Math.PI / 2).rotateX(0.5).translate(0, 0.55, 0), [0.5, 0.52, 0.56]);
      for (let i = 0; i < 5; i++) B(new THREE.TorusGeometry(1.15, 0.08, 4, 12, Math.PI * 1.25).rotateY(Math.PI / 2).rotateX(0.5 + Math.PI / 2).translate(-1.8 + i * 0.9, 0.55, 0), [0.3, 0.31, 0.34]);
      B(new THREE.BoxGeometry(0.1, 1.6, 1.2).rotateZ(-0.3).translate(2.0, 1.4, 0.2), [0.44, 0.46, 0.5]);
      B(new THREE.BoxGeometry(1.4, 0.06, 0.9).rotateZ(0.2).rotateY(0.6).translate(-1.6, 0.12, 1.5), [0.46, 0.47, 0.5]);
      B(new THREE.BoxGeometry(1.0, 0.06, 0.7).rotateX(0.3).rotateY(-0.4).translate(0.9, 0.1, -1.6), [0.42, 0.43, 0.46]);
      A(new THREE.BoxGeometry(0.35, 0.05, 2.36).rotateX(0.5).translate(0.4, 1.58, 0.35));
      A(new THREE.BoxGeometry(0.16, 0.16, 0.16).translate(2.05, 2.25, 0.2));
      break;
    }
    default: {      // seam: tilted layered slabs of black carbon rock with a graphite sheen
      for (let i = 0; i < 5; i++) {
        const w = 3.3 - i * 0.45, d = 2.0 - i * 0.22;
        B(new THREE.BoxGeometry(w, 0.34, d).rotateY(i * 0.18).rotateZ(0.28).translate(i * 0.12 - 0.2, 0.2 + i * 0.32, (i % 2) * 0.12), i % 2 ? [0.2, 0.19, 0.21] : [0.11, 0.11, 0.13]);
      }
      for (let i = 0; i < 9; i++) { const a = i * 0.7; A(new THREE.OctahedronGeometry(0.12, 0).translate(Math.cos(a) * (0.6 + (i % 3) * 0.35), 0.45 + (i % 4) * 0.34, Math.sin(a) * 0.7)); }
    }
  }
  return { body: mergeGeometries(body), acc: mergeGeometries(acc) };
}
const LOOK = {
  vein: { rough: 0.85, metal: 0.25, acc: 0xd6893a, glow: 0.55 },
  ice: { rough: 0.18, metal: 0.0, acc: 0x7fd8ff, glow: 0.7 },
  wreck: { rough: 0.45, metal: 0.7, acc: 0xff7a24, glow: 0.6, side: THREE.DoubleSide },
  seam: { rough: 0.35, metal: 0.4, acc: 0xa0a8c8, glow: 0.3 },
};

const R = { group: null, inst: {}, live: [], key: '', cx: 1e9, cz: 1e9, dirty: true, sparks: null };
function ensure() {
  if (R.group) return;
  R.group = new THREE.Group(); R.group.name = 'deposits';
  for (const k in DEPOSIT) {
    const sh = shapes(k), L = LOOK[k];
    const body = new THREE.InstancedMesh(sh.body, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: L.rough, metalness: L.metal, flatShading: true, side: L.side || THREE.FrontSide }), MAX_D);
    const acc = new THREE.InstancedMesh(sh.acc, new THREE.MeshStandardMaterial({ color: L.acc, emissive: L.acc, emissiveIntensity: L.glow, roughness: 0.4, metalness: 0.3, flatShading: true }), MAX_D);
    for (const m of [body, acc]) { m.count = 0; m.frustumCulled = false; R.group.add(m); }
    R.inst[k] = { body, acc, n: 0 };
  }
  // sparks from the cutter (planet coordinates, a small pool)
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(36 * 3).fill(-1e5), 3));
  R.sparks = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffc070, size: 0.09, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false }));
  R.sparks.frustumCulled = false; R.sparks.userData = { life: new Float32Array(36), vel: new Float32Array(108), i: 0 }; R.group.add(R.sparks);
}

export function leftIn(d) { const st = surfStore(false); const v = st && st.mined[d.id]; return v == null ? d.total : v; }
// a formation keeps some of its bulk until it is empty, then it is a flat stump
export function scaleFor(d, left) { return left <= 0 ? 0.55 : 0.34 + 0.66 * Math.pow(left / d.total, 0.75); }
export const radiusOf = (d, left = d.left) => 2.0 * d.size * scaleFor(d, left);

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _e = new THREE.Euler();
function setMatrix(d) {
  // mined out: a low heap of spent rubble, its bright ore gone
  const k = scaleFor(d, d.left) * d.size, flat = d.left <= 0 ? 0.3 : 1;
  _q.setFromEuler(_e.set(0, d.rot, 0));
  _m.compose(_p.set(d.x, d.y - (d.left <= 0 ? 0.02 : 0.2) * k, d.z), _q, _s.set(k, k * flat, k));
  const I = R.inst[d.kind]; I.body.setMatrixAt(d.slot, _m);
  if (d.left <= 0) _m.makeScale(0, 0, 0);
  I.acc.setMatrixAt(d.slot, _m);
  I.body.instanceMatrix.needsUpdate = true; I.acc.instanceMatrix.needsUpdate = true;
}
function refresh(pl, gx, gz) {
  R.cx = gx; R.cz = gz; R.dirty = false;
  const site = terrain.site; R.live = [];
  for (const k in R.inst) R.inst[k].n = 0;
  for (let j = gz - 2; j <= gz + 2; j++) for (let i = gx - 2; i <= gx + 2; i++) for (const d of depositsInCell(pl, i, j)) {
    if (site && Math.hypot(d.x - site.x, d.z - site.z) < 19) continue;       // not under the ship
    const I = R.inst[d.kind]; if (I.n >= MAX_D) continue;
    const e = { ...d, y: groundAt(pl, d.x, d.z, site), slot: I.n++, left: 0 };
    e.left = leftIn(e);
    R.live.push(e); setMatrix(e);
  }
  for (const k in R.inst) { const I = R.inst[k]; I.body.count = I.n; I.acc.count = I.n; }
}

// ---------------- per frame ----------------
const M = { heat: 0, lock: false, t: 0, target: null };
export function update(dt) {
  if (!M.cutting) { M.heat = Math.max(0, M.heat - COOL_RATE * dt); if (M.lock && M.heat <= HEAT_UNLOCK) { M.lock = false; flash('CUTTER COOLED. HOLD F TO MINE AGAIN.', 1800); } }
  M.cutting = false;
  updateSparks(dt);
  const on = landing.onSurface() && terrain.group && terrain.planet;
  if (!on) { if (R.group && R.group.parent) R.group.parent.remove(R.group); R.key = ''; R.live = []; return; }
  ensure();
  if (R.group.parent !== terrain.group) terrain.group.add(R.group);
  const pl = landing.planet(), key = surfKey() + ':' + pl.seed + ':' + JSON.stringify(terrain.site);
  const p = landing.planetXZ(S.pos), gx = Math.floor(p.x / DCELL), gz = Math.floor(p.z / DCELL);
  if (key !== R.key || gx !== R.cx || gz !== R.cz || R.dirty) { R.key = key; refresh(pl, gx, gz); }
}

// F on the surface: the nearest deposit within reach, if it is nearer than the nearest small piece
function nearest(p, reach) {
  let best = null, bd = reach;
  // (reach is measured from the formation's full size, so you never have to chase it in as it shrinks)
  for (const d of R.live) { const s = Math.hypot(d.x - p.x, d.z - p.z) - radiusOf(d, d.total); if (s < bd) { bd = s; best = d; } }
  return best ? { d: best, gap: bd } : null;
}
function interact(dt, fHeld, fEdge, p, nodeD) {
  const n = nearest(p, 1.6);
  if (!n || nodeD < n.gap + 1.2) { M.t = 0; return false; }
  const d = n.d, def = DEPOSIT[d.kind], res = def.res.toUpperCase();
  M.target = d;
  if (d.left <= 0) { prompt(`${def.label}: MINED OUT. NOTHING LEFT IN IT, AND IT WILL NOT GROW BACK.`); progressBar(null); return true; }
  const heat = Math.round(M.heat);
  if (M.lock) { prompt(`${def.label}: CUTTER TOO HOT (${heat}%). LET GO OF F FOR A MOMENT: IT COOLS.`); progressBar(null); return true; }
  if (S.eva.power < 2) { prompt(`${def.label}: SUIT POWER TOO LOW TO RUN THE CUTTER. GO BACK INSIDE TO RECHARGE.`); progressBar(null); return true; }
  prompt(`HOLD F: MINE THE ${def.label}  //  ${d.left} ${res} LEFT  //  ${def.per} PER PULL${heat > 5 ? `  //  CUTTER HEAT ${heat}%` : ''}`);
  if (fHeld) {
    M.cutting = true; M.t += dt; M.heat = Math.min(100, M.heat + HEAT_RATE * dt);
    S.harvestTarget = d; S.noise += 1.6 * dt; audio.setCutter(true);
    spark(d, p);
    progressBar(Math.min(100, M.t / PULL_S * 100));
    if (M.t >= PULL_S) { M.t = 0; pull(d); }
    if (M.heat >= 100) { M.lock = true; M.t = 0; flash('CUTTER OVERHEATED. LET GO OF F UNTIL IT COOLS (A FEW SECONDS).', 2600); audio.blip(300, 0.05); }
  } else { M.t = 0; progressBar(null); }
  return true;
}
function pull(d) {
  const P = S.P, def = DEPOSIT[d.kind], st = surfStore();
  const got = Math.min(def.per, d.left);
  d.left -= got; st.mined[d.id] = d.left;
  P.res[def.res] = (P.res[def.res] || 0) + got;
  S.eva.power = Math.max(0, S.eva.power - PULL_POWER);
  setMatrix(d);
  audio.pickup(def.res === 'ice' ? 'fuel' : 'scrap');
  flash(d.left > 0 ? `+${got} ${def.res.toUpperCase()}   (${def.label}: ${d.left} LEFT)` : `+${got} ${def.res.toUpperCase()}. THE ${def.label} IS MINED OUT.`, 2200);
  if (!P.flags.mineSaid) { P.flags.mineSaid = true; say(`A ${def.label}: BIG DEPOSITS GIVE ${def.per} ${def.res.toUpperCase()} PER PULL AND SHRINK AS YOU CUT THEM. THEY DO NOT GROW BACK. THE CUTTER HEATS UP: LET GO OF F NOW AND THEN.`, { hold: 16000 }); }
  emit('harvested', def.res); emit('mined', d.kind);
  doAutosave();
}

// the nearest-resource hint (landing.js): the nearest deposit that still has something in it
function hint(p) {
  let best = null, bd = 1e9;
  for (const d of R.live) { if (d.left <= 0) continue; const s = Math.max(0, Math.hypot(d.x - p.x, d.z - p.z) - radiusOf(d)); if (s < bd) { bd = s; best = d; } }
  return best ? { d: bd, label: `${ARTICLE[best.kind]} ${DEPOSIT[best.kind].label} (${best.left} ${DEPOSIT[best.kind].res.toUpperCase()} LEFT)` } : null;
}

// TAB on the surface: mark the deposits around you with their name and what is left (ship-local points for main.js)
export function scanMarks(maxD = 200) {
  if (!landing.onSurface()) return [];
  const o = landing.planetXZ(new THREE.Vector3()), p = landing.planetXZ(S.pos);
  return R.live.filter(d => d.left > 0 && Math.hypot(d.x - p.x, d.z - p.z) < maxD)
    .sort((a, b) => Math.hypot(a.x - p.x, a.z - p.z) - Math.hypot(b.x - p.x, b.z - p.z)).slice(0, 14)
    .map(d => ({ pos: new THREE.Vector3(d.x - o.x, d.y + 2.4 * d.size - ship.position.y, d.z - o.z), label: `${DEPOSIT[d.kind].label} ${d.left}`, kind: d.kind, d: Math.round(Math.hypot(d.x - p.x, d.z - p.z)) }));
}

// ---------------- sparks ----------------
function spark(d, p) {
  const U = R.sparks.userData, a = R.sparks.geometry.attributes.position.array;
  const dx = p.x - d.x, dz = p.z - d.z, l = Math.hypot(dx, dz) || 1, r = radiusOf(d) * 0.8;
  const hx = d.x + dx / l * r, hz = d.z + dz / l * r, hy = d.y + 0.9 * d.size;
  for (let k = 0; k < 2; k++) {
    const i = U.i = (U.i + 1) % 36;
    a[i * 3] = hx; a[i * 3 + 1] = hy; a[i * 3 + 2] = hz;
    U.vel[i * 3] = (Math.random() - 0.5) * 3 + dx / l * 1.5; U.vel[i * 3 + 1] = Math.random() * 2.5; U.vel[i * 3 + 2] = (Math.random() - 0.5) * 3 + dz / l * 1.5;
    U.life[i] = 0.45;
  }
}
function updateSparks(dt) {
  if (!R.sparks) return;
  const U = R.sparks.userData, a = R.sparks.geometry.attributes.position.array;
  let any = false;
  for (let i = 0; i < 36; i++) {
    if (U.life[i] <= 0) continue;
    any = true; U.life[i] -= dt;
    if (U.life[i] <= 0) { a[i * 3 + 1] = -1e5; continue; }
    U.vel[i * 3 + 1] -= 6 * dt;
    a[i * 3] += U.vel[i * 3] * dt; a[i * 3 + 1] += U.vel[i * 3 + 1] * dt; a[i * 3 + 2] += U.vel[i * 3 + 2] * dt;
  }
  if (any || R.sparks.visible) R.sparks.geometry.attributes.position.needsUpdate = true;
  R.sparks.visible = any;
}

landing.surfaceHooks.hint = hint;
// the base (systems/base.js) chains its own F handling behind this one
export const mineInteract = interact;

// ---------------- test surface ----------------
export function debug() {
  const p = landing.onSurface() ? landing.planetXZ(S.pos) : { x: 0, z: 0 };
  const o = landing.onSurface() ? landing.planetXZ(new THREE.Vector3()) : { x: 0, z: 0 };
  return {
    heat: M.heat, lock: M.lock,
    live: R.live.map(d => ({ id: d.id, kind: d.kind, res: d.res, total: d.total, left: d.left, size: d.size, r: radiusOf(d), scale: scaleFor(d, d.left), d: Math.hypot(d.x - p.x, d.z - p.z), gap: Math.hypot(d.x - p.x, d.z - p.z) - radiusOf(d), x: d.x, z: d.z, local: [d.x - o.x, d.z - o.z], y: d.y - ship.position.y }))
      .sort((a, b) => a.d - b.d),
  };
}
export function testHeat(v) { M.heat = v; M.lock = v >= 100; }
