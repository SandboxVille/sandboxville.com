#!/bin/bash
# SandboxVille Lobby for Mac. Double-click this file to start SandboxVille.
# It needs Node.js 20 or newer. SandboxVille itself installs nothing and never asks for your password.
cd "$(dirname "$0")" || exit 1

NODE=""
# A portable Node.js next to this file: node/bin/node, or the folder the Node.js download unpacks
# to (node-v22...), renamed to node or not, and one folder deeper too.
for p in ./node/bin/node ./node/*/bin/node ./node-v*/bin/node ./node-v*/*/bin/node; do
  if [ -x "$p" ]; then NODE="$p"; break; fi
done
if [ -n "$NODE" ]; then
  :
elif command -v node >/dev/null 2>&1; then
  NODE="$(command -v node)"
else
  for p in /usr/local/bin/node /opt/homebrew/bin/node; do
    if [ -x "$p" ]; then NODE="$p"; break; fi
  done
fi

close_prompt() {
  echo ""
  read -r -p "  Press Enter to close this window. " _ || true
}

if [ -z "$NODE" ]; then
  cat <<'EOF'

  SandboxVille needs one free program first. It is called Node.js.

  How to get it:
    1. Go to  https://nodejs.org
    2. Download the version marked LTS for macOS (the macOS Installer).
    3. Open the file you downloaded. Click Continue until it says the install worked.
    4. Close this window. Then double-click "Start SandboxVille.command" again.

  Not allowed to install programs on this Mac? Use the version with no installer:
    1. Go to  https://nodejs.org/en/download
    2. Pick macOS, then download the "macOS Binary (.tar.gz)".
    3. Open it. Move the folder you get (its name starts with node-v) into this
       SandboxVille folder, next to this file. You do not need to rename it.
    4. Then double-click "Start SandboxVille.command" again.

EOF
  close_prompt
  exit 1
fi

if ! "$NODE" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 20 ? 0 : 1)"; then
  cat <<'EOF'

  Your Node.js is too old for SandboxVille. It needs version 20 or newer.

  How to get a newer one:
    1. Go to  https://nodejs.org
    2. Download the version marked LTS for macOS (the macOS Installer).
    3. Open the file you downloaded. Click Continue until it says the install worked.
    4. Close this window. Then double-click "Start SandboxVille.command" again.

  Not allowed to install programs on this Mac? Use the version with no installer:
    1. Go to  https://nodejs.org/en/download
    2. Pick macOS, then download the "macOS Binary (.tar.gz)".
    3. Open it. Move the folder you get (its name starts with node-v) into this
       SandboxVille folder, next to this file. You do not need to rename it.
    4. Then double-click "Start SandboxVille.command" again.

EOF
  close_prompt
  exit 1
fi

echo ""
echo "  Starting SandboxVille ..."
echo "  Keep this window open while you play. Close it to stop SandboxVille."
echo "  Your browser opens by itself in a moment."
echo ""
"$NODE" host/world-host.mjs --open "$@"
status=$?
if [ "$status" -ne 0 ]; then
  echo ""
  echo "  SandboxVille stopped because of a problem. Read the lines above to see why."
  close_prompt
fi
exit "$status"
