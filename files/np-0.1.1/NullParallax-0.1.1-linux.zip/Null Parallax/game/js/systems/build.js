// Part-snap building. Twelve hull HARDPOINTS (render/ship.js) accept one
// module each; a TRUSS module offers a new socket three metres further out.
// Build mode (B, outside only, needs main power for the fabricator): aim at
// a ring, pick a part (1-9 / wheel / d-pad), click to place, G to take one
// back for half its cost. Every module draws power; the ship's power graph
// in survival.js decides what stays on.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { ship } from '../render/scene.js';
import { HARDPOINTS, shipFx } from '../render/ship.js';
import { glowSprite } from '../render/textures.js';
import { sharedBasis } from '../core/utils.js';
import { moduleColliders } from './movement.js';
import { flash, say } from '../ui/hud.js';
import { emit } from '../core/events.js';
import * as audio from '../audio.js';

export const PARTS = {
  floodlight: { label: 'FLOODLIGHT', cost: { salvage: 2, ore: 1 }, power: 0.6, desc: 'Light. The dark keeps away within 20 m of it.' },
  heater: { label: 'HEATER', cost: { salvage: 3, ore: 2 }, power: 1.2, desc: 'More heat. The cabin warms faster and holds its warmth.' },
  recycler: { label: 'O2 RECYCLER', cost: { salvage: 3, ice: 3 }, power: 0.8, desc: 'Turns ice into air for the ship. Eats ice slowly.' },
  rtg: { label: 'RTG', cost: { salvage: 5, ore: 3 }, power: -2.5, desc: 'Makes power from decay. Always on. Adds 2.5 power.' },
  shield: { label: 'SHIELD PLATE', cost: { ore: 4 }, power: 0, desc: 'Cuts radiation reaching the cabin by about a third.' },
  truss: { label: 'TRUSS', cost: { ore: 2 }, power: 0, desc: 'Extends a hardpoint 3 m outward. Build on its end.' },
  mast: { label: 'WATCH MAST', cost: { salvage: 3, ore: 2 }, power: 0.5, desc: 'Watches a 70 degree cone. What is watched cannot close.', unlock: 'mast' },
  baffle: { label: 'EM BAFFLE', cost: { salvage: 3, ore: 1, ice: 1 }, power: 0.2, desc: 'Swallows about half of what the ship emits.', unlock: 'baffle' },
  // v0.5 slice B: grows food. Each crop takes 1 water + 1 plant fibre (the seed stock) and gives 3 edible plants.
  hydro: { label: 'HYDROPONICS', cost: { salvage: 3, ore: 2, ice: 1 }, power: 0.7, desc: 'Grows food on main power. Each crop takes 1 water and 1 plant fibre and gives 3 edible plants in 4 minutes.' },
};
export const PART_ORDER = ['floodlight', 'heater', 'recycler', 'rtg', 'shield', 'truss', 'mast', 'baffle', 'hydro'];

export function partUnlocked(p) { const u = PARTS[p].unlock; return !u || !!S.P.unlocks[u]; }
export function canAfford(cost) { for (const k in cost) if ((S.P.res[k] || 0) < cost[k]) return false; return true; }
export function costText(cost) { return Object.entries(cost).map(([k, v]) => `${v} ${k.toUpperCase()}`).join(' + '); }
function pay(cost) { for (const k in cost) S.P.res[k] -= cost[k]; }

// ---- sockets: free hardpoints + truss ends ----
const trussLen = 3;
export function sockets() {
  const list = HARDPOINTS.map(h => ({ id: h.id, pos: h.pos, normal: h.normal }));
  for (const m of S.P.modules) if (m.part === 'truss') {
    const base = socketById(m.socket, list);
    if (base) list.push({ id: m.id + '.end', pos: base.pos.clone().addScaledVector(base.normal, trussLen), normal: base.normal.clone() });
  }
  return list;
}
function socketById(id, list) { return (list || sockets()).find(s => s.id === id); }
export function occupied(socketId) { return S.P.modules.some(m => m.socket === socketId); }

// ---- module meshes ----
const group = new THREE.Group(); ship.add(group); shipFx.modulesGroup = group;
let built = []; // { id, part, socket, group, lampPos, pos, normal }
export function moduleList() { return built; }

export const M = {
  metal: new THREE.MeshStandardMaterial({ color: 0x55575e, roughness: 0.45, metalness: 0.8 }),
  dark: new THREE.MeshStandardMaterial({ color: 0x1a1b1f, roughness: 0.7, metalness: 0.5 }),
  panel: new THREE.MeshStandardMaterial({ color: 0x2a3140, roughness: 0.4, metalness: 0.6 }),
  lens: new THREE.MeshBasicMaterial({ color: 0xfff1d6, toneMapped: false }),
  glass: new THREE.MeshStandardMaterial({ color: 0xa8d8e8, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.22, depthWrite: false }),
  soil: new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 0.95, metalness: 0 }),
  leaf: new THREE.MeshStandardMaterial({ color: 0x5fae3c, roughness: 0.7, metalness: 0, flatShading: true }),
  red: new THREE.MeshBasicMaterial({ color: 0xff4020, toneMapped: false }),
  cyan: new THREE.MeshBasicMaterial({ color: 0x6fd0ff, toneMapped: false }),
  orange: new THREE.MeshStandardMaterial({ color: 0xb85a1a, roughness: 0.6, metalness: 0.3 }),
  ghostOk: new THREE.MeshBasicMaterial({ color: 0x60ff90, transparent: true, opacity: 0.35, depthWrite: false }),
  ghostBad: new THREE.MeshBasicMaterial({ color: 0xff5040, transparent: true, opacity: 0.35, depthWrite: false }),
};
const glowTex = glowSprite();

// each builder returns a Group whose local +Y is the outward normal
export function meshFor(part) {
  const g = new THREE.Group();
  const cyl = (r1, r2, h, mat, y) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, 10), mat); m.position.y = y; g.add(m); return m; };
  const box = (x, y, z, sx, sy, sz, mat) => { const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), mat); m.position.set(x, y, z); g.add(m); return m; };
  cyl(0.35, 0.42, 0.15, M.dark, 0.07); // mount plate
  switch (part) {
    case 'truss':
      [[-0.18, -0.18], [0.18, -0.18], [-0.18, 0.18], [0.18, 0.18]].forEach(([x, z]) => box(x, 1.5, z, 0.05, 3, 0.05, M.metal));
      for (let i = 0; i < 6; i++) box(0, 0.25 + i * 0.5, 0, 0.42, 0.04, 0.42, M.metal);
      break;
    case 'floodlight': {
      cyl(0.06, 0.06, 1.2, M.metal, 0.7);
      const head = box(0, 1.4, 0, 0.6, 0.35, 0.35, M.dark); head.rotation.x = 0.5;
      const lens = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.25), M.lens); lens.position.set(0, 1.45, 0.19); lens.rotation.x = 0.5; g.add(lens);
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: 0xfff1d6, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      s.scale.set(2.2, 2.2, 1); s.position.set(0, 1.5, 0.3); g.add(s); g.userData.glow = s; g.userData.lens = lens;
      break;
    }
    case 'heater':
      box(0, 0.6, 0, 0.8, 1.0, 0.6, M.dark);
      for (let i = 0; i < 6; i++) box(0, 0.2 + i * 0.16, 0.32, 0.7, 0.05, 0.05, M.orange);
      break;
    case 'recycler':
      cyl(0.35, 0.35, 1.0, M.panel, 0.6); cyl(0.25, 0.25, 0.3, M.metal, 1.25);
      box(0.4, 0.6, 0, 0.1, 0.8, 0.1, M.metal); box(0.4, 0.8, 0, 0.05, 0.05, 0.05, M.cyan);
      break;
    case 'rtg':
      cyl(0.28, 0.28, 1.2, M.dark, 0.7);
      for (let i = 0; i < 8; i++) { const f = box(0, 0.7, 0, 0.9, 1.1, 0.03, M.metal); f.rotation.y = i * Math.PI / 8; }
      box(0, 1.35, 0, 0.12, 0.08, 0.12, M.red);
      break;
    case 'shield':
      box(0, 0.35, 0, 2.2, 0.08, 1.6, M.metal); box(0, 0.42, 0, 2.0, 0.04, 1.4, M.dark);
      cyl(0.05, 0.05, 0.3, M.metal, 0.2);
      break;
    case 'mast': {
      cyl(0.05, 0.08, 2.4, M.metal, 1.2);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), M.dark); eye.position.y = 2.5; g.add(eye);
      const iris = new THREE.Mesh(new THREE.CircleGeometry(0.12, 12), M.red); iris.position.set(0, 2.5, 0.221); g.add(iris);
      g.userData.eye = eye; g.userData.iris = iris;
      break;
    }
    case 'hydro': {
      // a tray of soil under a glass dome, a grow-light bar over it, six plants that grow with the crop
      box(0, 0.3, 0, 1.3, 0.3, 0.9, M.panel); box(0, 0.48, 0, 1.2, 0.06, 0.8, M.soil);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.72, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.glass); dome.scale.set(1, 0.9, 0.7); dome.position.y = 0.45; g.add(dome);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.05, 0.14), new THREE.MeshBasicMaterial({ color: 0xff60d0, toneMapped: false })); lamp.position.y = 1.08; g.add(lamp);
      box(0.52, 0.78, 0, 0.04, 0.6, 0.04, M.metal); box(-0.52, 0.78, 0, 0.04, 0.6, 0.04, M.metal);
      const crop = [];
      for (let i = 0; i < 6; i++) {
        const p = new THREE.Group(); p.position.set(-0.4 + (i % 3) * 0.4, 0.5, i < 3 ? -0.18 : 0.18);
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.02, 0.3, 4).translate(0, 0.15, 0), M.leaf); p.add(stem);
        for (let k = 0; k < 3; k++) { const lf = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.22, 3).scale(1, 1, 0.3).translate(0, 0.11, 0), M.leaf); lf.position.y = 0.1 + k * 0.08; lf.rotation.set(0.9, k * 2.1, 0); p.add(lf); }
        g.add(p); crop.push(p);
      }
      g.userData.crop = crop; g.userData.lamp = lamp;
      break;
    }
    case 'baffle':
      for (let i = 0; i < 4; i++) { const f = box(0, 0.5 + i * 0.3, 0, 1.2 - i * 0.2, 0.05, 1.2 - i * 0.2, M.panel); f.rotation.y = i * 0.4; }
      break;
  }
  return g;
}
function orient(g, pos, normal) {
  g.position.copy(pos);
  g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normal);
}

export function rebuildModules() {
  for (const b of built) { group.remove(b.group); b.group.traverse(o => { if (o.geometry) o.geometry.dispose(); }); }
  built = [];
  moduleColliders.length = 0;
  const socks = sockets();
  // modules whose socket vanished (a truss removed in an older save) are dropped
  S.P.modules = S.P.modules.filter(m => socks.some(s => s.id === m.socket) || m.part === 'truss' && socks.some(s => s.id === m.socket));
  for (const m of S.P.modules) {
    const s = socks.find(x => x.id === m.socket); if (!s) continue;
    const g = meshFor(m.part); orient(g, s.pos, s.normal); group.add(g);
    const lampPos = s.pos.clone().addScaledVector(s.normal, 1.5);
    built.push({ id: m.id, part: m.part, socket: m.socket, group: g, lampPos, pos: s.pos.clone(), normal: s.normal.clone() });
    const r = m.part === 'shield' ? 1.0 : 0.7;
    moduleColliders.push({ pos: s.pos.clone().addScaledVector(s.normal, m.part === 'truss' ? 1.5 : 0.8), r });
    if (m.part === 'truss') moduleColliders.push({ pos: s.pos.clone().addScaledVector(s.normal, 2.7), r: 0.5 });
  }
}

// ---- build mode ----
let ghost = null, ghostPart = null;
export const buildState = { target: null, removeTarget: null, reason: '' };

export function toggleBuild() {
  if (S.buildMode) { S.buildMode = false; hideGhost(); return; }
  if (S.mode !== 'eva') { flash('BUILD FROM OUTSIDE: GO EVA, THEN PRESS B.', 2600); return; }
  if (!S.P.unlocks.build) { flash('FABRICATOR OFFLINE. RESTORE MAIN POWER FIRST.', 2600); return; }
  S.buildMode = true;
  if (!S.P.flags.buildHint) { S.P.flags.buildHint = true; say('BUILD MODE: AIM AT AN AMBER RING ON THE HULL. 1-9 OR WHEEL PICKS A PART. CLICK PLACES IT. G TAKES ONE BACK.', { hold: 16000 }); }
  audio.click(1200);
}
export function selectPart(i) {
  const n = S.buildSurface ? (S.buildSurfaceN || PART_ORDER.length) : PART_ORDER.length;   // (surface build: the base parts)
  S.buildPart = ((i % n) + n) % n;
  audio.click(1500);
}
export function currentPart() { return PART_ORDER[S.buildPart]; }

function hideGhost() { if (ghost) { group.remove(ghost); ghost = null; ghostPart = null; } shipFx.hardpointRings.forEach(r => r.visible = false); }

const _f = new THREE.Vector3(), _to = new THREE.Vector3();
function aimSocket() {
  const B = sharedBasis(S.q); _f.copy(B.f);
  let best = null, bestScore = Infinity;
  for (const s of sockets()) {
    if (occupied(s.id)) continue;
    _to.copy(s.pos).sub(S.pos);
    const d = _to.length(); if (d > 16 || d < 0.5) continue;
    const ang = _to.normalize().angleTo(_f);
    if (ang > 0.26) continue;
    const score = ang * 4 + d * 0.02;
    if (score < bestScore) { bestScore = score; best = s; }
  }
  return best;
}
function aimModule() {
  const B = sharedBasis(S.q); _f.copy(B.f);
  let best = null, bestScore = Infinity;
  for (const b of built) {
    const c = b.pos.clone().addScaledVector(b.normal, 0.8);
    _to.copy(c).sub(S.pos); const d = _to.length(); if (d > 12) continue;
    const ang = _to.normalize().angleTo(_f); if (ang > 0.22) continue;
    if (ang < bestScore) { bestScore = ang; best = b; }
  }
  return best;
}

export function updateBuild() {
  if (!S.buildMode || S.buildSurface) { if (ghost) hideGhost(); return; }
  if (S.mode !== 'eva') { S.buildMode = false; hideGhost(); return; }
  const socks = sockets();
  shipFx.hardpointRings.forEach((r, i) => { r.visible = !occupied(HARDPOINTS[i].id); });
  const part = currentPart();
  const target = aimSocket();
  buildState.target = target;
  buildState.removeTarget = target ? null : aimModule();
  const ok = target && partUnlocked(part) && canAfford(PARTS[part].cost);
  // playtest: flying right into a ring gave the same "aim at a ring" message as being nowhere near one
  const tooClose = !target && sockets().some(s => !occupied(s.id) && s.pos.distanceTo(S.pos) < 0.9);
  buildState.reason = !target ? (buildState.removeTarget ? `G: TAKE BACK THE ${PARTS[buildState.removeTarget.part].label}` : tooClose ? 'TOO CLOSE TO THE RING. BACK OFF A FEW METRES (S) AND AIM AT IT.' : 'AIM AT A FREE AMBER RING (WITHIN 16 M)')
    : !partUnlocked(part) ? 'NOT KNOWN YET. SOMETHING OUT HERE WILL TEACH YOU WHY YOU NEED IT.'
    : !canAfford(PARTS[part].cost) ? `NEEDS ${costText(PARTS[part].cost)}` : `CLICK TO BUILD ${PARTS[part].label}`;
  if (!target) { if (ghost) ghost.visible = false; return; }
  if (!ghost || ghostPart !== part) {
    if (ghost) group.remove(ghost);
    ghost = meshFor(part); ghostPart = part; group.add(ghost);
  }
  ghost.visible = true;
  const mat = ok ? M.ghostOk : M.ghostBad;
  ghost.traverse(o => { if (o.isMesh) o.material = mat; if (o.isSprite) o.visible = false; });
  orient(ghost, target.pos, target.normal);
  void socks;
}

let idSeq = 0;
export function place() {
  if (!S.buildMode) return false;
  const part = currentPart(), def = PARTS[part], target = buildState.target;
  if (!target) { flash(buildState.reason, 2000); audio.blip(220, 0.03); return false; }
  if (!partUnlocked(part)) { flash(buildState.reason, 2600); audio.blip(220, 0.03); return false; }
  if (!canAfford(def.cost)) { flash(`NEEDS ${costText(def.cost)}. CUT IT FROM THE FIELD (HOLD F ON A CHUNK).`, 2800); audio.blip(220, 0.03); return false; }
  pay(def.cost);
  const id = 'm' + Date.now().toString(36) + (idSeq++);
  S.P.modules.push({ part, socket: target.id, id });
  rebuildModules();
  audio.clank();
  S.noise += 3;
  flash(`${def.label} BUILT. ${def.desc.toUpperCase()}`, 3600);
  emit('built', part);
  return true;
}
export function removeAimed() {
  if (!S.buildMode) return false;
  const b = buildState.removeTarget; if (!b) return false;
  if (b.part === 'truss' && occupied(b.id + '.end')) { flash('TAKE BACK WHAT IS ON THE END OF THE TRUSS FIRST.', 2600); return false; }
  S.P.modules = S.P.modules.filter(m => m.id !== b.id);
  const cost = PARTS[b.part].cost;
  for (const k in cost) S.P.res[k] += Math.floor(cost[k] / 2);
  rebuildModules();
  audio.clank();
  flash(`${PARTS[b.part].label} TAKEN BACK. HALF ITS PARTS RECOVERED.`, 2600);
  emit('removed', b.part);
  return true;
}
// the Listener or the Nearer can take a module
export function destroyRandomModule() {
  if (!S.P.modules.length) return null;
  const leaves = S.P.modules.filter(m => !(m.part === 'truss' && occupied(m.id + '.end')));
  const m = leaves[Math.floor(Math.random() * leaves.length)];
  S.P.modules = S.P.modules.filter(x => x.id !== m.id);
  rebuildModules();
  return PARTS[m.part].label;
}

// per-frame visuals: floodlight glows, mast eyes tracking, lights from the pool
const _cam = new THREE.Vector3();
export function updateModuleVisuals(t, shed, level) {
  for (const b of built) {
    const on = level === 'powered' && !shed.has(b.id);
    if (b.part === 'floodlight') { b.group.userData.glow.material.opacity = on ? 0.9 : 0; b.group.userData.lens.material.color.setHex(on ? 0xfff1d6 : 0x222222); }
    if (b.part === 'hydro') {
      const h = S.P.food && S.P.food.hydro[b.id];
      b.group.userData.lamp.material.color.setHex(on ? 0xff60d0 : 0x1a0a16);
      const k = h && h.on ? 0.12 + 0.88 * h.g : 0;
      for (const p of b.group.userData.crop) { p.visible = k > 0; p.scale.setScalar(Math.max(0.01, k)); }
    }
    if (b.part === 'mast') { b.group.userData.iris.material.color.setHex(on ? 0xff4020 : 0x220804); if (on) b.group.userData.eye.rotation.y = Math.sin(t * 0.4 + b.pos.z) * 0.6; }
  }
}
export function floodlightsNear(p, n) {
  return built.filter(b => b.part === 'floodlight').map(b => ({ b, d: b.lampPos.distanceTo(p) })).sort((a, c) => a.d - c.d).slice(0, n).map(x => x.b);
}
void _cam;
