// v0.5 slice B: the galley's recipe table. Data, not code: the COOK station
// (systems/galley.js) lists these rows in order, checks the inputs against
// the ship's stores (S.P.res), takes them, and adds one dish. Eating a dish
// at EAT RATION / DRINK WATER applies its DISHES row.
//
// Inputs are resource keys: meals (rations), water (pouches), ice, fibre
// (plant fibre), plant (an edible plant), badplant (a plant the scanner
// called toxic). `battery` is what the hot plate costs, on main power.

export const RECIPES = [
  { id: 'hotmeal', label: 'HOT MEAL', in: { meals: 1, water: 1 }, battery: 2, note: 'A RATION HEATED WITH WATER. FILLS YOU UP AND KEEPS YOU FULL LONGER.' },
  { id: 'salad', label: 'SALAD', in: { plant: 2, water: 1 }, battery: 0, note: 'FRESH PLANTS, WASHED. FOOD AND A LITTLE WATER.' },
  { id: 'tea', label: 'TEA', in: { fibre: 1, ice: 1 }, battery: 2, note: 'PLANT FIBRE STEEPED IN MELTED ICE. A WARM DRINK.' },
  { id: 'stew', label: 'PLANT STEW', in: { plant: 1, meals: 1, water: 1 }, battery: 3, note: 'A RATION COOKED WITH A FRESH PLANT. THE BEST MEAL ABOARD.' },
  { id: 'spoiled', label: 'SPOILED MESS', in: { badplant: 1, water: 1 }, battery: 0, bad: true, note: 'A TOXIC PLANT DOES NOT COOK SAFE. THIS WILL MAKE YOU SICK. DO NOT EAT IT.' },
];

// what a dish does when you eat or drink it. fed = seconds of WELL FED
// (hunger and thirst drain at half speed); sick = seconds of SICK.
export const DISHES = {
  hotmeal: { label: 'HOT MEAL', kind: 'food', hunger: 65, thirst: 15, fed: 240 },
  salad: { label: 'SALAD', kind: 'food', hunger: 40, thirst: 20, fed: 150 },
  stew: { label: 'PLANT STEW', kind: 'food', hunger: 80, thirst: 20, fed: 360 },
  tea: { label: 'TEA', kind: 'drink', hunger: 5, thirst: 70, fed: 150 },
  spoiled: { label: 'SPOILED MESS', kind: 'food', hunger: 10, thirst: 0, fed: 0, sick: 90 },
};
// a raw ration / water pouch, for comparison (galley.js keeps these numbers)
export const RAW = { meals: { hunger: 45 }, water: { thirst: 55 }, plant: { hunger: 15, thirst: 5 } };

// the order EAT RATION picks from: the best food first, the raw ration after,
// a raw plant after that, and the spoiled mess never (unless it is all there is)
export const EAT_ORDER = ['stew', 'hotmeal', 'salad'];
export const DRINK_ORDER = ['tea'];

export const SICK_HEALTH = 0.1;   // health lost per second while sick
export const SICK_DRAIN = 2;      // hunger / thirst drain multiplier while sick
export const FED_DRAIN = 0.5;     // hunger / thirst drain multiplier while well fed
