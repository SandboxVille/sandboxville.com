// Breaks the circular dependency between gameplay modules (which need to
// refresh the pause menu's journal/console tabs when something changes) and
// main.js (which is the only place the pause menu instance is actually
// created, because it needs callbacks into nearly every other module).
let menu = null;
export function setPauseMenu(m) { menu = m; }
export function refreshPause() { if (menu) menu.refresh(); }
