// Landing (v0.5 slice A): orbit a planet of the star you are parked at, fly
// the descent by hand, walk the surface, take off again.
//
//   ORBIT    sit at the helm while parked at a real star (sandbox). The star's
//            planets are listed (gen/planet.js, seeded by its HIP number);
//            1-4 picks one and it hangs in the window. G: LAND.
//   DESCENT  a lander problem, flown from the helm. Gravity pulls; W / SPACE /
//            RT is the retro burn along the ship's belly; the mouse (or S / up
//            arrow / stick) tilts the nose. Nose up turns part of the burn
//            against your forward speed. Touch down slow, level and nearly
//            stopped. Too hard is hull damage; much too hard is the death screen.
//   LANDED   the ship stands on its legs. The airlock opens onto the ground:
//            real gravity (walk, run, jump), the suit's air and heat follow the
//            atmosphere and the temperature, resource nodes can be collected
//            (hold F). At the helm, G takes off and puts you back in orbit.
//
// CAMPAIGN (v0.5 campaign integration): each story system has the planets of
// the star the probe measures itself against (System 1: Alpha Centauri A,
// System 2: Sirius, System 3: HIP 26602), offered at the helm only once that
// system's fix has named the star (no spoilers). The story still comes first:
// when the jump is ready in System 1, F at the chair is the jump and G there
// is the planets. Standing up in orbit returns the ship to its station, so a
// campaign never carries an orbit around; only a landing is saved.
//
// Saved: P.landing = { hip, pi, phase, site, taken, tod, dmg, q }. The planet
// itself is never saved, only its seed's inputs (the star and the index), the
// landing site and the nodes you took.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { EYE_H, WALK_SPEED, SPRINT_MULT, PLAYER_R } from '../core/constants.js';
import { qFromYawPitch, flatBasis, clamp } from '../core/utils.js';
import { planetsAt, makePlanet, groundAt, describe, heightHash, heightSig, scanLine, planetSeed } from '../gen/planet.js';
import * as terrain from '../render/terrain.js';
import { ship, camera, scene } from '../render/scene.js';
import { field, derelict, boundary, DERELICT_POS, SHIP_CENTER } from '../render/world.js';
import { shipFx, HATCH_EXT, HULL_R } from '../render/ship.js';
import { starName, starPos, systemD } from './catalogue.js';
import { held, lastInputDevice } from '../core/input.js';
import { say, flash, prompt, progressBar } from '../ui/hud.js';
import { emit, on } from '../core/events.js';
import { doAutosave } from './save-state.js';
import { hullCollide, moduleColliders } from './movement.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);
export const LEG = 3.0;                    // ship floor above the ground on its legs (hull belly at 1.1 - 3.3 = -2.2)
const START_ALT = 900, START_VF = 40, START_VY = -18;
const SAFE = { vy: 5, vf: 6, ang: 16 }, HARD = { vy: 11, vf: 18, ang: 40 };
const HELM_EYE = new THREE.Vector3(-0.72, 1.5, -8.42);

// transient
const D = { alt: 0, y: 0, vy: 0, vf: 0, pitch: 0, fuel: 100, thr: 0, px: 0, pz: 0, auto: false, t: 0, lastGrade: null, ascend: 0, orbitPos: new THREE.Vector3(), orbitSun: new THREE.Vector3(1, 0, 0) };
let cache = { key: '', list: [] };

// ---------------- where the planets come from ----------------
export const CAMPAIGN_STAR = { 1: 71683, 2: 32349, 3: 26602 };
// the fix in a campaign system names its star; before that the helm offers nothing
export function campaignFixed(P = S.P) {
  const n = P.system;
  return !!(P.flags && P.flags['fixed' + n]) || (n === 1 && P.storyStep >= 3) || (n === 2 && P.storyStep >= 13);
}
export function landingHip(P = S.P) {
  if (P.place) return P.place.hip;
  if (P.mode === 'campaign' && CAMPAIGN_STAR[P.system] && campaignFixed(P)) return CAMPAIGN_STAR[P.system];
  return null;
}
function hereName(hip) { return S.P.place ? (S.P.place.name || starName(hip)) : starName(hip); }
on('fix', n => { if (S.P && S.P.flags) S.P.flags['fixed' + n] = true; });

// ---------------- queries ----------------
export const L = () => S.P.landing;
export const phase = () => (S.P.landing ? S.P.landing.phase : null);
export const onPlanet = () => !!(S.P.landing && S.P.landing.phase !== 'orbit');
export const onSurface = () => !!(S.P.landing && S.P.landing.phase === 'landed');
export const helmActive = () => !!S.landHelm;
export const busy = () => phase() === 'descent' || D.ascend > 0;
export function planetsHere() {
  const hip = landingHip(); if (hip == null) return [];
  const key = 'p' + hip;
  if (cache.key !== key) cache = { key, list: planetsAt(hip, hereName(hip)) };
  return cache.list;
}
export function planet() { const l = L(); if (!l) return null; const list = planetsAt(l.hip, hereName(l.hip)); return list[l.pi] || list[0]; }
// can the helm offer planets right now
export function canOrbit() { const P = S.P; return !P.flight && (P.mode === 'sandbox' ? !!P.place : landingHip(P) != null); }
export const campaign = () => S.P.mode === 'campaign';

// ---------------- the helm ----------------
export function enterHelm() {
  if (!canOrbit() && !L()) return false;
  S.mode = 'interior'; S.helm = true; S.landHelm = true;
  S.pos.copy(HELM_EYE); S.vel.set(0, 0, 0);
  S.yaw = 0; S.pitch = phase() === 'landed' ? -0.08 : -0.12; S.roll = 0; qFromYawPitch(S.yaw, S.pitch, 0, S.q);
  S.buildMode = false; S.eva.lamp = false;
  if (!L()) enterOrbit(0, true);
  emit('landHelm');
  return true;
}
export function standUp() {
  if (!S.landHelm) return false;
  if (phase() === 'descent') { flash('NOT DURING THE DESCENT.', 1600); return false; }
  S.helm = false; S.landHelm = false; S.mode = 'interior';
  if (campaign() && phase() === 'orbit') { leaveOrbit(); say('BACK ON STATION.', { hold: 5000 }); }
  S.pos.set(-0.72, EYE_H, -7.3); S.yaw = 0; S.pitch = 0; qFromYawPitch(0, 0, 0, S.q);
  return true;
}
export function enterOrbit(pi, quiet) {
  const P = S.P; if (!canOrbit()) return false;
  const list = planetsHere(); if (!list.length) return false;
  pi = clamp(pi | 0, 0, list.length - 1);
  if (!P.landing) P.landing = { hip: landingHip(), pi, phase: 'orbit', site: null, taken: [], tod: 0.12, dmg: 0, q: null };
  else if (P.landing.phase !== 'orbit') return false;
  else if (P.landing.pi !== pi) { P.landing.pi = pi; P.landing.site = null; P.landing.taken = []; P.landing.tod = 0.12; }
  placeOrbitView(true);
  discover(planet(), false);
  if (!quiet) { audio.click(1500); const pl = planet(); flash(`ORBIT: ${pl.name}  //  ${scanLine(pl)}`, 3600); }
  return true;
}
export function leaveOrbit() {
  if (phase() !== 'orbit') return false;
  S.P.landing = null; terrain.showOrbit(null); S.landHelm = false;
  return true;
}
// where the planet hangs: below and ahead of the nose, lit from the real star's direction
function placeOrbitView(fresh) {
  const pl = planet(); if (!pl) return;
  if (fresh || !D.orbitSet) {
    const f = new THREE.Vector3(0, -0.62, -1).normalize().applyQuaternion(ship.quaternion);
    D.orbitPos.copy(f).multiplyScalar(4300);
    const P = S.P, l = L(), sp = l ? starPos(l.hip) : null;
    const here = P.place ? new THREE.Vector3(P.place.x, P.place.y, P.place.z) : P.mode === 'campaign' ? systemD(P.system) : null;
    if (sp && here && sp.distanceToSquared(here) > 1e-12) D.orbitSun.copy(sp.sub(here)).normalize();
    else D.orbitSun.set(1, 0.4, 0.2).normalize();
    D.orbitSet = true;
  }
  terrain.showOrbit(pl, D.orbitPos, 2900, D.orbitSun);
}

// ---------------- descent ----------------
export function beginDescent() {
  const l = L(); if (!l || l.phase !== 'orbit') return false;
  if (S.P.repair.thrusters < 50) { flash(`THE THRUSTER IS AT ${Math.round(S.P.repair.thrusters)}%. IT NEEDS 50% TO LAND AND TAKE OFF AGAIN. FUEL WILL NOT FIX IT: REPAIR IT OUTSIDE (HOLD F ON THE THRUSTER).`, 5200); return false; }
  doAutosave(true);                      // a crash wakes you here, in orbit
  const pl = planet();
  l.phase = 'descent';
  l.q = [ship.quaternion.x, ship.quaternion.y, ship.quaternion.z, ship.quaternion.w];
  D.q0 = l.q.slice();
  D.px = 0; D.pz = 0; D.vf = START_VF; D.vy = START_VY; D.pitch = 0; D.fuel = 100; D.thr = 0; D.t = 0; D.lastGrade = null;
  D.y = groundAt(pl, 0, 0) + LEG + START_ALT;
  terrain.showOrbit(null);
  terrain.setPlanet(pl, null, l.taken);
  terrain.terrain.origin.set(D.px, D.pz);
  hideLocal(true);
  terrain.showSurface(true);
  S.pitch = -0.28; qFromYawPitch(S.yaw, S.pitch, 0, S.q);
  poseShip();
  fade('DE-ORBIT BURN COMPLETE', 900);
  say(`DESCENT: ${pl.name}. ${describe(pl)}.`, { delay: 500, hold: 14000 });
  say(`RETRO: HOLD ${keys().thr}. NOSE UP (${keys().pitch}) TURNS THE BURN AGAINST YOUR SPEED. TOUCH DOWN BELOW ${SAFE.vy} M/S, LEVEL. TOO HARD? PRESS ${keys().land} FOR LANDING ASSIST.`, { delay: 2600, hold: 20000 });
  emit('descent', pl);
  return true;
}
function keys() { const pad = lastInputDevice() === 'pad'; return pad ? { thr: 'RT', pitch: 'LEFT STICK', land: 'Y', stand: 'X' } : { thr: 'W / SPACE', pitch: 'MOUSE / ARROWS', land: 'G', stand: 'F' }; }
function thrustAccel(pl) { return pl.gravity * 2.2 + 6; }
function descentStep(dt, mouse, ax) {
  const pl = planet(), A = thrustAccel(pl), g = pl.gravity;
  let thrIn, pitchRate, mousePitch = 0;
  if (D.auto) {
    const alt = D.alt;
    const pd = clamp(D.vf / 35, -0.15, 0.75) * (alt > 8 ? 1 : 0.3);
    pitchRate = clamp((pd - D.pitch) * 2.5, -0.9, 0.9);
    const vyT = -clamp(alt * 0.09, 1.4, 26);
    thrIn = clamp((vyT - D.vy) * 0.5 + g / (A * Math.max(0.3, Math.cos(D.pitch))), 0, 1);
  } else {
    thrIn = Math.max(held('w') || held(' ') || held('shift') ? 1 : 0, ax.padRT > 0.08 ? ax.padRT : 0, held('gp_a') ? 1 : 0);
    // nose up: S, the up arrow, pulling back on the stick, or the mouse forward (invert Y flips the mouse)
    const keyP = (held('s') || held('arrowup') ? 1 : 0) - (held('arrowdown') ? 1 : 0);
    const padF = ax.moveF - ((held('w') ? 1 : 0) - (held('s') ? 1 : 0));
    pitchRate = keyP * 0.7 - padF * 0.7;
    mousePitch = -mouse.dy * 0.0025 * (S.settings.invertY ? -1 : 1) * S.settings.sensitivity;
  }
  if (D.fuel <= 0) thrIn = 0;
  D.thr += clamp(thrIn - D.thr, -4 * dt, 3 * dt);
  D.pitch = clamp(D.pitch + pitchRate * dt + mousePitch, -0.5, 1.2);
  const drag = pl.density * 0.02;
  const aF = -A * D.thr * Math.sin(D.pitch) - drag * D.vf;
  const aY = A * D.thr * Math.cos(D.pitch) - g - drag * D.vy;
  D.vf += aF * dt; D.vy += aY * dt;
  D.pz -= D.vf * dt; D.y += D.vy * dt;
  D.fuel = Math.max(0, D.fuel - D.thr * dt * 2.1);
  D.t += dt;
  const gnd = groundAt(pl, D.px, D.pz);
  D.alt = D.y - LEG - gnd;
  audio.setThrust(D.thr * 0.8);
  S.noise += D.thr * 4 * dt;
  terrain.terrain.origin.set(D.px, D.pz);
  poseShip();
  if (D.alt > START_ALT + 700) { abort(); return; }
  if (D.alt <= 0) touchdown(gnd);
}
function poseShip() {
  ship.position.set(0, D.y, 0);
  ship.quaternion.setFromAxisAngle(new THREE.Vector3(1, 0, 0), D.pitch);
  ship.updateMatrixWorld(true);
}
function abort() {
  const l = L(); l.phase = 'orbit';
  restoreShipPose(); terrain.showSurface(false); hideLocal(false); placeOrbitView(true);
  say('ABORTED. THE SHIP CLIMBED BACK TO ORBIT.', { hold: 8000 });
}
// grade a touchdown: 'safe' | 'hard' | 'crash'
export function grade(vy, vf, angDeg) {
  vy = Math.abs(vy); vf = Math.abs(vf); angDeg = Math.abs(angDeg);
  if (vy <= SAFE.vy && vf <= SAFE.vf && angDeg <= SAFE.ang) return 'safe';
  if (vy <= HARD.vy && vf <= HARD.vf && angDeg <= HARD.ang) return 'hard';
  return 'crash';
}
function touchdown(gnd) {
  const l = L(), pl = planet(), P = S.P, Lf = P.life;
  const ang = THREE.MathUtils.radToDeg(D.pitch);
  const gr = grade(D.vy, D.vf, ang);
  D.lastGrade = { grade: gr, vy: Math.abs(D.vy), vf: Math.abs(D.vf), ang, fuel: D.fuel };
  audio.setThrust(0);
  if (gr === 'crash') {
    D.vy = 0; D.vf = 0;
    S.crashFacts = `YOU HIT THE GROUND AT ${D.lastGrade.vy.toFixed(1)} M/S DOWN, ${D.lastGrade.vf.toFixed(1)} M/S FORWARD, ${Math.round(Math.abs(ang))} DEG OFF LEVEL.`;
    audio.bump(1); emit('landCrash', D.lastGrade);
    return;
  }
  l.phase = 'landed';
  l.site = { x: +D.px.toFixed(3), z: +D.pz.toFixed(3), h: +gnd.toFixed(3) };
  discover(pl, true);
  D.vy = 0; D.vf = 0; D.pitch = 0; D.thr = 0;
  settleOnSite();
  if (gr === 'hard') {
    const k = clamp((D.lastGrade.vy - SAFE.vy) / (HARD.vy - SAFE.vy), 0, 1) + clamp((D.lastGrade.vf - SAFE.vf) / (HARD.vf - SAFE.vf), 0, 1) * 0.5;
    const hurt = Math.round(12 + 26 * Math.min(1, k));
    Lf.health = Math.max(5, Lf.health - hurt); Lf.shipO2 = Math.max(0, Lf.shipO2 - 12); Lf.battery = Math.max(0, Lf.battery - 15);
    l.dmg = (l.dmg || 0) + 1;
    audio.bump(0.9);
    say(`HARD LANDING: ${D.lastGrade.vy.toFixed(1)} M/S. HULL DAMAGE. A SEAM IS VENTING: SHIP AIR -12%, BATTERY -15%. YOU TOOK ${hurt} HEALTH.`, { hold: 16000 });
  } else {
    audio.bump(0.35);
    say(`TOUCHDOWN: ${D.lastGrade.vy.toFixed(1)} M/S. ${pl.name}. THE LEGS HOLD.`, { hold: 12000 });
  }
  say(`${describe(pl)}. ${airAdvice(pl)} THE AIRLOCK OPENS ONTO THE GROUND.`, { delay: 2400, hold: 20000 });
  emit('landed', { grade: gr, planet: pl.name });
  doAutosave(true);
}
function airAdvice(pl) {
  return { none: 'NO AIR: THE SUIT RUNS ON ITS OWN TANK, AS IN SPACE.', thin: 'THIN AIR: THE SUIT TOPS UP FROM IT; THE TANK LASTS LONGER.', breathable: 'BREATHABLE AIR: THE SUIT VENTS OPEN; THE TANK HOLDS.', toxic: 'TOXIC AIR: THE SCRUBBERS WORK HARD; THE TANK DRAINS FASTER.' }[pl.atmo]
    + (pl.tempC < -40 || pl.tempC > 60 ? ` ${pl.tempC} C OUTSIDE: THE SUIT HEATER${pl.tempC > 60 ? ' (COOLER)' : ''} EATS SUIT POWER.` : '');
}
function settleOnSite() {
  const l = L(), pl = planet();
  terrain.setPlanet(pl, l.site, l.taken);
  terrain.terrain.origin.set(l.site.x, l.site.z);
  D.px = l.site.x; D.pz = l.site.z; D.y = l.site.h + LEG; D.pitch = 0; D.alt = 0;
  poseShip();
  hideLocal(true); terrain.showSurface(true); showLegs(true);
}

// ---------------- take-off ----------------
export function takeOff() {
  const l = L(); if (!l || l.phase !== 'landed' || D.ascend > 0) return false;
  if (S.mode !== 'interior') return false;
  D.ascend = 0.001; audio.setThrust(1);
  flash('TAKE-OFF. MAIN ENGINE.', 2400);
  return true;
}
function ascendStep(dt) {
  D.ascend += dt;
  D.vy = Math.min(90, D.vy + 18 * dt); D.y += D.vy * dt; poseShip();
  if (D.ascend > 3.2) finishTakeOff();
}
function finishTakeOff() {
  const l = L(); D.ascend = 0; audio.setThrust(0);
  l.phase = 'orbit'; l.site = null;
  restoreShipPose(); terrain.showSurface(false); showLegs(false); hideLocal(false);
  placeOrbitView(true);
  fade('ORBIT', 700);
  say(`BACK IN ORBIT OVER ${planet().name}. G: LAND AGAIN. N: THE CHART, TO LEAVE.`, { delay: 600, hold: 12000 });
  emit('tookOff');
  doAutosave(true);
}
function restoreShipPose() {
  const l = L();
  ship.position.set(0, 0, 0);
  const q = (l && l.q) || D.q0;
  if (q) ship.quaternion.set(q[0], q[1], q[2], q[3]).normalize();
  if (l) l.q = null;
  D.q0 = null;
  ship.updateMatrixWorld(true);
}

// ---------------- the local space around the parked ship comes and goes ----------------
function hideLocal(hide) {
  if (field.group) field.group.visible = !hide;
  if (derelict.group) { derelict.group.visible = !hide; if (!hide) derelict.group.position.copy(DERELICT_POS); }
  if (boundary.lattice) boundary.lattice.visible = !hide && boundary.lattice.visible;
  if (boundary.printed) boundary.printed.visible = !hide && boundary.printed.visible;
}
let legs = null;
function showLegs(on) {
  if (!legs && on) {
    legs = new THREE.Group(); legs.name = 'landingLegs';
    const m = new THREE.MeshStandardMaterial({ color: 0x5a5e66, roughness: 0.6, metalness: 0.7 }), pad = new THREE.MeshStandardMaterial({ color: 0x2c2e32, roughness: 0.8, metalness: 0.4 });
    for (const [x, z] of [[-2.6, -9.5], [2.6, -9.5], [-2.6, 3.2], [2.6, 3.2]]) {
      const top = new THREE.Vector3(x * 0.55, -1.2, z), foot = new THREE.Vector3(x, -LEG + 0.12, z);
      const len = top.distanceTo(foot);
      const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, len, 8), m);
      strut.position.copy(top).add(foot).multiplyScalar(0.5);
      strut.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), foot.clone().sub(top).normalize());
      legs.add(strut);
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.65, 0.18, 12), pad); p.position.copy(foot); legs.add(p);
    }
    // a ladder under the hatch
    for (let y = -LEG + 0.35; y < 0.6; y += 0.45) { const r = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.7), m); r.position.set(HATCH_EXT.x - 0.2, y, HATCH_EXT.z); legs.add(r); }
    for (const dz of [-0.36, 0.36]) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.07, LEG + 0.8, 0.07), m); s.position.set(HATCH_EXT.x - 0.2, (-LEG + 0.8) / 2, HATCH_EXT.z + dz); legs.add(s); }
    ship.add(legs);
  }
  if (legs) legs.visible = on;
}

// ---------------- after a load (or a death's reload) ----------------
export function restore() {
  const l = L();
  D.ascend = 0; D.auto = false; S.landHelm = false; D.orbitSet = false;
  // a campaign keeps no orbit between sessions: it loads back on station (a landing loads landed)
  if (l && campaign() && l.phase !== 'landed') { S.P.landing = null; if (D.q0 || ship.position.lengthSq() > 0) restoreShipPose(); terrain.reset(); showLegs(false); return; }
  if (!l || landingHip() !== l.hip) { if (l) S.P.landing = null; if (D.q0 || ship.position.lengthSq() > 0) restoreShipPose(); terrain.reset(); showLegs(false); return; }
  if (l.phase === 'descent') { l.phase = 'orbit'; }
  if (l.phase === 'orbit') {
    restoreShipPose();
    terrain.showSurface(false); showLegs(false); hideLocal(false); placeOrbitView(true);
  } else if (l.phase === 'landed') {
    if (!l.site) { l.phase = 'orbit'; return restore(); }
    settleOnSite();
  }
}

// ---------------- the surface: walking with real gravity ----------------
const _v = new THREE.Vector3();
export function planetXZ(localPos) { const l = L(); return { x: localPos.x + ship.position.x + (l && l.site ? l.site.x : D.px), z: localPos.z + ship.position.z + (l && l.site ? l.site.z : D.pz) }; }
export function groundLocalY(localPos) {
  const l = L(), pl = planet(); const p = planetXZ(localPos);
  let h = groundAt(pl, p.x, p.z, l.site);
  if (surfaceHooks.floor) h = Math.max(h, surfaceHooks.floor(p.x, p.z, localPos.y + ship.position.y));   // a base floor (the shelter)
  return h - ship.position.y;
}
// surface build (2026-09-29): the mining and base systems plug in here (they import this file, not the other way round)
export const surfaceHooks = { interact: null, hint: null, floor: null, collide: null };
export const dayLevel = () => (D.day == null ? 1 : D.day);
export function surfaceStep(dt, ax) {
  const pl = planet(); if (!pl) return;
  if (!S.P.flags.groundHint) { S.P.flags.groundHint = true; say(lastInputDevice() === 'pad' ? `ON THE GROUND. LEFT STICK WALKS, A JUMPS. HOLD X AT A GLOWING PIECE, A PLANT OR A BIG DEPOSIT TO COLLECT OR MINE IT. Y BUILDS A BASE. THE LADDER BY THE HATCH TAKES YOU BACK IN.` : `ON THE GROUND. WASD WALKS, SHIFT RUNS, SPACE JUMPS. HOLD F AT A GLOWING PIECE, A PLANT OR A BIG DEPOSIT (VEIN, OUTCROP, WRECK, SEAM) TO COLLECT OR MINE IT. B BUILDS A BASE. F AT THE HATCH TAKES YOU BACK IN.`, { hold: 18000 }); say(`GRAVITY ${(pl.gravity / 9.81).toFixed(2)} G. ${airAdvice(pl)} WATCH O2 AND SUIT, TOP LEFT.`, { delay: 3200, hold: 18000 }); }
  S.eva.tethered = false;
  const g = pl.gravity;
  const { f, r } = flatBasis(S.yaw);
  const wx = f.x * ax.moveF + r.x * ax.moveX, wz = f.z * ax.moveF + r.z * ax.moveX;
  const wl = Math.hypot(wx, wz);
  const heavy = clamp(1.15 - (g - 9.81) / 25, 0.55, 1.15);
  const sprint = ax.boost && ax.moveF > 0.2;
  const speed = WALK_SPEED * (sprint ? SPRINT_MULT : 1) * heavy * (S.P.life.warmth < 30 ? 0.72 : 1);
  const gy = groundLocalY(S.pos) + EYE_H;
  const grounded = S.pos.y <= gy + 0.05;
  const k = Math.min(1, dt * (grounded ? (wl > 0.01 ? 12 : 10) : 1.2));
  const tx = wl > 0.01 ? wx / Math.max(1, wl) * speed : 0, tz = wl > 0.01 ? wz / Math.max(1, wl) * speed : 0;
  S.vel.x += (tx - S.vel.x) * k; S.vel.z += (tz - S.vel.z) * k;
  if (grounded && S.vel.y <= 0) {
    S.vel.y = 0;
    if (held(' ') || held('gp_a')) { S.vel.y = Math.sqrt(2 * g * 1.1); S.noise += 0.8; }
  } else S.vel.y -= g * dt;
  S.pos.addScaledVector(S.vel, dt);
  // the ship: the hull capsule, the legs and built modules push you out
  hullCollide(S.pos, S.vel);
  for (const m of moduleColliders) { _v.copy(S.pos).sub(m.pos); const min = m.r + PLAYER_R; const d = _v.length(); if (d < min && d > 1e-5) S.pos.copy(m.pos).addScaledVector(_v.divideScalar(d), min); }
  if (surfaceHooks.collide) surfaceHooks.collide(S.pos, S.vel);
  const gy2 = groundLocalY(S.pos) + EYE_H;
  if (S.pos.y < gy2) { if (S.vel.y < -9) S.lastImpact = -S.vel.y; S.pos.y = gy2; if (S.vel.y < 0) S.vel.y = 0; }
  // footsteps
  const sp = Math.hypot(S.vel.x, S.vel.z);
  if (grounded && sp > 0.3) { const prev = D.step || 0; D.step = prev + dt * sp * 2.1 / Math.sqrt(heavy); if (Math.floor(prev / Math.PI) !== Math.floor(D.step / Math.PI)) { audio.footstep(sp / WALK_SPEED); S.noise += sprint ? 1.4 : 0.3; } }
  S.exerting = sprint;
  S.thrusting = 0;
}

// suit drains on the surface: multipliers on the space numbers, plus what heat or cold does
export function suitFactors() {
  if (!onSurface() || S.mode !== 'eva') return null;
  const pl = planet();
  const o2 = { none: 1, thin: 0.55, breathable: -0.35, toxic: 1.35 }[pl.atmo];
  const conduct = pl.atmo === 'none' ? 0.7 : 1;
  const heat = conduct * (1 + Math.abs(pl.tempC - 15) / 55);
  return { o2, heat, rad: pl.atmo === 'none' ? 0.6 : 0.15, hot: pl.tempC > 35, atmo: pl.atmo, tempC: pl.tempC };
}

// collecting from the ground: the nearest node within reach
let collectT = 0;
export function surfaceInteract(dt, fHeld, fEdge) {
  const t = terrain.terrain; const p = planetXZ(S.pos);
  let best = null, bd = 3.4;
  for (const n of t.nodes) { const d = Math.hypot(n.x - p.x, n.z - p.z); if (d < bd) { bd = d; best = n; } }
  // surface build: a deposit to mine, a crate, the shelter's cot (whichever is nearer than the nearest small piece)
  if (surfaceHooks.interact && surfaceHooks.interact(dt, fHeld, fEdge, p, best ? bd : Infinity)) { collectT = 0; return true; }
  if (!best) {
    collectT = 0;
    // nothing in reach: say what IS collectable and how far the nearest one is (rocks, hills and spires are scenery)
    let nn = null, nd = 1e9;
    for (const n of t.nodes) { const d = Math.hypot(n.x - p.x, n.z - p.z); if (d < nd) { nd = d; nn = n; } }
    let nl = nn ? ({ ore: 'ORE', ice: 'ICE', salvage: 'SALVAGE', carbon: 'CARBON', fibre: 'PLANT FIBRE', plant: 'AN EDIBLE PLANT', badplant: 'A TOXIC PLANT' }[nn.type] || 'A RESOURCE') : '';
    // the big deposits count too, and they are named with what is left in them
    const dh = surfaceHooks.hint ? surfaceHooks.hint(p) : null;
    if (dh && dh.d < nd) { nd = dh.d; nl = dh.label; nn = nn || {}; }
    if (nn) {
      prompt(`NEAREST RESOURCE: ${nl}, ${Math.round(nd)} M AWAY. WALK UP TO IT AND HOLD F. LOOSE ROCKS, HILLS AND SPIRES ARE SCENERY: NOTHING TO MINE IN THEM.`);
      progressBar(null); return true;
    }
    return false;
  }
  const label = { ore: 'ORE', ice: 'ICE', salvage: 'SALVAGE', carbon: 'CARBON', fibre: 'PLANT FIBRE' }[best.type];
  // v0.5 slice B: a plant is picked, and the scan says in plain words whether it is safe to eat
  if (best.scan) prompt(`HOLD F: COLLECT ${best.name}  //  SCAN: ${best.scan.slice(best.name.length + 2)}`);
  else prompt(`HOLD F: COLLECT ${label}`);
  if (fHeld) {
    collectT += dt; S.harvestTarget = best; S.noise += 1.2 * dt;
    progressBar(Math.min(100, collectT / 1.4 * 100));
    if (collectT >= 1.4) { collectT = 0; collect(best); }
  } else { collectT = 0; progressBar(null); }
  return true;
}
function collect(n) {
  const l = L(), P = S.P;
  const amt = n.type === 'salvage' ? 2 : n.type === 'fibre' ? 3 : n.type === 'plant' || n.type === 'badplant' ? 1 : 1 + Math.round(n.size * 2);
  P.res[n.type] = (P.res[n.type] || 0) + amt;
  if (!l.taken.includes(n.id)) l.taken.push(n.id);
  if (l.taken.length > 400) l.taken.splice(0, l.taken.length - 400);
  terrain.removeNode(n.id);
  audio.pickup(n.type === 'ice' ? 'fuel' : 'scrap');
  if (n.type === 'badplant') {
    flash(`+1 TOXIC PLANT (${n.name}). DO NOT EAT IT.`, 3200);
    if (!P.flags.badPlantSaid) { P.flags.badPlantSaid = true; say(`${n.scan} IT IS KEPT APART IN THE STORES AS A TOXIC PLANT. THE GALLEY WILL NOT SERVE IT UNLESS IT IS ALL YOU HAVE.`, { hold: 16000 }); }
  } else if (n.type === 'plant') {
    flash(`+1 EDIBLE PLANT (${n.name})`, 2400);
    if (!P.flags.plantSaid) { P.flags.plantSaid = true; say(`${n.scan} AT THE GALLEY: COOK (THE LAST STATION) MAKES SALAD OR STEW. A HYDROPONICS BAY ON THE HULL GROWS MORE FROM PLANT FIBRE.`, { hold: 16000 }); }
  } else flash(`+${amt} ${n.type.toUpperCase()}`, 2000);
  emit('harvested', n.type);
}

// ---------------- per frame ----------------
const _sun = new THREE.Vector3(), _cw = new THREE.Vector3(), _lampDir = new THREE.Vector3();
export function update(dt, mouse, ax, fEdge) {
  const l = L();
  if (!l) { if (S.landHelm) { S.landHelm = false; S.helm = false; } S.surfaceInfo = ''; hud(false); return; }
  if (!onSurface()) S.surfaceInfo = '';
  if (S.landHelm && S.helm) {
    if (fEdge && l.phase !== 'descent' && !D.ascend) standUp();
  }
  if (l.phase === 'descent' && !S.paused) descentStep(dt, mouse, ax);
  else if (l.phase === 'landed' && D.ascend > 0) ascendStep(dt);
  if (l.phase === 'orbit' && !terrain.orbitVisible()) placeOrbitView(false);
  hud(true);
}
// after gfx: light the ship for the planet, move the ground rings, the sky
export function lateUpdate(dt, camW) {
  const l = L(); if (!l || l.phase === 'orbit') return;
  const pl = planet();
  if (!S.paused && !S.dying) l.tod = (l.tod + dt / (pl.dayLengthH * 25)) % 1;
  const el = Math.sin(l.tod * Math.PI * 2) * 0.95;
  _sun.set(Math.cos(el) * Math.cos(pl.sunAz), Math.sin(el), Math.cos(el) * Math.sin(pl.sunAz)).normalize();
  const day = THREE.MathUtils.smoothstep(_sun.y, -0.1, 0.18);
  const lampOn = (S.mode === 'eva') && S.eva.lamp && S.eva.power > 0;
  if (lampOn) camera.getWorldDirection(_lampDir);
  const center = l.phase === 'landed' && S.mode === 'eva' ? planetXZ(S.pos) : { x: D.px, z: D.pz };
  terrain.update(new THREE.Vector2(center.x, center.z), camW, _sun, day, lampOn ? { k: 1, dir: _lampDir } : null);
  const h = shipFx.hemi;
  if (h && S.mode !== 'interior') {
    h.position.copy(_sun); h.color.setRGB(...(pl.density ? pl.sky : [0.6, 0.6, 0.65])).lerp(new THREE.Color(1, 0.96, 0.9), 0.5);
    h.groundColor.setRGB(...pl.tint[0]).multiplyScalar(0.5);
    h.intensity = 0.15 + 1.5 * day;
  }
  D.day = day;
  S.surfaceInfo = `${pl.name} "${displayName(pl)}"  //  ${pl.atmo.toUpperCase()} AIR  ${pl.tempC} C  ${(pl.gravity / 9.81).toFixed(2)} G`;
}

// ---------------- HUD ----------------
let hudEl = null, hudHtml = '';
function hud(on) {
  if (!on || (!S.landHelm && phase() !== 'descent')) { if (hudEl && hudEl.style.display !== 'none') hudEl.style.display = 'none'; return; }
  if (!hudEl) {
    hudEl = document.createElement('div'); hudEl.id = 'landHud';
    hudEl.style.cssText = 'position:fixed;left:50%;bottom:9vh;transform:translateX(-50%);min-width:min(620px,92vw);max-width:92vw;padding:12px 16px;background:rgba(6,10,14,.72);border:1px solid rgba(255,179,71,.45);color:#d8e6ee;font:13px/1.45 monospace;letter-spacing:.04em;z-index:30;pointer-events:none';
    document.body.appendChild(hudEl);
  }
  hudEl.style.display = S.paused ? 'none' : 'block';
  const l = L(), K = keys();
  let h = '';
  if (l.phase === 'orbit') {
    const list = planetsHere();
    h += `<div style="color:#ffb347">ORBIT  //  ${l ? hereName(l.hip) : ''}  //  ${list.length} PLANET${list.length > 1 ? 'S' : ''}</div>`;
    list.forEach((p, i) => { h += `<div style="${i === l.pi ? 'color:#fff;background:rgba(255,179,71,.18)' : 'opacity:.7'}">${i + 1}  ${p.name}  <b style="color:#ffcf8a">"${displayName(p)}"</b>  <span style="opacity:.75">${i === l.pi ? scanLine(p) : describe(p)}</span></div>`; });
    h += `<div style="margin-top:6px;opacity:.85">1-${list.length}: CHOOSE   ${K.land}: LAND   K: NAME IT   ${campaign() ? '' : 'N: THE CHART (LEAVE)   '}${K.stand}: STAND UP${campaign() ? ' (BACK ON STATION)' : ''}</div>`;
  } else if (l.phase === 'descent') {
    const c = (v, a, b) => v <= a ? '#7dff9a' : v <= b ? '#ffcf5a' : '#ff5a4a';
    const ang = Math.abs(THREE.MathUtils.radToDeg(D.pitch));
    const gd = (label, v, unit, col, pct) => `<div style="display:flex;gap:10px;align-items:center"><b style="width:92px">${label}</b><span style="display:inline-block;width:160px;height:8px;background:#1a2228"><i style="display:block;height:100%;width:${clamp(pct, 0, 100).toFixed(0)}%;background:${col}"></i></span><span style="color:${col}">${v} ${unit}</span></div>`;
    h += `<div style="color:#ffb347">DESCENT  //  ${planet().name}  //  G ${(planet().gravity / 9.81).toFixed(2)}</div>`;
    h += gd('ALTITUDE', Math.max(0, D.alt).toFixed(0), 'M', '#9fd0ff', D.alt / START_ALT * 100);
    h += gd('DESCENT', (-D.vy).toFixed(1), 'M/S', c(-D.vy, SAFE.vy, HARD.vy), Math.abs(D.vy) / 30 * 100);
    h += gd('FORWARD', D.vf.toFixed(1), 'M/S', c(Math.abs(D.vf), SAFE.vf, HARD.vf), Math.abs(D.vf) / START_VF * 100);
    h += gd('ANGLE', (THREE.MathUtils.radToDeg(D.pitch)).toFixed(0), 'DEG', c(ang, SAFE.ang, HARD.ang), ang / 60 * 100);
    h += gd('RETRO', Math.round(D.thr * 100), '%', '#ffb347', D.thr * 100);
    h += gd('FUEL', Math.round(D.fuel), '%', D.fuel < 20 ? '#ff5a4a' : '#9fd0ff', D.fuel);
    const tip = -D.vy > SAFE.vy * (D.alt < 60 ? 1 : 4) ? `TOO FAST DOWN: HOLD ${K.thr}` : Math.abs(D.vf) > SAFE.vf && D.alt < 250 ? `STILL MOVING FORWARD: NOSE UP (${K.pitch}) AND BURN` : ang > SAFE.ang && D.alt < 40 ? 'LEVEL THE NOSE FOR TOUCHDOWN' : 'GOOD. KEEP IT SLOW AND LEVEL';
    h += `<div style="margin-top:6px">${tip}</div><div style="opacity:.7">SAFE: DOWN < ${SAFE.vy} M/S, FORWARD < ${SAFE.vf} M/S, ANGLE < ${SAFE.ang} DEG &nbsp; G: LANDING ASSIST</div>`;
  } else if (l.phase === 'landed') {
    h += `<div style="color:#ffb347">LANDED  //  ${planet().name}  "${displayName(planet())}"</div><div>${scanLine(planet())}</div>`;
    h += `<div style="margin-top:6px;opacity:.85">${K.land}: TAKE OFF (BACK TO ORBIT)   ${K.stand}: STAND UP (THE AIRLOCK IS AFT)</div>`;
  }
  if (h !== hudHtml) { hudEl.innerHTML = h; hudHtml = h; }
}

function fade(text, ms) {
  const f = $('fader'); if (!f) return;
  f.querySelector('div').textContent = text; f.style.transition = 'none'; f.style.display = 'flex'; f.style.opacity = 1;
  setTimeout(() => { f.style.transition = 'opacity 1.2s ease'; f.style.opacity = 0; setTimeout(() => { f.style.display = 'none'; f.style.transition = ''; }, 1300); }, ms);
}

// ---------------- keys from main.js ----------------
// G at the landing helm: land from orbit, take off from the ground
export function gKey() {
  if (!S.landHelm) return false;
  const p = phase();
  if (p === 'orbit') { beginDescent(); return true; }
  if (p === 'landed') { takeOff(); return true; }
  if (p === 'descent') { D.auto = !D.auto; flash(D.auto ? 'LANDING ASSIST ON: THE SHIP FLIES ITSELF DOWN. PRESS G AGAIN TO FLY IT YOURSELF.' : 'LANDING ASSIST OFF: YOU HAVE THE CONTROLS.', 3400); return true; }
  return true;
}
export function numKey(n) { if (!S.landHelm || phase() !== 'orbit') return false; return enterOrbit(n - 1); }

// ---------------- test surface ----------------
export function debug() {
  const l = L(); const pl = l ? planet() : null;
  return { auto: D.auto, phase: phase(), helm: !!S.landHelm, planet: pl ? { name: pl.name, seed: pl.seed, atmo: pl.atmo, tempC: pl.tempC, gravity: pl.gravity, terrain: pl.terrain } : null, site: l && l.site, taken: l ? l.taken.length : 0, alt: D.alt, vy: D.vy, vf: D.vf, pitch: D.pitch, fuel: D.fuel, thr: D.thr, last: D.lastGrade, ascend: D.ascend, shipPos: ship.position.toArray(), day: D.day, terrain: terrain.stats(), ground: l && l.phase === 'landed' ? groundLocalY(S.pos) : null, orbitVisible: terrain.orbitVisible() };
}
export function testAuto(on) { D.auto = !!on; }
// jump the descent to just above the ground with given speeds (vy positive = down)
export function testFinal(vy, vf, pitchDeg, alt = 0.02) {
  if (phase() !== 'descent') return false;
  const pl = planet(); D.vy = -Math.abs(vy); D.vf = vf; D.pitch = THREE.MathUtils.degToRad(pitchDeg); D.y = groundAt(pl, D.px, D.pz) + LEG + alt; D.thr = 0; D.auto = false; D.fuel = 0;
  return true;
}
export { heightHash, makePlanet, planetsAt, heightSig, scanLine, planetSeed };

// ---------------- the discovery log (VARIETY): every world you orbit is logged; K names it ----------------
const dKey = pl => `${pl.hip}:${pl.index}`;
export function displayName(pl) { const d = S.P.discoveries && S.P.discoveries[dKey(pl)]; return d && d.n ? d.n : pl.alias; }
function discover(pl, landed) {
  const P = S.P; if (!pl) return;
  P.discoveries = P.discoveries || {};
  const k = dKey(pl), fresh = !P.discoveries[k];
  const d = P.discoveries[k] || (P.discoveries[k] = { n: '', t: Math.round(P.stats.timePlayed || 0), landed: false });
  if (landed) d.landed = true;
  if (fresh) flash(`NEW WORLD LOGGED: ${pl.name} ("${pl.alias}"). K: GIVE IT YOUR OWN NAME.`, 4200);
}
export function discoveryList() {
  const P = S.P, out = [];
  for (const k in (P.discoveries || {})) {
    const [hip, pi] = k.split(':').map(Number), pl = planetsAt(hip, starName(hip))[pi]; if (!pl) continue;
    const d = P.discoveries[k];
    out.push({ key: k, name: pl.name, given: d.n || pl.alias, custom: !!d.n, landed: !!d.landed, scan: scanLine(pl), t: d.t });
  }
  return out.sort((a, b) => a.t - b.t);
}
export function nameKey() {
  const l = L(); if (!l || !S.landHelm) return false;
  const pl = planet(); if (!pl || document.getElementById('nameInput')) return true;
  if (document.pointerLockElement) document.exitPointerLock();
  const box = document.createElement('div'); box.id = 'nameBox';
  box.style.cssText = 'position:fixed;left:50%;top:34%;transform:translateX(-50%);padding:12px 16px;background:rgba(6,10,14,.92);border:1px solid #ffb347;color:#ffe0b0;font:13px monospace;z-index:60;letter-spacing:.04em';
  box.innerHTML = `NAME ${pl.name} (NOW "${displayName(pl)}"). ENTER SAVES, ESC CANCELS.<br>`;
  const inp = document.createElement('input'); inp.id = 'nameInput'; inp.maxLength = 24; inp.value = S.P.discoveries && S.P.discoveries[dKey(pl)] && S.P.discoveries[dKey(pl)].n || '';
  inp.style.cssText = 'margin-top:8px;width:320px;background:#0b1218;color:#fff;border:1px solid #6a7a88;font:15px monospace;padding:4px 6px;text-transform:uppercase';
  box.appendChild(inp); document.body.appendChild(box);
  const close = () => { box.remove(); };
  inp.addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') { setWorldName(pl, inp.value); close(); }
    else if (e.key === 'Escape') close();
  });
  inp.addEventListener('keyup', e => e.stopPropagation());
  setTimeout(() => inp.focus(), 0);
  return true;
}
export function cleanName(s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9 '\-]/g, '').replace(/\s+/g, ' ').trim().slice(0, 24); }
export function setWorldName(pl, s) {
  const P = S.P; discover(pl, false);
  const n = cleanName(s);
  P.discoveries[dKey(pl)].n = n;
  flash(n ? `${pl.name} IS NOW "${n}" IN YOUR DISCOVERY LOG.` : `${pl.name}: NAME CLEARED.`, 3200);
  hudHtml = ''; doAutosave(true);
  return n;
}
