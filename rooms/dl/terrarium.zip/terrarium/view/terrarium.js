export const TERRARIUM = (() => {
  const W = 900, H = 600, DT = 0.5;
  const P = { vrest: -52, vth: -45, vreset: -52, tau: 20, refr: 2.2, tsyn: 5 };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dist = (a, b, c, d) => { const x = a - c, y = b - d; return Math.sqrt(x * x + y * y); };
  const wrapA = a => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
  class Neuron {
    constructor(name, o = {}) {
      this.name = name; this.tau = o.tau || P.tau; this.vth = o.vth || P.vth;
      this.v = P.vrest + Math.random() * 3; this.g = 0; this.ref = 0; this.spikes = 0; this.lastT = -1e9;
    }
    step(iext, T) {
      this.g *= EG;
      if (this.ref > 0) { this.ref -= DT; this.v = P.vreset; return false; }
      this.v += DT / this.tau * ((P.vrest - this.v) + iext + this.g);
      if (this.v >= this.vth) { this.v = P.vreset; this.ref = P.refr; this.spikes++; this.lastT = T; return true; }
      return false;
    }
  }
  const noise = (s = 6) => (Math.random() - 0.5) * s;
  const EG = Math.exp(-DT / P.tsyn);
  const POND = { x: 660, y: 430, rx: 190, ry: 120 };
  const HIVE = { x: 120, y: 90 }, NEST = { x: 130, y: 520 }, LAMP = { x: 450, y: 60 }, WEB = { x: 820, y: 90 };
  const FLOWERS = [{ x: 300, y: 150 }, { x: 520, y: 300 }, { x: 250, y: 330 }, { x: 420, y: 500 }];
  const inPond = (x, y) => ((x - POND.x) / POND.rx) ** 2 + ((y - POND.y) / POND.ry) ** 2 < 1;
  const pondEdge = (x, y) => ((x - POND.x) / POND.rx) ** 2 + ((y - POND.y) / POND.ry) ** 2;
  const GW = 45, GH = 30, CW = W / GW, CH = H / GH; const phero = new Float32Array(GW * GH);
  const pheroAt = (x, y) => { const i = clamp(Math.floor(x / CW), 0, GW - 1), j = clamp(Math.floor(y / CH), 0, GH - 1); return phero[j * GW + i]; };
  const pheroAdd = (x, y, v) => { const i = clamp(Math.floor(x / CW), 0, GW - 1), j = clamp(Math.floor(y / CH), 0, GH - 1); phero[j * GW + i] = Math.min(3, phero[j * GW + i] + v); };
  const S = {
    T: 0, born: Date.now(), scents: [], seeds: [], ripples: [], flashes: [], chirps: [], honey: 0, log: [],
    spikesTotal: 0, meals: 0, syncEvents: 0, seedsCaught: 0
  };
  const hourNow = () => { const d = new Date(); return d.getHours() + d.getMinutes() / 60; };
  let hcAt = -1e9, hc = 12;
  const hourCached = () => { const t = performance.now(); if (t - hcAt > 1000 || t < hcAt) { hcAt = t; hc = hourNow(); } return hc; };
  const daylight = () => { const h = hourCached(); if (h < 5 || h > 21) return 0; if (h < 7) return (h - 5) / 2; if (h > 19) return (21 - h) / 2; return 1; };
  const lampOn = () => daylight() < 0.35;
  const isDusk = () => { const d = daylight(); return d > 0.05 && d < 0.6; };
  const scentAt = (x, y) => { let o = 0; for (const s of S.scents) o += s.s * Math.exp(-dist(x, y, s.x, s.y) / 110); for (const f of FLOWERS) o += 0.55 * Math.exp(-dist(x, y, f.x, f.y) / 90); return o; };
  const flowerAt = (x, y) => { let o = 0; for (const f of FLOWERS) o += Math.exp(-dist(x, y, f.x, f.y) / 90); return o; };
  const hiveAt = (x, y) => Math.exp(-dist(x, y, HIVE.x, HIVE.y) / 160);
  const nestAt = (x, y) => Math.exp(-dist(x, y, NEST.x, NEST.y) / 160);
  const lightAt = (x, y) => (lampOn() ? 1.4 * Math.exp(-dist(x, y, LAMP.x, LAMP.y) / 140) : 0) + daylight() * 0.4;
  const soundAt = (x, y) => { let o = 0; for (const c of S.chirps) if (S.T - c.t < 900) o += Math.exp(-dist(x, y, c.x, c.y) / 220); return o; };
  const rippleAt = (x, y) => { let o = 0; for (const r of S.ripples) { const age = S.T - r.t; if (age < 2500) o += Math.exp(-Math.abs(dist(x, y, r.x, r.y) - age * 0.06) / 25) * (1 - age / 2500); } return o; };
  class Animal {
    constructor(spec, x, y, tag, genome) {
      this.spec = spec; this.tag = tag || spec.name; this.x = x; this.y = y; this.a = rnd(-Math.PI, Math.PI); this.v = 0;
      this.born = S.T; this.spikes = 0; this.meals = 0; this.mem = Object.assign({}, spec.mem || {});
      this.fired = {}; this.trail = [];
      this.genome = genome || cloneG(spec.founderG || refGenome(spec));
      this.id = 0; this.gen = 0; this.par = []; this.en = 1; this.lastBreed = -1e12; this.d = 0; this._m0 = 0;
      this.lifeSpan = EVO.life * rnd(0.8, 1.2) * (spec.lifeK || 1);
      this.setTraits();
      if (spec.brain) { this.brain = new Brain(spec.ref, this.genome); this.N = this.brain.pseudo; this.S = []; this.keys = []; this.src = []; }
      else this.wire();
    }
    wire() {
      const sp = this.spec, G = this.genome, del = new Set(G.del || []), alias = {};
      const w = (G.w && G.w.length === sp.synapses.length) ? G.w : sp.synapses.map(s => s[2]);
      this.N = {};
      for (const [n, o] of Object.entries(sp.neurons)) {
        if (del.has(n)) continue;
        const q = G.np && G.np[n];
        this.N[n] = new Neuron(n, q ? { tau: (o.tau || P.tau) * q[0], vth: (o.vth || P.vth) + q[1] } : o);
      }
      const base = sp.synapses.map(([p, q], i) => [p, q, w[i]]), syn = base.slice();
      (G.dup || []).forEach((src, k) => {
        if (!sp.neurons[src]) return;
        const nm = src + "'" + (k + 1); this.N[nm] = new Neuron(nm, sp.neurons[src]); alias[nm] = src;
        for (const [p, q, ww] of base) { if (p === src) syn.push([nm, q, ww]); if (q === src) syn.push([p, nm, ww]); }
      });
      this.S = syn.filter(([p, q]) => this.N[p] && this.N[q]);
      this.keys = Object.keys(this.N); this.src = this.keys.map(k => alias[k] || k);
    }
    setTraits() {
      const t = this.genome.t, sp = this.spec;
      this.size = t.size; this.sizeK = t.size / sp.size; this.spd = t.speed; this.hue = t.hue;
      this.color = tint(sp.baseColor || sp.color, t.hue);
      this.mK = Math.pow(this.sizeK, 0.75) * (0.7 + 0.3 * t.speed);
    }
    step() {
      if (this.brain) return this.cstep();
      const spec = this.spec, ext = spec.sense(this);
      const f = this.fired; let any = false; const N = this.N, ks = this.keys, src = this.src;
      for (let i = 0; i < ks.length; i++) { const k = ks[i], fk = N[k].step(ext[src[i]] || 0, S.T); f[k] = fk; if (fk) { this.spikes++; S.spikesTotal++; any = true; } }
      if (any) for (const [pre, post, w] of this.S) if (f[pre]) this.N[post].g += w;
      spec.motor(this, f);
      this.walls();
    }
    walls() {
      if (this.x < 14) { this.x = 14; this.a = Math.PI - this.a; } if (this.x > W - 14) { this.x = W - 14; this.a = Math.PI - this.a; }
      if (this.y < 14) { this.y = 14; this.a = -this.a; } if (this.y > H - 14) { this.y = H - 14; this.a = -this.a; }
    }
    cstep() {
      const sp = this.spec, B = this.brain, ev = Math.max(BR.every, B.R.minEvery);
      if (B.exact) {
        const ex = ev * (B.R.validated && !sp.slowFirst ? 1 : BR.uEvery);
        if ((STEP + this.id) % ex === 0) {
          const t0 = performance.now();
          xSense(this, B);
          const ns = B.advance(DT, this);
          if (ns) { this.spikes += ns; S.spikesTotal += ns; }
          BR.acc += performance.now() - t0;
        }
        xMotor(this, B);
        this.walls();
        return;
      }
      if ((STEP + this.id) % ev === 0) {
        const t0 = performance.now();
        cSense(this, B);
        const ns = B.step(DT * ev, this);
        if (ns) { this.spikes += ns; S.spikesTotal += ns; }
        BR.acc += performance.now() - t0;
      }
      cMotor(this, B);
      this.walls();
    }
    move(turn, push, damp) { this.a = wrapA(this.a + turn); this.v = this.v * damp + push * 0.02 * (this.spd || 1); this.x += Math.cos(this.a) * this.v; this.y += Math.sin(this.a) * this.v; }
  }
  const steerNeurons = (extra = {}) => Object.assign({ sL: {}, sR: {}, dL: {}, dR: {}, mL: {}, mR: {}, pace: {} }, extra);
  const steerSyn = (wS = 34, wX = -26, wM = 30, wP = 28) => [["sL", "dL", wS], ["sR", "dR", wS], ["sL", "dR", wX], ["sR", "dL", wX], ["dL", "mL", wM], ["dR", "mR", wM], ["pace", "mL", wP], ["pace", "mR", wP]];
  const antennae = (an, field, reach = 14, spread = 0.7) => [field(an.x + reach * Math.cos(an.a - spread), an.y + reach * Math.sin(an.a - spread)), field(an.x + reach * Math.cos(an.a + spread), an.y + reach * Math.sin(an.a + spread))];
  const walk = (an, f, o = {}) => {
    let turn = 0, push = 0; const tk = o.turn || 0.12, pk = o.push || 0.6;
    if (f.mL) { turn -= tk; push += pk; } if (f.mR) { turn += tk; push += pk; } if (f.pace) push += (o.pacePush ?? 0.1);
    if (o.still) { push *= 0.05; turn *= 0.2; }
    an.move(turn, push * (o.gain || 1), o.damp || 0.997);
  };
  const SPECIES = {};
  SPECIES.fly = {
    name: "fly", plural: "flies", legs: 6, color: "#f4f7fa", size: 9,
    neurons: steerNeurons({ sat: {}, groom: {} }),
    synapses: steerSyn().concat([["sat", "groom", 36], ["groom", "mL", -45], ["groom", "mR", -45], ["groom", "pace", -30]]),
    mem: { groomUntil: 0 },
    sense(an) { const [l, r] = antennae(an, scentAt); return { sL: 2 + l * 40 + noise(), sR: 2 + r * 40 + noise(), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 8.2 + noise(0.3), sat: S.T < an.mem.groomUntil ? 12 : 0 }; },
    motor(an, f) {
      walk(an, f, { still: S.T < an.mem.groomUntil });
      for (const s of S.scents) if (s.s > 0 && dist(an.x, an.y, s.x, s.y) < 12) { s.s = 0; an.meals++; S.meals++; an.mem.groomUntil = S.T + 2500; note(an.tag + " found a scent and is grooming"); }
    },
    draw(c, an) { body(c, an, "#f4f7fa"); wings(c, an, S.T < an.mem.groomUntil ? 0.9 : 0.25); }
  };
  SPECIES.ant = {
    name: "ant", plural: "ants", color: "#c2553a", size: 7,
    neurons: steerNeurons({ carry: { tau: 400 } }),
    synapses: steerSyn(30, -22, 30, 26),
    mem: { carrying: false },
    sense(an) {
      const home = an.mem.carrying; const field = home ? (x, y) => nestAt(x, y) * 1.2 + pheroAt(x, y) * 0.5 : (x, y) => scentAt(x, y) * 0.9 + pheroAt(x, y) * 0.7;
      const [l, r] = antennae(an, field, 12, 0.8);
      return { sL: 3 + l * 30 + noise(5), sR: 3 + r * 30 + noise(5), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 8.4 + noise(0.3), carry: home ? 9 : 0 };
    },
    motor(an, f) {
      walk(an, f, { turn: 0.1, push: 0.45, damp: 0.996 });
      if (an.mem.carrying) { if (Math.random() < 0.02) pheroAdd(an.x, an.y, 0.06); if (dist(an.x, an.y, NEST.x, NEST.y) < 16) { an.mem.carrying = false; an.meals++; S.meals++; } }
      else for (const s of S.scents) if (s.s > 0.3 && dist(an.x, an.y, s.x, s.y) < 12) { s.s -= 0.3; an.mem.carrying = true; note(an.tag + " picked up a crumb and turned for the nest"); }
    },
    draw(c, an) { body(c, an, an.mem.carrying ? "#e8845f" : "#c2553a", 3); }
  };
  SPECIES.moth = {
    name: "moth", plural: "moths", color: "#d9cfae", size: 9,
    neurons: steerNeurons({ rest: {} }),
    synapses: steerSyn(36, -20, 30, 30).concat([["rest", "pace", -30], ["rest", "mL", -20], ["rest", "mR", -20]]),
    sense(an) { const [l, r] = antennae(an, lightAt, 16, 0.6); const day = daylight(); return { sL: 2 + l * 26 + noise(), sR: 2 + r * 26 + noise(), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 9 + noise(0.3), rest: day > 0.6 ? 10 : 0 }; },
    motor(an, f) { walk(an, f, { turn: 0.16, push: 0.8, damp: 0.995, pacePush: 0.15 }); },
    draw(c, an) { body(c, an, "#d9cfae"); wings(c, an, 0.6, "#e6dcc0"); }
  };
  SPECIES.firefly = {
    name: "firefly", plural: "fireflies", color: "#b9c76a", size: 7,
    neurons: steerNeurons({ osc: { tau: 900, vth: -45.5 } }),
    synapses: steerSyn(20, -10, 26, 24).concat([["osc", "pace", 12]]),
    mem: { seen: 0 },
    sense(an) {
      const night = daylight() < 0.35; let seen = 0;
      for (const fl of S.flashes) if (S.T - fl.t < 140 && fl.who !== an && dist(an.x, an.y, fl.x, fl.y) < 260) seen += 1;
      an.mem.seen = seen;
      const [l, r] = antennae(an, (x, y) => Math.exp(-dist(x, y, POND.x - 120, POND.y - 200) / 300), 12, 0.7);
      return { sL: 2 + l * 6 + noise(4), sR: 2 + r * 6 + noise(4), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: night ? 7.4 + noise(0.3) : 3, osc: night ? 7.9 + seen * 3.5 : 0 };
    },
    motor(an, f) { walk(an, f, { turn: 0.14, push: 0.5, damp: 0.996 }); if (f.osc) { S.flashes.push({ x: an.x, y: an.y, t: S.T, who: an }); if (an.mem.seen >= 3) { S.syncEvents++; if (Math.random() < 0.05) note("the fireflies are flashing together"); } } },
    draw(c, an) { const lit = S.T - an.N.osc.lastT < 220; if (lit) { c.fillStyle = "rgba(220,255,120,0.35)"; c.beginPath(); c.arc(an.x, an.y, 22, 0, 7); c.fill(); } body(c, an, lit ? "#f2ffa0" : "#8a9650", 3); }
  };
  SPECIES.cricket = {
    name: "cricket", plural: "crickets", color: "#6b5b3e", size: 8,
    neurons: steerNeurons({ song: { tau: 600 } }),
    synapses: steerSyn(34, -26, 30, 22).concat([["song", "pace", -8]]),
    mem: { male: true },
    sense(an) {
      const sing = an.mem.male && (isDusk() || daylight() < 0.35);
      const [l, r] = an.mem.male ? antennae(an, (x, y) => 0.3 * Math.exp(-dist(x, y, 200, 420) / 250), 12, 0.7) : antennae(an, soundAt, 16, 0.8);
      return { sL: 2 + l * 30 + noise(5), sR: 2 + r * 30 + noise(5), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: (an.mem.male ? 6.5 : 8) + noise(0.3), song: sing ? 8.3 : 0 };
    },
    motor(an, f) { walk(an, f, { turn: 0.1, push: 0.5, damp: 0.996, pacePush: 0.06 }); if (f.song) S.chirps.push({ x: an.x, y: an.y, t: S.T }); },
    draw(c, an) { body(c, an, "#6b5b3e", 3); if (an.mem.male && S.T - an.N.song.lastT < 300) { c.strokeStyle = "rgba(255,230,150,0.6)"; c.lineWidth = 1; for (let k = 1; k <= 2; k++) { c.beginPath(); c.arc(an.x, an.y, 12 * k, -0.6, 0.6); c.stroke(); } } }
  };
  SPECIES.snail = {
    name: "snail", plural: "snails", color: "#a88b6a", size: 9,
    neurons: steerNeurons({ touch: {}, hide: { tau: 800 } }),
    synapses: steerSyn(30, -20, 30, 20).concat([["touch", "hide", 40], ["hide", "mL", -50], ["hide", "mR", -50], ["hide", "pace", -40]]),
    mem: { hidden: 0 },
    sense(an) {
      const damp = (x, y) => Math.exp(-((pondEdge(x, y) - 1.15) ** 2) * 6) + 0.2 * (1 - daylight());
      const [l, r] = antennae(an, damp, 10, 0.8); let touched = 0;
      for (const o of ANIMALS) if (o !== an && dist(o.x, o.y, an.x, an.y) < 13) touched = 1;
      if (S.pointer && dist(S.pointer.x, S.pointer.y, an.x, an.y) < 24) touched = 1;
      an.mem.hidden = S.T - an.N.hide.lastT < 3000 ? 1 : 0;
      return { sL: 2 + l * 14 + noise(4), sR: 2 + r * 14 + noise(4), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 7 + noise(0.2), touch: touched ? 14 : 0 };
    },
    motor(an, f) { if (f.touch && !an.mem.hidden) note(an.tag + " pulled into its shell"); walk(an, f, { turn: 0.08, push: 0.18, damp: 0.99, pacePush: 0.03, still: !!an.mem.hidden }); },
    draw(c, an) { c.fillStyle = "#a88b6a"; c.beginPath(); c.arc(an.x - 3 * Math.cos(an.a), an.y - 3 * Math.sin(an.a), 6, 0, 7); c.fill(); c.strokeStyle = "#6f5a44"; c.lineWidth = 1; c.beginPath(); c.arc(an.x - 3 * Math.cos(an.a), an.y - 3 * Math.sin(an.a), 3.5, 0, 5); c.stroke(); if (!an.mem.hidden) { c.fillStyle = "#c9b28f"; c.beginPath(); c.ellipse(an.x + 4 * Math.cos(an.a), an.y + 4 * Math.sin(an.a), 6, 2.5, an.a, 0, 7); c.fill(); } }
  };
  SPECIES.bee = {
    name: "bee", plural: "bees", color: "#e3b334", size: 8,
    neurons: steerNeurons({ full: { tau: 500 } }),
    synapses: steerSyn(34, -26, 30, 28),
    mem: { nectar: 0 },
    sense(an) {
      const home = an.mem.nectar >= 3; const field = home ? hiveAt : flowerAt; const [l, r] = antennae(an, field, 16, 0.7);
      return { sL: 2 + l * 34 + noise(), sR: 2 + r * 34 + noise(), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: (daylight() > 0.3 ? 9 : 4) + noise(0.3), full: home ? 8 : 0 };
    },
    motor(an, f) {
      walk(an, f, { turn: 0.15, push: 0.75, damp: 0.995, pacePush: 0.14 });
      if (an.mem.nectar < 3) for (const fl of FLOWERS) if (dist(an.x, an.y, fl.x, fl.y) < 10 && Math.random() < 0.01) { an.mem.nectar++; }
      if (an.mem.nectar >= 3 && dist(an.x, an.y, HIVE.x, HIVE.y) < 14) { S.honey += an.mem.nectar; an.mem.nectar = 0; an.meals++; S.meals++; note(an.tag + " brought nectar home, honey " + S.honey); }
    },
    draw(c, an) { body(c, an, "#e3b334", 3); c.strokeStyle = "#2b2b2b"; c.lineWidth = 1.5; for (const k of [-2, 1]) { c.beginPath(); c.moveTo(an.x + k * Math.cos(an.a) - 3 * Math.sin(an.a), an.y + k * Math.sin(an.a) + 3 * Math.cos(an.a)); c.lineTo(an.x + k * Math.cos(an.a) + 3 * Math.sin(an.a), an.y + k * Math.sin(an.a) - 3 * Math.cos(an.a)); c.stroke(); } wings(c, an, 0.5, "rgba(255,255,255,0.7)"); }
  };
  SPECIES.strider = {
    name: "water strider", plural: "water striders", color: "#8fb3c9", size: 8,
    neurons: steerNeurons({ edge: {} }),
    synapses: steerSyn(30, -20, 30, 18).concat([["edge", "dL", 30], ["edge", "mL", 20]]),
    sense(an) { const [l, r] = antennae(an, rippleAt, 18, 0.9); const e = pondEdge(an.x, an.y); return { sL: 2 + l * 40 + noise(5), sR: 2 + r * 40 + noise(5), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 7.5 + noise(0.3), edge: e > 0.8 ? 14 : 0 }; },
    motor(an, f) { walk(an, f, { turn: 0.2, push: 0.9, damp: 0.994, pacePush: 0.05 }); if (!inPond(an.x, an.y)) { const ang = Math.atan2(POND.y - an.y, POND.x - an.x); an.a = ang; an.x += Math.cos(ang) * 2; an.y += Math.sin(ang) * 2; } },
    draw(c, an) { c.strokeStyle = "#8fb3c9"; c.lineWidth = 1; for (const s of [-1, 1]) for (const k of [-4, 0, 5]) { c.beginPath(); c.moveTo(an.x + k * Math.cos(an.a), an.y + k * Math.sin(an.a)); c.lineTo(an.x + k * Math.cos(an.a) - s * 11 * Math.sin(an.a), an.y + k * Math.sin(an.a) + s * 11 * Math.cos(an.a)); c.stroke(); } body(c, an, "#8fb3c9", 2); }
  };
  SPECIES.minnow = {
    name: "minnow", plural: "minnows", color: "#b7c9d6", size: 8,
    neurons: steerNeurons({ edge: {} }),
    synapses: steerSyn(28, -18, 30, 24).concat([["edge", "dL", 34], ["edge", "mL", 18]]),
    sense(an) {
      let ax = 0, ay = 0, cx = 0, cy = 0, n = 0;
      for (const o of ANIMALS) if (o !== an && o.spec === an.spec) { const d = dist(o.x, o.y, an.x, an.y); if (d < 90) { ax += Math.cos(o.a); ay += Math.sin(o.a); cx += o.x; cy += o.y; n++; } }
      let l = 0, r = 0;
      if (n) { const want = Math.atan2(ay / n + (cy / n - an.y) * 0.02, ax / n + (cx / n - an.x) * 0.02); const d = wrapA(want - an.a); l = Math.max(0, -d); r = Math.max(0, d); }
      const e = pondEdge(an.x, an.y);
      return { sL: 2 + l * 12 + noise(5), sR: 2 + r * 12 + noise(5), dL: 4 + noise(0.6), dR: 4 + noise(0.6), mL: 1 + noise(0.4), mR: 1 + noise(0.4), pace: 8.6 + noise(0.3), edge: e > 0.75 ? 14 : 0 };
    },
    motor(an, f) { walk(an, f, { turn: 0.09, push: 0.55, damp: 0.996, pacePush: 0.12 }); if (!inPond(an.x, an.y)) { const ang = Math.atan2(POND.y - an.y, POND.x - an.x); an.a = ang; an.x += Math.cos(ang) * 2; an.y += Math.sin(ang) * 2; } },
    draw(c, an) { c.fillStyle = "#b7c9d6"; c.beginPath(); c.ellipse(an.x, an.y, 7, 2.6, an.a, 0, 7); c.fill(); c.beginPath(); c.moveTo(an.x - 6 * Math.cos(an.a), an.y - 6 * Math.sin(an.a)); c.lineTo(an.x - 10 * Math.cos(an.a) - 3 * Math.sin(an.a), an.y - 10 * Math.sin(an.a) + 3 * Math.cos(an.a)); c.lineTo(an.x - 10 * Math.cos(an.a) + 3 * Math.sin(an.a), an.y - 10 * Math.sin(an.a) - 3 * Math.cos(an.a)); c.fill(); }
  };
  SPECIES.frog = {
    name: "frog", plural: "frogs", color: "#5f9a4f", size: 12,
    neurons: { bug: {}, hop: { tau: 300 }, turnL: {}, turnR: {}, pace: {} },
    synapses: [["bug", "hop", 45], ["bug", "pace", -10]],
    mem: { snapUntil: 0, target: null },
    sense(an) {
      let best = null, bd = 80;
      for (const sd of S.seeds) { const d = dist(sd.x, sd.y, an.x, an.y); const ahead = Math.abs(wrapA(Math.atan2(sd.y - an.y, sd.x - an.x) - an.a)) < 1.2; if (d < bd && ahead && sd.vx * sd.vx + sd.vy * sd.vy > 0.0004) { bd = d; best = sd; } }
      an.mem.target = best;
      const d = best ? wrapA(Math.atan2(best.y - an.y, best.x - an.x) - an.a) : 0;
      return { bug: best ? 12 + noise(2) : 1 + noise(2), hop: 0, turnL: best && d < -0.15 ? 9 : 0, turnR: best && d > 0.15 ? 9 : 0, pace: 6.6 + noise(1.2) };
    },
    motor(an, f) {
      if (f.turnL) an.a -= 0.1; if (f.turnR) an.a += 0.1;
      if (f.hop && an.mem.target) { const t = an.mem.target; const d = dist(t.x, t.y, an.x, an.y); if (d < 46) { S.seeds.splice(S.seeds.indexOf(t), 1); an.meals++; S.seedsCaught++; an.mem.snapUntil = S.T + 250; note(an.tag + " snapped up a drifting seed"); } else { an.x += Math.cos(an.a) * 9; an.y += Math.sin(an.a) * 9; } }
      else if (f.pace && Math.random() < 0.004) { an.a += rnd(-0.5, 0.5); }
      if (pondEdge(an.x, an.y) < 0.85) { an.x += (an.x - POND.x) * 0.02; an.y += (an.y - POND.y) * 0.02; }
    },
    draw(c, an) { c.fillStyle = "#5f9a4f"; c.beginPath(); c.ellipse(an.x, an.y, 11, 8, an.a, 0, 7); c.fill(); c.fillStyle = "#e9f2d8"; for (const s of [-1, 1]) { c.beginPath(); c.arc(an.x + 6 * Math.cos(an.a) - s * 4 * Math.sin(an.a), an.y + 6 * Math.sin(an.a) + s * 4 * Math.cos(an.a), 2.2, 0, 7); c.fill(); } if (S.T < an.mem.snapUntil && an.mem.target) { c.strokeStyle = "#e07a8a"; c.lineWidth = 2; c.beginPath(); c.moveTo(an.x, an.y); c.lineTo(an.mem.target.x, an.mem.target.y); c.stroke(); } }
  };
  SPECIES.spider = {
    name: "spider", plural: "spiders", color: "#3b3b46", size: 9,
    neurons: { vib: {}, run: { tau: 250 }, home: {}, calm: { tau: 2000 } },
    synapses: [["vib", "run", 40], ["run", "calm", 6], ["calm", "run", -30]],
    mem: { spot: null },
    sense(an) {
      let vib = 0, spot = null;
      if (S.pointer && dist(S.pointer.x, S.pointer.y, WEB.x, WEB.y) < 70) { vib = 1; spot = S.pointer; }
      for (const sd of S.seeds) if (dist(sd.x, sd.y, WEB.x, WEB.y) < 60) { vib = 1; spot = sd; }
      if (Math.random() < 0.0004) { vib = 0.5; spot = { x: WEB.x + rnd(-50, 50), y: WEB.y + rnd(-50, 50) }; }
      if (spot) an.mem.spot = spot;
      const away = dist(an.x, an.y, WEB.x, WEB.y);
      return { vib: 3.5 + vib * 12 + noise(4), run: 0, home: away > 8 ? 8 : 0, calm: 0 };
    },
    motor(an, f) {
      if (f.run && an.mem.spot) { const t = an.mem.spot, d = dist(t.x, t.y, an.x, an.y); if (d > 4) { const ang = Math.atan2(t.y - an.y, t.x - an.x); an.a = ang; an.x += Math.cos(ang) * 6; an.y += Math.sin(ang) * 6; } else { note("the spider checked a tug on the web and went back"); an.mem.spot = null; } }
      else if (f.home) { const ang = Math.atan2(WEB.y - an.y, WEB.x - an.x); an.a = ang; an.x += Math.cos(ang) * 1.5; an.y += Math.sin(ang) * 1.5; }
      if (dist(an.x, an.y, WEB.x, WEB.y) > 64) { const ang = Math.atan2(WEB.y - an.y, WEB.x - an.x); an.x += Math.cos(ang) * 3; an.y += Math.sin(ang) * 3; }
    },
    draw(c, an) { c.strokeStyle = "#3b3b46"; c.lineWidth = 1; for (let k = 0; k < 4; k++) { const t = an.a + 0.5 + k * 0.7; c.beginPath(); c.moveTo(an.x - 9 * Math.cos(t), an.y - 9 * Math.sin(t)); c.lineTo(an.x + 9 * Math.cos(t), an.y + 9 * Math.sin(t)); c.stroke(); } c.fillStyle = "#3b3b46"; c.beginPath(); c.arc(an.x, an.y, 4, 0, 7); c.fill(); c.beginPath(); c.arc(an.x - 5 * Math.cos(an.a), an.y - 5 * Math.sin(an.a), 5, 0, 7); c.fill(); }
  };
  function body(c, an, col, legLen = 6) { c.save(); c.translate(an.x, an.y); c.rotate(an.a); c.fillStyle = col; c.beginPath(); c.ellipse(0, 0, an.spec.size, an.spec.size * 0.5, 0, 0, 7); c.fill(); c.beginPath(); c.arc(an.spec.size, 0, an.spec.size * 0.35, 0, 7); c.fill(); c.strokeStyle = col; c.lineWidth = 1; for (const s of [-1, 1]) { for (const lx of [-an.spec.size * 0.5, 0, an.spec.size * 0.5]) { c.beginPath(); c.moveTo(lx, s * 2.5); c.lineTo(lx - 2, s * (2.5 + legLen)); c.stroke(); } c.beginPath(); c.moveTo(an.spec.size + 1, s * 1.2); c.lineTo(an.spec.size + 6, s * 4); c.stroke(); } c.restore(); }
  function wings(c, an, spread, col = "rgba(255,255,255,0.35)") { c.save(); c.translate(an.x, an.y); c.rotate(an.a); c.fillStyle = col; c.beginPath(); c.ellipse(-3, -5, 8, 3, -spread, 0, 7); c.fill(); c.beginPath(); c.ellipse(-3, 5, 8, 3, spread, 0, 7); c.fill(); c.restore(); }
  const fresh = (n, ms) => !!n && (S.T - n.lastT) < ms;
  const lean = (an, ms) => {
    const l = an.N.sL, r = an.N.sR; if (!l || !r) return 0;
    const dl = S.T - l.lastT, dr = S.T - r.lastT;
    if (dl > ms && dr > ms) return 0;
    return dl < dr ? -1 : 1;
  };
  SPECIES.fly.state = an => {
    if (S.T < an.mem.groomUntil) return "cleaning itself after a meal";
    const s = lean(an, 400); if (s) return s < 0 ? "smells food to its left" : "smells food to its right";
    return "wandering, sniffing for food";
  };
  SPECIES.ant.state = an => {
    if (an.mem.carrying) return "carrying a crumb home";
    if (pheroAt(an.x, an.y) > 0.12) return "following the ant trail";
    if (lean(an, 400)) return "smells food nearby";
    return "out looking for food";
  };
  SPECIES.moth.state = an => {
    if (fresh(an.N.rest, 300) || daylight() > 0.6) return "resting, it is daytime";
    if (!lampOn()) return "fluttering in the dusk";
    return dist(an.x, an.y, LAMP.x, LAMP.y) < 70 ? "circling the lamp light"
         : (lean(an, 400) ? "flying toward the lamp" : "looking for a light");
  };
  SPECIES.firefly.state = an => {
    if (fresh(an.N.osc, 220)) return an.mem.seen >= 3 ? "flashing with the others" : "flashing its light";
    if (daylight() >= 0.35) return "resting, it is daytime";
    if (an.mem.seen >= 3) return "sees " + an.mem.seen + " others flashing";
    return "resting, it is dark";
  };
  SPECIES.cricket.state = an => {
    if (an.mem.male){
      if (fresh(an.N.song, 400)) return "singing to find a mate";
      return (isDusk() || daylight() < 0.35) ? "resting between chirps" : "quiet until evening";
    }
    if (lean(an, 500)) return "walking toward the song";
    return "listening for a song";
  };
  SPECIES.snail.state = an => {
    if (an.mem.hidden) return "hiding in its shell";
    const e = pondEdge(an.x, an.y);
    return (e > 1.0 && e < 1.4) ? "resting on damp ground" : "looking for damp ground";
  };
  SPECIES.bee.state = an => {
    const k = an.mem.nectar, dh = dist(an.x, an.y, HIVE.x, HIVE.y);
    if (k >= 3) return dh < 40 ? "at the hive, making honey" : "full of nectar, flying home";
    if (dh < 22) return "resting at the hive";
    if (flowerAt(an.x, an.y) > 0.6) return k ? "filling up on nectar (" + k + " of 3)" : "drinking nectar from a flower";
    return daylight() > 0.3 ? "out looking for flowers" : "flying slow, it is dark";
  };
  SPECIES.strider.state = an => {
    if (lean(an, 400)) return "chasing a ripple";
    if (fresh(an.N.edge, 300)) return "turning away from the bank";
    return "skating on the water";
  };
  SPECIES.minnow.state = an => {
    if (fresh(an.N.edge, 300)) return "turning away from the bank";
    let n = 0; for (const o of ANIMALS) if (o !== an && o.spec === an.spec && dist(o.x, o.y, an.x, an.y) < 90) n++;
    return n ? "swimming with " + n + (n === 1 ? " other" : " others") : "swimming alone";
  };
  SPECIES.frog.state = an => {
    if (S.T < an.mem.snapUntil) return "caught a seed!";
    if (fresh(an.N.hop, 300)) return "jumping at a seed";
    if (an.mem.target) return "watching a seed drift by";
    return "sitting by the water";
  };
  SPECIES.spider.state = an => {
    if (fresh(an.N.run, 300) && an.mem.spot) return "running to a tug on its web";
    if (dist(an.x, an.y, WEB.x, WEB.y) > 10) return "walking back to its web";
    return fresh(an.N.vib, 250) ? "feels the web shaking" : "waiting in its web";
  };
  function stateOf(an){
    try { return (an && an.spec && an.spec.state) ? an.spec.state(an) : ""; }
    catch (e){ return ""; }
  }
  const ANIMALS = [];
  const FOUNDING = [
    ["fly", 1, () => [450, 330]],
    ["ant", 6, i => [NEST.x + rnd(-20, 20), NEST.y + rnd(-20, 20)]],
    ["moth", 2, i => [rnd(300, 600), rnd(120, 220)]],
    ["firefly", 5, i => [rnd(380, 560), rnd(180, 320)]],
    ["cricket", 2, i => [rnd(160, 260), rnd(380, 460)], i => ({ male: i === 0 })],
    ["snail", 2, i => [POND.x - 230 + i * 40, POND.y + 20]],
    ["bee", 3, i => [HIVE.x + rnd(-15, 15), HIVE.y + rnd(-15, 15)]],
    ["strider", 2, i => [POND.x + rnd(-80, 80), POND.y + rnd(-50, 50)]],
    ["minnow", 5, i => [POND.x + rnd(-100, 100), POND.y + rnd(-60, 60)]],
    ["frog", 1, () => [POND.x - POND.rx - 8, POND.y - 30]],
    ["spider", 1, () => [WEB.x, WEB.y]]
  ];
  function populate() {
    ANIMALS.length = 0; let k = 0;
    for (const [key, n, place, memf] of FOUNDING) {
      const sp = SPECIES[key]; sp.place = place; sp.founders = n; sp.foundMem = memf || null;
      for (let i = 0; i < n; i++) {
        const [x, y] = place(i);
        const an = makeAnimal(sp, x, y, cloneG(sp.founderG), { tag: n === 1 ? sp.name : sp.name + " " + (i + 1), mut: "founder" });
        if (memf) Object.assign(an.mem, memf(i));
        k++;
      }
      S.evo.tagN[key] = n;
    }
    return k;
  }
  const NOTE_AT = new Map();
  function note(t, key) { const k = key || t.split(' ').slice(0, 2).join(' '); const last = NOTE_AT.get(k) || -1e9; if (S.T - last < 4000) return; NOTE_AT.set(k, S.T); S.log.unshift({ t: Date.now(), text: t }); if (S.log.length > 40) S.log.length = 40; }
  const IO_KEYS = ["sense_L", "sense_R", "touch_front", "touch_back", "food", "motor_L", "motor_R", "forward", "backward", "feed", "nose"];
  const G_SL = 0, G_SR = 1, G_TF = 2, G_TB = 3, G_FOOD = 4, G_ML = 5, G_MR = 6, G_FWD = 7, G_BWD = 8, G_FEED = 9, G_NOSE = 10, NIO = IO_KEYS.length;
  const SENSOR_GROUPS = [G_SL, G_SR, G_TF, G_TB, G_FOOD, G_NOSE];
  const EVO = {
    lifeScale: 1, totalCap: 60, speciateAt: 0.35, recsMax: 2000, eventsMax: 300,
    mature: 6 * 60e3, life: 90 * 60e3, cooldown: 8 * 60e3, starve: 30 * 60e3,
    enMax: 1.5, breedAt: 1.0, breedCost: 0.45, childEn: 0.6, meal: 0.2, graze: 0.75, nicheK: 2
  };
  const BR = { every: 1, maxEvery: 4, uEvery: 1, maxU: 16, budget: 4, acc: 0, brainMs: 0, tickMs: 0, maxTickMs: 0, frames: 0, slowed: 0 };
  let STEP = 0, popVer = 0;
  const LAWNS = [{ x: 215, y: 440, r: 42 }, { x: 470, y: 565, r: 36 }];
  const freshEvo = () => ({ nextId: 1, recs: [], sum: {}, events: [], fam: {}, tagN: {}, species: {}, births: 0, deaths: 0, founders: 0 });
  S.evo = freshEvo();
  const REC_BY_ID = new Map();
  const PENDING = [];
  const PENDING_SPECIES = [];
  const gauss = () => { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); };
  const pick = a => a[(Math.random() * a.length) | 0];
  function parseCol(s) {
    if (s[0] === "#") { let h = s.slice(1); if (h.length === 3) h = h.replace(/./g, "$&$&"); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255, 1]; }
    const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null;
    const p = m[1].split(",").map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
  }
  function hueRot(p, deg) {
    const r = p[0] / 255, g = p[1] / 255, b = p[2] / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
    if (mx === mn) return [p[0], p[1], p[2]];
    const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    let h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6;
    h = ((h + deg / 360) % 1 + 1) % 1;
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, pp = 2 * l - q;
    const f = t => { t = (t % 1 + 1) % 1; return t < 1 / 6 ? pp + (q - pp) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? pp + (q - pp) * (2 / 3 - t) * 6 : pp; };
    return [f(h + 1 / 3), f(h), f(h - 1 / 3)].map(x => Math.round(clamp(x, 0, 1) * 255));
  }
  const TINT = new Map();
  function tint(col, deg) {
    deg = Math.round(deg || 0); if (!deg || typeof col !== "string") return col;
    const key = col + "|" + deg; let o = TINT.get(key); if (o !== undefined) return o;
    const p = parseCol(col); o = col;
    if (p) { const c = hueRot(p, deg); o = p[3] >= 1 ? "#" + c.map(x => x.toString(16).padStart(2, "0")).join("") : "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + p[3] + ")"; }
    if (TINT.size > 5000) TINT.clear(); TINT.set(key, o); return o;
  }
  class TintCtx {
    constructor() { this.c = null; this.h = 0; }
    set fillStyle(v) { this.c.fillStyle = tint(v, this.h); } get fillStyle() { return this.c.fillStyle; }
    set strokeStyle(v) { this.c.strokeStyle = tint(v, this.h); } get strokeStyle() { return this.c.strokeStyle; }
    set lineWidth(v) { this.c.lineWidth = v; } get lineWidth() { return this.c.lineWidth; }
    set lineCap(v) { this.c.lineCap = v; } get lineCap() { return this.c.lineCap; }
    set lineJoin(v) { this.c.lineJoin = v; } get lineJoin() { return this.c.lineJoin; }
    beginPath() { this.c.beginPath(); } closePath() { this.c.closePath(); } fill() { this.c.fill(); } stroke() { this.c.stroke(); }
    moveTo(x, y) { this.c.moveTo(x, y); } lineTo(x, y) { this.c.lineTo(x, y); }
    arc(x, y, r, a0, a1, ccw) { this.c.arc(x, y, r, a0, a1, !!ccw); }
    ellipse(x, y, rx, ry, rot, a0, a1, ccw) { this.c.ellipse(x, y, rx, ry, rot, a0, a1, !!ccw); }
    save() { this.c.save(); } restore() { this.c.restore(); } translate(x, y) { this.c.translate(x, y); } rotate(a) { this.c.rotate(a); } scale(x, y) { this.c.scale(x, y); }
    fillRect(x, y, w, h) { this.c.fillRect(x, y, w, h); } strokeRect(x, y, w, h) { this.c.strokeRect(x, y, w, h); }
  }
  const TC = new TintCtx();
  const rootOf = sp => SPECIES[sp.rootKey] || sp;
  function refGenome(sp) {
    const t = { size: sp.size, speed: 1, hue: 0 };
    if (sp.brain) return { k: "c", sig: sp.ref ? sp.ref.sig : "", t, wd: new Map(), pv: new Map(), dup: [], del: [] };
    return { k: "h", t, w: sp.synapses.map(s => s[2]), np: {}, dup: [], del: [] };
  }
  function cloneG(g) {
    if (g.k === "c") return { k: "c", sig: g.sig, t: Object.assign({}, g.t), wd: new Map(g.wd), pv: new Map(g.pv), dup: g.dup.slice(), del: g.del.slice() };
    const np = {}; for (const k in g.np) np[k] = g.np[k].slice();
    return { k: "h", t: Object.assign({}, g.t), w: g.w.slice(), np, dup: g.dup.slice(), del: g.del.slice() };
  }
  function packG(g) {
    if (g.k === "c") return { k: "c", sig: g.sig, t: { size: +g.t.size.toFixed(3), speed: +g.t.speed.toFixed(4), hue: +g.t.hue.toFixed(2) }, wd: [...g.wd].map(([e, m]) => [e, +m.toFixed(4)]), pv: [...g.pv].map(([i, d]) => [i, +d.toFixed(3)]), dup: g.dup, del: g.del };
    return { k: "h", t: { size: +g.t.size.toFixed(3), speed: +g.t.speed.toFixed(4), hue: +g.t.hue.toFixed(2) }, w: g.w.map(x => +x.toFixed(3)), np: g.np, dup: g.dup, del: g.del };
  }
  function unpackG(o) {
    if (!o || !o.t) return null;
    if (o.k === "c") return { k: "c", sig: o.sig || "", t: Object.assign({}, o.t), wd: new Map(o.wd || []), pv: new Map(o.pv || []), dup: (o.dup || []).slice(), del: (o.del || []).slice() };
    return { k: "h", t: Object.assign({}, o.t), w: (o.w || []).slice(), np: JSON.parse(JSON.stringify(o.np || {})), dup: (o.dup || []).slice(), del: (o.del || []).slice() };
  }
  function mutate(g, sp) {
    const m = [], root = rootOf(sp);
    if (g.k === "h") {
      const n = g.w.length;
      if (n) { const k = Math.max(1, Math.round(n * 0.03)); for (let j = 0; j < k; j++) { const i = (Math.random() * n) | 0; g.w[i] *= 1 + rnd(-0.05, 0.05); } m.push("w" + k); }
      if (Math.random() < 0.3) {
        const nm = pick(Object.keys(sp.neurons)), q = g.np[nm] || [1, 0];
        if (Math.random() < 0.5) q[0] = clamp(q[0] * Math.exp(gauss() * 0.05), 0.7, 1.4); else q[1] = clamp(q[1] + gauss() * 0.25, -2, 2);
        g.np[nm] = q; m.push("p:" + nm);
      }
      const inter = (sp.inter || []).filter(x => sp.neurons[x]);
      if (inter.length && g.dup.length < 4 && Math.random() < 0.03) { const s = pick(inter); g.dup.push(s); m.push("dup:" + s); }
      else if (Math.random() < 0.02) {
        if (g.dup.length && Math.random() < 0.6) { const i = (Math.random() * g.dup.length) | 0; m.push("del:" + g.dup[i] + "'"); g.dup.splice(i, 1); }
        else { const c = inter.filter(x => g.dup.includes(x) && !g.del.includes(x)); if (c.length) { const s = pick(c); g.del.push(s); m.push("del:" + s); } }
      }
    } else {
      const R = sp.ref, E = R.E;
      if (E) { const k = clamp(Math.round(E * 0.02), 1, 150); for (let j = 0; j < k; j++) { const e = (Math.random() * E) | 0; g.wd.set(e, (g.wd.get(e) || 1) * (1 + rnd(-0.05, 0.05))); } m.push("w" + k); }
      if (Math.random() < 0.3 && R.nonIO.length) { const i = pick(R.nonIO); g.pv.set(i, clamp((g.pv.get(i) || 0) + gauss() * 0.25, -2, 2)); m.push("p:" + R.names[i]); }
      const free = R.nonIO;
      if (free.length && g.dup.length < 6 && Math.random() < 0.03) { const s = pick(free); if (!g.del.includes(s)) { g.dup.push(s); m.push("dup:" + R.names[s]); } }
      else if (free.length && g.del.length < 30 && Math.random() < 0.02) { const s = pick(free); if (!g.del.includes(s) && !g.dup.includes(s)) { g.del.push(s); m.push("del:" + R.names[s]); } }
    }
    const t = g.t, s0 = t.size, v0 = t.speed, h0 = t.hue;
    t.size = clamp(t.size * Math.exp(gauss() * 0.03), root.size * 0.6, root.size * 1.6);
    t.speed = clamp(t.speed * Math.exp(gauss() * 0.03), 0.6, 1.6);
    t.hue += gauss() * 5;
    m.push("size" + fmtPct(t.size / s0 - 1), "speed" + fmtPct(t.speed / v0 - 1), "hue" + (t.hue - h0 >= 0 ? "+" : "") + (t.hue - h0).toFixed(1));
    return m.join(" ");
  }
  const fmtPct = x => (x >= 0 ? "+" : "") + (x * 100).toFixed(1) + "%";
  function msetDiff(a, b) { const c = new Map(); for (const x of a) c.set(x, (c.get(x) || 0) + 1); for (const x of b) c.set(x, (c.get(x) || 0) - 1); let n = 0; for (const v of c.values()) n += Math.abs(v); return n; }
  function distG(a, b, sp) {
    const tr = Math.hypot(Math.log(a.t.size / b.t.size), Math.log(a.t.speed / b.t.speed), (a.t.hue - b.t.hue) / 60);
    let br = 0, pr = 0;
    if (a.k === "h" && b.k === "h") {
      const n = Math.min(a.w.length, b.w.length); let s = 0;
      for (let i = 0; i < n; i++) s += Math.abs(a.w[i] - b.w[i]) / Math.max(1, Math.abs(b.w[i]));
      br = n ? 2 * s / n : 0;
      let q = 0; for (const k of new Set([...Object.keys(a.np), ...Object.keys(b.np)])) { const x = a.np[k] || [1, 0], y = b.np[k] || [1, 0]; q += Math.abs(Math.log(x[0] / y[0])) + Math.abs(x[1] - y[1]) / 2; }
      pr = q / Math.max(1, Object.keys(sp.neurons).length);
    } else if (a.k === "c" && b.k === "c" && sp.ref) {
      let s = 0; for (const e of new Set([...a.wd.keys(), ...b.wd.keys()])) s += Math.abs((a.wd.get(e) || 1) - (b.wd.get(e) || 1));
      br = 2 * s / Math.max(1, sp.ref.E);
      let q = 0; for (const i of new Set([...a.pv.keys(), ...b.pv.keys()])) q += Math.abs((a.pv.get(i) || 0) - (b.pv.get(i) || 0)) / 2;
      pr = q / Math.max(1, sp.ref.N);
    }
    return tr + br + pr + 0.1 * (msetDiff(a.dup, b.dup) + msetDiff(a.del, b.del));
  }
  const num = (x, d) => (typeof x === "number" && isFinite(x)) ? x : d;
  function buildRef(j, file) {
    if (!j || !Array.isArray(j.neurons) || !Array.isArray(j.synapses)) throw new Error("not a brain file (needs neurons[] and synapses[])");
    const N = j.neurons.length, pos = new Map();
    j.neurons.forEach((n, k) => pos.set(n && n.i != null ? n.i : k, k));
    const at = i => { const p = pos.get(i); return p === undefined ? -1 : p; };
    const M = j.neuron_model || {};
    const P2 = { vrest: num(M.vrest, P.vrest), vth: num(M.vth, P.vth), vreset: num(M.vreset, P.vreset), tau: num(M.tau, P.tau), refr: num(M.refr, P.refr), tsyn: num(M.tsyn, P.tsyn), dt: num(M.dt, DT),
      delay: num(M.delay, 1.8), kick: num(M.poisson_kick_mV, 68.75), stimHz: num(M.stim_rate_hz, 200), spikelet: num(M.spikelet_mV_per_g, 3.5) };
    const exact = typeof j.update_rule === "string" && j.update_rule.length > 0;
    const graded = exact && M.type === "graded";
    if (graded) Object.assign(P2, { vrest: num(M.E_L, -35), vreset: num(M.E_L, -35), vth: num(M.V_th, -18), dt: num(M.dt, 0.5) });
    const syn = j.synapses, L = syn.length, pre = new Int32Array(L), post = new Int32Array(L), ww = new Float64Array(L), deg = new Int32Array(N);
    let E = 0;
    for (let k = 0; k < L; k++) { const s = syn[k]; if (!s) continue; const a = at(s[0]), b = at(s[1]), w = +s[2] * (graded && +s[3] < 0 ? -1 : 1); if (a < 0 || b < 0 || !isFinite(w) || w === 0) continue; pre[E] = a; post[E] = b; ww[E] = w; deg[a]++; E++; }
    const rowPtr = new Int32Array(N + 1); for (let i = 0; i < N; i++) rowPtr[i + 1] = rowPtr[i] + deg[i];
    const fill = rowPtr.slice(0, N), col = new Int32Array(E), w = new Float64Array(E);
    for (let e = 0; e < E; e++) { const k = fill[pre[e]]++; col[k] = post[e]; w[k] = ww[e]; }
    const nMass = new Float64Array(N); let totMass = 0;
    for (let i = 0; i < N; i++) for (let e = rowPtr[i]; e < rowPtr[i + 1]; e++) { const a = Math.abs(w[e]); nMass[i] += a; nMass[col[e]] += a; totMass += a; }
    const gp = (j.gap || []).map(g => g && [at(g[0]), at(g[1]), +g[2]]).filter(g => g && g[0] >= 0 && g[1] >= 0 && g[0] !== g[1] && isFinite(g[2]) && g[2] !== 0);
    const ga = Int32Array.from(gp, g => g[0]), gb = Int32Array.from(gp, g => g[1]), gg = Float64Array.from(gp, g => g[2]);
    const gdeg = new Int32Array(N); for (const q of gp) { gdeg[q[0]]++; gdeg[q[1]]++; }
    const gRow = new Int32Array(N + 1); for (let i = 0; i < N; i++) gRow[i + 1] = gRow[i] + gdeg[i];
    const gf = gRow.slice(0, N), gCol = new Int32Array(gRow[N]), gW = new Float64Array(gRow[N]);
    for (const q of gp) { let k = gf[q[0]]++; gCol[k] = q[1]; gW[k] = q[2]; k = gf[q[1]]++; gCol[k] = q[0]; gW[k] = q[2]; }
    const io = [], mask = new Uint16Array(N), isIO = new Uint8Array(N), jio = j.io || {};
    IO_KEYS.forEach((k, b) => { const arr = Int32Array.from([...new Set((jio[k] || []).map(at).filter(x => x >= 0))]); io.push(arr); for (const x of arr) { mask[x] |= 1 << b; isIO[x] = 1; } });
    const nonIO = [], ioAll = []; for (let i = 0; i < N; i++) (isIO[i] ? ioAll : nonIO).push(i);
    const sens = new Set(); for (const b of SENSOR_GROUPS) for (const x of io[b]) sens.add(x);
    const names = j.neurons.map((n, k) => String((n && (n.name || n.ext_id)) || ("n" + k)));
    let h = (E * 31 + N) | 0; const stride = Math.max(1, E >> 8);
    for (let e = 0; e < E; e += stride) h = (Math.imul(h, 31) + col[e] * 7 + Math.round(w[e] * 1000)) | 0;
    return {
      id: String(j.id || file), file, source: String(j.source || ""), license: String(j.license || ""), note: String(j.note || ""), validation: j.validation || null,
      N, E, rowPtr, col, w, ga, gb, gg, gRow, gCol, gW, io, mask, isIO, ioAll: Int32Array.from(ioAll), nonIO: Int32Array.from(nonIO), names, P: P2,
      exact, graded, GM: graded ? {
        EL: num(M.E_L, -35), Ee: num(M.E_exc, 0), Ei: num(M.E_inh, -45), tau: num(M.tau_m, 100), taus: num(M.tau_s, 10), dt: num(M.dt, 0.5), Is: num(M.I_stim, 20),
        chem: num(M.chem_scale, 0.03), gap: num(M.gap_scale, 0.003), vth: num(M.V_th, -18), slope: num(M.slope, 1.5), settle: num(M.settle_ms, 2000) } : null,
      validated: !!(j.validation && j.validation.result === "pass"), sensAll: Int32Array.from([...sens].sort((a, b) => a - b)), nMass, totMass,
      minEvery: Math.max(1, Math.round(P2.dt / DT)), sig: N + ":" + E + ":" + (h >>> 0).toString(36)
    };
  }
  function brainDrift(R, g) {
    if (!R || !g || !R.totMass) return 0;
    let dm = 0; const span = Math.max(1, R.P.vth - R.P.vrest);
    for (const [e, m] of g.wd || []) if (e >= 0 && e < R.E) dm += Math.abs(R.w[e]) * Math.abs(m - 1);
    for (const i of g.del || []) if (i >= 0 && i < R.N && !R.isIO[i]) dm += R.nMass[i];
    for (const s of g.dup || []) if (s >= 0 && s < R.N) dm += R.nMass[s];
    for (const [i, d] of g.pv || []) if (i >= 0 && i < R.N && !R.isIO[i]) dm += R.nMass[i] * Math.min(1, Math.abs(d) / span);
    return Math.min(1, dm / R.totMass);
  }
  const driftPct = x => { const p = x * 100; return p <= 0 ? "0%" : p < 0.1 ? "under 0.1%" : p.toFixed(1) + "%"; };
  class Brain {
    constructor(R, g) {
      this.R = R; const N0 = R.N, dup = (g.dup || []).filter(s => s >= 0 && s < N0), N = N0 + dup.length; this.N = N;
      const wR = new Float64Array(R.w);
      for (const [e, m] of g.wd) if (e >= 0 && e < R.E) wR[e] *= m;
      if (!dup.length) { this.rowPtr = R.rowPtr; this.col = R.col; this.w = wR; this.mask = R.mask; }
      else {
        const dupOf = new Map(); dup.forEach((s, k) => { if (!dupOf.has(s)) dupOf.set(s, []); dupOf.get(s).push(N0 + k); });
        const deg = new Int32Array(N);
        for (let i = 0; i < N0; i++) for (let e = R.rowPtr[i]; e < R.rowPtr[i + 1]; e++) { deg[i]++; const d = dupOf.get(R.col[e]); if (d) deg[i] += d.length; }
        dup.forEach((s, k) => { deg[N0 + k] = R.rowPtr[s + 1] - R.rowPtr[s]; });
        const rp = new Int32Array(N + 1); for (let i = 0; i < N; i++) rp[i + 1] = rp[i] + deg[i];
        const col = new Int32Array(rp[N]), w = new Float32Array(rp[N]); let k = 0;
        for (let i = 0; i < N0; i++) for (let e = R.rowPtr[i]; e < R.rowPtr[i + 1]; e++) { col[k] = R.col[e]; w[k++] = wR[e]; const d = dupOf.get(R.col[e]); if (d) for (const x of d) { col[k] = x; w[k++] = wR[e]; } }
        dup.forEach(s => { for (let e = R.rowPtr[s]; e < R.rowPtr[s + 1]; e++) { col[k] = R.col[e]; w[k++] = wR[e]; } });
        this.rowPtr = rp; this.col = col; this.w = w; this.mask = new Uint16Array(N); this.mask.set(R.mask);
      }
      const P2 = R.P;
      this.v = new Float32Array(N); for (let i = 0; i < N; i++) this.v[i] = P2.vrest + Math.random() * 3;
      this.g = new Float32Array(N); this.rf = new Float32Array(N); this.ext = new Float32Array(N);
      this.vth = new Float64Array(N).fill(P2.vth);
      for (const [i, d] of g.pv) if (i >= 0 && i < N && !(i < N0 && R.isIO[i])) this.vth[i] += d;
      for (const i of g.del || []) if (i >= 0 && i < N0 && !R.isIO[i]) this.vth[i] = Infinity;
      this.gi = R.ga.length ? new Float32Array(N) : null;
      this.spk = new Int32Array(N);
      this.cnt = new Float32Array(NIO); this.rate = new Float32Array(NIO); this.lastFire = new Float64Array(NIO).fill(-1e9);
      this.has = R.io.map(a => a.length > 0);
      this.pseudo = {}; this.pz = [];
      IO_KEYS.forEach((k, b) => { const o = { name: k, v: P2.vreset, vth: P2.vth, lastT: -1e9, spikes: 0 }; this.pz.push(o); if (this.has[b]) this.pseudo[k] = o; });
      this._dt = 0; this._eg = 1; this._rk = 1;
      this.drift = brainDrift(R, g);
      this.exact = false; this.graded = false;
      if (R.graded) this.initGraded(N, g);
      else if (R.exact) this.initExact(N);
    }
    initGraded(N, g) {
      const R = this.R, M = R.GM, N0 = R.N;
      this.exact = true; this.graded = true; this.dt = M.dt;
      const del = new Set((g.del || []).filter(i => i >= 0 && i < N0 && !R.isIO[i]));
      const K = R.ga.length, gG = new Float64Array(K), gs = new Float64Array(N);
      for (let k = 0; k < K; k++) { const a = R.ga[k], b = R.gb[k]; if (del.has(a) || del.has(b)) continue; gG[k] = M.gap * R.gg[k]; gs[a] += gG[k]; gs[b] += gG[k]; }
      this.gG = gG; this.gapsum = gs;
      const gW = new Float64Array(R.gW.length);
      for (let i = 0; i < N0; i++) for (let e = R.gRow[i]; e < R.gRow[i + 1]; e++) gW[e] = (del.has(i) || del.has(R.gCol[e])) ? 0 : M.gap * R.gW[e];
      this.gWs = gW;
      const rp = this.rowPtr, col = this.col, w = this.w, cE = new Int32Array(N + 1), cI = new Int32Array(N + 1);
      for (let j = 0; j < N; j++) for (let e = rp[j]; e < rp[j + 1]; e++) (w[e] < 0 ? cI : cE)[col[e] + 1]++;
      for (let i = 0; i < N; i++) { cE[i + 1] += cE[i]; cI[i + 1] += cI[i]; }
      const fE = cE.slice(0, N), fI = cI.slice(0, N), pE = new Int32Array(cE[N]), gEa = new Float64Array(cE[N]), pI = new Int32Array(cI[N]), gIa = new Float64Array(cI[N]);
      for (let j = 0; j < N; j++) for (let e = rp[j]; e < rp[j + 1]; e++) { const i = col[e]; if (w[e] < 0) { const k = fI[i]++; pI[k] = j; gIa[k] = M.chem * -w[e]; } else { const k = fE[i]++; pE[k] = j; gEa[k] = M.chem * w[e]; } }
      this.inE = cE; this.preE = pE; this.gEx = gEa; this.inI = cI; this.preI = pI; this.gIn = gIa;
      this.V = new Float64Array(N); this.sA = new Float64Array(N);
      this.ge = new Float64Array(N); this.gi2 = new Float64Array(N); this.gj = new Float64Array(N); this.Iext = new Float64Array(N);
      this.lev = new Float64Array(NIO); this.levOn = false; this.ivalid = false;
      this.cntN = new Float64Array(N); this.tot = new Float64Array(NIO); this.s = 0; this.idle = false; this.feedSince = 0; this.brainMs = 0;
      const plain = !g.wd.size && !g.pv.size && !(g.dup || []).length && !(g.del || []).length;
      const fwd = R.io[G_FWD], bwd = R.io[G_BWD], mean = (idx) => { let t = 0; for (let k = 0; k < idx.length; k++) t += this.V[idx[k]]; return idx.length ? t / idx.length : 0; };
      if (plain && R.gSettled) { this.V.set(R.gSettled.V); this.sA.set(R.gSettled.s); this.baseF = R.gSettled.bF; this.baseB = R.gSettled.bB; }
      else {
        this.V.fill(M.EL); for (let i = 0; i < N; i++) this.sA[i] = 1 / (1 + Math.exp(-(M.EL - this.vth[i]) / M.slope));
        const n = Math.round(M.settle / M.dt); for (let q = 0; q < n; q++) this.gSub();
        this.baseF = mean(fwd); this.baseB = mean(bwd);
        if (plain) R.gSettled = { V: Float64Array.from(this.V), s: Float64Array.from(this.sA), bF: this.baseF, bB: this.baseB };
      }
      this.fwdDrive = 0; this.bwdDrive = 0; this.gMean = mean;
    }
    gSub() {
      const M = this.R.GM, N = this.N, V = this.V, sA = this.sA, ge = this.ge, gi = this.gi2, gj = this.gj, I = this.Iext, vth = this.vth;
      const inE = this.inE, preE = this.preE, gEx = this.gEx, inI = this.inI, preI = this.preI, gIn = this.gIn;
      const gRow = this.R.gRow, gCol = this.R.gCol, gW = this.gWs, gs = this.gapsum, N0 = this.R.N;
      for (let i = 0; i < N; i++) {
        let x = 0; for (let e = inE[i], e1 = inE[i + 1]; e < e1; e++) x += sA[preE[e]] * gEx[e]; ge[i] = x;
        let y = 0; for (let e = inI[i], e1 = inI[i + 1]; e < e1; e++) y += sA[preI[e]] * gIn[e]; gi[i] = y;
      }
      for (let i = 0; i < N0; i++) { let z = 0; for (let e = gRow[i], e1 = gRow[i + 1]; e < e1; e++) z += gW[e] * V[gCol[e]]; gj[i] = z; }
      const a = M.dt / M.tau, bs = M.dt / M.taus, EL = M.EL, Ee = M.Ee, Ei = M.Ei, sl = M.slope;
      for (let i = 0; i < N; i++) {
        const gE = ge[i], gI = gi[i];
        V[i] = (V[i] + a * (EL + gE * Ee + gI * Ei + gj[i] + I[i])) / (1 + a * (1 + gE + gI + gs[i]));
      }
      for (let i = 0; i < N; i++) sA[i] += bs * (1 / (1 + Math.exp(-(V[i] - vth[i]) / sl)) - sA[i]);
    }
    setLevel(b, level) { const v = clamp(+level || 0, 0, 1); if (this.lev[b] !== v) { this.lev[b] = v; this.ivalid = false; } }
    advanceGraded(ms, an) {
      const R = this.R, M = R.GM, n = Math.round(ms / this.dt);
      if (!this.ivalid) {
        const I = this.Iext; I.fill(0); this.levOn = false;
        for (let b = 0; b < NIO; b++) { const L = this.lev[b]; if (!L) continue; this.levOn = true; const a = R.io[b]; for (let k = 0; k < a.length; k++) I[a[k]] += M.Is * L; }
        this.ivalid = true;
      }
      for (let q = 0; q < n; q++) this.gSub();
      this.s += n; this.brainMs += n * this.dt;
      this.fwdDrive = this.gMean(R.io[G_FWD]) - this.baseF; this.bwdDrive = this.gMean(R.io[G_BWD]) - this.baseB;
      for (let b = 0; b < NIO; b++) { if (!this.has[b]) continue; const o = this.pz[b]; o.v = this.gMean(R.io[b]); if (this.lev[b]) { o.lastT = S.T; this.lastFire[b] = S.T; } }
      return 0;
    }
    initExact(N) {
      const R = this.R, P2 = R.P, dt = P2.dt;
      this.exact = true; this.dt = dt;
      this.xa = Math.exp(-dt / P2.tau); this.xb = Math.exp(-dt / P2.tsyn); this.xc = P2.tsyn / (P2.tsyn - P2.tau) * (this.xb - this.xa);
      this.v = new Float64Array(N).fill(P2.vrest); this.g = new Float64Array(N);
      this.last = new Float64Array(N).fill(-1e15);
      this.rfs = new Int32Array(N).fill(Math.round(P2.refr / dt));
      for (const i of R.sensAll) this.rfs[i] = 0;
      this.dly = Math.max(1, Math.round(P2.delay / dt));
      this.ring = []; for (let k = 0; k < this.dly; k++) this.ring.push(new Int32Array(N));
      this.rlen = new Int32Array(this.dly); this.pend = 0;
      this.cur = new Int32Array(N); this.fl = new Uint8Array(N);
      this.pp = new Float64Array(N); this.stimOn = false;
      this.cntN = new Float64Array(N); this.tot = new Float64Array(NIO);
      this.gv = R.ga.length ? new Float64Array(N) : null;
      this.s = 0; this.idle = true; this.feedSince = 0; this.brainMs = 0;
    }
    clearStim() { if (this.graded) { for (let b = 0; b < NIO; b++) this.setLevel(b, 0); return; } const a = this.R.sensAll, pp = this.pp; for (let k = 0; k < a.length; k++) pp[a[k]] = 0; this.stimOn = false; }
    setStim(b, hz) {
      if (this.graded) return this.setLevel(b, hz > 0 ? 1 : 0);
      const a = this.R.io[b], p = hz * this.dt / 1000, pp = this.pp;
      for (let k = 0; k < a.length; k++) if (p > pp[a[k]]) pp[a[k]] = p;
      if (p > 0 && a.length) { this.stimOn = true; this.idle = false; }
    }
    advance(ms, an) {
      if (this.graded) return this.advanceGraded(ms, an);
      const n = Math.round(ms / this.dt); let ns = 0;
      this.brainMs += n * this.dt;
      if (this.idle && !this.stimOn) { this.s += n; this.groupRates(n * this.dt, an); return 0; }
      const R = this.R, P2 = R.P, N = this.N, v = this.v, g = this.g, last = this.last, rfs = this.rfs, vth = this.vth;
      const fl = this.fl, pp = this.pp, sens = R.sensAll, cntN = this.cntN, cur = this.cur, cnt = this.cnt;
      const a = this.xa, b = this.xb, c = this.xc, v0 = P2.vrest, vre = P2.vreset, kick = P2.kick;
      const rp = this.rowPtr, col = this.col, w = this.w, mask = this.mask, dly = this.dly, ring = this.ring, rlen = this.rlen;
      const gv = this.gv, ga = R.ga, gb = R.gb, gg = R.gg, sk = P2.spikelet, gdt = this.dt / P2.tau, NG = ga.length;
      for (let q = 0; q < n; q++) {
        const s = this.s;
        if (gv) { gv.fill(0); for (let k = 0; k < NG; k++) { const p = ga[k], r = gb[k], d = gg[k] * (v[r] - v[p]); gv[p] += d; gv[r] -= d; } }
        let m = 0;
        for (let i = 0; i < N; i++) {
          if (s - last[i] < rfs[i]) continue;
          let vi = v0 + (v[i] - v0) * a + g[i] * c;
          if (gv) vi += gdt * gv[i];
          v[i] = vi; g[i] *= b;
          if (vi > vth[i]) cur[m++] = i;
        }
        const slot = s % dly, old = ring[slot], on = rlen[slot];
        for (let k = 0; k < on; k++) { const x = old[k]; for (let e = rp[x], e1 = rp[x + 1]; e < e1; e++) g[col[e]] += w[e]; }
        this.pend -= on;
        if (gv && m) {
          const gr = R.gRow, gc = R.gCol, gw = R.gW;
          for (let k = 0; k < m; k++) { const x = cur[k]; if (x < R.N) for (let e = gr[x], e1 = gr[x + 1]; e < e1; e++) v[gc[e]] += sk * gw[e]; }
        }
        if (this.stimOn) for (let k = 0; k < sens.length; k++) { const i = sens[k]; if (pp[i] > 0 && Math.random() < pp[i]) v[i] += kick; }
        for (let k = 0; k < m; k++) {
          const i = cur[k]; v[i] = vre; g[i] = 0; last[i] = s; old[k] = i; cntN[i]++;
          const mk = mask[i]; if (mk) for (let bb = 0; bb < NIO; bb++) if (mk & (1 << bb)) cnt[bb]++;
        }
        rlen[slot] = m; this.pend += m; ns += m;
        this.s = s + 1;
      }
      this.feedSince += cnt[G_FEED];
      this.groupRates(n * this.dt, an);
      if (!this.stimOn && this.pend === 0) {
        let rest = true;
        for (let i = 0; i < N; i++) if (Math.abs(v[i] - v0) > 1e-9 || Math.abs(g[i]) > 1e-9) { rest = false; break; }
        if (rest) { v.fill(v0); g.fill(0); this.idle = true; }
      } else this.idle = false;
      return ns;
    }
    groupRates(dt, an) {
      if (dt !== this._dt) { this._dt = dt; this._rk = Math.exp(-dt / 80); }
      const rk = this._rk, io = this.R.io, T = S.T, rate = this.rate, pz = this.pz, cnt = this.cnt, P2 = this.R.P, span = P2.vth - P2.vreset;
      for (let b = 0; b < NIO; b++) {
        const n = io[b].length; if (!n) continue;
        const c = cnt[b]; rate[b] = rate[b] * rk + (1 - rk) * c / (n * dt);
        const o = pz[b];
        if (c) { this.lastFire[b] = T; o.lastT = T; o.spikes += c; this.tot[b] += c; if (an && an.rec) an.rec.push([T, IO_KEYS[b]]); }
        o.v = P2.vreset + span * Math.min(1, rate[b] / 0.05);
        cnt[b] = 0;
      }
    }
    clearIn() { const a = this.R.ioAll, x = this.ext; for (let k = 0; k < a.length; k++) x[a[k]] = 0; }
    drive(b, mv, nz) { const a = this.R.io[b], x = this.ext; for (let k = 0; k < a.length; k++) x[a[k]] += mv + (nz ? (Math.random() - 0.5) * nz : 0); }
    step(dt, an) {
      const R = this.R, P2 = R.P, N = this.N, v = this.v, g = this.g, rf = this.rf, ext = this.ext, vth = this.vth, spk = this.spk;
      if (dt !== this._dt) { this._dt = dt; this._eg = Math.exp(-dt / P2.tsyn); this._rk = Math.exp(-dt / 80); }
      const eg = this._eg, a = dt / P2.tau, vr = P2.vrest, vre = P2.vreset, refr = P2.refr, gi = this.gi;
      if (gi) {
        gi.fill(0); const ga = R.ga, gb = R.gb, gg = R.gg;
        for (let k = 0; k < ga.length; k++) { const p = ga[k], q = gb[k], d = gg[k] * (v[q] - v[p]); gi[p] += d; gi[q] -= d; }
      }
      let ns = 0;
      if (gi) {
        for (let i = 0; i < N; i++) {
          const gs = g[i] * eg; g[i] = gs;
          if (rf[i] > 0) { rf[i] -= dt; continue; }
          const vi = v[i] + a * ((vr - v[i]) + ext[i] + gs + gi[i]);
          if (vi >= vth[i]) { v[i] = vre; rf[i] = refr; spk[ns++] = i; } else v[i] = vi;
        }
      } else {
        for (let i = 0; i < N; i++) {
          const gs = g[i] * eg; g[i] = gs;
          if (rf[i] > 0) { rf[i] -= dt; continue; }
          const vi = v[i] + a * ((vr - v[i]) + ext[i] + gs);
          if (vi >= vth[i]) { v[i] = vre; rf[i] = refr; spk[ns++] = i; } else v[i] = vi;
        }
      }
      const rp = this.rowPtr, col = this.col, w = this.w, mask = this.mask, cnt = this.cnt;
      for (let k = 0; k < ns; k++) {
        const s = spk[k];
        for (let e = rp[s], e1 = rp[s + 1]; e < e1; e++) g[col[e]] += w[e];
        const m = mask[s]; if (m) for (let b = 0; b < NIO; b++) if (m & (1 << b)) cnt[b]++;
      }
      const rk = this._rk, io = R.io, T = S.T, rate = this.rate, pz = this.pz, span = P2.vth - vre;
      for (let b = 0; b < NIO; b++) {
        const n = io[b].length; if (!n) continue;
        const c = cnt[b]; rate[b] = rate[b] * rk + (1 - rk) * c / (n * dt);
        const o = pz[b];
        if (c) { this.lastFire[b] = T; o.lastT = T; o.spikes += c; if (an && an.rec) an.rec.push([T, IO_KEYS[b]]); }
        o.v = vre + span * Math.min(1, rate[b] / 0.05);
        cnt[b] = 0;
      }
      return ns;
    }
  }
  const lawnField = (x, y) => { let o = 0; for (const l of LAWNS) o += Math.exp(-Math.max(0, dist(x, y, l.x, l.y) - l.r) / 110); return o * 0.7; };
  const onLawn = (x, y) => LAWNS.some(l => dist(x, y, l.x, l.y) < l.r);
  const fruitNear = (x, y) => { for (const s of S.scents) if (s.s > 0.05 && dist(x, y, s.x, s.y) < 11) return s; return null; };
  function touchAt(an, fwd) {
    const L = an.size || an.spec.size; let hx, hy;
    if (an.segs && fwd < 0) { const s = an.segs, n = s.length; hx = s[n - 2]; hy = s[n - 1]; }
    else { hx = an.x + fwd * Math.cos(an.a) * L; hy = an.y + fwd * Math.sin(an.a) * L; }
    if (hx < 17 || hx > W - 17 || hy < 17 || hy > H - 17) return 1;
    if (S.pointer && dist(S.pointer.x, S.pointer.y, hx, hy) < 22) return 1;
    if (an.spec.body === "worm" && inPond(hx, hy)) return 1;
    for (const o of ANIMALS) if (o !== an && Math.abs(o.x - hx) < 8 && Math.abs(o.y - hy) < 8) return 1;
    return 0;
  }
  function cSense(an, B) {
    const worm = an.spec.body === "worm";
    const [l, r] = antennae(an, worm ? lawnField : scentAt, worm ? 7 : 12, worm ? 0.9 : 0.7);
    B.clearIn();
    B.drive(G_SL, 3 + l * 30, 5); B.drive(G_SR, 3 + r * 30, 5);
    if (touchAt(an, 1)) { B.drive(G_TF, 14, 2); an.mem.touchT = S.T; }
    if (touchAt(an, -1)) B.drive(G_TB, 14, 2);
    const hx = an.x + Math.cos(an.a) * (an.size || 6) * 0.8, hy = an.y + Math.sin(an.a) * (an.size || 6) * 0.8;
    const fruit = worm ? null : fruitNear(hx, hy), food = worm ? onLawn(hx, hy) : !!fruit;
    an.mem.food = food ? 1 : 0; an.mem.fruit = fruit;
    if (food) B.drive(G_FOOD, 12, 2);
    B.drive(G_FWD, 7.4, 2);
    B.drive(G_ML, 1, 0.8); B.drive(G_MR, 1, 0.8);
  }
  const R0 = 0.02;
  function cMotor(an, B) {
    const sp = an.spec, r = B.rate, h = B.has, worm = sp.body === "worm";
    const fwd = h[G_FWD] ? r[G_FWD] : (r[G_ML] + r[G_MR]) / 2, back = h[G_BWD] ? r[G_BWD] : 0;
    const vt = Math.tanh((fwd - back) / R0) * sp.speed * (an.spd || 1);
    an.v += (vt - an.v) * 0.01;
    an.a = wrapA(an.a + Math.tanh((r[G_MR] - r[G_ML]) / R0) * sp.turn);
    an.x += Math.cos(an.a) * an.v; an.y += Math.sin(an.a) * an.v;
    if (worm) {
      if (inPond(an.x, an.y)) { an.x += (an.x - POND.x) * 0.004; an.y += (an.y - POND.y) * 0.004; }
      const n = 10, gap = sp.size * 0.5;
      let s = an.segs;
      if (!s) { s = an.segs = new Float32Array(n * 2); for (let k = 0; k < n; k++) { s[2 * k] = an.x - Math.cos(an.a) * gap * k; s[2 * k + 1] = an.y - Math.sin(an.a) * gap * k; } }
      s[0] = an.x; s[1] = an.y;
      for (let k = 1; k < n; k++) { const dx = s[2 * k] - s[2 * k - 2], dy = s[2 * k + 1] - s[2 * k - 1], d = Math.hypot(dx, dy) || 1e-6; s[2 * k] = s[2 * k - 2] + dx / d * gap; s[2 * k + 1] = s[2 * k - 1] + dy / d * gap; }
    }
    if (an.mem.food && (!h[G_FEED] || r[G_FEED] > 0.004) && S.T >= (an.mem.biteT || 0)) {
      an.mem.biteT = S.T + (worm ? 2000 : 400); an.meals++; S.meals++; an.mem.eatUntil = S.T + 700;
      if (an.mem.fruit) an.mem.fruit.s -= 0.2;
      note(an.tag + (worm ? " is eating bacteria on the lawn" : " is eating fallen fruit"));
    }
  }
  function cDraw(c, an) {
    const sp = an.spec;
    if (sp.body === "worm") {
      const s = an.segs; if (!s) return;
      c.strokeStyle = sp.baseColor; c.lineWidth = sp.size * 0.55; c.lineCap = "round"; c.lineJoin = "round";
      c.beginPath(); c.moveTo(s[0], s[1]); for (let k = 2; k < s.length; k += 2) c.lineTo(s[k], s[k + 1]); c.stroke();
      c.lineCap = "butt"; c.lineJoin = "miter";
      c.fillStyle = S.T < (an.mem.eatUntil || 0) ? "#ffe0c8" : "#b89a8c"; c.beginPath(); c.arc(s[0], s[1], sp.size * 0.33, 0, 7); c.fill();
    } else {
      body(c, an, sp.baseColor, 5); wings(c, an, S.T < (an.mem.eatUntil || 0) ? 0.8 : 0.3, "rgba(230,240,255,0.4)");
      c.fillStyle = "#b8322a"; c.beginPath(); c.arc(an.x + Math.cos(an.a) * sp.size, an.y + Math.sin(an.a) * sp.size, 1.6, 0, 7); c.fill();
    }
  }
  function cState(an) {
    const B = an.brain; if (!B) return "";
    if (B.exact) return xState(an);
    const r = B.rate, worm = an.spec.body === "worm", tail = " (real brain)", sp = an.spec;
    if (S.T < (an.mem.eatUntil || 0)) return (worm ? "eating bacteria" : "eating fallen fruit") + tail;
    if (an.v < -0.25 * sp.speed) return (S.T - (an.mem.touchT || -1e9) < 1500 ? "backing away from a touch" : "backing up") + tail;
    const dL = S.T - B.lastFire[G_SL], dR = S.T - B.lastFire[G_SR];
    if (Math.abs(r[G_MR] - r[G_ML]) > 0.004 && (dL < 300 || dR < 300)) return (r[G_ML] > r[G_MR] ? "turning toward a smell on its left" : "turning toward a smell on its right") + tail;
    if (Math.abs(an.v) > 0.25 * sp.speed) return (worm ? "crawling forward" : "walking, smelling for fruit") + tail;
    return "still, its brain is quiet" + tail;
  }
  const FEED_SPIKES = 15, BITE_MS = 400, BITES_TO_FULL = 5;
  const WORM_HONEST = "real wiring, touch reflex validated (Wicks & Rankin sign rule); chemotaxis and crawling rhythm not validated";
  const REV_MV = 0.5;
  const FOOD_LEVEL = 0;
  function wormContact(an, fwd) {
    const L = an.size || an.spec.size; let hx, hy;
    if (an.segs && fwd < 0) { const s = an.segs, n = s.length; hx = s[n - 2]; hy = s[n - 1]; }
    else { hx = an.x + fwd * Math.cos(an.a) * L; hy = an.y + fwd * Math.sin(an.a) * L; }
    let mech = 0, harsh = 0;
    if (hx < 17 || hx > W - 17 || hy < 17 || hy > H - 17 || inPond(hx, hy)) harsh = 1;
    if (S.pointer && dist(S.pointer.x, S.pointer.y, hx, hy) < 22) mech = 1;
    if (!mech) for (const o of ANIMALS) if (o !== an && Math.abs(o.x - hx) < 8 && Math.abs(o.y - hy) < 8) { mech = 1; break; }
    return { mech, harsh };
  }
  function gSense(an, B) {
    const hx = an.x + Math.cos(an.a) * (an.size || 6) * 0.8, hy = an.y + Math.sin(an.a) * (an.size || 6) * 0.8;
    const food = onLawn(hx, hy); an.mem.food = food ? 1 : 0; an.mem.fruit = null;
    const h = wormContact(an, 1), t = wormContact(an, -1);
    B.setLevel(G_TF, h.mech); B.setLevel(G_TB, t.mech || t.harsh); B.setLevel(G_NOSE, h.harsh); B.setLevel(G_FOOD, food ? FOOD_LEVEL : 0);
    if (h.mech) an.mem.touchT = S.T; if (t.mech || t.harsh) an.mem.tailT = S.T; if (h.harsh) an.mem.noseT = S.T;
  }
  function gMotor(an, B) {
    const sp = an.spec, spd = sp.speed * (an.spd || 1), d = B.fwdDrive - B.bwdDrive, rev = d < -REV_MV;
    if (rev) { if (!an.mem.revving) an.mem.revving = 1; an.mem.revT = S.T; }
    else if (an.mem.revving) { an.mem.revving = 0; an.mem.turnLeft = (Math.random() < 0.5 ? -1 : 1) * rnd(1.2, 2.4); }
    if (an.mem.turnLeft) { const k = Math.sign(an.mem.turnLeft) * Math.min(Math.abs(an.mem.turnLeft), 0.004); an.a = wrapA(an.a + k); an.mem.turnLeft -= k; if (Math.abs(an.mem.turnLeft) < 1e-4) an.mem.turnLeft = 0; }
    else if (!rev) { const [l, r] = antennae(an, lawnField, 7, 0.9); an.a = wrapA(an.a + gauss() * 0.01 + clamp((r - l) * 0.6, -0.004, 0.004)); }
    const vt = rev ? -spd * clamp(-d / 4, 0.4, 1.2) : spd * clamp(1 + 0.5 * d, 0.5, 2) * (an.mem.food ? 0.3 : 1);
    an.v += (vt - an.v) * 0.01;
    an.x += Math.cos(an.a) * an.v; an.y += Math.sin(an.a) * an.v;
    if (inPond(an.x, an.y)) { an.x += (an.x - POND.x) * 0.004; an.y += (an.y - POND.y) * 0.004; }
    const n = 10, gap = sp.size * 0.5;
    let s = an.segs;
    if (!s) { s = an.segs = new Float32Array(n * 2); for (let k = 0; k < n; k++) { s[2 * k] = an.x - Math.cos(an.a) * gap * k; s[2 * k + 1] = an.y - Math.sin(an.a) * gap * k; } }
    s[0] = an.x; s[1] = an.y;
    for (let k = 1; k < n; k++) { const dx = s[2 * k] - s[2 * k - 2], dy = s[2 * k + 1] - s[2 * k - 1], dd = Math.hypot(dx, dy) || 1e-6; s[2 * k] = s[2 * k - 2] + dx / dd * gap; s[2 * k + 1] = s[2 * k - 1] + dy / dd * gap; }
    if (an.mem.food && S.T >= (an.mem.biteT || 0)) {
      an.mem.biteT = S.T + 2000; an.meals++; S.meals++; an.mem.eatUntil = S.T + 700;
      note(an.tag + " is eating bacteria on the lawn (simple rule)");
    }
  }
  function gState(an) {
    const B = an.brain, sp = an.spec, rev = B.fwdDrive - B.bwdDrive < -REV_MV;
    const drift = B.drift > 0 ? "; brain " + driftPct(B.drift) + " changed from the validated " + (sp.circuit || sp.brainTag || B.R.id) + " circuit" : "";
    const tail = " [" + WORM_HONEST + drift + "]";
    if (rev) {
      const why = S.T - (an.mem.noseT || -1e9) < 800 ? "its nose (ASH) hit something harsh" : S.T - (an.mem.touchT || -1e9) < 800 ? "its head was touched" : "its backward command cells are still up";
      return "reversing: " + why + ", backward cells (AVA, AVD) " + B.bwdDrive.toFixed(2) + " mV vs forward (AVB, PVC) " + B.fwdDrive.toFixed(2) + " mV" + tail;
    }
    if (S.T < (an.mem.eatUntil || 0)) return "eating bacteria (simple rule)" + tail;
    if (S.T - (an.mem.tailT || -1e9) < 800) return "tail touched: crawling forward faster, forward cells " + B.fwdDrive.toFixed(2) + " mV vs backward " + B.bwdDrive.toFixed(2) + " mV" + tail;
    return (an.mem.food ? "on a bacteria lawn, crawling slowly" : "crawling forward") + tail;
  }
  const nectarAt = (x, y) => FLOWERS.some(f => dist(x, y, f.x, f.y) < 11);
  function xSense(an, B) {
    if (B.graded) return gSense(an, B);
    const worm = an.spec.body === "worm", hz = B.R.P.stimHz;
    B.clearStim();
    const hx = an.x + Math.cos(an.a) * (an.size || 6) * 0.8, hy = an.y + Math.sin(an.a) * (an.size || 6) * 0.8;
    if (worm) {
      const food = onLawn(hx, hy); an.mem.food = food ? 1 : 0; an.mem.fruit = null;
      if (food) B.setStim(G_FOOD, hz);
      if (touchAt(an, 1)) { B.setStim(G_TF, hz); an.mem.touchT = S.T; }
      if (touchAt(an, -1)) B.setStim(G_TB, hz);
      return;
    }
    const fruit = fruitNear(hx, hy), food = !!fruit || nectarAt(hx, hy);
    an.mem.food = food ? 1 : 0; an.mem.fruit = fruit;
    if (food) B.setStim(G_FOOD, hz); else B.feedSince = 0;
  }
  function xMotor(an, B) {
    if (B.graded) return gMotor(an, B);
    const sp = an.spec, worm = sp.body === "worm", spd = sp.speed * (an.spd || 1);
    if (worm) {
      const back = S.T - (an.mem.touchT || -1e9) < 1200;
      const [l, r] = antennae(an, lawnField, 7, 0.9);
      if (!back) an.a = wrapA(an.a + gauss() * 0.01 + clamp((r - l) * 0.6, -0.004, 0.004));
      const vt = back ? -0.5 * spd : (an.mem.food ? 0.3 * spd : spd);
      an.v += (vt - an.v) * 0.01;
      an.x += Math.cos(an.a) * an.v; an.y += Math.sin(an.a) * an.v;
      if (inPond(an.x, an.y)) { an.x += (an.x - POND.x) * 0.004; an.y += (an.y - POND.y) * 0.004; }
      const n = 10, gap = sp.size * 0.5;
      let s = an.segs;
      if (!s) { s = an.segs = new Float32Array(n * 2); for (let k = 0; k < n; k++) { s[2 * k] = an.x - Math.cos(an.a) * gap * k; s[2 * k + 1] = an.y - Math.sin(an.a) * gap * k; } }
      s[0] = an.x; s[1] = an.y;
      for (let k = 1; k < n; k++) { const dx = s[2 * k] - s[2 * k - 2], dy = s[2 * k + 1] - s[2 * k - 1], d = Math.hypot(dx, dy) || 1e-6; s[2 * k] = s[2 * k - 2] + dx / d * gap; s[2 * k + 1] = s[2 * k - 1] + dy / d * gap; }
      if (an.mem.food && S.T >= (an.mem.biteT || 0)) {
        an.mem.biteT = S.T + 2000; an.meals++; S.meals++; an.mem.eatUntil = S.T + 700;
        note(an.tag + " is eating bacteria on the lawn (simple rule)");
      }
      return;
    }
    const full = S.T < (an.mem.fullUntil || 0), tasting = an.mem.food && !full;
    if (tasting && !an.mem.tasteT) an.mem.tasteT = S.T;
    if (!an.mem.food) an.mem.tasteT = 0;
    const stuck = tasting && S.T - an.mem.tasteT > 3000 && S.T - B.lastFire[G_FEED] > 3000;
    if (stuck) { an.mem.fullUntil = S.T + 4000; an.mem.tasteT = 0; }
    const stay = tasting && !stuck;
    if (!stay) {
      const [l, r] = antennae(an, scentAt, 12, 0.7);
      an.a = wrapA(an.a + gauss() * 0.03 + (full ? 0 : clamp((r - l) * 0.8, -0.02, 0.02)));
    }
    an.v += ((stay ? 0 : spd) - an.v) * (stay ? 0.05 : 0.01);
    an.x += Math.cos(an.a) * an.v; an.y += Math.sin(an.a) * an.v;
    if (an.mem.food && B.feedSince >= FEED_SPIKES && S.T >= (an.mem.biteT || 0)) {
      B.feedSince = 0; an.mem.biteT = S.T + BITE_MS; an.meals++; S.meals++; an.mem.eatUntil = S.T + 700;
      an.mem.bites = (an.mem.bites || 0) + 1;
      if (an.mem.fruit) an.mem.fruit.s -= 0.2;
      if (an.mem.bites >= BITES_TO_FULL) { an.mem.bites = 0; an.mem.fullUntil = S.T + 15000; }
      note(an.tag + " is feeding: its MN9 feeding neurons fired on " + (an.mem.fruit ? "fallen fruit" : "flower nectar"));
    }
  }
  function xState(an) {
    if (an.brain.graded) return gState(an);
    const B = an.brain, sp = an.spec, R = B.R, worm = sp.body === "worm";
    const drift = B.drift > 0 ? "; brain " + driftPct(B.drift) + " changed from the " + (R.validated ? "validated " : "") + (sp.brainTag || R.id) + " " + (R.validated ? "circuit" : "wiring map") : "";
    if (worm) {
      const tail = " (simple rule; real wiring map, behaviour not validated" + drift + ")";
      if (S.T < (an.mem.eatUntil || 0)) return "eating bacteria" + tail;
      if (an.v < -0.1 * sp.speed) return "backing off a touch" + tail;
      return (an.mem.food ? "on a bacteria lawn" : "crawling") + tail;
    }
    const mn9 = S.T - B.lastFire[G_FEED] < 250, sugar = S.T - B.lastFire[G_FOOD] < 250;
    const tail = drift ? " [real brain" + drift + "]" : " [real, validated brain]";
    if (an.mem.food && mn9) return "tasting sugar - feeding neurons (MN9) firing, eating" + tail;
    if (an.mem.food && sugar) return "tasting sugar - feeding neurons not firing" + tail;
    if (mn9) return "feeding neurons (MN9) still firing" + tail;
    if (S.T < (an.mem.fullUntil || 0)) return "walking off (walks on a simple rule, not its brain)" + tail;
    return "walking, smelling for fruit (walks on a simple rule; eats on its real brain)" + tail;
  }
  const CONNECTOMES = [];
  const CREDITS = CONNECTOMES.map(d => d.credit);
  const soilSpot = () => { let x, y, k = 0; do { x = rnd(40, W - 40); y = rnd(40, H - 40); } while (inPond(x, y) && ++k < 50); return [x, y]; };
  function fetchBrain(file) {
    const store = (typeof globalThis !== "undefined" && globalThis.__TERRARIUM_NO_BRAINS__) || {};
    return Object.prototype.hasOwnProperty.call(store, file)
      ? Promise.resolve(store[file])
      : Promise.reject(new Error("brain asset not delivered by host: " + file));
  }
  function addConnectomeSpecies(def, json) {
    const R = buildRef(json, def.file || def.key);
    const sp = Object.assign({ neurons: {}, synapses: [], mem: {}, plural: def.name, graze: EVO.graze, nicheK: EVO.nicheK }, def,
      { brain: true, ref: R, baseColor: def.color, rootKey: def.key, draw: cDraw, state: cState, sense: () => ({}), motor: () => {} });
    sp.place = def.place || (def.body === "worm" ? (i => { const l = LAWNS[i % LAWNS.length]; return [l.x + rnd(-25, 25), l.y + rnd(-25, 25)]; }) : soilSpot);
    SPECIES[def.key] = sp; sp.founderG = refGenome(sp); ensureSum(def.key, null);
    resolvePending(); ensureFloors();
    console.log("[terrarium] real brain loaded for " + def.name + ": " + R.id + ", " + R.N + " neurons, " + R.E + " synapses, " + R.ga.length + " gap junctions");
    note("a real brain arrived: " + def.name + ", " + R.N.toLocaleString() + " neurons" + (def.honest ? " (" + def.honest + ")" : "") + (def.credit ? ". " + def.credit : ""), "brain " + def.key);
    return sp;
  }
  function loadConnectome(def) {
    if (SPECIES[def.key] && SPECIES[def.key].ref) return Promise.resolve(SPECIES[def.key]);
    return fetchBrain(def.file).then(j => addConnectomeSpecies(def, j))
      .catch(e => { console.info("[terrarium] " + def.name + " is not in the terrarium: brain file brains/" + def.file + " could not be loaded (" + ((e && e.message) || e) + ")"); return null; });
  }
  const loadBrains = () => Promise.all(CONNECTOMES.map(loadConnectome));
  function ensureSum(key, from) {
    const sm = S.evo.sum[key] || (S.evo.sum[key] = { name: (SPECIES[key] && SPECIES[key].name) || key, from: from || null, T0: S.T, births: 0, founders: 0, deaths: 0, causes: {}, maxGen: 0, mut: { w: 0, p: 0, dup: 0, del: 0 }, extinctT: null });
    return sm;
  }
  function brainLabel(sp) {
    if (sp.brain) return (sp.ref && !sp.ref.validated ? "real wiring map: " : "real connectome: ") + (sp.ref ? sp.ref.id + ", " + sp.ref.N.toLocaleString() + " neurons, " + sp.ref.E.toLocaleString() + " synapses" : "not loaded") + (sp.honest ? "; " + sp.honest : "") + (sp.derived ? ", evolved line" : "");
    return "hand-built circuit: " + Object.keys(sp.neurons).length + " neurons" + (sp.derived ? ", evolved line" : "");
  }
  function countBy() { const c = {}; for (const an of ANIMALS) { const k = an.spec.key; c[k] = (c[k] || 0) + 1; } return c; }
  function nextTag(sp) { const n = (S.evo.tagN[sp.key] || 0) + 1; S.evo.tagN[sp.key] = n; return (sp.short || sp.name) + " " + n; }
  function famLetter(n) { let s = ""; n = n - 1; do { s = String.fromCharCode(97 + n % 26) + s; n = Math.floor(n / 26) - 1; } while (n >= 0); return s; }
  function defineDerived(def) {
    const parent = SPECIES[def.parent]; if (!parent) return null;
    const root = SPECIES[def.root] || rootOf(parent), fg = unpackG(def.founder); if (!fg) return null;
    const sp = Object.create(parent);
    Object.assign(sp, { key: def.key, name: def.name, plural: def.name, short: def.short || def.name, derived: true, parentKey: def.parent, rootKey: root.key,
      founderG: fg, hueShift: def.hueShift || 0, drawAs: root.drawAs || root.name, color: tint(root.baseColor || root.color, fg.t.hue), bornT: def.T });
    if (sp.brain && fg.sig !== sp.ref.sig) sp.founderG = Object.assign(refGenome(sp), { t: fg.t });
    SPECIES[def.key] = sp; ensureSum(def.key, def.parent).name = def.name;
    return sp;
  }
  function deriveSpecies(parent, g, an) {
    const root = rootOf(parent), fam = (S.evo.fam[root.key] = (S.evo.fam[root.key] || 1) + 1), letter = famLetter(fam);
    const short = (root.short || root.name) + "-" + letter;
    const shift = (Math.random() < 0.5 ? -1 : 1) * rnd(25, 40); g.t.hue += shift;
    const def = { key: root.key + "-" + letter, name: short + (root.brainTag ? " (" + root.brainTag + ")" : ""), short, parent: parent.key, root: root.key, T: Math.round(S.T), gen: an.gen + 1, from: an.tag, hueShift: +shift.toFixed(2), founder: packG(g) };
    S.evo.species[def.key] = def;
    const sp = defineDerived(def); ensureSum(def.key, parent.key).gen0 = def.gen;
    S.evo.events.push({ t: Math.round(S.T), wall: Date.now(), kind: "new species", key: def.key, name: def.name, parent: parent.name, gen: def.gen, from: an.tag });
    if (S.evo.events.length > EVO.eventsMax) S.evo.events.shift();
    note("a NEW SPECIES: " + def.name + ", split from " + parent.name + " after " + def.gen + " generations", "species " + def.key);
    return sp;
  }
  function resolvePending() {
    let moved = true;
    while (moved) { moved = false; for (let i = PENDING_SPECIES.length - 1; i >= 0; i--) if (SPECIES[PENDING_SPECIES[i].parent]) { defineDerived(PENDING_SPECIES[i]); PENDING_SPECIES.splice(i, 1); moved = true; } }
    let got = 0;
    for (let i = PENDING.length - 1; i >= 0; i--) { const sp = SPECIES[PENDING[i].sp]; if (sp && (!sp.brain || sp.ref)) { revive(PENDING[i]); PENDING.splice(i, 1); got++; } }
    if (got) popVer++;
  }
  function ensureFloors() {
    const c = countBy();
    for (const k in SPECIES) {
      const sp = SPECIES[k];
      if (sp.derived || (sp.brain && !sp.ref) || c[k] || PENDING.some(r => r.sp === k) || !sp.place) continue;
      const n = sp.founders || 1;
      for (let i = 0; i < n; i++) { const [x, y] = sp.place(i); const an = makeAnimal(sp, x, y, cloneG(sp.founderG), { mut: "founder" }); if (sp.foundMem) Object.assign(an.mem, sp.foundMem(i)); }
    }
  }
  function makeAnimal(sp, x, y, g, o = {}) {
    const an = new Animal(sp, x, y, o.tag || nextTag(sp), g);
    an.id = S.evo.nextId++; an.gen = o.gen || 0; an.par = o.par || []; an.d = o.d || 0;
    if (sp.birthMem) Object.assign(an.mem, sp.birthMem());
    ANIMALS.push(an); popVer++;
    const sm = ensureSum(sp.key, sp.parentKey), mut = o.mut || "";
    if (mut === "founder") { sm.founders++; S.evo.founders++; } else { sm.births++; S.evo.births++; }
    sm.maxGen = Math.max(sm.maxGen, an.gen);
    if (/(^| )w\d/.test(mut)) sm.mut.w++; if (mut.includes("p:")) sm.mut.p++; if (mut.includes("dup:")) sm.mut.dup++; if (mut.includes("del:")) sm.mut.del++;
    const rec = { t: Math.round(S.T), id: an.id, tag: an.tag, parents: an.par, species: sp.key, generation: an.gen, mutations: mut, distance: +an.d.toFixed(4), death: null };
    S.evo.recs.push(rec); REC_BY_ID.set(an.id, rec);
    while (S.evo.recs.length > EVO.recsMax) REC_BY_ID.delete(S.evo.recs.shift().id);
    return an;
  }
  function revive(rec) {
    const sp = SPECIES[rec.sp]; let g = unpackG(rec.g);
    if (!g || g.k !== (sp.brain ? "c" : "h")) g = cloneG(sp.founderG);
    if (g.k === "c" && g.sig !== sp.ref.sig) { note("the " + sp.name + " brain file changed; saved rewiring was reset, body traits kept", "sig " + sp.key); g = Object.assign(cloneG(sp.founderG), { t: g.t }); }
    const an = new Animal(sp, rec.x, rec.y, rec.tag, g);
    Object.assign(an, { id: rec.id || S.evo.nextId++, gen: rec.gen || 0, par: rec.par || [], a: rec.a || 0, spikes: rec.spikes || 0, meals: rec.meals || 0,
      born: rec.born != null ? rec.born : S.T, en: rec.en != null ? rec.en : 1, lastBreed: rec.lastBreed != null ? rec.lastBreed : -1e12, d: rec.d || 0 });
    if (rec.life) an.lifeSpan = rec.life;
    an._m0 = an.meals; Object.assign(an.mem, rec.mem || {}); an.mem.fruit = null;
    ANIMALS.push(an); return an;
  }
  function breed(an, forced) {
    const sp = an.spec, g = cloneG(an.genome), mut = mutate(g, sp);
    let d = distG(g, sp.founderG, sp), csp = sp;
    if (!forced && d >= EVO.speciateAt) {
      let best = null, bd = EVO.speciateAt * 0.6;
      for (const k in SPECIES) {
        const x = SPECIES[k]; if (!x.derived || x.parentKey !== sp.key || !ANIMALS.some(o => o.spec === x)) continue;
        const f = cloneG(x.founderG); f.t.hue -= x.hueShift || 0;
        const dx = distG(g, f, x); if (dx < bd) { bd = dx; best = x; }
      }
      if (best) { g.t.hue += best.hueShift || 0; csp = best; d = distG(g, best.founderG, best); }
      else { csp = deriveSpecies(sp, g, an); d = 0; }
    }
    const x = clamp(an.x + rnd(-12, 12), 14, W - 14), y = clamp(an.y + rnd(-12, 12), 14, H - 14);
    const ch = makeAnimal(csp, x, y, g, { gen: an.gen + 1, par: [an.id], mut, d });
    ch.a = wrapA(an.a + Math.PI + rnd(-0.6, 0.6)); ch.en = EVO.childEn;
    if (!forced) an.en -= EVO.breedCost;
    an.lastBreed = S.T;
    if (csp === sp) note(an.tag + " had a young one, " + ch.tag, "birth " + an.id);
    return ch;
  }
  function die(an, cause) {
    const i = ANIMALS.indexOf(an); if (i < 0) return;
    ANIMALS.splice(i, 1); popVer++;
    const k = an.spec.key, sm = ensureSum(k, an.spec.parentKey);
    sm.deaths++; sm.causes[cause] = (sm.causes[cause] || 0) + 1; S.evo.deaths++;
    const r = REC_BY_ID.get(an.id); if (r) r.death = { t: Math.round(S.T), cause, age: Math.round(S.T - an.born) };
    if (an.spec.derived && !ANIMALS.some(o => o.spec === an.spec) && !PENDING.some(p => p.sp === k)) {
      sm.extinctT = Math.round(S.T);
      S.evo.events.push({ t: Math.round(S.T), wall: Date.now(), kind: "died out", key: k, name: an.spec.name });
      if (S.evo.events.length > EVO.eventsMax) S.evo.events.shift();
      note("the last " + an.spec.name + " is gone; that line has died out", "extinct " + k);
    } else note(an.tag + (cause === "old age" ? " died of old age" : " starved"), "death " + an.id);
    an.rec = null;
  }
  const NICHE = {
    moth: an => (lampOn() && dist(an.x, an.y, LAMP.x, LAMP.y) < 90) || flowerAt(an.x, an.y) > 0.6 ? 1 : 0,
    firefly: an => an.mem.seen >= 3 ? 1 : (flowerAt(an.x, an.y) > 0.6 ? 0.6 : 0),
    cricket: an => flowerAt(an.x, an.y) > 0.35 ? 1 : 0,
    snail: an => { const e = pondEdge(an.x, an.y); return e > 1.0 && e < 1.4 ? 1 : 0; },
    strider: an => (rippleAt(an.x, an.y) > 0.1 || S.seeds.some(sd => dist(sd.x, sd.y, an.x, an.y) < 25)) ? 1 : 0,
    minnow: an => { let n = 0; for (const o of ANIMALS) if (o !== an && o.spec === an.spec && Math.abs(o.x - an.x) < 90 && Math.abs(o.y - an.y) < 90) n++; return n >= 2 ? 1 : 0; },
    spider: an => dist(an.x, an.y, WEB.x, WEB.y) < 20 ? 0.35 : 0
  };
  const CAPS = { fly: 3, ant: 8, moth: 4, firefly: 7, cricket: 4, snail: 4, bee: 5, strider: 4, minnow: 7, frog: 2, spider: 2 };
  function famCount() { const f = {}; for (const an of ANIMALS) { const k = an.spec.rootKey || an.spec.key; f[k] = (f[k] || 0) + 1; } return f; }
  function lifeTick(dtms) {
    const ls = EVO.lifeScale, c = countBy(), fam = famCount(), met = dtms / (EVO.starve * ls);
    for (let i = ANIMALS.length - 1; i >= 0; i--) {
      const an = ANIMALS[i]; if (!an) continue;
      const sp = an.spec, k = sp.key;
      if (an.meals !== an._m0) { an.en += Math.max(0, an.meals - an._m0) * EVO.meal / ls; an._m0 = an.meals; }
      const niche = sp.niche ? sp.niche(an) : 0;
      an.en = Math.min(EVO.enMax, an.en + met * ((sp.graze != null ? sp.graze : EVO.graze) + niche * (sp.nicheK || EVO.nicheK) - an.mK));
      const age = S.T - an.born, last = !sp.derived && c[k] === 1;
      if (age > an.lifeSpan * ls) {
        if (last) { const ch = breed(an, true); c[ch.spec.key] = (c[ch.spec.key] || 0) + 1; fam[sp.rootKey] = (fam[sp.rootKey] || 0) + 1; }
        die(an, "old age"); c[k]--; fam[sp.rootKey]--; continue;
      }
      if (an.en <= 0) { if (last) an.en = 0; else { die(an, "starved"); c[k]--; fam[sp.rootKey]--; continue; } }
      if (age >= EVO.mature * ls * (sp.matureK || 1) && an.en >= EVO.breedAt && S.T - an.lastBreed >= EVO.cooldown * ls
          && (c[k] || 0) < (sp.cap || 4) && (fam[sp.rootKey] || 0) < Math.ceil((sp.cap || 4) * 1.5) && ANIMALS.length < EVO.totalCap) {
        const ch = breed(an, false); c[ch.spec.key] = (c[ch.spec.key] || 0) + 1; fam[sp.rootKey] = (fam[sp.rootKey] || 0) + 1;
      }
    }
  }
  function evolutionReport() {
    const E = S.evo, alive = {}, hm = ms => { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 3600) + "h " + Math.floor(s % 3600 / 60) + "m"; };
    for (const an of ANIMALS) {
      const k = an.spec.key, o = alive[k] || (alive[k] = { n: 0, d: 0, gen: 0, size: 0, speed: 0, hue: 0 }), f = an.spec.founderG ? an.spec.founderG.t : an.genome.t;
      o.n++; o.d += an.d || 0; o.gen = Math.max(o.gen, an.gen || 0);
      o.size += an.genome.t.size / f.size; o.speed += an.genome.t.speed / f.speed; o.hue += an.genome.t.hue - f.hue;
    }
    const nNew = E.events.filter(e => e.kind === "new species").length;
    const out = ["THE TERRARIUM: HOW THE ANIMALS ARE CHANGING",
      "After " + hm(S.T) + " of terrarium time: " + ANIMALS.length + " animals alive in " + Object.keys(alive).length + " species. " +
      E.births + " born and " + E.deaths + " died since the gene line began (plus " + E.founders + " founders). " +
      (nNew ? nNew + " new species " + (nNew === 1 ? "has" : "have") + " formed." : "No new species yet (one splits off when a newborn drifts " + EVO.speciateAt + " from its species' founder).") +
      (EVO.lifeScale !== 1 ? " NOTE: lives are running at " + EVO.lifeScale + "x their normal length (fast-forward)." : ""), ""];
    const keys = Object.keys(E.sum).sort((a, b) => (E.sum[a].T0 - E.sum[b].T0) || (a < b ? -1 : 1));
    for (const k of keys) {
      const sm = E.sum[k], sp = SPECIES[k], a = alive[k] || { n: 0 };
      if (!sp && !a.n && !sm.births && !sm.deaths) continue;
      const kind = sp ? (sp.brain ? (sp.ref && !sp.ref.validated ? "real wiring map, behaviour not validated" : "real connectome brain" + (sp.ref && sp.ref.validated ? ", validated for " + (sp.validFor || "its test") : "")) : "hand-built brain") : "brain not loaded";
      let head = sm.name.toUpperCase() + " (" + kind + ")";
      if (sm.from) head += ", split from " + ((SPECIES[sm.from] && SPECIES[sm.from].name) || sm.from) + (sm.gen0 != null ? " at generation " + sm.gen0 : "") + " (" + hm(sm.T0) + ")";
      out.push(head);
      const causes = Object.entries(sm.causes).map(([c, n]) => n + " " + c).join(", ");
      out.push("  " + a.n + " alive" + (!a.n && sm.extinctT != null ? " (this line died out at " + hm(sm.extinctT) + ")" : "") +
        ". Generations: up to " + sm.maxGen + ". Born " + sm.births + (sm.founders ? " (+" + sm.founders + " founders)" : "") + ", died " + sm.deaths + (causes ? " (" + causes + ")" : "") + ".");
      if (a.n) {
        out.push("  Average distance from its founder: " + (a.d / a.n).toFixed(3) + " (a new species splits off at " + EVO.speciateAt + ").");
        const notes = [], sz = a.size / a.n - 1, spd = a.speed / a.n - 1, hu = a.hue / a.n;
        if (Math.abs(sz) >= 0.02) notes.push("bodies " + Math.abs(sz * 100).toFixed(0) + "% " + (sz > 0 ? "bigger" : "smaller") + " than the founder");
        if (Math.abs(spd) >= 0.02) notes.push("moving " + Math.abs(spd * 100).toFixed(0) + "% " + (spd > 0 ? "faster" : "slower"));
        if (Math.abs(hu) >= 3) notes.push("colour shifted " + Math.abs(hu).toFixed(0) + " degrees");
        if (notes.length) out.push("  Bodies: " + notes.join(", ") + ".");
        if (sp && sp.brain && sp.ref) {
          const ds = ANIMALS.filter(o => o.spec.key === k && o.brain).map(o => o.brain.drift);
          const avg = ds.reduce((x, y) => x + y, 0) / Math.max(1, ds.length), mx = Math.max(0, ...ds);
          const what = (sp.ref.validated ? "the validated " : "the ") + (sp.circuit || sp.brainTag || sp.ref.id) + (sp.ref.validated ? " circuit" : " wiring map (not validated)");
          out.push("  Brains: " + (mx > 0 ? "on average " + driftPct(avg) + " changed from " + what + " (most changed: " + driftPct(mx) + ")." : "exactly " + what + ", unchanged."));
          if (sp.honest) out.push("  " + sp.honest.charAt(0).toUpperCase() + sp.honest.slice(1) + ".");
        }
      }
      const mm = sm.mut, mn = [];
      if (mm.w) mn.push(mm.w + " births with rewired synapses");
      if (mm.p) mn.push(mm.p + " with a neuron's threshold or timing tuned");
      if (mm.dup) mn.push(mm.dup + " with a copied neuron");
      if (mm.del) mn.push(mm.del + " with a lost neuron");
      if (mn.length) out.push("  Mutations: " + mn.join(", ") + ".");
      const kids = E.events.filter(e => e.kind === "new species" && e.parent === sm.name).map(e => e.name);
      if (kids.length) out.push("  Gave rise to: " + kids.join(", ") + ".");
    }
    if (PENDING.length) out.push("", PENDING.length + " saved animals are waiting for their brain file to load.");
    const real = CONNECTOMES.filter(d => !(SPECIES[d.key] && SPECIES[d.key].ref)).map(d => d.name);
    if (real.length) out.push("", "Not in the terrarium (brain file missing): " + real.join(", ") + ".");
    if (ANIMALS.some(a => a.brain && !a.brain.exact)) out.push("", "Real brains step every " + (Math.max(1, BR.every) * DT) + " ms of their time" + (BR.every > 1 ? " (slowed to keep the frame rate)" : "") + "; they cost about " + BR.brainMs.toFixed(2) + " ms per frame.");
    if (ANIMALS.some(a => a.brain && a.brain.exact)) out.push("", "Real brains run their own file's update rule at its own dt (fruit fly 0.1 ms, worm 0.5 ms), never stretched. Against the world clock: " + exactSpeedText() + " (slower = fewer brain milliseconds per world millisecond, to keep the frame rate). All brains together cost about " + BR.brainMs.toFixed(2) + " ms per frame.");
    const cr = CONNECTOMES.filter(d => SPECIES[d.key] && SPECIES[d.key].ref).map(d => d.credit);
    if (cr.length) out.push("", "Credits: " + cr.join(" "));
    return out.join("\n");
  }
  for (const k in SPECIES) {
    const sp = SPECIES[k];
    Object.assign(sp, { key: k, rootKey: k, baseColor: sp.color, cap: CAPS[k] || 4, founderG: null });
    if (NICHE[k]) sp.niche = NICHE[k];
    if (sp.neurons.dL && sp.neurons.dR) sp.inter = ["dL", "dR"];
    sp.founderG = refGenome(sp);
  }
  SPECIES.cricket.birthMem = () => ({ male: Math.random() < 0.5 });
  let last = performance.now(), running = false, speed = 1, autoTicking = false, saveTimer = 0;
  function tick() { if (autoTicking) return; _tick(); }
  function _tick() {
    const now = performance.now(); let ms = Math.min(now - last, 200); last = now;
    stepWorld(Math.round(ms / DT * speed));
  }
  function stepWorld(steps) {
    const t0 = performance.now(); BR.acc = 0;
    for (let i = 0; i < steps; i++) {
      for (const an of ANIMALS) an.step();
      S.T += DT; STEP++;
      if (S.T % 50 < DT) { for (let j = 0; j < phero.length; j++) phero[j] *= 0.9995; }
      if (Math.random() < 0.0009) S.seeds.push({ x: rnd(560, 880), y: rnd(300, 560), vx: rnd(-0.03, 0.03), vy: rnd(-0.03, 0.03) });
      for (const sd of S.seeds) { sd.x += sd.vx * DT * 0.6 + noise(0.02); sd.y += sd.vy * DT * 0.6 + noise(0.02); }
      S.seeds = S.seeds.filter(sd => sd.x > 0 && sd.x < W && sd.y > 0 && sd.y < H).slice(-8);
      if (STEP % 20 === 0) lifeTick(20 * DT);
      if (Math.random() < DT / 60000 && S.scents.filter(s => s.fruit).length < 3) { const [x, y] = soilSpot(); S.scents.push({ x, y, s: 1, fruit: 1 }); }
    }
    S.scents = S.scents.filter(s => s.s > 0.05);
    S.flashes = S.flashes.filter(f => S.T - f.t < 400); S.chirps = S.chirps.filter(c => S.T - c.t < 1200); S.ripples = S.ripples.filter(r => S.T - r.t < 2600);
    const tt = performance.now() - t0;
    BR.tickMs = BR.tickMs * 0.95 + tt * 0.05; BR.maxTickMs = Math.max(BR.maxTickMs * 0.999, tt); BR.brainMs = BR.brainMs * 0.9 + BR.acc * 0.1; BR.frames++;
    const unval = BR.uEvery < BR.maxU && ANIMALS.some(a => a.brain && a.brain.exact && (!a.brain.R.validated || a.spec.slowFirst));
    if (BR.brainMs > BR.budget && (unval || BR.every < BR.maxEvery)) {
      if (unval) { BR.uEvery *= 2; BR.brainMs /= 1.5; }
      else { BR.every *= 2; BR.brainMs /= 2; }
      BR.slowed++;
      note("to keep the frame rate, the real brains now run at " + exactSpeedText(), "brain rate");
    } else if (BR.brainMs < BR.budget * 0.3 && BR.frames % 120 === 0) {
      if (BR.every > 1) { BR.every /= 2; BR.brainMs *= 2; }
      else if (BR.uEvery > 1) { BR.uEvery /= 2; BR.brainMs *= 1.5; }
    }
  }
  const speedFrac = k => k <= 1 ? "full speed" : "1/" + k + " speed";
  function exactSpeedText() {
    return "fruit fly brains " + speedFrac(Math.max(1, BR.every)) + ", worm brains " + speedFrac(Math.max(1, BR.every) * BR.uEvery);
  }
  function draw(c) {
    const day = daylight();
    c.fillStyle = day > 0.5 ? "#1d2a1f" : "#0f151a"; c.fillRect(0, 0, W, H);
    c.fillStyle = day > 0.5 ? "#274a63" : "#182c3e"; c.beginPath(); c.ellipse(POND.x, POND.y, POND.rx, POND.ry, 0, 0, 7); c.fill();
    for (const r of S.ripples) { const age = S.T - r.t; c.strokeStyle = "rgba(180,220,255," + (0.5 * (1 - age / 2500)) + ")"; c.beginPath(); c.arc(r.x, r.y, age * 0.06, 0, 7); c.stroke(); }
    for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) { const v = phero[j * GW + i]; if (v > 0.02) { c.fillStyle = "rgba(230,120,80," + Math.min(0.5, v * 0.25) + ")"; c.fillRect(i * CW, j * CH, CW, CH); } }
    for (const f of FLOWERS) { c.fillStyle = "#d86a8a"; for (let k = 0; k < 5; k++) { c.beginPath(); c.arc(f.x + 6 * Math.cos(k * 1.257), f.y + 6 * Math.sin(k * 1.257), 4, 0, 7); c.fill(); } c.fillStyle = "#f2d16b"; c.beginPath(); c.arc(f.x, f.y, 3.5, 0, 7); c.fill(); }
    c.fillStyle = "#b08a3c"; c.beginPath(); c.moveTo(HIVE.x - 14, HIVE.y + 12); c.lineTo(HIVE.x + 14, HIVE.y + 12); c.lineTo(HIVE.x + 10, HIVE.y - 12); c.lineTo(HIVE.x - 10, HIVE.y - 12); c.closePath(); c.fill();
    c.fillStyle = "#7a5a3a"; c.beginPath(); c.arc(NEST.x, NEST.y, 12, 0, 7); c.fill(); c.fillStyle = "#3a2a1a"; c.beginPath(); c.arc(NEST.x, NEST.y, 4, 0, 7); c.fill();
    if (lampOn()) { const rg = c.createRadialGradient(LAMP.x, LAMP.y, 4, LAMP.x, LAMP.y, 150); rg.addColorStop(0, "rgba(255,225,150,0.55)"); rg.addColorStop(1, "rgba(255,225,150,0)"); c.fillStyle = rg; c.beginPath(); c.arc(LAMP.x, LAMP.y, 150, 0, 7); c.fill(); }
    c.fillStyle = lampOn() ? "#ffe9a8" : "#556"; c.beginPath(); c.arc(LAMP.x, LAMP.y, 6, 0, 7); c.fill(); c.strokeStyle = "#667"; c.beginPath(); c.moveTo(LAMP.x, LAMP.y); c.lineTo(LAMP.x, 0); c.stroke();
    c.strokeStyle = "rgba(200,210,230,0.35)"; c.lineWidth = 0.8; for (let k = 0; k < 8; k++) { const t = k * Math.PI / 4; c.beginPath(); c.moveTo(WEB.x, WEB.y); c.lineTo(WEB.x + 64 * Math.cos(t), WEB.y + 64 * Math.sin(t)); c.stroke(); } for (let r = 14; r < 64; r += 12) { c.beginPath(); c.arc(WEB.x, WEB.y, r, 0, 7); c.stroke(); }
    for (const s of S.scents) { const rg = c.createRadialGradient(s.x, s.y, 2, s.x, s.y, 110); rg.addColorStop(0, "rgba(255,179,71,0.35)"); rg.addColorStop(1, "rgba(255,179,71,0)"); c.fillStyle = rg; c.beginPath(); c.arc(s.x, s.y, 110, 0, 7); c.fill(); c.fillStyle = "#ffb347"; c.beginPath(); c.arc(s.x, s.y, 4, 0, 7); c.fill(); }
    c.fillStyle = "#e8e2c8"; for (const sd of S.seeds) { c.beginPath(); c.arc(sd.x, sd.y, 2, 0, 7); c.fill(); }
    if (ANIMALS.some(a => a.spec.body === "worm")) { c.fillStyle = "rgba(200,205,150,0.13)"; for (const l of LAWNS) { c.beginPath(); c.arc(l.x, l.y, l.r, 0, 7); c.fill(); } }
    for (const an of ANIMALS) {
      const h = Math.round(an.hue || 0), k = an.sizeK || 1, big = Math.abs(k - 1) >= 0.02;
      if (!h && !big) { an.spec.draw(c, an); continue; }
      TC.c = c; TC.h = h;
      if (big) { c.save(); c.translate(an.x, an.y); c.scale(k, k); c.translate(-an.x, -an.y); an.spec.draw(TC, an); c.restore(); }
      else an.spec.draw(TC, an);
    }
    if (day < 1) { c.fillStyle = "rgba(5,8,20," + (0.35 * (1 - day)) + ")"; c.fillRect(0, 0, W, H); }
  }
  function census() {
    const by = {}; for (const an of ANIMALS) { const k = an.spec.name; (by[k] = by[k] || { n: 0, spikes: 0, meals: 0, doing: [], key: an.spec.key, brain: brainLabel(an.spec), real: !!an.spec.brain, maxGen: 0 }); by[k].n++; by[k].spikes += an.spikes; by[k].meals += an.meals; by[k].maxGen = Math.max(by[k].maxGen, an.gen || 0); by[k].doing.push(an.tag + ": " + stateOf(an)); }
    const fly = ANIMALS.find(a => a.spec === SPECIES.fly);
    return { species: Object.keys(by).length, animals: ANIMALS.length, by, simSeconds: Math.round(S.T / 1000), ageSeconds: Math.round((Date.now() - S.born) / 1000), spikes: S.spikesTotal, meals: S.meals, honey: S.honey, seedsCaught: S.seedsCaught, syncEvents: S.syncEvents, daylight: +daylight().toFixed(2), fly: fly ? { spikes: fly.spikes, meals: fly.meals, x: Math.round(fly.x), y: Math.round(fly.y) } : null,
      evolution: { births: S.evo.births, deaths: S.evo.deaths, founders: S.evo.founders, newSpecies: S.evo.events.filter(e => e.kind === "new species").length, realBrainAnimals: ANIMALS.filter(a => a.brain).length, waitingForBrain: PENDING.length, brainStepMs: Math.max(1, BR.every) * DT, exactBrainSpeed: 1 / Math.max(1, BR.every), unvalidatedBrainSpeed: 1 / (Math.max(1, BR.every) * BR.uEvery), wormBrainSpeed: 1 / (Math.max(1, BR.every) * BR.uEvery) },
      credits: CONNECTOMES.filter(d => SPECIES[d.key] && SPECIES[d.key].ref).map(d => d.credit) };
  }
  const packAnimal = a => ({ id: a.id, sp: a.spec.key, species: a.spec.name, tag: a.tag, x: a.x, y: a.y, a: a.a, spikes: a.spikes, meals: a.meals, mem: Object.assign({}, a.mem, { fruit: null }),
    born: a.born, en: +a.en.toFixed(4), gen: a.gen, par: a.par, lastBreed: a.lastBreed, life: Math.round(a.lifeSpan), d: +(a.d || 0).toFixed(4), g: packG(a.genome) });
  function snapshot() {
    const E = S.evo;
    return { kind: "terrarium", v: 2, saved: new Date().toISOString(), born: S.born, T: S.T, spikesTotal: S.spikesTotal, meals: S.meals, honey: S.honey, seedsCaught: S.seedsCaught, syncEvents: S.syncEvents, log: S.log.slice(0, 20),
      animals: ANIMALS.map(packAnimal).concat(PENDING),
      lineage: { nextId: E.nextId, births: E.births, deaths: E.deaths, founders: E.founders, fam: E.fam, tagN: E.tagN, species: E.species, sum: E.sum, events: E.events, recs: E.recs },
      census: census() };
  }
  function restore(snap) {
    if (!snap || snap.kind !== "terrarium") return false;
    S.born = snap.born || S.born; S.T = snap.T || 0; S.spikesTotal = snap.spikesTotal || 0; S.meals = snap.meals || 0; S.honey = snap.honey || 0; S.seedsCaught = snap.seedsCaught || 0; S.syncEvents = snap.syncEvents || 0; S.log = snap.log || [];
    if (snap.v >= 2 && snap.lineage) {
      S.evo = Object.assign(freshEvo(), snap.lineage);
      REC_BY_ID.clear(); for (const r of S.evo.recs) REC_BY_ID.set(r.id, r);
      for (const k in SPECIES) if (SPECIES[k].derived) delete SPECIES[k];
      PENDING_SPECIES.length = 0; PENDING.length = 0; ANIMALS.length = 0;
      for (const def of Object.values(S.evo.species || {}).sort((a, b) => a.T - b.T)) PENDING_SPECIES.push(def);
      for (const rec of snap.animals || []) PENDING.push(rec);
      resolvePending(); popVer++; ensureFloors();
      return true;
    }
    for (const rec of snap.animals || []) { const an = ANIMALS.find(a => a.tag === rec.tag); if (an) { an.x = rec.x; an.y = rec.y; an.a = rec.a; an.spikes = rec.spikes || 0; an.meals = rec.meals || 0; an._m0 = an.meals; Object.assign(an.mem, rec.mem || {}); } }
    for (const an of ANIMALS) { an.born = S.T; an.lastBreed = -1e12; }
    for (const r of S.evo.recs) r.t = Math.round(S.T);
    popVer++;
    return true;
  }
  return {
    W, H, S, ANIMALS, SPECIES, POND, HIVE, NEST, LAMP, WEB, FLOWERS,
    start() {
      if (!running) {
        populate(); running = true; last = performance.now();
        autoTicking = true;
        loadBrains();
      }
      return ANIMALS.length;
    },
    get running() { return running; },
    daylight, lampOn,
    tick, draw, census, snapshot, restore, note, stateOf,
    CAP: 64, EVO, LAWNS, CONNECTOMES,
    get popVer() { return popVer; },
    evolutionReport, addConnectomeSpecies, loadBrains,
    brainKit: { buildRef: (j, f) => buildRef(j, f), Brain, IO_KEYS, brainDrift, mutateForTest: (g, sp) => mutate(g, sp), emptyGenome: () => ({ k: "c", sig: "", t: { size: 1, speed: 1, hue: 0 }, wd: new Map(), pv: new Map(), dup: [], del: [] }) },
    brainOf(an) { return an && an.spec ? brainLabel(an.spec) : ""; },
    lineage() { return S.evo; },
    lineageJSONL() { return S.evo.recs.map(r => JSON.stringify(r)).join("\n"); },
    perf() { return { brainStepMs: Math.max(1, BR.every) * DT, exactBrainDtMs: 0.1, exactBrainSpeed: 1 / Math.max(1, BR.every), unvalidatedBrainSpeed: 1 / (Math.max(1, BR.every) * BR.uEvery), wormBrainSpeed: 1 / (Math.max(1, BR.every) * BR.uEvery), wormBrainDtMs: 0.5, brainMsPerFrame: +BR.brainMs.toFixed(3), tickMs: +BR.tickMs.toFixed(3), maxTickMs: +BR.maxTickMs.toFixed(3), slowed: BR.slowed, budgetMs: BR.budget }; },
    CREDITS,
    advance(ms) { stepWorld(Math.round(ms / DT * speed)); },
    setLifeScale(v) { EVO.lifeScale = clamp(+v || 1, 0.001, 100); return EVO.lifeScale; },
    setSpeed(v) { speed = clamp(v, 0, 8); return speed; },
    scent(x, y) { S.scents.push({ x: x ?? rnd(60, W - 60), y: y ?? rnd(60, H - 60), s: 1 }); },
    touch(x, y) { S.pointer = { x, y, t: S.T }; setTimeout(() => { if (S.pointer && S.pointer.t <= S.T) S.pointer = null; }, 600); if (inPond(x, y)) S.ripples.push({ x, y, t: S.T }); },
    seed() { S.seeds.push({ x: rnd(560, 880), y: rnd(300, 560), vx: rnd(-0.03, 0.03), vy: rnd(-0.03, 0.03) }); },
    who() { const c = census(); return Object.entries(c.by).map(([k, v]) => v.n + " " + (v.n === 1 ? k : (SPECIES[v.key] && SPECIES[v.key].plural) || k + "s") + " (" + (v.real ? "real brain, " : "") + v.spikes.toLocaleString() + " spikes, " + v.meals + " meals" + (v.maxGen ? ", generation " + v.maxGen : "") + ")").join(" - "); }
  };
})();
