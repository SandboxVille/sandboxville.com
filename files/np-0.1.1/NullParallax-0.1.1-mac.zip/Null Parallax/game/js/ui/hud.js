// Presentation only: the probe's log voice (bottom left), the objective line
// (top), status and resource panels, the EM meter (what the Listener hears),
// the world waypoint, the build bar, the fear overlays (dark, cold,
// radiation, drift), and the live console screen inside the ship.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { camera, ship } from '../render/scene.js';
import { shipFx, HATCH_EXT } from '../render/ship.js';
import { SHIP_CENTER, dOutOf } from '../render/world.js';
import { TETHER_MAX, BOUNDARY_R } from '../core/constants.js';
import { tetherKey, lastInputDevice } from '../core/input.js';
import * as audio from '../audio.js';

const $ = id => document.getElementById(id);
const consoleEl = $('console');

// ---------------- the log voice ----------------
export function say(text, { hold = 14000, delay = 0 } = {}) {
  return new Promise(res => setTimeout(() => {
    const line = document.createElement('div'); consoleEl.appendChild(line);
    let i = 0; const tick = setInterval(() => { line.textContent = text.slice(0, ++i); if (i % 3 === 0) audio.blip(1400, 0.006); if (i >= text.length) { clearInterval(tick); res(); } }, 22);
    if (hold) setTimeout(() => { line.style.opacity = 0; setTimeout(() => line.remove(), 3000); }, hold + text.length * 22);
    while (consoleEl.children.length > 6) consoleEl.firstChild.remove();
  }, delay));
}

const capEl = $('caption');
export function caption(text, holdMs = 2200) {
  if (!S.settings.subtitles || !capEl) return;
  capEl.textContent = text; capEl.style.opacity = 1;
  clearTimeout(caption._t);
  caption._t = setTimeout(() => { capEl.style.opacity = 0; }, holdMs);
}

// centre flash (pickups, short warnings)
export function flash(text, ms = 2400) {
  const el = $('lock'); el.textContent = text; el.style.opacity = 1;
  clearTimeout(el._t); el._t = setTimeout(() => el.style.opacity = 0, ms);
}
let promptText = null;






function devicePrompt(text) {
  if (!text) return text;
  const dev = lastInputDevice();
  if (dev === 'touch') return text;
  const key = dev === 'pad' ? 'X' : String((S.settings.keybinds && S.settings.keybinds.interact) || 'f').toUpperCase();
  if (key === 'F') return text;
  return text.replace(/^(HOLD )?F:/, (m, hold) => (hold || '') + key + ':');
}
export function prompt(text, op = 1) {
  const el = $('interact');
  const shown = devicePrompt(text);
  if (shown !== promptText) { el.textContent = shown; promptText = shown; }
  el.style.opacity = text ? op : 0;
}
let barVal = -1;
export function progressBar(v) {
  const el = $('repairBar');
  if (v === null || v === undefined) { if (barVal !== -1) { el.style.opacity = 0; barVal = -1; } return; }
  el.style.opacity = 1; const w = Math.max(0, Math.min(100, v));
  if (Math.abs(w - barVal) > 0.3) { el.querySelector('i').style.width = w + '%'; barVal = w; }
}

// ---------------- helpers ----------------
function setText(el, t) { if (el && el._t !== t) { el.textContent = t; el._t = t; } }
function setHTML(el, h) { if (el && el._h !== h) { el.innerHTML = h; el._h = h; } }
const bar = (v, low, cls = '') => `<span class="gbar${v < low ? ' low' : ''} ${cls}"><i style="width:${Math.max(0, Math.min(100, v)).toFixed(0)}%"></i></span>`;

// drift makes instruments lie a little: a number read at low sanity may be off
function lie(v, amt) {
  const s = S.P.life.sanity;
  if (s > 60 || Math.random() > (60 - s) / 400) return v;
  return v + (Math.random() - 0.5) * amt;
}

// ---------------- per-frame HUD ----------------
let slowT = 0, screenT = 0;
const tmp = new THREE.Vector3();
export function updateHud(dt, ctx) {
  const P = S.P, L = P.life, T = S.threat;
  const hudOn = S.awake && !S.ended;
  document.body.classList.toggle('hudOn', hudOn);
  document.body.classList.toggle('building', !!S.buildMode);
  if (!hudOn) return;
  // objective
  const obj = ctx.objective || { text: '', sub: '' };
  setText($('objText'), obj.text || '');
  setText($('objSub'), obj.sub || '');
  // waypoint
  updateWaypoint(obj);
  slowT -= dt;
  if (slowT <= 0) {
    slowT = 0.15;
    updatePanels(ctx);
  }
  updateOverlays(dt);
  updateEm(ctx);
  updateBuildBar(ctx);
  screenT -= dt;
  if (screenT <= 0) { screenT = 0.5; drawConsoleScreen(ctx); }
}

function updatePanels(ctx) {
  const P = S.P, L = P.life, pw = ctx.power;
  const eva = S.mode === 'eva' || S.mode === 'derelict';
  let h = '';
  if (eva) {
    const o2 = lie(S.eva.oxygen, 30);
    h += `<div class="g"><b>O2</b> ${bar(o2, 25)} ${Math.round(o2)}%</div>`;
    h += `<div class="g"><b>SUIT</b> ${bar(S.eva.power, 20)} ${Math.round(S.eva.power)}%${S.eva.lamp ? ' <em>LAMP</em>' : ''}</div>`;
    h += `<div class="g"><b>PROP</b> ${bar(S.eva.propellant, 20)} ${Math.round(S.eva.propellant)}%</div>`;
  } else {
    h += `<div class="g"><b>CABIN</b> <span class="${L.cabinC < 2 ? 'warn' : ''}">${lie(L.cabinC, 8).toFixed(0)} C</span> &nbsp; <b>AIR</b> ${Math.round(L.shipO2)}%</div>`;
    const lvl = pw.level === 'powered' ? 'MAIN' : pw.level === 'emergency' ? (P.repair.power >= 100 ? 'BROWNOUT' : 'EMERGENCY') : 'DARK';
    h += `<div class="g"><b>POWER</b> <span class="${pw.level !== 'powered' ? 'warn' : ''}">${lvl}</span> ${pw.gen.toFixed(1)}/${pw.use.toFixed(1)} &nbsp; <b>BATT</b> ${Math.round(L.battery)}%</div>`;
  }
  for (const [key, label] of [['health', 'HEALTH'], ['hunger', 'HUNGER'], ['thirst', 'THIRST']]) h += `<div class="g"><b>${label}</b> ${bar(L[key], 25)} ${Math.ceil(L[key])}%</div>`;
  // v0.5 slice B: a cooked meal leaves you WELL FED (slower drain); a toxic plant leaves you SICK
  const Fd = P.food;
  if (Fd && (Fd.fed > 0 || Fd.sick > 0)) h += `<div class="g" id="foodTags">${Fd.fed > 0 ? `<em>WELL FED ${Math.ceil(Fd.fed / 60)} MIN</em> ` : ''}${Fd.sick > 0 ? `<span class="warn">SICK: HUNGER AND THIRST DRAIN FAST</span>` : ''}</div>`;
  h += `<div class="g"><b>WARMTH</b> ${bar(L.warmth, 35)} </div>`;
  if (L.rad > 3 || S.threat.pulse.state !== 'dormant') h += `<div class="g"><b>RAD</b> ${bar(L.rad, 200, 'rad')} ${Math.round(L.rad)}</div>`;
  h += `<div class="g"><b>MIND</b> ${bar(lie(L.sanity, 30), 35, 'mind')} </div>`;
  if (eva && S.surfaceInfo) {
    h += `<div class="dim">${S.surfaceInfo}</div><div class="dim">SHIP ${Math.round(S.pos.distanceTo(HATCH_EXT))} M</div>`;
  } else if (eva) {
    const r = S.pos.distanceTo(SHIP_CENTER);
    const sp = S.vel.length();
    // W0: past the edge the suit does not know where the ship is
    const outside = S.mode === 'eva' && r > BOUNDARY_R;
    h += `<div class="dim">SHIP ${outside ? '???' : Math.round(r)} M &nbsp; SPEED ${sp.toFixed(1)} M/S</div>`;
    h += `<div class="dim">DAMPERS ${S.eva.dampers ? 'ON' : '<span class="warn">OFF</span>'}</div>`;
    // W0: the LINE gauge. Mechanical, so it reads true even outside. Amber past 50 m.
    if (S.mode === 'eva') {
      const key = tetherKey();
      if (S.eva.tethered) { const used = Math.min(TETHER_MAX, S.pos.distanceTo(HATCH_EXT)); h += `<div class="dim lineG${used > 50 ? ' amber' : ''}">LINE ${Math.round(used)}/${TETHER_MAX} M&nbsp;&nbsp;${key}: UNCLIP</div>`; }
      else h += `<div class="dim lineG"><span class="warn">UNCLIPPED</span>&nbsp;&nbsp;${key} AT THE HATCH: CLIP ON</div>`;
    }
  }
  setHTML($('status'), h);
  const R = P.res;
  setHTML($('res'), `<div><b>SALVAGE</b> ${R.salvage}</div><div><b>ORE</b> ${R.ore}</div><div><b>ICE</b> ${R.ice}</div><div><b>FUEL</b> ${R.fuel}</div><div><b>MEALS</b> ${R.meals}</div><div><b>WATER</b> ${R.water}</div>${R.carbon ? `<div><b>CARBON</b> ${R.carbon}</div>` : ''}${R.fibre ? `<div><b>FIBRE</b> ${R.fibre}</div>` : ''}${R.plant ? `<div><b>PLANTS</b> ${R.plant}</div>` : ''}${R.badplant ? `<div class="warn"><b>TOXIC</b> ${R.badplant}</div>` : ''}${(R.hotmeal || 0) + (R.salad || 0) + (R.stew || 0) + (R.tea || 0) ? `<div><b>COOKED</b> ${(R.hotmeal || 0) + (R.salad || 0) + (R.stew || 0) + (R.tea || 0)}</div>` : ''}`);
  // control hints (context)
  const pad = ctx.device === 'pad';
  let hint;
  if (S.landHelm) hint = pad ? 'Y: LAND / TAKE OFF   RT: RETRO   LEFT STICK: NOSE   X: STAND   START: MENU' : 'G: LAND / TAKE OFF   1-4: PLANET   W / SPACE: RETRO   MOUSE / S: NOSE UP   F: STAND UP   ESC: MENU';
  else if (S.buildMode && S.buildSurface) hint = pad ? 'D-PAD: PART   LB / RB: TURN   A: BUILD   B: EXIT' : '1-9 / WHEEL: PART   Q / E: TURN   CLICK: BUILD   G: TAKE BACK   B: EXIT';
  else if (eva && S.surfaceInfo) hint = pad ? 'X HOLD: COLLECT / MINE   A: JUMP   Y: BUILD A BASE   D-UP: LAMP   START: MENU' : 'WASD: WALK   SHIFT: RUN   SPACE: JUMP   F HOLD: COLLECT / MINE   B: BUILD A BASE   TAB: SCAN   L: LAMP   ESC: MENU';
  else if (S.helm) hint = pad ? 'STICKS: TURN   RT HOLD: GAS   LT HOLD: BRAKE   A HOLD: ALIGN   BACK: GO DARK (CUTS THE DRIVE)   X: STAND   START: MENU' : 'MOUSE / A D / ARROWS: TURN   Q/E: ROLL   W HOLD: GAS   S HOLD: BRAKE   SPACE HOLD: ALIGN   X: GO DARK (CUTS THE DRIVE)   F: STAND UP   ESC: MENU';
  else if (S.buildMode) hint = pad ? 'D-PAD: PART   A: BUILD   B: EXIT   Y: EXIT' : '1-9 / WHEEL: PART   CLICK: BUILD   G: TAKE BACK   B: EXIT';
  else if (eva) hint = pad ? 'X HOLD: CUT/REPAIR   A: SIGHT   Y: BUILD   D-UP: LAMP   D-DOWN: SCAN   R3: DAMPERS   START: MENU' : 'F HOLD: CUT / REPAIR   CLICK: SIGHT   B: BUILD   L: LAMP   TAB: SCAN   V: DAMPERS   T: TETHER   ESC: MENU';
  else hint = pad ? 'X: USE   A: SIGHT   BACK: GO DARK   START: MENU' : 'F: USE   CLICK: SIGHT   SHIFT: RUN   X: GO DARK   J: JOURNAL   M: MISSION   ESC: MENU';
  setText($('ctrlHint'), hint);
}

// what the Listener hears: attention (fill) and current emission (tick)
function updateEm(ctx) {
  const el = $('em');
  const T = S.threat;
  if (!ctx.listenerActive) { el.style.opacity = 0; return; }
  el.style.opacity = 1;
  const a = Math.min(100, T.attention);
  el.querySelector('i').style.height = a + '%';
  el.querySelector('u').style.bottom = Math.min(100, (T.emit || 0) * 12) + '%';
  el.classList.toggle('hot', T.listenerState !== 'idle');
  setText(el.querySelector('span'), T.listenerState === 'passing' ? 'SILENCE' : T.listenerState === 'coming' ? 'QUIET' : 'EM');
}

function updateBuildBar(ctx) {
  const el = $('buildBar');
  if (!S.buildMode) { el.style.display = 'none'; return; }
  el.style.display = 'flex';
  const html = ctx.parts.map((p, i) => {
    const d = ctx.PARTS[p]; const locked = d.unlock && !S.P.unlocks[d.unlock];
    const afford = Object.entries(d.cost).every(([k, v]) => (S.P.res[k] || 0) >= v);
    return `<div class="bp${i === S.buildPart ? ' sel' : ''}${locked ? ' locked' : ''}${!afford ? ' poor' : ''}"><b>${i + 1} ${locked ? '???' : d.label}</b><small>${locked ? 'NOT KNOWN YET' : Object.entries(d.cost).map(([k, v]) => `${v} ${k}`).join(' ')}</small></div>`;
  }).join('');
  const sel = ctx.PARTS[ctx.parts[S.buildPart]];
  setHTML(el, `<div class="bps">${html}</div><div class="bdesc">${(sel.unlock && !S.P.unlocks[sel.unlock]) ? '' : sel.desc.toUpperCase() + (sel.power > 0 ? ` USES ${sel.power} POWER.` : '')}<br><span class="dim">${ctx.buildReason || ''}</span></div>`);
}

function updateWaypoint(obj) {
  const el = $('waypoint');
  if (!obj.target || S.dying || S.sleeping) { el.style.display = 'none'; return; }
  tmp.copy(obj.target); ship.localToWorld(tmp);
  const dist = S.pos.distanceTo(obj.target);
  camera.updateMatrixWorld();
  const c = tmp.clone().applyMatrix4(camera.matrixWorldInverse);   // camera space: x right, y up, -z ahead
  const p = tmp.clone().project(camera);
  let x = (p.x + 1) / 2 * innerWidth, y = (1 - p.y) / 2 * innerHeight;
  const m = 40, top = m + 30;
  let edge = c.z > 0 || x < m || x > innerWidth - m || y < top || y > innerHeight - m;
  // playtest: off-screen, the marker used to park at the bottom edge for "behind you" AND for "below you",
  // so nobody could tell which way to turn. Now it rides the screen border in the direction to turn,
  // with an arrow pointing that way.
  // "behind" means well behind: a target almost straight below or above you is not labelled behind
  const behind = c.z > 0.35 * c.length();
  let ang = 0;
  if (edge) {
    let dx = c.x, dy = c.y;
    // behind you: point left or right (turn around), never straight down at the floor
    if (behind) { const h = Math.hypot(c.x, c.z); dx = (c.x >= 0 ? 1 : -1) * Math.max(Math.abs(c.x), 0.8 * h); dy = c.y * 0.5; }
    if (Math.hypot(dx, dy) < 1e-4) { dx = 1; dy = 0; }
    const hw = innerWidth / 2 - m, hh = (innerHeight - m - top) / 2, cy = top + hh;
    const k = Math.min(hw / Math.abs(dx || 1e-6), hh / Math.abs(dy || 1e-6));
    x = innerWidth / 2 + dx * k; y = cy - dy * k;
    ang = Math.atan2(-dy, dx) * 180 / Math.PI;
  }
  el.style.display = 'block';
  el.style.transform = `translate(${x.toFixed(0)}px, ${y.toFixed(0)}px)`;
  el.classList.toggle('edge', edge);
  el.classList.toggle('behind', behind);
  el.classList.toggle('flip', x > innerWidth - 190);
  el.dataset.ang = edge ? ang.toFixed(0) : '';
  let arrow = el.querySelector('i');
  if (!arrow) { arrow = document.createElement('i'); el.appendChild(arrow); }
  arrow.style.transform = `rotate(${ang.toFixed(0)}deg) translateX(14px)`;
  // W0: outside the edge the distance is unknown; a target past the end of the line says so
  const dtxt = S.mode === 'eva' && dOutOf(S.pos) > 0 ? '???' : dist < 1000 ? Math.round(dist) + ' M' : '';
  setText(el.querySelector('span'), `${obj.label || ''} ${dtxt}${behind ? ' (BEHIND YOU)' : ''}${obj.pastLine ? `  PAST YOUR LINE: ${tetherKey()}` : ''}`);
  el.style.opacity = dist < 2.2 ? 0.25 : 1;
}

// fear overlays: the dark creeping in, frost, radiation snow, drift
let noiseCtx = null, noiseT = 0;
function updateOverlays(dt) {
  const T = S.threat, L = S.P.life;
  const k = T.dark / 100;
  const breathe = Math.sin(performance.now() / 1000 * (1.1 + k * 1.8)) * (2 + k * 5);
  $('ovDark').style.opacity = Math.min(1, k * 1.25).toFixed(3);
  $('ovDark').style.setProperty('--r', (64 - k * 42 + breathe).toFixed(1) + '%');
  const cold = L.warmth < 50 ? (50 - L.warmth) / 50 : 0;
  $('ovCold').style.opacity = cold.toFixed(3);
  const jolt = T.figureJolt ? Math.max(0, 1 - (performance.now() - T.figureJolt) / 700) : 0; // CREW 2's sting
  const hurt = Math.max(S.lastImpactT && performance.now() - S.lastImpactT < 400 ? 0.5 : 0, jolt * 0.8);
  $('ovHurt').style.opacity = hurt;
  // static: radiation surge and a failing mind
  const rad = T.pulse.state === 'pulse' ? 0.13 : 0;
  const drift = L.sanity < 40 ? (40 - L.sanity) / 40 * 0.1 : 0;
  const passing = T.listenerState === 'passing' ? 0.035 : 0;
  const st = Math.max(rad, drift, passing, T.figureFlicker > 0 ? 0.12 : 0, T.figureAfter > 0 ? 0.04 + 0.08 * T.figureAfter / 10 : 0, jolt * 0.3);
  const nc = $('ovNoise');
  nc.style.opacity = st > 0.01 ? 1 : 0;
  if (st > 0.01) {
    noiseT -= dt;
    if (noiseT <= 0) {
      // sparse bright hits, like particles striking a camera sensor; denser as it gets worse
      noiseT = 0.05;
      if (!noiseCtx) noiseCtx = nc.getContext('2d');
      const W = Math.max(320, innerWidth >> 1), H = Math.max(180, innerHeight >> 1);
      if (nc.width !== W || nc.height !== H) { nc.width = W; nc.height = H; }
      noiseCtx.clearRect(0, 0, nc.width, nc.height);
      const n = Math.floor(st * 1500);
      for (let i = 0; i < n; i++) {
        const a = 0.2 + Math.random() * 0.6, big = Math.random() < 0.04;
        noiseCtx.fillStyle = `rgba(${230 + Math.random() * 25 | 0},${220 + Math.random() * 35 | 0},${200 + Math.random() * 55 | 0},${a.toFixed(2)})`;
        noiseCtx.fillRect(Math.random() * nc.width | 0, Math.random() * nc.height | 0, big ? 2 : 1, big ? 2 : 1);
      }
      if (T.listenerState === 'passing' || L.sanity < 25) { noiseCtx.fillStyle = 'rgba(40,10,10,0.08)'; noiseCtx.fillRect(0, Math.random() * nc.height | 0, nc.width, 2 + Math.random() * 6); }
    }
  }
  document.body.classList.toggle('drifting', L.sanity < 30);
}

// ---------------- the console screen inside the ship ----------------
function drawConsoleScreen(ctx) {
  const scr = shipFx.screen; if (!scr) return;
  const g = scr.g, P = S.P, L = P.life, pw = ctx.power;
  const on = pw.level !== 'dark';
  g.fillStyle = on ? '#020a0d' : '#000'; g.fillRect(0, 0, 512, 256);
  if (!on) { scr.tex.needsUpdate = true; return; }
  const c = pw.level === 'powered' ? '#6fd0ff' : '#ff5a3a';
  g.fillStyle = c; g.font = 'bold 22px monospace';
  const fln = ctx.flightLines;
  g.fillText(P.storyStep <= 1 ? 'KESTREL-4  //  PRESS F' : fln ? 'KESTREL-4  //  UNDER WAY' : `KESTREL-4  //  ${P.place ? (P.place.name || 'HIP ' + P.place.hip) : 'SYSTEM ' + P.system}`, 16, 32);
  g.font = '18px monospace';
  const line = (i, t, warn) => { g.fillStyle = warn ? '#ff5a3a' : c; g.fillText(t, 16, 64 + i * 26); };
  if (fln) { fln.forEach((t, i) => line(i, t, i === 5 && P.flight && P.flight.heat > 80)); scr.tex.needsUpdate = true; return; }
  line(0, `POWER   ${pw.level.toUpperCase()}  ${pw.gen.toFixed(1)} / ${pw.use.toFixed(1)}`, pw.level !== 'powered');
  line(1, `CABIN   ${L.cabinC.toFixed(0)} C    AIR ${Math.round(L.shipO2)}%`, L.cabinC < 2);
  line(2, `REPAIR  PWR ${Math.round(P.repair.power)}  COM ${Math.round(P.repair.comms)}  THR ${Math.round(P.repair.thrusters)}`);
  line(3, `FIX     ${S.fixed ? 'HELD' : 'NONE'}   LOG ${P.journalOrder.length}`);
  line(4, 'D-7     DEFER', true);
  line(5, S.threat.listenerState !== 'idle' ? 'EM      SOMETHING IS LISTENING' : `EM      ${(S.threat.emit || 0).toFixed(1)}`, S.threat.listenerState !== 'idle');
  scr.tex.needsUpdate = true;
}
