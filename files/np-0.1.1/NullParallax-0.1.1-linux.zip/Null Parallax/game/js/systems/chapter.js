// CH1: the chapter-complete beat. Not one of the four full endings -- "one
// clean, honest stopping point... so this can ship standalone" (Phase 1
// scope). Shown once, the first time THRUSTERS and fuel clear System 1, then
// the player continues straight into System 2 (already in the codebase as
// the seed of Act II). No dead end: continuing is the only button.
import { S } from '../core/state.js';
import * as audio from '../audio.js';
import { releaseLock } from '../core/input.js';

const $ = id => document.getElementById(id);

const RECAP_LINES = [
  'YOU WOKE FOUR LIGHT YEARS FROM HOME, IN A PROBE THAT CANNOT FLY THAT FAR.',
  'YOU CALLED HOME. SOMETHING 1.6 MILLION KILOMETRES AWAY ANSWERED FIRST, IN YOUR WORDS, UNDER THE OTHER CREW MEMBER\'S NAME.',
  'THE OTHER SHIP WAS THIS SHIP. THE SUIT HAD YOUR NAME ON IT. THE RECORDER STOPPED MID-SENTENCE, CERTAIN.',
  'THE JUMP WILL TAKE YOU SOMEWHERE ELSE. IT WILL NOT TAKE YOU OUTSIDE WHATEVER THIS IS.',
];

export function showChapterComplete(onContinue) {
  showCard({ title: 'CHAPTER 1 COMPLETE', lines: RECAP_LINES }, onContinue);
}
// P3: the same card, any title (Act II uses it)
export function showCard({ title, lines, sub }, onContinue) {
  const el = $('chapterEnd');
  if (!el) { onContinue(); return; } // defensive: never block progress on a missing element
  audio.duck(true);
  audio.chapterClose();
  el.querySelector('h2').textContent = title;
  el.querySelector('#chapterEndBody').innerHTML = (sub ? `<div class="sub">${sub}</div>` : '') + lines.map(l => `<div>${l}</div>`).join('');
  el.style.display = 'flex';
  requestAnimationFrame(() => el.style.opacity = 1);
  // playtest: under pointer lock the mouse cannot reach the continue button (every click goes to the game),
  // so the card used to sit there until its 24 s timeout. It now frees the mouse and also takes a key.
  releaseLock();
  const onKey = e => { if (e.key === 'Enter' || e.key === ' ' || e.key === 'f' || e.key === 'F') { e.preventDefault(); e.stopImmediatePropagation(); go(); } };
  addEventListener('keydown', onKey, true);
  let done = false;
  const go = () => {
    if (done) return; done = true;
    removeEventListener('keydown', onKey, true);
    el.style.opacity = 0;
    setTimeout(() => { el.style.display = 'none'; audio.duck(S.paused); }, 900);
    btn.removeEventListener('click', go);
    onContinue();
  };
  const btn = $('chapterEndContinue');
  btn.addEventListener('click', go);
  // no dead end even if the button is somehow unreachable (e.g. a headless
  // test driver that only presses keys): auto-continue after a long pause.
  setTimeout(go, 45000);
}
