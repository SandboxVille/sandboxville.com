// Interaction: everything F does. The airlock, the tether, cutting salvage
// out of the field, repairing the three fixtures, examining the things the
// ship keeps in plain sight, the bunk, the console, and the derelict.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { EYE_H, INTERACT_RADIUS, REEL_ACCEL, REPAIR_RATE, HARVEST_RATE, OXY_MAX, PROP_MAX, SECRET_RADIUS, REPAIR_COST, TETHER_MAX } from '../core/constants.js';
import { tetherKey } from '../core/input.js';
import { noteText } from '../ui/howto.js';
import { HATCH_INT, HATCH_EXT, SECRET_POS, CONSOLE_POS, BUNK_POS, nodeList, shipFx } from '../render/ship.js';
import { ship } from '../render/scene.js';
import { field, derelict, derelictPointWorld, updateFieldMatrices } from '../render/world.js';
import { spawnInterior, enterEvaOrientation, leaveEvaOrientation } from './movement.js';
import { repair, remainingCost } from './repair.js';
import { refillSuit, sleep } from './survival.js';
import { unlockFragment } from './journal.js';
import { sharedBasis } from '../core/utils.js';
import { say, flash, prompt, progressBar } from '../ui/hud.js';
import { doAutosave } from './save-state.js';
import { emit } from '../core/events.js';
import * as audio from '../audio.js';
import * as flight from './flight.js';
import { stations, useGalley, crateIn, crateFound, cookFocus } from './galley.js';
import * as wreck from './derelict.js';
import { doJump, jumpReady } from './repair.js';
import * as landing from './landing.js';

// ---------------- tether ----------------
export function buildTetherLine() {
  removeTetherLine();
  const geo = new THREE.BufferGeometry().setFromPoints([HATCH_EXT.clone(), S.pos.clone()]);
  S.tetherLine = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0.5 }));
  S.tetherLine.frustumCulled = false;
  ship.add(S.tetherLine);
}
export function removeTetherLine() { if (S.tetherLine) { ship.remove(S.tetherLine); S.tetherLine.geometry.dispose(); S.tetherLine.material.dispose(); S.tetherLine = null; } }
export function updateTetherLine() {
  if (!S.tetherLine) return;
  if (!S.eva.tethered || S.mode !== 'eva') { removeTetherLine(); return; }
  const p = S.tetherLine.geometry.attributes.position;
  p.setXYZ(0, HATCH_EXT.x, HATCH_EXT.y, HATCH_EXT.z); p.setXYZ(1, S.pos.x, S.pos.y - 0.3, S.pos.z);
  p.needsUpdate = true;
}
export function cutTether() {
  if (S.mode !== 'eva' || !S.eva.tethered) return;
  S.eva.tethered = false; removeTetherLine();
  say('TETHER CUT. NOTHING IS HOLDING YOU TO THE SHIP NOW.', { hold: 6000 }); audio.blip(500, 0.03);
  emit('tetherCut');
}
// W0: the line is a tool. Clipped: T cuts it (today's text). Unclipped at the hatch: T clips you back on.
export const CLIP_R = 4;
export function toggleTether() {
  if (S.mode !== 'eva' || S.cycling) return;
  if (S.eva.tethered) { cutTether(); return; }
  if (S.pos.distanceTo(HATCH_EXT) <= CLIP_R) {
    S.eva.tethered = true; buildTetherLine();
    say(`CLIPPED ON. ${TETHER_MAX} M OF LINE.`, { hold: 6000 }); flash('CLIPPED ON.', 1600); audio.click(1500);
    emit('tetherOn');
  } else flash(`CLIP ON AT THE HATCH: FLY BACK TO IT AND PRESS ${tetherKey()}.`, 2600);
}

// ---------------- airlock ----------------
export function cycleAirlock() {
  if (S.cycling) return;
  S.cycling = true;
  const goingOut = S.mode === 'interior';
  flash(goingOut ? 'CYCLING AIRLOCK: SUIT SEALED, DEPRESSURIZING' : 'CYCLING AIRLOCK: REPRESSURIZING', 1800);
  audio.servo();
  if (shipFx.hatchLight) shipFx.hatchLight.material.color.setHex(0xffb347);
  setTimeout(() => {
    if (goingOut) {
      S.mode = 'eva'; S.pos.copy(HATCH_EXT).add(new THREE.Vector3(0.8, 0, 0)); S.vel.set(0.6, 0, 0);
      enterEvaOrientation();
      S.eva.tethered = !landing.onSurface(); // v0.5: on the ground there is nothing to be tethered against
      S.eva.lamp = S.eva.power > 0 && !(landing.onSurface() && landing.debug().day > 0.5);
      if (shipFx.suitOnRack) shipFx.suitOnRack.visible = false;
      if (S.eva.tethered) buildTetherLine();
      emit('eva');
    } else {
      leaveEvaOrientation();
      spawnInterior('airlock');
      removeTetherLine();
      refillSuit();
      if (shipFx.suitOnRack) shipFx.suitOnRack.visible = true;
      emit('inside');
    }
    if (shipFx.hatchLight) shipFx.hatchLight.material.color.setHex(0xff3020);
    S.cycling = false;
    doAutosave(true);
  }, 1500);
}

// ---------------- aiming ----------------
const _f = new THREE.Vector3(), _to = new THREE.Vector3();
export function aimedChunk(maxDist = 7.5) {
  const B = sharedBasis(S.q); _f.copy(B.f);
  let best = null, bestT = Infinity;
  for (const c of field.chunks) {
    if (c.hp <= 0) continue;
    _to.copy(c.pos).sub(S.pos);
    const t = _to.dot(_f);
    if (t <= 0 || t > maxDist + c.radius) continue;
    const perp2 = _to.lengthSq() - t * t;
    const r = c.radius * 1.15 + 0.2;
    if (perp2 < r * r && t < bestT) { bestT = t; best = c; }
  }
  return best;
}
function lookingAt(p, maxDist, maxDeg) {
  _to.copy(p).sub(S.pos); const d = _to.length();
  if (d > maxDist) return false;
  if (d < 0.9) return true;
  return _to.normalize().angleTo(sharedBasis(S.q).f) < THREE.MathUtils.degToRad(maxDeg);
}

// examine points inside the ship: position, radius, text (once each gives a flag)
const EXAMINE = [
  { id: 'bunk2', pos: new THREE.Vector3(0.95, 0.7, -4.4), text: () => S.P.act2 && S.P.act2.manifest ? 'THE OTHER BUNK IS MADE. THE BLANKET IS WARM. THE PILLOW STILL HAS THE SHAPE OF A HEAD IN IT. NOBODY IS IN IT.' : 'THE OTHER BUNK. STRIPPED TO THE FRAME. THE STRAPS WERE CUT, NOT UNBUCKLED.' },
  { id: 'photo', pos: new THREE.Vector3(-1.25, 1.35, -2.6), text: 'TWO PEOPLE IN SUITS. ONE HAS BEEN TORN AWAY. YOU DO NOT REMEMBER TEARING IT.', frag: 'photo' },
  { id: 'hook', pos: new THREE.Vector3(-1.3, 1.6, 1.0), text: () => S.P.act2 && S.P.act2.manifest ? 'TWO HOOKS. TWO SUITS. THE SECOND ONE IS DAMP INSIDE, AS IF SOMEONE HAS JUST TAKEN IT OFF.' : 'TWO HOOKS. ONE SUIT. THE MANIFEST SAYS TWO SUITS WERE LOADED.' },
  { id: 'tally', pos: new THREE.Vector3(-1.255, 1.05, -3.4), text: () => `TALLY MARKS, ONE PER SLEEP. YOU COUNT ${11 + S.P.stats.sleeps + (S.P.stats.flightDays || 0)}. YOU REMEMBER ${S.P.stats.sleeps === 0 ? 'NONE OF THEM' : S.P.stats.sleeps}.${S.P.stats.flightDays ? ` ${S.P.stats.flightDays} OF THEM ARE FROM THE FLIGHT. THEY ARE IN YOUR HANDWRITING.` : ''}`, frag: 'tally' },
  { id: 'window', pos: new THREE.Vector3(0, 1.45, -9.4), r: 2.2, text: () => S.fixed ? 'THE SAME STARS YOU LEARNED AS A CHILD. FROM HERE THEY ARE IN THE WRONG PLACES, BY EXACTLY THE RIGHT AMOUNT.' : 'STARS. CLICK ONE TO SIGHT IT.' },
  // W0: the PRE-EVA placard by the hatch, and the note taped by the other bunk (its lines live in ui/howto.js)
  { id: 'preeva', pos: new THREE.Vector3(1.44, 1.45, 1.62), text: () => { const k = tetherKey(); return `PRE-EVA, STENCILLED BY THE HATCH: LAMP ON (L). AIR: ABOUT 5 MINUTES, TURN BACK AT HALF. LINE ${TETHER_MAX} M. ${k} UNCLIPS. ${k} AT THE HATCH CLIPS BACK ON.`; } },
  { id: 'note', pos: new THREE.Vector3(1.25, 1.3, -3.05), text: () => noteText(S.P.flags) },
];

// ---------------- the per-frame F logic ----------------
let lastPrompt = '';
export function updateInteract(dt, fHeld, fEdge) {
  S.activeRepairNode = null; S.harvestTarget = null;
  audio.setCutter(false);
  if (S.cycling || S.dying || S.sleeping || S.ended || S.helm) { prompt(''); progressBar(null); return; }
  if (S.mode === 'interior') { interiorInteract(fEdge); progressBar(null); return; }
  if (S.buildMode) { prompt(''); progressBar(null); return; }
  evaInteract(dt, fHeld, fEdge);
}

const CHAIR = new THREE.Vector3(-0.72, 0.75, -7.95);
function interiorInteract(fEdge) {
  const P = S.P;
  S.chairOffer = false;
  // (P3: near the hatch but looking at something else, such as the suit rack, lets you look closer at it)
  if (S.pos.distanceTo(HATCH_INT) < 1.9 && (S.pos.distanceTo(HATCH_INT) < 1.0 || lookingAt(HATCH_INT, 1.9, 60))) {
    if (P.flight && P.flight.started) { prompt('THE AIRLOCK IS LOCKED WHILE THE SHIP IS UNDER WAY.'); return; }
    // 2026-09-28: a course plotted but not lit is still parked. The airlock used to lock then too, so a plan
    // without the fuel to finish it could never be fixed. Going out now cancels the course; the fuel goes back.
    if (P.flight) {
      prompt('F: CYCLE THE AIRLOCK (CANCELS THE COURSE: THE FUEL GOES BACK TO THE HOLD)');
      if (fEdge && flight.cancelPlan()) { if (P.mode === 'campaign' && P.storyStep === 10) P.storyStep = 8; cycleAirlock(); }
      return;
    }
    prompt('F: CYCLE THE AIRLOCK (GO OUTSIDE)');
    if (fEdge) cycleAirlock();
    return;
  }
  for (const station of stations) {
    const p = new THREE.Vector3(1.65, 1.35, station.z);
    const to = p.clone().sub(S.pos);
    if (to.length() < 2.1 && to.normalize().angleTo(sharedBasis(S.q).f) < 0.20) {
      if (station.id === 'cook') cookFocus();
      prompt(`F: ${station.label} // ${station.detail()}`);
      if (fEdge) useGalley(station.id);
      return;
    }
  }
  // P3: the helm (the left chair at the console)
  const chairD = Math.hypot(S.pos.x - CHAIR.x, S.pos.z - CHAIR.z);
  // (the helm flies the ship: from System 1 in the story, anywhere in the sandbox; System 2 -> 3 is still the console jump)
  // v0.5: parked at a real star (sandbox), or on a planet: the helm lists the planets, lands and takes off
  const storyJump = P.mode === 'campaign' && P.system === 1 && P.storyStep >= 8 && jumpReady() && !P.landing;
  // v0.5 campaign: when the story's jump is ready it keeps F; the planets are on G
  if (storyJump && landing.canOrbit() && chairD < 1.25 && lookingAt(CHAIR, 2.2, 40)) {
    S.chairOffer = true;
    prompt(`F: SIT AT THE HELM (LEAVE THIS SYSTEM)  //  G: THE PLANETS OF ${landing.planetsHere().length ? landing.planetsHere()[0].name.replace(/ [b-h]$/, '') : 'THIS STAR'}`);
    if (fEdge) doJump();
    return;
  }
  if (!storyJump && (landing.canOrbit() || P.landing) && !P.flight && chairD < 1.25 && lookingAt(CHAIR, 2.2, 40)) {
    prompt(landing.onSurface() ? 'F: SIT AT THE HELM (TAKE OFF)' : 'F: SIT AT THE HELM (PLANETS, LAND, OR PLOT A COURSE)');
    if (fEdge) landing.enterHelm();
    return;
  }
  const canHelm = P.flight || (P.mode === 'campaign' && P.system === 1 && P.storyStep >= 8 && jumpReady()) || (P.mode === 'sandbox' && P.repair.thrusters >= 50);
  if (canHelm && chairD < 1.25 && (P.flight || lookingAt(CHAIR, 2.2, 40))) {
    prompt(P.flight ? 'F: SIT AT THE HELM' : P.mode === 'sandbox' ? 'F: SIT AT THE HELM (PLOT A COURSE)' : 'F: SIT AT THE HELM (LEAVE THIS SYSTEM)');
    if (fEdge) { if (P.flight) flight.enterHelm(); else doJump(); }
    return;
  }
  if (S.pos.distanceTo(CONSOLE_POS) < 2.1 && lookingAt(CONSOLE_POS, 2.6, 38)) {
    prompt(P.storyStep <= 1 ? 'F: WAKE THE CONSOLE' : 'F: USE THE CONSOLE');
    if (fEdge) emit('consoleUse');
    return;
  }
  if (S.pos.distanceTo(BUNK_POS) < 1.6 && lookingAt(BUNK_POS, 2, 60)) {
    prompt(P.flight ? 'F: SLEEP THROUGH THE COAST' : 'F: SLEEP (SAVES THE GAME)');
    if (fEdge) sleep(() => { if (!S.P.flight) doAutosave(true); });
    return;
  }
  for (const e of EXAMINE) {
    if (lookingAt(e.pos, e.r || 1.7, 32)) {
      prompt('F: LOOK CLOSER');
      if (fEdge) {
        const text = typeof e.text === 'function' ? e.text() : e.text;
        say(text, { hold: 12000 });
        if (!P.flags['ex_' + e.id]) { P.flags['ex_' + e.id] = true; if (e.frag) unlockFragment(1, e.frag); }
        emit('examined', e.id);
      }
      return;
    }
  }
  prompt('');
}

function evaInteract(dt, fHeld, fEdge) {
  const P = S.P;
  if (S.pos.distanceTo(HATCH_EXT) < INTERACT_RADIUS + 0.5) {
    prompt('F: CYCLE INSIDE');
    if (fEdge) cycleAirlock();
    progressBar(null);
    return;
  }
  // v0.5: on a planet, F collects from the ground (and nothing else out here is in reach)
  if (landing.onSurface()) { if (!landing.surfaceInteract(dt, fHeld, fEdge)) { prompt(''); progressBar(null); } return; }
  if (!P.secretFound && S.pos.distanceTo(SECRET_POS) < SECRET_RADIUS) {
    prompt('F: RECOVER THE CANISTER');
    if (fEdge) foundSecret();
    return;
  }
  // derelict: the body and the recorder
  if (derelict.group && S.pos.distanceTo(derelict.group.position) < 30) {
    const bodyP = derelictPointWorld(derelict.body), recP = derelictPointWorld(derelict.recorder);
    // P3: the break is a way in (and, once the recorder is out, the thing you came for)
    const bp = wreck.breakPoint();
    const dBreak = bp ? S.pos.distanceTo(bp) : Infinity;
    if (dBreak < 3.4 && (P.derelict.looted || P.mode === 'sandbox') && dBreak < S.pos.distanceTo(bodyP) + 0.6) {
      prompt(P.derelict.read ? 'F: CLIMB BACK INSIDE (MAG BOOTS)' : 'F: CLIMB INSIDE THROUGH THE BREAK (MAG BOOTS)');
      if (fEdge) wreck.enter();
      progressBar(null); return;
    }
    if (S.pos.distanceTo(bodyP) < 3.2) {
      prompt('F: CHECK THE SUIT');
      if (fEdge) checkBody();
      progressBar(null); return;
    }
    if (S.pos.distanceTo(recP) < 3.2 && !P.derelict.looted) {
      prompt('F: PULL THE FLIGHT RECORDER');
      if (fEdge) takeRecorder();
      progressBar(null); return;
    }
    if (dBreak < 3.4 && (P.derelict.looted || P.mode === 'sandbox')) {
      prompt(P.derelict.read ? 'F: CLIMB BACK INSIDE (MAG BOOTS)' : 'F: CLIMB INSIDE THROUGH THE BREAK (MAG BOOTS)');
      if (fEdge) wreck.enter();
      progressBar(null); return;
    }
  }
  // repair fixtures
  let node = null, nd = INTERACT_RADIUS + 0.4;
  for (const n of nodeList()) { const d = S.pos.distanceTo(n.pos); if (d < nd) { nd = d; node = n; } }
  if (node) {
    const v = P.repair[node.key];
    if (v >= 100) { prompt(`${node.label}: REPAIRED`); progressBar(null); return; }
    const rem = remainingCost(node.key);
    const hasAny = (rem.salvage === 0 || P.res.salvage > 0) && (rem.ore === 0 || P.res.ore > 0);
    const need = [rem.salvage ? `${rem.salvage} SALVAGE` : '', rem.ore ? `${rem.ore} ORE` : ''].filter(Boolean).join(' + ');
    if (!hasAny) { prompt(`${node.label} ${Math.round(v)}%: NEEDS ${need}. CUT IT FROM THE FIELD.`); progressBar(v); return; }
    prompt(`HOLD F: REPAIR ${node.label} (${Math.round(v)}%, STILL NEEDS ${need || 'NOTHING'})`);
    if (fHeld) {
      const added = repair(node.key, REPAIR_RATE * dt);
      S.activeRepairNode = node.key;
      S.noise += 1.4 * dt;
      audio.setCutter(added > 0);
      if (added <= 0) prompt(`${node.label} ${Math.round(P.repair[node.key])}%: OUT OF PARTS. NEEDS ${need}.`);
    }
    progressBar(P.repair[node.key]);
    return;
  }
  // salvage field
  const c = aimedChunk();
  if (c) {
    const label = c.type === 'salvage' ? 'SALVAGE PLATE' : c.type === 'ore' ? 'ORE ROCK' : 'ICE';
    prompt(`HOLD F: CUT ${label}${crateIn(c) ? '  //  A SEALED RATION CRATE IS WELDED TO IT' : ''}`);
    if (fHeld) {
      S.harvestTarget = c;
      c.hp -= 1.15 * dt * (0.8 + 0.4 / c.size);
      S.noise += 2.0 * dt;
      audio.setCutter(true);
      sparkAt(c);
      if (c.hp <= 0) harvestDone(c);
    }
    progressBar(Math.max(0, 100 - c.hp / c.maxHp * 100));
    return;
  }
  progressBar(null);
  if (S.eva.tethered) {
    prompt(fHeld ? 'REELING IN...' : 'HOLD F: REEL IN THE TETHER', 0.55);
    if (fHeld) reelIn(dt);
  } else prompt('');
}

function harvestDone(c) {
  c.hp = 0;
  const key = c.type;
  S.P.res[key] = (S.P.res[key] || 0) + c.yieldN;
  S.P.harvested[c.key] = 0;
  audio.pickup(key === 'ice' ? 'fuel' : 'scrap');
  const crate = crateFound(c);
  flash(`+${c.yieldN} ${key.toUpperCase()}${crate ? '  +2 RATIONS (SEALED CRATE)' : ''}   (SALVAGE ${S.P.res.salvage} / ORE ${S.P.res.ore} / ICE ${S.P.res.ice})`, 2400);
  updateFieldMatrices(0);
  emit('harvested', key);
  doAutosave();
}
function reelIn(dt) {
  const toAnchor = HATCH_EXT.clone().sub(S.pos);
  if (toAnchor.length() < 0.6) return;
  toAnchor.normalize(); S.vel.addScaledVector(toAnchor, REEL_ACCEL * dt);
  S.noise += 0.5 * dt;
}

// sparks while cutting: a tiny pooled point burst
let sparks = null;
function sparkAt(c) {
  if (!sparks) {
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(30 * 3), 3));
    sparks = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffc070, size: 0.08, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }));
    sparks.frustumCulled = false; ship.add(sparks);
    sparks.userData.life = new Float32Array(30); sparks.userData.vel = new Float32Array(90); sparks.userData.i = 0;
  }
  const B = sharedBasis(S.q);
  const hit = S.pos.clone().addScaledVector(B.f, Math.max(0.5, c.pos.distanceTo(S.pos) - c.radius * 0.8));
  const U = sparks.userData, p = sparks.geometry.attributes.position.array;
  for (let k = 0; k < 2; k++) {
    const i = U.i = (U.i + 1) % 30;
    p[i * 3] = hit.x; p[i * 3 + 1] = hit.y; p[i * 3 + 2] = hit.z;
    U.vel[i * 3] = (Math.random() - 0.5) * 3 - B.f.x * 2; U.vel[i * 3 + 1] = (Math.random() - 0.5) * 3 - B.f.y * 2; U.vel[i * 3 + 2] = (Math.random() - 0.5) * 3 - B.f.z * 2;
    U.life[i] = 0.5;
  }
}
export function updateSparks(dt) {
  if (!sparks) return;
  const U = sparks.userData, p = sparks.geometry.attributes.position.array;
  let any = false;
  for (let i = 0; i < 30; i++) {
    if (U.life[i] <= 0) { p[i * 3 + 1] = 1e6; continue; }
    any = true; U.life[i] -= dt;
    p[i * 3] += U.vel[i * 3] * dt; p[i * 3 + 1] += U.vel[i * 3 + 1] * dt; p[i * 3 + 2] += U.vel[i * 3 + 2] * dt;
  }
  sparks.geometry.attributes.position.needsUpdate = true;
  sparks.visible = any;
}

// ---------------- the canister (Chapter 1's off-path secret) ----------------
export function foundSecret() {
  if (S.P.secretFound) return;
  S.P.secretFound = true;
  audio.pickup('fuel');
  if (shipFx.secretGroup) shipFx.secretGroup.visible = false;
  S.P.res.salvage += 2;
  say('PERSONAL EFFECTS CANISTER. NOT ON ANY MANIFEST. INSIDE: A WATCH STOPPED AT 04:37, AND 2 SALVAGE.', { hold: 12000 });
  unlockFragment(1, 'secret');
  doAutosave(true);
}

// ---------------- the derelict ----------------
function checkBody() {
  const P = S.P;
  if (!P.derelict.body) {
    P.derelict.body = true;
    audio.dip(1200);
    say('THE NAME TAPE SAYS CREW 1.', { delay: 600, hold: 12000 });
    say('YOUR BUNK SAYS CREW 1.', { delay: 3400, hold: 12000 });
    say('THE VISOR IS DARK. YOU DO NOT LOOK INSIDE.', { delay: 6400, hold: 14000 });
    unlockFragment(1, 'body');
    emit('derelictBody');
  } else say('THE SUIT TURNS SLOWLY ON ITS LINE. IT IS THE SAME MODEL AS YOURS. IT HAS THE SAME SCUFF ON THE LEFT GLOVE.', { hold: 10000 });
}
function takeRecorder() {
  const P = S.P;
  P.derelict.looted = true;
  if (derelict.recorder) derelict.recorder.visible = false;
  audio.pickup('scrap');
  P.res.salvage += 3;
  say('FLIGHT RECORDER RECOVERED. THE LAST ENTRIES PLAY BACK IN YOUR VOICE:', { hold: 14000 });
  const lines = [
    'DAY 212. SIGHTED THREE STARS. THE FIX SAYS 4.00 LIGHT YEARS. THAT CANNOT BE RIGHT.',
    'DAY 213. SENT THE SIGNAL HOME. THE REPLY CAME BACK IN 11 SECONDS.',
    'DAY 219. FOUND THE OTHER SHIP. IT IS THIS SHIP. I DID NOT CHECK THE NAME ON THE SUIT.',
    'DAY 220. THE SKY HAS AN EDGE, ABOUT 900 METRES OUT. I WENT AND TOUCHED IT.',
    'DAY 221. I KNOW WHAT IT IS NOW. IT IS SIMPLE. IT IS',
  ];
  lines.forEach((l, i) => say(l, { delay: 2400 + i * 3600, hold: 26000 }));
  setTimeout(() => { unlockFragment(1, 'recorder'); emit('recorder'); doAutosave(true); }, 2400 + lines.length * 3600);
}

// test/support exports
export { reelIn, harvestDone };
void EYE_H; void OXY_MAX; void PROP_MAX; void REPAIR_COST; void HARVEST_RATE; void lastPrompt;
