// The things to fear. Each has ONE rule the player can learn and test:
//
//   THE LISTENER  -- it hears what you emit. Thrusters, sprinting, cutting,
//                    scanning, transmitting and the ship's own power draw all
//                    add to its attention. When it comes, go quiet: cut power
//                    (X), stop moving, wait for it to pass.
//   THE UNLIT     -- it lives where there is no light. In the dark outside
//                    your lamp it gathers. Keep a light on you or near you.
//   THE NEARER    -- it moves only while nothing is looking at it. Turn and
//                    face it and it stops. Watch masts count as looking.
//
// Plus the null-bearing surge (radiation you can hide from), hull contact
// (the Nearer on the outside of the ship while you are inside it), and the
// second crew member, who is only ever at the edge of your vision.
// None of them is ever explained. The rules are the only thing that is true.
import * as THREE from 'three';
import { S } from '../core/state.js';
import {
  LISTEN_DECAY, LISTEN_WARN, LISTEN_COME, UNLIT_RISE, UNLIT_FALL, NEARER_WATCH_DEG,
  NULL_PULSE_GAP, NULL_PULSE_WARN, NULL_PULSE_LEN, BOUNDARY_R,
} from '../core/constants.js';
import { randomDir, sharedBasis, clamp } from '../core/utils.js';
import { camera, approachMesh } from '../render/scene.js';
import { ROOMS } from '../render/ship.js';
import { listenerBody, figure, unlitShapes, SHIP_CENTER } from '../render/world.js';
import { power, lightLevel, die } from './survival.js';
import { moduleList, destroyRandomModule, PARTS } from './build.js';
import { say, caption, flash } from '../ui/hud.js';
import { emit } from '../core/events.js';
import { unlockFragment } from './journal.js';
import * as audio from '../audio.js';
import { lastInputDevice } from '../core/input.js';

const diff = () => S.settings.difficulty === 'story' ? 0.6 : 1;
export function learn(key) {
  if (S.P.flags['learn_' + key]) return false;
  S.P.flags['learn_' + key] = true; emit('learned', key); return true;
}
// W0: outside measured space (on foot, past the edge)
const outsideEdge = () => S.mode === 'eva' && S.pos.distanceTo(SHIP_CENTER) > BOUNDARY_R;
// the open world's own dread terms, kept apart from the campaign term (plan 5.5); zero in every older test state
function openDread() { return outsideEdge() ? 0.1 : 0; }
export function dread() {
  const P = S.P;
  return clamp(0.08 + P.journalOrder.length * 0.03 + (P.system - 1) * 0.18 + Math.min(0.3, P.stats.timePlayed / 3600 * 0.3) + (P.derelict.found ? 0.1 : 0) + Math.min(0.3, (P.stats.flights || 0) * 0.06) + openDread(), 0, 1);
}

// camera-relative pan (-1 left .. +1 right) for a world-space direction
const _q = new THREE.Quaternion(), _v = new THREE.Vector3();
function panOfWorldDir(dir) { camera.getWorldQuaternion(_q); _v.copy(dir).applyQuaternion(_q.invert()); return clamp(_v.x * 1.2, -1, 1); }
function panOfShipDir(dir) { _v.copy(dir).applyQuaternion(_q.copy(S.q).invert()); return clamp(_v.x * 1.2, -1, 1); }

// ===================== THE UNLIT =====================
function updateUnlit(dt) {
  const T = S.threat;
  const light = lightLevel();
  T.light = light;
  const exposed = S.mode === 'eva' || S.mode === 'derelict' || power.level === 'dark';
  if (exposed && light < 0.3 && S.P.storyStep >= 2 && !S.sleeping) {
    const rise = UNLIT_RISE * (1 - light / 0.3) * (0.7 + dread() * 0.8) * (S.mode === 'interior' ? 0.55 : 1) * diff();
    T.dark = Math.min(100, T.dark + rise * dt);
  } else T.dark = Math.max(0, T.dark - UNLIT_FALL * dt);
  if (T.dark > 22 && learn('unlit')) {
    say('THE DARK OUTSIDE YOUR LIGHT IS NOT EMPTY.', { hold: 9000 });
    say('IT KEEPS AWAY FROM LIGHT. LAMP: L. FLOODLIGHTS CAN BE BUILT.', { delay: 2200, hold: 12000 });
  }
  if (T.dark > 75 && !T.darkWarned) { T.darkWarned = true; flash('MAKE LIGHT.', 2400); }
  if (T.dark < 40) T.darkWarned = false;
  audio.setWhispers(T.dark / 100, dt);
  // shapes that circle just outside the lamp, only visible against the stars
  const k = T.dark / 100;
  const t = performance.now() / 1000;
  const B = sharedBasis(S.q);
  unlitShapes.forEach((u, i) => {
    const vis = S.mode === 'eva' && k > 0.35;
    u.mesh.visible = vis;
    if (!vis) return;
    const r = 13 - k * 7;
    const a = u.ang + t * (0.08 + i * 0.013);
    const off = new THREE.Vector3(Math.cos(a) * r, Math.sin(t * 0.3 + u.bob) * 3, Math.sin(a) * r);
    // keep them mostly out of the lamp cone: push toward the sides and behind
    const fw = off.clone().normalize().dot(B.f);
    if (fw > 0.6 && S.eva.lamp) off.addScaledVector(B.f, -r * 0.8);
    u.mesh.position.copy(S.pos).add(off);
    u.mesh.lookAt(S.pos);
    u.mesh.material.opacity = clamp((k - 0.35) * 1.6, 0, 0.96);
  });
  if (T.dark >= 100) die('unlit');
}

// ===================== THE LISTENER =====================
const LS = { dirA: new THREE.Vector3(), dirB: new THREE.Vector3(), strike: 0, strikes: 0, cooldown: 0, emitRate: 0 };
export function setListenerCooldown(v) { LS.cooldown = v; }
export function listenerActive() { return S.P.storyStep >= 4 || S.P.mode === 'sandbox'; }
function updateListener(dt) {
  const T = S.threat;
  const frameNoise = S.noise; S.noise = 0;
  const shipEmit = S.mode === 'interior' || S.pos.distanceTo(SHIP_CENTER) < 40 ? power.shipEmit : power.shipEmit * 0.5;
  const lampEmit = S.mode === 'eva' && S.eva.lamp ? 0.2 : 0;
  const rate = frameNoise / Math.max(dt, 1e-4) + shipEmit + lampEmit;
  LS.emitRate += (rate - LS.emitRate) * Math.min(1, dt * 3);
  T.emit = LS.emitRate;
  if (!listenerActive() || S.sleeping) { T.attention = Math.max(0, T.attention - LISTEN_DECAY * dt); return; }
  LS.cooldown = Math.max(0, LS.cooldown - dt);
  const gain = (frameNoise + (shipEmit + lampEmit) * dt) * (0.8 + dread() * 0.5) * diff();
  if (T.listenerState === 'idle' || T.listenerState === 'aware') {
    const cap = LS.cooldown > 0 ? LISTEN_WARN - 5 : 200;
    T.attention = clamp(T.attention + gain - LISTEN_DECAY * dt, 0, cap);
  }
  const lvl = T.listenerState === 'passing' ? 1 : T.listenerState === 'coming' ? 0.55 : T.listenerState === 'aware' ? 0.25 : 0;
  const dirNow = T.listenerDir || LS.dirA;
  audio.setListener(lvl, panOfWorldDir(dirNow));

  switch (T.listenerState) {
    case 'idle':
      if (T.attention >= LISTEN_WARN) {
        T.listenerState = 'aware';
        const a = randomDir(Math.random); a.y = a.y * 0.4; a.normalize();
        LS.dirA.copy(a); T.listenerDir = LS.dirA.clone();
        audio.listenerCall(panOfWorldDir(a)); caption('[a long call, from very far away]', 4000);
        if (learn('listener_aware')) {
          say('SOMETHING ANSWERED FROM OUTSIDE. A BEARING WITH NOTHING ON IT.', { hold: 10000 });
          say('IT GOT LOUDER WHEN THE THRUSTERS FIRED. THE EM BAR (RIGHT) IS WHAT IT HEARS.', { delay: 2600, hold: 14000 });
        } else flash('SOMETHING IS LISTENING.', 2400);
      }
      break;
    case 'aware':
      if (T.attention < LISTEN_WARN * 0.55) { T.listenerState = 'idle'; break; }
      if (T.attention >= LISTEN_COME) {
        T.listenerState = 'coming'; T.listenerT = 12 * (1.2 - dread() * 0.3);
        audio.alarm(); audio.listenerCall(panOfWorldDir(LS.dirA));
        // 2026-09-28: the key follows the device (on a pad X stands you up at the helm; BACK goes dark), and at the helm it says the drive
        const dk = lastInputDevice() === 'pad' ? 'BACK' : 'X';
        say(S.helm && S.P.flight ? `IT IS COMING. LET GO OF THE DRIVE. GO QUIET: CUT POWER (${dk}). WAIT FOR IT TO PASS.` : `IT IS COMING. GO QUIET: CUT POWER (${dk}). STOP MOVING. STOP CUTTING.`, { hold: 14000 });
      }
      break;
    case 'coming':
      T.listenerT -= dt;
      if (T.listenerT <= 0) {
        T.listenerState = 'passing'; T.listenerT = 22;
        LS.strike = 0; LS.strikes = 0;
        // it crosses the sky: from dirA to a point ~80 degrees away
        const axis = new THREE.Vector3().crossVectors(LS.dirA, new THREE.Vector3(0, 1, 0)).normalize();
        LS.dirB.copy(LS.dirA).applyAxisAngle(new THREE.Vector3(0, 1, 0), 1.4).addScaledVector(axis, 0.1).normalize();
        audio.dip(1400);
        emit('listenerPass');
      }
      break;
    case 'passing': {
      T.listenerT -= dt;
      const u = 1 - T.listenerT / 22;
      const d = LS.dirA.clone().lerp(LS.dirB, u).normalize();
      T.listenerDir = d;
      if (listenerBody.mesh) {
        listenerBody.mesh.visible = true;
        listenerBody.mesh.position.copy(d).multiplyScalar(3600);
        listenerBody.mesh.lookAt(LS.dirB.clone().multiplyScalar(3600).add(new THREE.Vector3(0, 400, 0)));
      }
      // while it passes: anything loud is a touch
      const loud = rate > 1.0 ? rate : 0;
      if (loud) LS.strike += dt * loud / 4;
      else LS.strike = Math.max(0, LS.strike - dt * 0.15);
      if (LS.strike >= 1) { LS.strike = -1.5; strike(); } // a strike, then a moment to go quiet
      if (T.listenerT <= 0) endPass();
      break;
    }
  }
}
function strike() {
  const T = S.threat;
  LS.strikes++;
  audio.shove(); audio.knock(0, 2);
  if (LS.strikes >= 2) { die('listener'); return; }
  if (S.mode === 'eva') {
    S.eva.oxygen = Math.max(1, S.eva.oxygen - 30);
    S.vel.add(randomDir(Math.random).multiplyScalar(6));
    S.P.life.sanity = Math.max(1, S.P.life.sanity - 25);
    say('IT TOUCHED YOU. SUIT OXYGEN LOST. ONE MORE AND IT KEEPS YOU.', { hold: 10000 });
  } else {
    S.P.life.sanity = Math.max(1, S.P.life.sanity - 20);
    S.P.life.cabinC -= 8;
    const lost = destroyRandomModule();
    if (lost) say(`IT TOOK THE ${lost}. ONE MORE AND IT TAKES YOU.`, { hold: 10000 });
    else { S.P.repair.comms = Math.max(0, S.P.repair.comms - 25); say('IT TOUCHED THE ANTENNA. COMMS DAMAGED. ONE MORE AND IT TAKES YOU.', { hold: 10000 }); }
  }
  T.attention = Math.min(T.attention, 90);
}
function endPass() {
  const T = S.threat;
  T.listenerState = 'idle'; T.attention = 0; T.listenerDir = null;
  if (listenerBody.mesh) listenerBody.mesh.visible = false;
  LS.cooldown = 150 - dread() * 60;
  S.P.stats.listenerPassings++;
  if (!S.P.unlocks.baffle) {
    S.P.unlocks.baffle = true;
    say('IT PASSED. IT WILL COME BACK WHEN IT HEARS YOU AGAIN.', { hold: 10000 });
    say('NEW BLUEPRINT: EM BAFFLE. IT SWALLOWS WHAT THE SHIP EMITS.', { delay: 2600, hold: 12000 });
    learn('listener');
  } else say('IT PASSED.', { hold: 5000 });
  emit('listenerGone');
}

// ===================== THE NEARER =====================
const NS = { evaT: 0, seen: false };
function mastWatching(shipDirFromCenter) {
  for (const b of moduleList()) {
    if (b.part !== 'mast' || power.shed.has(b.id) || power.level !== 'powered') continue;
    if (b.normal.angleTo(shipDirFromCenter) < THREE.MathUtils.degToRad(35)) return true;
  }
  return false;
}
export function mastsOnline() { return moduleList().filter(b => b.part === 'mast' && !power.shed.has(b.id) && power.level === 'powered').length; }
function updateNearer(dt) {
  const T = S.threat;
  if (S.mode !== 'eva' || S.cycling) { if (T.approach && S.mode !== 'eva') T.approach = null; approachMesh.visible = false; audio.setNearer(0, 0); NS.evaT = 0; NS.doneThisEva = false; return; }
  NS.evaT += dt;
  if (!T.approach) {
    approachMesh.visible = false; audio.setNearer(0, 0);
    // (design doc 2.4: after a contact it "is gone until the next EVA"; it used to come back 25 s later)
    // (W0: outside measured space it comes twice as often)
    if (S.P.storyStep >= 3 && !NS.doneThisEva && NS.evaT > 45 && Math.random() < dt / 30 * (0.4 + dread()) * (outsideEdge() ? 2 : 1)) {
      T.approach = { dir: randomDir(Math.random), dist: 95 + Math.random() * 30 };
    }
    return;
  }
  const a = T.approach;
  const B = sharedBasis(S.q);
  const eyeWatch = B.f.angleTo(a.dir) < THREE.MathUtils.degToRad(NEARER_WATCH_DEG);
  const where = S.pos.clone().addScaledVector(a.dir, a.dist);
  const fromShip = where.clone().sub(SHIP_CENTER).normalize();
  const watched = eyeWatch || mastWatching(fromShip);
  // playtest: watched, it gave back only 1.2 m/s, so one look bought a few metres and it was back in seconds.
  // Watched it now gives ground faster (design doc: "freezes or slowly gives ground back"); held in view for
  // long enough it is gone, which is the lesson the watch masts then automate.
  a.dist = Math.min(130, a.dist + (watched ? 3.0 : -(2.4 + dread() * 2.4) * diff()) * dt);
  a.watchT = watched ? (a.watchT || 0) + dt : 0;
  if (a.watchT > 4.5) {
    T.approach = null; approachMesh.visible = false; audio.setNearer(0, 0); NS.evaT = 0;
    if (learn('nearer_held')) say('YOU HELD YOUR EYES ON IT. THE PRESSURE IN YOUR EARS IS GONE. SO IS IT.', { hold: 12000 });
    return;
  }
  audio.setNearer(clamp((70 - a.dist) / 64, 0, 1), panOfShipDir(a.dir));
  // playtest: the only warning was a sound; with subtitles on, say where it is when it first gets loud
  if (!watched && a.dist < 62 && !a.heard) {
    a.heard = true;
    const c = a.dir.clone().applyQuaternion(camera.quaternion.clone().invert());
    const where = c.z > 0.5 ? 'BEHIND YOU' : c.x > 0.35 ? 'TO YOUR RIGHT' : c.x < -0.35 ? 'TO YOUR LEFT' : c.y > 0.3 ? 'ABOVE YOU' : c.y < -0.3 ? 'BELOW YOU' : 'AHEAD';
    caption(`[a low pressure in the ears, growing: ${where}]`, 5000);
  }
  if (watched && a.heard && a.dist > 75) a.heard = false;
  if (a.dist < 36) {
    approachMesh.visible = true;
    approachMesh.position.copy(where);
    approachMesh.scale.setScalar(clamp((36 - a.dist) / 22, 0.2, 1.2) * 1.3);
    approachMesh.material.opacity = clamp((36 - a.dist) / 16, 0.2, 0.99);
    approachMesh.children[0].material.uniforms.uK.value = clamp((40 - a.dist) / 25, 0, 1);
    if (eyeWatch && !NS.seen) {
      NS.seen = true;
      if (learn('nearer_seen')) say('THERE IS A SHAPE WHERE THE STARS SHOULD BE. IT HAS NOT MOVED SINCE YOU LOOKED.', { hold: 12000 });
    }
  } else approachMesh.visible = false;
  if (a.dist <= 4) {
    audio.shove(); caption('[a hard shove from somewhere unwatched]');
    S.eva.oxygen = Math.max(0, S.eva.oxygen - 20);
    S.P.life.sanity = Math.max(1, S.P.life.sanity - 20);
    S.vel.addScaledVector(a.dir, -7);
    say('SOMETHING WAS CLOSER THAN THE LAST READING SAID.', { hold: 9000 });
    T.approach = null; approachMesh.visible = false; NS.evaT = 20; NS.seen = false; NS.doneThisEva = true;
    emit('nearerContact');
    unlockFragment(1, 'nearer');
    if (!S.P.unlocks.mast) {
      S.P.unlocks.mast = true; learn('nearer');
      say('IT ONLY CLOSED WHILE NOTHING WAS LOOKING AT IT.', { delay: 2600, hold: 12000 });
      say('NEW BLUEPRINT: WATCH MAST. A MAST COUNTS AS LOOKING.', { delay: 5200, hold: 12000 });
    }
    if (S.eva.oxygen <= 0) die('nearer');
  }
}

// ===================== HULL CONTACT (inside) =====================
function updateHull(dt) {
  const T = S.threat;
  if (S.mode !== 'interior' || S.sleeping || S.P.storyStep < 5) { if (T.hull && S.mode === 'eva') { T.approach = { dir: sharedBasis(S.q).f.clone().negate(), dist: 30 }; } T.hull = null; return; }
  if (!T.hull) {
    if (performance.now() > (S.quietUntil || 0) && Math.random() < dt / 240 * (0.3 + dread())) { T.hull = { t: 0, next: 1, pan: Math.random() * 2 - 1 }; }
    return;
  }
  const h = T.hull;
  h.t += dt; h.next -= dt;
  if (h.next <= 0) {
    h.next = 2.5 + Math.random() * 2.5;
    h.pan = clamp(h.pan + (Math.random() - 0.5) * 0.8, -1, 1);
    audio.knock(h.pan, 1 + Math.floor(Math.random() * 3)); caption('[knocking, on the outside of the hull]', 2500);
    if (h.t < 3 && learn('hull')) say('SOMETHING IS ON THE OUTSIDE OF THE HULL. NOTHING IS WATCHING THE HULL.', { hold: 10000 });
  }
  const masts = mastsOnline();
  if (masts >= 1 && h.t > 4 + (3 - Math.min(3, masts)) * 3) {
    T.hull = null; say('IT LET GO WHEN THE MAST TURNED TOWARD IT.', { hold: 8000 }); return;
  }
  if (h.t > 28) {
    const lost = destroyRandomModule();
    if (lost) say(`HULL CONTACT ENDED. THE ${lost} IS GONE.`, { hold: 10000 });
    else { const k = ['comms', 'thrusters'][Math.floor(Math.random() * 2)]; S.P.repair[k] = Math.max(0, S.P.repair[k] - 15); say(`HULL CONTACT ENDED. ${k.toUpperCase()} DAMAGED.`, { hold: 10000 }); }
    S.P.life.sanity = Math.max(1, S.P.life.sanity - 10);
    T.hull = null;
  }
}

// ===================== THE NULL SURGE =====================
function updatePulse(dt) {
  const T = S.threat, p = T.pulse;
  if (!S.P.flags.nullWoke) { p.state = 'dormant'; return; }
  const now = S.P.stats.timePlayed;
  if (!p.next) p.next = now + 60;
  if (p.state === 'dormant' && now >= p.next - NULL_PULSE_WARN) {
    p.state = 'warn'; audio.alarm();
    say(`THE NULL BEARING IS SURGING. RADIATION IN ${NULL_PULSE_WARN} SECONDS. GET INSIDE.`, { hold: 12000 });
    if (learn('pulse')) say('IT DID NOT DO THIS BEFORE YOU MEASURED IT.', { delay: 3000, hold: 12000 });
  } else if (p.state === 'warn' && now >= p.next) {
    p.state = 'pulse'; p.t = NULL_PULSE_LEN; audio.sting();
  } else if (p.state === 'pulse') {
    p.t -= dt;
    if (p.t <= 0) { p.state = 'dormant'; p.next = now + NULL_PULSE_GAP[0] + Math.random() * (NULL_PULSE_GAP[1] - NULL_PULSE_GAP[0]) - dread() * 50; say('SURGE OVER.', { hold: 5000 }); }
  }
  if (S.sys.starMat) {
    const target = p.state === 'pulse' ? 1 : p.state === 'warn' ? 0.5 : 0.18;
    const u = S.sys.starMat.uniforms.uLens; if (u) u.value += (target - u.value) * Math.min(1, dt * 1.5);
  }
}










const FS = { vis: false, a: 0, warned: false, spotted: false, age: 0, hold: 0, lead: 4, fake: false, stepT: 0, lunged: false };
const FIG_LINES = ['CREW COMPLEMENT: 1.', 'LIFE SIGNS: 1. THE READING DID NOT CHANGE.', 'THE FOOTSTEPS STOPPED ONE STEP AFTER YOU DID.', 'NO ONE ELSE IS ABOARD. THE LOG SAYS SO.'];
const FIG_CAPS = ['A FOOTSTEP. BEHIND YOU.', 'SOMETHING SHIFTS ITS WEIGHT.', 'BREATHING. NOT YOURS.', 'A SUIT BOOT ON THE DECK PLATE.'];
function figureSchedule(L) {
  S.threat.figureT = 35 + L.sanity * 0.8 + Math.random() * 35;
  FS.lead = 2.5 + Math.random() * 4.5;
  FS.fake = !!S.P.flags.figureSeen && Math.random() < 0.3;
  FS.warned = false;
}
// face the player in the ship's own frame. (Object3D.lookAt takes WORLD coordinates, and the ship is turned in the
// world, so lookAt with ship-frame numbers tipped the figure over, half into the deck, where it was hard to see.)
function faceMe(m) { m.rotation.set(0, Math.atan2(S.pos.x - m.position.x, S.pos.z - m.position.z), 0); }
function updateFigure(dt) {
  const L = S.P.life, T = S.threat;
  const m = figure.mesh; if (!m) return;
  T.figureBlack = Math.max(0, (T.figureBlack || 0) - dt);
  T.figureAfter = Math.max(0, (T.figureAfter || 0) - dt);
  T.figureFlicker = Math.max(0, (T.figureFlicker || 0) - dt);
  const eligible = S.mode === 'interior' && L.sanity < 55 && !S.sleeping && S.P.storyStep >= 3;
  if (!eligible || S.dying) { m.visible = false; FS.vis = false; FS.a = 0; FS.warned = false; T.figureFlicker = 0; T.figureBlack = 0; return; }
  const B = sharedBasis(S.q);
  if (!FS.vis) {
    T.figureT -= dt;
    if (T.figureT < FS.lead && !FS.warned) {
      FS.warned = true; FS.stepT = 0.4 + Math.random() * 0.8;
      audio.dip(1400 + Math.random() * 1600);
      T.figureFlicker = FS.lead + 0.6;
      if (Math.random() < 0.6) caption(FIG_CAPS[Math.floor(Math.random() * FIG_CAPS.length)], 2200);
    }
    if (FS.warned && T.figureT > 0) {
      // footsteps behind you, closer together as it gets near
      FS.stepT -= dt;
      if (FS.stepT <= 0) { audio.footstep(0.5 + (1 - T.figureT / FS.lead) * 0.9); FS.stepT = 0.35 + Math.random() * 0.9 * Math.max(0.2, T.figureT / FS.lead); }
    }
    if (T.figureT <= 0) {
      if (FS.fake) { figureSchedule(L); T.figureT *= 0.5; return; } // the dread came, and nothing did. This time.
      // stand somewhere behind or beside you, inside the ship, 3-7 m away
      for (let tries = 0; tries < 12; tries++) {
        const r = ROOMS[Math.floor(Math.random() * ROOMS.length)];
        const x = r.xmin + Math.random() * (r.xmax - r.xmin), z = r.zmin + Math.random() * (r.zmax - r.zmin);
        const to = new THREE.Vector3(x - S.pos.x, 0, z - S.pos.z); const d = to.length();
        if (d < 3 || d > 7) continue;
        if (to.normalize().dot(new THREE.Vector3(B.f.x, 0, B.f.z).normalize()) > 0.2) continue;
        m.position.set(x, 0, z); faceMe(m); m.scale.setScalar(1);
        m.visible = true; FS.vis = true; FS.a = 0.7; FS.spotted = false; FS.lunged = false; FS.age = 0; FS.hold = 0;
        break;
      }
      if (!FS.vis) T.figureT = 3;
    }
    return;
  }
  const to = new THREE.Vector3(m.position.x - S.pos.x, 0.9, m.position.z - S.pos.z);
  const looking = to.clone().normalize().angleTo(B.f) < THREE.MathUtils.degToRad(24);
  const close = Math.hypot(to.x, to.z) < 1.6;
  FS.age += dt;
  if ((looking || close) && !FS.spotted) {
    // the sting: it is right in front of you
    FS.spotted = true; FS.lunged = true; FS.hold = 0.22 + Math.random() * 0.2;
    const fwd = new THREE.Vector3(B.f.x, 0, B.f.z); if (fwd.lengthSq() < 1e-6) fwd.set(0, 0, -1); fwd.normalize();
    m.position.set(S.pos.x + fwd.x * 0.95, 0, S.pos.z + fwd.z * 0.95); faceMe(m); m.scale.setScalar(1.12);
    FS.a = 1;
    audio.shadowSting(); T.figureFlicker = FS.hold + 0.1; T.figureJolt = performance.now(); T.figureStings = (T.figureStings || 0) + 1;
    L.sanity = Math.max(5, L.sanity - 10);
    const first = !S.P.flags.figureSeen;
    S.P.flags.figureSeen = true;
    if (first || Math.random() < 0.6) say(first ? FIG_LINES[0] : FIG_LINES[1 + Math.floor(Math.random() * (FIG_LINES.length - 1))], { delay: 1600, hold: 10000 });
  }
  if (FS.spotted || FS.age > 12) {
    FS.hold -= dt;
    // gone at once after the sting (lamps out for half a second); an unseen one fades away on its own
    if (FS.hold <= 0) FS.a = FS.lunged ? 0 : FS.a - dt * 7;
    if (FS.a <= 0) {
      m.visible = false; FS.vis = false; m.scale.setScalar(1);
      if (FS.lunged) { T.figureBlack = 0.5; T.figureAfter = 10; audio.dip(2500); }
      FS.lunged = false;
      figureSchedule(L);
    }
  } else FS.a = Math.min(0.92, FS.a + dt * 0.8);
  figure.mat.opacity = clamp(FS.a, 0, 1);
}
// the ship lamps while CREW 2 is about: flicker 0 (normal) .. 4 (strobing); dark for the half second after the sting
export function figureLights() {
  const T = S.threat;
  if (T.figureBlack > 0) return { dark: true, flicker: 0 };
  return { dark: false, flicker: T.figureFlicker > 0 ? (FS.spotted && FS.vis ? 4 : 1.2 + Math.random() * 0.8) : T.figureAfter > 0 ? 0.6 * T.figureAfter / 10 + 0.2 : 0 };
}

export function update(dt) {
  S.threat.dread = dread();
  // v0.5: down on a planet the space things stay in space (the Listener still hears you; CREW 2 still visits the cabin)
  const down = !!(S.P.landing && S.P.landing.phase !== 'orbit');
  if (down) { S.threat.dark = Math.max(0, S.threat.dark - 14 * dt); S.threat.approach = null; approachMesh.visible = false; S.threat.hull = null; }
  else { updateUnlit(dt); updateNearer(dt); updateHull(dt); updatePulse(dt); }
  updateListener(dt);
  updateFigure(dt);
}
export function resetTransient() {
  const T = S.threat;
  T.attention = 0; T.listenerState = 'idle'; T.listenerDir = null; T.dark = 0; T.approach = null; T.hull = null;
  T.pulse.state = 'dormant'; T.pulse.next = 0;
  if (listenerBody.mesh) listenerBody.mesh.visible = false;
  approachMesh.visible = false;
  FS.vis = false; FS.a = 0; FS.warned = false; FS.spotted = false; FS.lunged = false; FS.fake = false; FS.lead = 2.5 + Math.random() * 4.5;
  T.figureFlicker = 0; T.figureBlack = 0; T.figureAfter = 0; T.figureT = 25 + Math.random() * 20;
  if (figure.mesh) { figure.mesh.visible = false; figure.mesh.scale.setScalar(1); }
  LS.cooldown = 60;
}
void PARTS;
