# Library fixture root note

This is a made-up test note at the top level (no subfolder), used to prove
The Library groups root-level notes under a "(root)" shelf.
