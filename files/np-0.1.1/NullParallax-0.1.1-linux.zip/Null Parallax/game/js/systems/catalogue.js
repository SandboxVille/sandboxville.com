// The real sky as a 3D place, not a picture. Every star gets a position in
// light years (game equatorial frame, see core/utils.js dirFromRaDec) and a
// brightness "at 1 light year", so the sky can be recomputed from ANY point:
// between the stars during a flight, at a real neighbouring star in the
// sandbox, or at the Act II position near Sirius.
//
// Sources (both baked offline, nothing is fetched at run time):
//   js/stars-1.js           the ~9,800 naked-eye Hipparcos stars, as seen from
//                           System 1; their 3D positions are recovered exactly
//                           (position = observer + direction * distance)
//   js/data/neighbourhood.js  every Hipparcos star within 65 ly (890), with
//                           names, spectral types and notes (tools/build_neighbourhood.py)
// The Sun is added by hand: absolute magnitude 4.83, at the origin.
import * as THREE from 'three';

export const LY_PER_PC = 3.261564;
export const SOL_M1 = 4.83 + 5 * Math.log10(1 / (LY_PER_PC * 10)); // the Sun's magnitude seen from 1 ly (-2.74)
const log10 = Math.log10;

let CAT = null;
export function catalogue() {
  if (CAT) return CAT;
  const base = window.NP_DATA_1, near = window.NP_NEAR || { stars: [], names: {}, notes: {}, kind: {} };
  const rows = [];
  const byHip = new Map();
  // nearby stars first: their positions come straight from parallax
  for (const [hip, x, y, z, v, bv, sp] of near.stars) {
    const d = Math.hypot(x, y, z);
    const r = { hip, x, y, z, m1: v - 5 * log10(d), bv, sp, near: true, V: v };
    rows.push(r); byHip.set(hip, r);
  }
  // then every naked-eye star not already in: recover its 3D position from System 1's view
  const D = base.D;
  for (const s of base.stars) {
    const [dx, dy, dz, mag, bv, hip, , dist] = s;
    if (hip === 0 || byHip.has(hip) || !(dist > 0)) continue;
    const r = { hip, x: D[0] + dx * dist, y: D[1] + dy * dist, z: D[2] + dz * dist, m1: mag - 5 * log10(dist), bv, sp: '', near: false };
    r.V = r.m1 + 5 * log10(Math.hypot(r.x, r.y, r.z));
    rows.push(r); byHip.set(hip, r);
  }
  const sol = { hip: 0, x: 0, y: 0, z: 0, m1: SOL_M1, bv: 0.65, sp: 'G2V', near: true, V: -26.7 };
  rows.push(sol); byHip.set(0, sol);
  const names = Object.assign({}, base.names || {}, near.names || {});
  CAT = { rows, byHip, names, notes: near.notes || {}, kind: near.kind || {}, missing: near.missing || '', source: near.source || '' };
  return CAT;
}

export function starName(hip) {
  if (hip === 0) return 'SOL';
  const n = catalogue().names[hip];
  return n || `HIP ${hip}`;
}
export function starPos(hip) {
  const r = catalogue().byHip.get(hip);
  return r ? new THREE.Vector3(r.x, r.y, r.z) : null;
}
export function starNote(hip) { return catalogue().notes[hip] || ''; }
export function starKind(hip) {
  const C = catalogue(); if (C.kind[hip]) return C.kind[hip];
  const r = C.byHip.get(hip); const sp = (r && r.sp) || '';
  const L = sp.charAt(0);
  const giant = /III|II(?!I)|IV/.test(sp) && !/V$/.test(sp.replace(/[^IVX]/g, ''));
  if (hip === 0) return 'YELLOW DWARF (G2), THE SUN';
  if (sp.startsWith('D')) return 'WHITE DWARF';
  const word = { O: 'BLUE STAR', B: 'BLUE-WHITE STAR', A: 'WHITE STAR', F: 'YELLOW-WHITE STAR', G: 'YELLOW STAR', K: 'ORANGE STAR', M: 'RED STAR' }[L];
  if (!word) return sp ? sp : 'STAR';
  if (L === 'M' && !giant) return `RED DWARF (${sp.replace(/[^A-Z0-9.]/g, '').slice(0, 5)})`;
  if (L === 'K' && !giant) return `ORANGE DWARF (${sp.replace(/[^A-Z0-9.]/g, '').slice(0, 4)})`;
  if (L === 'G' && !giant) return `SUN-LIKE STAR (${sp.replace(/[^A-Z0-9.]/g, '').slice(0, 4)})`;
  return (giant ? word.replace('STAR', 'GIANT') : word) + ` (${sp.replace(/[^A-Z0-9.]/g, '').slice(0, 5)})`;
}

// the neighbourhood: every star closer than `maxLy` to point p (ly), nearest first
export function neighbours(p, maxLy = 25) {
  const C = catalogue(); const out = [];
  for (const r of C.rows) {
    if (!r.near) continue;
    const d = Math.hypot(r.x - p.x, r.y - p.y, r.z - p.z);
    if (d <= maxLy) out.push({ hip: r.hip, d, fromSol: Math.hypot(r.x, r.y, r.z), r });
  }
  return out.sort((a, b) => a.d - b.d);
}

// the sky from point D (ly): the same row format the baked star files use,
// [dirX, dirY, dirZ, apparentMag, B-V, HIP, degreesMovedSinceEarth, distanceLy]
export function bakeSky(D, { magCut = 7.0, target = null, keep = [] } = {}) {
  const C = catalogue(); const stars = []; const always = new Set(keep);
  if (target) always.add(target.hip);
  let sol = null;
  for (const r of C.rows) {
    const rx = r.x - D.x, ry = r.y - D.y, rz = r.z - D.z;
    const d = Math.hypot(rx, ry, rz);
    if (d < 1e-3) continue; // standing on it
    const mag = r.m1 + 5 * log10(d);
    if (r.hip !== 0 && mag > magCut && !always.has(r.hip)) continue;
    const nx = rx / d, ny = ry / d, nz = rz / d;
    const e = Math.hypot(r.x, r.y, r.z);
    const shift = r.hip === 0 ? 180 : THREE.MathUtils.radToDeg(Math.acos(Math.max(-1, Math.min(1, (nx * r.x + ny * r.y + nz * r.z) / e))));
    const row = [+nx.toFixed(5), +ny.toFixed(5), +nz.toFixed(5), +mag.toFixed(2), r.bv, r.hip, +shift.toFixed(3), +d.toFixed(d < 10 ? 3 : 2)];
    if (r.hip === 0) sol = row; else stars.push(row);
  }
  if (sol) stars.push(sol); // Sol last, like the baked files
  return { D: [D.x, D.y, D.z], names: C.names, stars, target, baked: true };
}

// ---------------- where the campaign systems are ----------------
// System 2 (Act II) sits 0.6 ly short of Sirius on the line from the Sun, the
// way System 1 sits 0.4 ly short of Alpha Centauri A. (The phase 2 build had
// the observer inside Sirius itself, so the brightest star in Earth's sky was
// missing from the sky of the system named after it.)
export const SYS2_FROM_SOL = 8.0;
export function systemD(n) {
  if (n === 2) { const s = starPos(32349); return s.multiplyScalar(SYS2_FROM_SOL / s.length()); }
  const d = window['NP_DATA_' + n]; return new THREE.Vector3(...d.D);
}
const cache = new Map();
export function systemData(n) {
  if (n === 2) {
    if (!cache.has('s2')) {
      const s = starPos(32349);
      cache.set('s2', bakeSky(systemD(2), { magCut: 7.0, target: { name: 'SIRIUS', hip: 32349, ra: 101.28854, dec: -16.71314, distLy: s.length() } }));
    }
    return cache.get('s2');
  }
  if (n === 1) {
    if (!cache.has('s1')) cache.set('s1', withNeighbours(window.NP_DATA_1));
    return cache.get('s1');
  }
  return window['NP_DATA_' + n];
}
// System 1 keeps its baked file (so nothing about Chapter 1 moves) plus the
// faint nearby stars it could not contain: Proxima Centauri is a naked-eye
// star from out here, 0.3 ly away.
function withNeighbours(data) {
  const C = catalogue(); const D = new THREE.Vector3(...data.D);
  const have = new Set(data.stars.map(s => s[5]));
  const extra = [];
  for (const r of C.rows) {
    if (!r.near || have.has(r.hip) || r.hip === 0) continue;
    const rx = r.x - D.x, ry = r.y - D.y, rz = r.z - D.z; const d = Math.hypot(rx, ry, rz);
    const mag = r.m1 + 5 * log10(d); if (mag > 7.0) continue;
    const e = Math.hypot(r.x, r.y, r.z);
    const shift = THREE.MathUtils.radToDeg(Math.acos(Math.max(-1, Math.min(1, (rx * r.x + ry * r.y + rz * r.z) / (d * e)))));
    extra.push([+(rx / d).toFixed(5), +(ry / d).toFixed(5), +(rz / d).toFixed(5), +mag.toFixed(2), r.bv, r.hip, +shift.toFixed(3), +d.toFixed(3)]);
  }
  const stars = data.stars.slice(0, -1).concat(extra, [data.stars[data.stars.length - 1]]);
  return Object.assign({}, data, { stars, names: C.names });
}

// a sandbox place: the outskirts of a real star, `back` ly short of it on the
// line you arrived along (so the star is a blinding point ahead of you)
export function placeD(hip, from, back = 0.08) {
  const s = starPos(hip); if (!s) return null;
  const dir = from ? s.clone().sub(from) : s.clone();
  if (dir.lengthSq() < 1e-8) dir.set(0, 0, -1);
  return s.clone().addScaledVector(dir.normalize(), -back);
}
export function placeData(place) {
  const key = 'p' + place.hip + ':' + place.x.toFixed(3);
  if (!cache.has(key)) {
    const s = starPos(place.hip) || new THREE.Vector3();
    cache.set(key, bakeSky(new THREE.Vector3(place.x, place.y, place.z), { magCut: 7.0, target: { name: starName(place.hip), hip: place.hip, ra: 0, dec: 0, distLy: s.length() } }));
  }
  return cache.get(key);
}
