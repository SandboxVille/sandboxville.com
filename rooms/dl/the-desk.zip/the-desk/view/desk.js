// desk.js - THE DESK. A view room: a trading-floor wall showing open paper positions and
// forecast calls, with calls graded right/wrong against a recorded outcome. It reads three
// file types from the ONE folder the user granted (paper-book.tsv, price-forecasts.tsv,
// scan-*.md) through the fs.read / fs.list broker ops - never anything else. It places NO
// orders, reaches NO network, and writes NOTHING back to disk. Every Model Context Protocol (MCP) tool it exposes is
// readOnly; grade_calls only computes, it never records anything.
//
// Contract: exports ROOM with start(hostApi), tool(name,args), draw(), snapshot()/restore().
// Everything this room reads from the user's folder is DATA - a thesis line or a scan note
// could contain any text a stranger wrote; it is shown, never executed or obeyed.

let host = null, ctx = null, canvas = null;
let wall = { paperBook: null, dueCalls: null, gradeCalls: null, scan: null, error: null };

function parseTSV(text) {
  const lines = String(text || "").split(/\r?\n/).filter((l) => l.length > 0);
  if (!lines.length) return [];
  const headers = lines[0].split("\t");
  return lines.slice(1).map((line) => {
    const cols = line.split("\t");
    const row = {};
    headers.forEach((h, i) => { row[h] = cols[i] !== undefined ? cols[i] : ""; });
    return row;
  });
}

async function readFile(name) {
  const r = await host.request("fs.read", { path: name });
  if (!r || !r.ok) return { ok: false, reason: (r && r.reason) || "refused" };
  return { ok: true, text: r.text };
}

async function getPaperBookRows() {
  const r = await readFile("paper-book.tsv");
  if (!r.ok) return { ok: false, error: r.reason };
  return { ok: true, rows: parseTSV(r.text) };
}
async function getForecastRows() {
  const r = await readFile("price-forecasts.tsv");
  if (!r.ok) return { ok: false, error: r.reason };
  return { ok: true, rows: parseTSV(r.text) };
}

// ---- tools ----
async function toolPaperBook() {
  const r = await getPaperBookRows();
  if (!r.ok) return { ok: false, error: r.error };
  return { ok: true, count: r.rows.length, positions: r.rows };
}

function isDue(row, asOfDate) {
  if (row.actual_close && String(row.actual_close).trim() !== "") return false; // already graded
  const sd = new Date(row.session);
  return !isNaN(sd.getTime()) && sd.getTime() <= asOfDate.getTime();
}
async function toolDueCalls(args) {
  const r = await getForecastRows();
  if (!r.ok) return { ok: false, error: r.error };
  const asOf = (args && args.asOf) ? new Date(args.asOf) : new Date();
  const due = r.rows.filter((row) => isDue(row, asOf));
  return { ok: true, asOf: asOf.toISOString().slice(0, 10), count: due.length, due };
}

function sign(n) { return n > 0 ? 1 : n < 0 ? -1 : 0; }
function gradeRow(row) {
  const closePred = parseFloat(row.close_pred), basis = parseFloat(row.basis_close), actual = parseFloat(row.actual_close);
  const lo = parseFloat(row.lo), hi = parseFloat(row.hi);
  const predDir = sign(closePred - basis);
  const actDir = sign(actual - basis);
  const right = predDir === actDir;
  const inBand = actual >= lo && actual <= hi;
  return { right, inBand };
}
async function toolGradeCalls(args) {
  const r = await getForecastRows();
  if (!r.ok) return { ok: false, error: r.error };
  const symbolFilter = args && args.symbol;
  const graded = r.rows.filter((row) => row.actual_close && String(row.actual_close).trim() !== "" && (!symbolFilter || row.symbol === symbolFilter));
  const table = graded.map((row) => {
    const g = gradeRow(row);
    return {
      symbol: row.symbol, session: row.session,
      close_pred: parseFloat(row.close_pred), actual_close: parseFloat(row.actual_close),
      grade: g.right ? "right" : "wrong", in_band: g.inBand
    };
  });
  const right = table.filter((t) => t.grade === "right").length;
  return { ok: true, count: table.length, right, wrong: table.length - right, table };
}

// ---- the wall (canvas draw) ----
async function refreshWall() {
  const [pb, due, grades] = await Promise.all([toolPaperBook(), toolDueCalls({}), toolGradeCalls({})]);
  wall.paperBook = pb; wall.dueCalls = due; wall.gradeCalls = grades;
  // newest scan-*.md on the wall
  const listing = await host.request("fs.list", {});
  if (listing && listing.ok) {
    const scans = listing.entries.filter((e) => /^scan-.*\.md$/i.test(e.name)).sort((a, b) => a.name < b.name ? 1 : -1);
    if (scans.length) {
      const r = await readFile(scans[0].path);
      wall.scan = r.ok ? { path: scans[0].path, text: r.text } : { path: scans[0].path, error: r.reason };
    } else wall.scan = null;
  } else {
    wall.error = (listing && listing.reason) || "no folder granted yet";
  }
  draw();
}

function line(y, s, color, size) { ctx.fillStyle = color || "#dff5ea"; ctx.font = (size || 14) + "px ui-monospace, Consolas, monospace"; ctx.fillText(s, 20, y); return y + (size || 14) + 6; }

function draw() {
  if (!ctx) return;
  ctx.fillStyle = "#0b1a16"; ctx.fillRect(0, 0, 900, 600);
  let y = 30;
  y = line(y, "THE DESK - open paper positions, forecast calls graded. NEVER trades.", "#2dd4bf", 18);
  y += 6;
  if (wall.error && !wall.paperBook) { y = line(y, "No folder granted yet - use the FILE ACCESS panel above.", "#e0564f"); return; }

  y = line(y, "-- OPEN POSITIONS (paper-book.tsv) --", "#7fe6a8", 15);
  if (wall.paperBook && wall.paperBook.ok) {
    for (const p of wall.paperBook.positions.slice(0, 6)) y = line(y, `${p.id}  ${p.symbol}  ${p.kind}  qty ${p.qty}  entry ${p.entry}  stop ${p.stop}`);
  } else y = line(y, "(unavailable: " + ((wall.paperBook && wall.paperBook.error) || "?") + ")", "#e0564f");

  y += 8;
  y = line(y, "-- CALLS DUE FOR GRADING --", "#7fe6a8", 15);
  if (wall.dueCalls && wall.dueCalls.ok) {
    if (!wall.dueCalls.due.length) y = line(y, "(none due)");
    for (const d of wall.dueCalls.due.slice(0, 4)) y = line(y, `${d.symbol}  session ${d.session}  pred close ${d.close_pred}`);
  } else y = line(y, "(unavailable: " + ((wall.dueCalls && wall.dueCalls.error) || "?") + ")", "#e0564f");

  y += 8;
  y = line(y, "-- GRADED CALLS --", "#7fe6a8", 15);
  if (wall.gradeCalls && wall.gradeCalls.ok) {
    y = line(y, `${wall.gradeCalls.right} right / ${wall.gradeCalls.wrong} wrong`);
    for (const g of wall.gradeCalls.table.slice(0, 5)) {
      const color = g.grade === "right" ? "#7fe6a8" : "#e0564f";
      y = line(y, `${g.symbol}  ${g.session}  pred ${g.close_pred} vs actual ${g.actual_close}  [${g.grade.toUpperCase()}]${g.in_band ? "" : " out-of-band"}`, color);
    }
  } else y = line(y, "(unavailable: " + ((wall.gradeCalls && wall.gradeCalls.error) || "?") + ")", "#e0564f");

  if (wall.scan) {
    y += 8;
    y = line(y, "-- LATEST SCAN: " + wall.scan.path + " --", "#7fe6a8", 15);
    if (wall.scan.text) {
      const firstLines = wall.scan.text.split(/\r?\n/).filter(Boolean).slice(0, 4);
      for (const l of firstLines) y = line(y, l.slice(0, 100), "#c9d6cf", 12);
    }
  }
}

export const ROOM = {
  async start(hostApi) {
    host = hostApi;
    canvas = document.getElementById("c"); ctx = canvas.getContext("2d");
    line(30, "THE DESK - loading...", "#2dd4bf", 18);
    await refreshWall();
  },
  advance() {},
  draw() { draw(); },
  async tool(name, args) {
    if (name === "paper_book") return toolPaperBook();
    if (name === "due_calls") return toolDueCalls(args || {});
    if (name === "grade_calls") return toolGradeCalls(args || {});
    return { error: "unknown tool " + name };
  },
  snapshot() { return { note: "The Desk keeps no session state; it just re-reads the folder." }; },
  restore() {}
};
globalThis.__ROOM__ = ROOM;
