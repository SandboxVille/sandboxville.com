// Engine singletons: renderer, scene, camera, the ship's root object, the
// helmet lamp, and a fixed pool of lights. The light COUNT never changes
// after startup (only intensities do) so three.js never recompiles shaders
// mid-game -- that is what keeps frame times flat on integrated GPUs.
import * as THREE from 'three';
import { BASE_ZOOMS } from '../core/constants.js';

export const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
document.body.prepend(renderer.domElement);

const QUALITY = { low: 0.7, medium: 1.0, high: 1.5 };
export function applyQuality(q) {
  const pr = Math.min(devicePixelRatio || 1, QUALITY[q] || 1);
  renderer.setPixelRatio(pr);
  renderer.setSize(innerWidth, innerHeight);
  return pr;
}
applyQuality('medium');

export const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

export const camera = new THREE.PerspectiveCamera(BASE_ZOOMS[0], innerWidth / innerHeight, 0.05, 20000);
camera.rotation.order = 'YXZ';

export const ship = new THREE.Object3D();
scene.add(ship);
ship.add(camera);
window.__ship = ship; // debug/QA only

// helmet lamp: a spotlight riding the camera, pointed down the view axis
export const helmetLamp = new THREE.SpotLight(0xdfe8ff, 0, 60, THREE.MathUtils.degToRad(26), 0.55, 1.0);
helmetLamp.position.set(0.15, -0.1, 0);
camera.add(helmetLamp);
camera.add(helmetLamp.target);
helmetLamp.target.position.set(0.1, -0.15, -5);

// pooled lights for built floodlights (moved to the nearest ones each frame)
export const lightPool = [0, 1, 2].map(() => { const l = new THREE.PointLight(0xfff1d6, 0, 34, 1.5); ship.add(l); return l; });

// crossing silhouette: one flat, unlit, camera-facing plane, shared across systems
export const crossMesh = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.97, side: THREE.DoubleSide }));
crossMesh.visible = false;
scene.add(crossMesh);

// the Nearer: an absence, never a body. A black volume that hides the stars
// behind it. Parented to the ship frame so its position is in ship metres.
export const approachMesh = new THREE.Mesh(new THREE.SphereGeometry(2.2, 20, 14), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.98, depthWrite: true }));
approachMesh.visible = false;
ship.add(approachMesh);
// a faint cold rim, so the absence has an edge you can learn to see
export const approachRim = new THREE.Mesh(new THREE.SphereGeometry(2.35, 24, 16), new THREE.ShaderMaterial({
  uniforms: { uK: { value: 0 } }, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.BackSide,
  vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
  fragmentShader: `uniform float uK; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 6.0); gl_FragColor = vec4(vec3(0.35, 0.38, 0.45) * f * uK, 1.0); }`,
}));
approachRim.renderOrder = 3;
approachMesh.add(approachRim);

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
});
