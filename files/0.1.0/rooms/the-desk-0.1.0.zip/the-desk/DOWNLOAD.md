# The Desk

Skill: Checking and judging. Version 0.1.0.

## What this room does

Your watchlist and paper trades on the wall; forecasts get graded against what actually happened.

What it lets your AI do: Reads the paper book and forecast calls from the folder you picked, and grades calls. It never places a trade.

## Its door sign (what it can touch, and nothing more)

SandboxVille shows you this exact sign before the room is placed:

```
=== The Desk  (io.github.sandboxville/the-desk v0.1.0) ===
This room can:
  + show its own screen
  + keep 2 MB of its own private notes
  + answer questions about itself (paper_book, due_calls, grade_calls)
Nothing else: no internet, no programs on your computer, no saved secrets, no other rooms.
----------------------------------------
RED LINE - this room can reach beyond itself:
  ! Can READ files in the ONE folder you pick: read only (cannot change or delete anything) (only these file types: paper-book.tsv, price-forecasts.tsv, scan-*.md). Nothing outside that folder.
----------------------------------------
```

## How to add it

You do not need to unzip this file.

1. Put this zip file, just as it is, in the `add-rooms-here` folder inside your SandboxVille folder.
2. Start SandboxVille: double-click `Start SandboxVille.cmd` (Windows) or `Start SandboxVille.command` (Mac), or run `./start-sandboxville.sh` (Linux). In a terminal in your SandboxVille folder you can also run `node host/world-host.mjs --open`. If SandboxVille is already running, skip this step.
3. Your browser opens, already paired. Only that browser can place a room. An AI can never place, move or remove a room.
4. You spawn in your Lobby. Walk to a glowing EMPTY LOT sign and press E.
5. Pick The Desk. SandboxVille finds this zip by its fingerprint (sha256), checks it against its catalog and checks every file the room pins, then shows the door sign above.
6. Read the sign. If you are happy with it, press PLACE. The page reloads with the room in place.

The room reads nothing until you lend it a folder yourself: open the room, type the folder's path, and press lend this folder. It can only read inside that one folder, never change or delete anything.

## How to remove it

Walk to its door, press E to read the door sign, then press REMOVE ROOM. SandboxVille tells you what will happen, then you confirm.
The room and its own private notes move to the trash folder in your SandboxVille data folder (`~/.sandboxville/trash/`). Nothing is deleted for good until you empty that folder yourself.
Any folder you lent it was only ever read, never written, so there is nothing to undo there; the permission ends when the room is removed.

Tools it gives your AI: paper_book, due_calls, grade_calls.

## Things to try once it is in

- Grade yesterday's calls
- What's open on the paper book?
- What calls are due for grading?

## License

Free to use with SandboxVille, for yourself. All rights reserved. See LICENSE.txt in this zip.
