// Movement: look (mouse/pad/keys), interior walking, EVA 6DOF flight with
// optional inertia dampers, and collision against the hull, built modules,
// the salvage field, the derelict and the boundary.
//
// P2: the camera orientation truth is the quaternion S.q. Walking rebuilds
// it from yaw/pitch (no roll, pitch clamped); EVA rotates it freely in its
// own local frame so you can loop, roll and fly upside down.
import * as THREE from 'three';
import { S } from '../core/state.js';
import {
  EYE_H, WALK_SPEED, SPRINT_MULT, WALK_ACCEL, WALK_FRICTION, MOUSE_BASE, PAD_LOOK_RATE,
  EVA_ACCEL, EVA_BOOST_MULT, EVA_MAX_SPEED, EVA_DAMP_ASSIST, EVA_DAMP_FREE, ROLL_SPEED,
  TETHER_MAX, PLAYER_R, PROP_DRAIN_K, BOUNDARY_R,
} from '../core/constants.js';
import { qFromYawPitch, yawPitchFromQ, sharedBasis, flatBasis, clamp } from '../core/utils.js';
import { ROOMS, HULL_A, HULL_B, HULL_R, HATCH_EXT } from '../render/ship.js';
import { field, derelict, SHIP_CENTER, dOutOf } from '../render/world.js';
import * as audio from '../audio.js';
import { say, flash } from '../ui/hud.js';
import { tetherKey } from '../core/input.js';
import { emit } from '../core/events.js';
import { onSurface, surfaceStep } from './landing.js';

// W0: the edge is a membrane. It sits where the old wall was; it bounces you
// the first time, then gives EDGE_GIVE_MS later (plan 5.3 / 8.2).
export const MEMBRANE_R = BOUNDARY_R - 1.5;
const EDGE_GIVE_MS = 7000;
// how far past the edge of measured space the suit is (0 inside it, and 0 anywhere but on foot outside)
export function dOut() { return S.mode === 'eva' ? dOutOf(S.pos) : 0; }

export function inConsoleRoom() {
  const r = ROOMS[0];
  return S.pos.x > r.xmin - 0.4 && S.pos.x < r.xmax + 0.4 && S.pos.z > r.zmin - 0.4 && S.pos.z < r.zmax + 0.3;
}
export function canSight() { return S.mode === 'eva' || (S.mode === 'interior' && inConsoleRoom()); }
export function roomName() {
  if (S.mode !== 'interior') return 'outside';
  for (const r of ROOMS) if (S.pos.x >= r.xmin - 0.05 && S.pos.x <= r.xmax + 0.05 && S.pos.z >= r.zmin - 0.05 && S.pos.z <= r.zmax + 0.05) return r.name;
  return 'corridor';
}

export function clampInterior(p) {
  let best = null, bestD = Infinity;
  for (const r of ROOMS) {
    const cx = Math.max(r.xmin, Math.min(r.xmax, p.x));
    const cz = Math.max(r.zmin, Math.min(r.zmax, p.z));
    if (cx === p.x && cz === p.z) return { x: p.x, z: p.z, hit: false };
    const d = (cx - p.x) ** 2 + (cz - p.z) ** 2;
    if (d < bestD) { bestD = d; best = { x: cx, z: cz, hit: true }; }
  }
  return best || { x: p.x, z: p.z, hit: false };
}

const _ab = new THREE.Vector3(), _c = new THREE.Vector3(), _d = new THREE.Vector3();
function pushOutSphere(pv, vv, center, rad) {
  _d.copy(pv).sub(center);
  const dist = _d.length(), min = rad + PLAYER_R;
  if (dist >= min) return 0;
  const n = dist > 1e-5 ? _d.multiplyScalar(1 / dist) : _d.set(0, 1, 0);
  pv.copy(center).addScaledVector(n, min);
  const vn = vv.dot(n);
  if (vn < 0) { vv.addScaledVector(n, -vn * 1.3); return -vn; }
  return 0;
}
function pushOutCapsule(pv, vv, a, b, r) {
  _ab.copy(b).sub(a);
  const t = clamp(_c.copy(pv).sub(a).dot(_ab) / _ab.lengthSq(), 0, 1);
  _c.copy(a).addScaledVector(_ab, t);
  return pushOutSphere(pv, vv, _c.clone(), r);
}
export function hullCollide(pv, vv) { return pushOutCapsule(pv, vv, HULL_A, HULL_B, HULL_R); }

const _mInv = new THREE.Matrix4(), _lp = new THREE.Vector3(), _lv = new THREE.Vector3();
function derelictCollide(pv, vv) {
  if (!derelict.group) return 0;
  if (pv.distanceTo(derelict.group.position) > 30) return 0;
  let impact = 0;
  const m = new THREE.Matrix4(), rotM = new THREE.Matrix3(), rotInv = new THREE.Matrix3();
  for (const h of derelict.halves) {
    m.multiplyMatrices(derelict.group.matrix, h.group.matrix);
    _mInv.copy(m).invert();
    _lp.copy(pv).applyMatrix4(_mInv);
    const before = _lp.clone();
    rotInv.setFromMatrix4(_mInv); rotM.setFromMatrix4(m);
    _lv.copy(vv).applyMatrix3(rotInv);
    const a = new THREE.Vector3(0, 0, -h.len / 2), b = new THREE.Vector3(0, 0, h.len / 2);
    const hit = pushOutCapsule(_lp, _lv, a, b, h.r);
    if (_lp.distanceToSquared(before) > 1e-10) {
      impact = Math.max(impact, hit);
      pv.copy(_lp).applyMatrix4(m);
      vv.copy(_lv).applyMatrix3(rotM);
    }
  }
  return impact;
}

// built modules register simple collision spheres here (systems/build.js)
export const moduleColliders = [];

export function spawnInterior(at = 'airlock') {
  S.mode = 'interior'; S.helm = false;
  if (at === 'console') { S.pos.set(0, EYE_H, -7.2); S.yaw = 0; }
  else if (at === 'bunk') { S.pos.set(-0.35, EYE_H, -4.4); S.yaw = -Math.PI / 2 + 0.25; }
  else { S.pos.set(0, EYE_H, 1.3); S.yaw = Math.PI; }
  S.pitch = 0; S.roll = 0;
  S.vel.set(0, 0, 0);
  qFromYawPitch(S.yaw, S.pitch, 0, S.q);
  S.approach = null; S.eva.tethered = false; S.eva.lamp = false;
  S.buildMode = false;
}

export function enterEvaOrientation() {
  // leaving the hatch: face outward (+x), level
  S.yaw = -Math.PI / 2; S.pitch = 0; S.roll = 0;
  qFromYawPitch(S.yaw, S.pitch, 0, S.q);
}
export function leaveEvaOrientation() {
  const yp = yawPitchFromQ(S.q); S.yaw = yp.yaw; S.pitch = clamp(yp.pitch, -1.4, 1.4); S.roll = 0;
  qFromYawPitch(S.yaw, S.pitch, 0, S.q);
}

export function setZoom(z) {
  z = THREE.MathUtils.clamp(z, 0, S.ZOOMS.length - 1);
  if (z !== S.zoom) { S.zoom = z; audio.servo(); }
}

const _qy = new THREE.Quaternion(), _qx = new THREE.Quaternion(), _qz = new THREE.Quaternion();
const AX_Y = new THREE.Vector3(0, 1, 0), AX_X = new THREE.Vector3(1, 0, 0), AX_Z = new THREE.Vector3(0, 0, 1);
export function updateLook(dt, mouse, ax) {
  const st = S.settings;
  const zoomK = Math.min(1, S.fov / S.ZOOMS[0]);
  const inv = st.invertY ? -1 : 1;
  const padCurve = v => Math.sign(v) * Math.pow(Math.abs(v), 1.8);
  let dx = mouse.dx * MOUSE_BASE * st.sensitivity * zoomK;
  let dy = mouse.dy * MOUSE_BASE * st.sensitivity * zoomK * inv;
  dx += (padCurve(ax.padRX) * PAD_LOOK_RATE * st.padLook + ax.kLookX * 1.8) * dt * zoomK;
  dy += (padCurve(ax.padRY) * PAD_LOOK_RATE * st.padLook * inv + ax.kLookY * 1.8) * dt * zoomK;
  // cold and fear make hands shake: a tiny, honest jitter, never enough to fight the player
  const shake = S.shake || 0;
  if (shake > 0) { dx += (Math.random() - 0.5) * shake * dt; dy += (Math.random() - 0.5) * shake * dt; }
  if (S.mode === 'eva' && !onSurface()) {
    _qy.setFromAxisAngle(AX_Y, -dx); _qx.setFromAxisAngle(AX_X, -dy);
    S.q.multiply(_qy).multiply(_qx);
    if (ax.roll) { _qz.setFromAxisAngle(AX_Z, -ax.roll * ROLL_SPEED * dt); S.q.multiply(_qz); }
    S.q.normalize();
  } else {
    S.yaw -= dx; S.pitch = clamp(S.pitch - dy, -1.45, 1.45);
    qFromYawPitch(S.yaw, S.pitch, 0, S.q);
  }
  S.tYaw = S.yaw; S.tPitch = S.pitch;
}

let stepPhase = 0;
export function updatePlayer(dt, ax) {
  if (S.cycling || S.ended || S.dying || S.sleeping || S.helm) { S.vel.multiplyScalar(0.8); return; }
  const coldK = S.P.life.warmth < 30 ? 0.72 : 1;
  if (S.mode === 'interior') {
    const { f, r } = flatBasis(S.yaw);
    const wx = f.x * ax.moveF + r.x * ax.moveX, wz = f.z * ax.moveF + r.z * ax.moveX;
    let wl = Math.hypot(wx, wz);
    const sprint = ax.boost && ax.moveF > 0.2;
    const speed = WALK_SPEED * (sprint ? SPRINT_MULT : 1) * coldK;
    const tx = wl > 0.01 ? wx / Math.max(1, wl) * speed : 0, tz = wl > 0.01 ? wz / Math.max(1, wl) * speed : 0;
    const k = Math.min(1, dt * (wl > 0.01 ? WALK_ACCEL : WALK_FRICTION));
    S.vel.x += (tx - S.vel.x) * k; S.vel.z += (tz - S.vel.z) * k; S.vel.y = 0;
    S.pos.x += S.vel.x * dt; S.pos.z += S.vel.z * dt;
    const c = clampInterior(S.pos);
    if (c.hit) { if (c.x !== S.pos.x) S.vel.x = 0; if (c.z !== S.pos.z) S.vel.z = 0; }
    S.pos.x = c.x; S.pos.z = c.z;
    // head bob + footsteps
    const sp = Math.hypot(S.vel.x, S.vel.z);
    const bobTarget = S.settings.headBob && sp > 0.3 ? 0.03 * Math.min(1.4, sp / WALK_SPEED) : 0;
    S.bobAmp += (bobTarget - S.bobAmp) * Math.min(1, dt * 8);
    if (sp > 0.3) {
      const prev = stepPhase; stepPhase += dt * sp * 2.3;
      if (Math.floor(prev / Math.PI) !== Math.floor(stepPhase / Math.PI)) { audio.footstep(sp / WALK_SPEED); S.noise += sprint ? 1.6 : 0.35; }
    }
    S.bob = stepPhase;
    S.pos.y = EYE_H + Math.abs(Math.sin(stepPhase)) * S.bobAmp;
    S.exerting = sprint;
    return;
  }
  // ---- v0.5: on a planet's surface you walk, with its gravity ----
  if (onSurface()) { surfaceStep(dt, ax); return; }
  // ---- EVA ----
  const B = sharedBasis(S.q);
  const tx = B.f.x * ax.moveF + B.r.x * ax.moveX + B.u.x * ax.moveU;
  const ty = B.f.y * ax.moveF + B.r.y * ax.moveX + B.u.y * ax.moveU;
  const tz = B.f.z * ax.moveF + B.r.z * ax.moveX + B.u.z * ax.moveU;
  const mag = Math.min(1, Math.hypot(tx, ty, tz));
  const hasProp = S.eva.propellant > 0;
  const boost = ax.boost && hasProp;
  S.thrusting = 0;
  if (mag > 0.02 && hasProp) {
    const accel = EVA_ACCEL * (boost ? EVA_BOOST_MULT : 1) * coldK;
    const inv = 1 / Math.max(1e-6, Math.hypot(tx, ty, tz));
    S.vel.x += tx * inv * mag * accel * dt; S.vel.y += ty * inv * mag * accel * dt; S.vel.z += tz * inv * mag * accel * dt;
    const use = mag * accel * dt * PROP_DRAIN_K * (S.settings.difficulty === 'story' ? 0.5 : 1);
    S.eva.propellant = Math.max(0, S.eva.propellant - use);
    S.thrusting = mag * (boost ? 1 : 0.4);
    S.noise += mag * (boost ? 5.5 : 1.6) * dt;
  }
  if (S.eva.dampers && mag < 0.05 && hasProp) {
    const before = S.vel.length();
    S.vel.multiplyScalar(Math.exp(-EVA_DAMP_ASSIST * dt));
    const spent = (before - S.vel.length()) * 0.05;
    S.eva.propellant = Math.max(0, S.eva.propellant - spent);
    if (before > 0.3) S.thrusting = Math.max(S.thrusting, 0.15);
  } else S.vel.multiplyScalar(Math.exp(-EVA_DAMP_FREE * dt));
  const maxV = EVA_MAX_SPEED * (boost ? 1.4 : 1);
  if (S.vel.length() > maxV) S.vel.setLength(maxV);
  S.pos.addScaledVector(S.vel, dt);
  S.exerting = boost;

  if (S.eva.tethered) {
    const delta = S.pos.clone().sub(HATCH_EXT);
    const dist = delta.length();
    if (dist > TETHER_MAX) {
      delta.setLength(TETHER_MAX); S.pos.copy(HATCH_EXT).add(delta);
      const radial = delta.normalize();
      const vr = S.vel.dot(radial);
      if (vr > 0) { S.vel.addScaledVector(radial, -vr * 1.2); if (vr > 2) audio.tetherCreak(); }
      // playtest (and the owner's own first flight): the tether stopped him dead at 60 m with no word why
      if (vr > 0.15 || S.thrusting > 0.05) tetherFullHint();
    }
  }
  let impact = hullCollide(S.pos, S.vel);
  for (const m of moduleColliders) impact = Math.max(impact, pushOutSphere(S.pos, S.vel, m.pos, m.r));
  for (const c of field.chunks) {
    if (c.hp <= 0) continue;
    const dx = S.pos.x - c.pos.x, dy = S.pos.y - c.pos.y, dz = S.pos.z - c.pos.z;
    const rr = c.radius + PLAYER_R;
    if (dx * dx + dy * dy + dz * dz < rr * rr) impact = Math.max(impact, pushOutSphere(S.pos, S.vel, c.pos, c.radius));
  }
  impact = Math.max(impact, derelictCollide(S.pos, S.vel));
  // the boundary: the measurement stops here. W0: it is a membrane. The first touch bounces you, as it
  // always did, and 7 s later it gives: an outward push goes through (slowed once), and coming back is free.
  const fromC = _d.copy(S.pos).sub(SHIP_CENTER);
  const rc = fromC.length();
  const prevR = S.edgePrevR == null ? rc : S.edgePrevR;
  // (only a real crossing from inside counts; a jump of 25 m in one frame is a teleport, not a push)
  if (rc > MEMBRANE_R && prevR <= MEMBRANE_R + 1e-6 && rc - prevR < 25) {
    const now = performance.now();
    const open = !!S.P.flags.edgeOpen || (S.edgeOpenAt > 0 && now >= S.edgeOpenAt);
    if (!open) {
      fromC.multiplyScalar(1 / rc);
      S.pos.copy(SHIP_CENTER).addScaledVector(fromC, MEMBRANE_R);
      const vo = S.vel.dot(fromC); if (vo > 0) { S.vel.addScaledVector(fromC, -vo * 1.6); impact = Math.max(impact, vo); }
      S.touchedBoundary = true;
      if (!(S.edgeOpenAt > 0)) S.edgeOpenAt = now + EDGE_GIVE_MS;
    } else {
      S.vel.multiplyScalar(0.5);
      emit('edgePass');
    }
  }
  S.edgePrevR = S.pos.distanceTo(SHIP_CENTER);
  if (impact > 1.6) { audio.bump(Math.min(1, impact / 8)); S.lastImpact = impact; }
}

let tetherHintT = -1e9;
function tetherFullHint() {
  const now = performance.now();
  if (now - tetherHintT < 9000) return;
  tetherHintT = now;
  const key = tetherKey();
  const text = `TETHER AT FULL LENGTH (${TETHER_MAX} M). PRESS ${key} TO UNCLIP. NOTHING WILL HOLD YOU TO THE SHIP AFTER THAT.`;
  flash(text, 4200);
  if (!S.P.flags.tetherFullSaid) { S.P.flags.tetherFullSaid = true; say(text, { hold: 14000 }); }
}

export function distToHull(p) {
  _ab.copy(HULL_B).sub(HULL_A);
  const t = clamp(_c.copy(p).sub(HULL_A).dot(_ab) / _ab.lengthSq(), 0, 1);
  _c.copy(HULL_A).addScaledVector(_ab, t);
  return p.distanceTo(_c) - HULL_R;
}

// test-only: move in interior mode without going through input
export function moveTestStep(x, z, dtMs) {
  const d = (dtMs || 16) / 1000;
  if (S.mode === 'interior') {
    S.pos.x += x * WALK_SPEED * d; S.pos.z += z * WALK_SPEED * d;
    const c = clampInterior(S.pos); S.pos.x = c.x; S.pos.z = c.z;
  }
}
