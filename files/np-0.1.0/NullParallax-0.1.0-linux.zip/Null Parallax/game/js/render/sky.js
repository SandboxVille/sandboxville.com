import*as t from"three";import{renderer as l,scene as f}from"./scene.js";import{dirFromRaDec as c,noiseGLSL as p}from"../core/utils.js";const S=`
  varying vec3 vCol; varying float vA; varying float vSize;
  void main() {
    vec2 p = gl_PointCoord * 2.0 - 1.0; float d2 = dot(p, p);
    if (d2 > 1.0) discard;
    float r = sqrt(d2) * vSize * 0.5;                 // pixels from the centre
    float core = exp(-r * r / 1.7);
    float glowK = clamp((vSize - 3.0) / 14.0, 0.0, 1.0);
    float glow = exp(-r / (0.9 + vSize * 0.16)) * (0.10 + 0.34 * glowK) * (1.0 - d2);
    float spike = glowK * 0.10 * (exp(-abs(p.x) * vSize * 0.9) + exp(-abs(p.y) * vSize * 0.9)) * (1.0 - d2) * (1.0 - d2);
    gl_FragColor = vec4(vCol * (core * 1.25 + glow + spike) * vA, 1.0);
  }`,n=(()=>{const o=c(192.85948,27.12825),r=c(266.40499,-28.93617);r.addScaledVector(o,-r.dot(o)).normalize();const a=new t.Vector3().crossVectors(o,r).normalize();return{ngp:o,gc:r,gy:a}})(),b=n,m="varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }",u=`
  uniform vec3 uNGP, uGC, uGY; varying vec2 vUv;
  ${p}
  const float PI = 3.14159265;
  void main(){
    float lon = (vUv.x * 2.0 - 1.0) * PI, lat = (vUv.y - 0.5) * PI;
    vec3 d = vec3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon));
    float b = asin(clamp(dot(d, uNGP), -1.0, 1.0));
    float l = atan(dot(d, uGY), dot(d, uGC));
    float bd = degrees(b), ld = degrees(l);
    float inner = 0.5 + 0.5 * cos(l);
    float width = mix(3.8, 9.5, pow(inner, 1.5));
    float disk = exp(-(bd * bd) / (width * width));
    float halo = exp(-abs(bd) / 26.0) * 0.10;
    float along = 0.28 + 0.72 * pow(inner, 1.6);
    float bulge = exp(-(ld * ld) / (2.0 * 11.0 * 11.0) - (bd * bd) / (2.0 * 8.0 * 8.0));
    vec3 q = d * 7.0;
    float clouds = fbm(q * 1.3 + vec3(1.7, 0.3, 2.9));
    float fine = n3(q * 9.0);
    float lum = disk * along * (0.45 + 1.1 * clouds * clouds + 0.25 * fine) + bulge * 1.15 + halo * along;
    // dust: the Great Rift and friends, just above the plane in the inner half
    float dn = fbm(q * 2.1 + vec3(5.2, 1.1, 7.7));
    float rift = exp(-pow((bd - 1.2 - 1.6 * sin(l * 2.3)) / (2.2 + 1.8 * inner), 2.0)) * smoothstep(-0.3, 0.7, cos(l * 0.85));
    float ext = rift * (0.45 + 1.6 * smoothstep(0.38, 0.78, dn)) + disk * 0.35 * smoothstep(0.55, 0.85, dn);
    lum *= exp(-1.7 * ext);
    vec3 cold = vec3(0.74, 0.82, 1.0), warm = vec3(1.0, 0.84, 0.62);
    vec3 col = mix(cold, warm, clamp(bulge * 0.9 + inner * disk * 0.35, 0.0, 1.0));
    gl_FragColor = vec4(col * lum, 1.0);
  }`,g="varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",h=`
  uniform sampler2D tMW; uniform float uK; varying vec3 vD;
  float ign(vec2 p){ return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
  void main(){
    vec3 d = normalize(vD);
    vec2 uv = vec2(atan(d.z, d.x) / 6.2831853 + 0.5, asin(clamp(d.y, -1.0, 1.0)) / 3.14159265 + 0.5);
    vec3 c = texture2D(tMW, uv).rgb * uK;
    c += (ign(gl_FragCoord.xy) - 0.5) / 255.0 * step(0.0005, uK);
    gl_FragColor = vec4(max(c, 0.0), 1.0);
  }`,e={mesh:null,mat:null,rt:null,k:.065};function y(){if(e.mesh)return e.mesh;const o=2048,r=1024;e.rt=new t.WebGLRenderTarget(o,r,{type:t.HalfFloatType,depthBuffer:!1}),e.rt.texture.generateMipmaps=!1,e.rt.texture.minFilter=e.rt.texture.magFilter=t.LinearFilter,e.rt.texture.wrapS=t.RepeatWrapping;const a=new t.ShaderMaterial({uniforms:{uNGP:{value:n.ngp},uGC:{value:n.gc},uGY:{value:n.gy}},vertexShader:m,fragmentShader:u,depthTest:!1,depthWrite:!1}),i=new t.BufferGeometry;i.setAttribute("position",new t.Float32BufferAttribute([-1,-1,0,3,-1,0,-1,3,0],3));const s=new t.Mesh(i,a);s.frustumCulled=!1;const d=new t.Scene;d.add(s);const v=l.getRenderTarget();return l.setRenderTarget(e.rt),l.render(d,new t.OrthographicCamera(-1,1,1,-1,0,1)),l.setRenderTarget(v),a.dispose(),i.dispose(),e.mat=new t.ShaderMaterial({uniforms:{tMW:{value:e.rt.texture},uK:{value:e.k}},vertexShader:g,fragmentShader:h,side:t.BackSide,depthWrite:!1,depthTest:!0}),e.mesh=new t.Mesh(new t.SphereGeometry(4200,48,24),e.mat),e.mesh.renderOrder=10,e.mesh.frustumCulled=!1,f.add(e.mesh),e.mesh}export{S as STAR_FRAG,y as buildMilkyWay,b as galactic,e as milky};
