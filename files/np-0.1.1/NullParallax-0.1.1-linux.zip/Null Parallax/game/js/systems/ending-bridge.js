// Breaks a three-way import cycle (repair -> flow -> entities -> repair):
// entities.js needs to trigger the COLLAPSE ending, but triggerEnding lives
// in repair.js, which needs flow.js (to advance systems on a normal jump),
// which needs entities.js (to start the dread scheduler on wake/arrival).
// main.js wires the real function in once every module has loaded.
let fn = null;
export function setTriggerEnding(f) { fn = f; }
export function triggerEndingCall(kind) { if (fn) fn(kind); }
