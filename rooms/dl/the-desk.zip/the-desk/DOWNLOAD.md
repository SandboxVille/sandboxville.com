# The Desk

## What this room does

Your watchlist and paper trades on the wall. Forecast calls you wrote down earlier get graded against what actually happened, using files from one folder you pick.

What it lets your AI do: It can list your open paper-trade tickets, list forecast calls that are due for grading, and compute right/wrong for calls that already have a recorded outcome. It never places a trade, and it never reaches the network.

## Its door label (what it can touch, and nothing more)

- Tools for your AI: paper_book, due_calls, grade_calls. All three only read or compute, none of them place a trade or write anything.
- Can READ files in the ONE folder you pick: read only, cannot change or delete anything (only paper-book.tsv, price-forecasts.tsv, and scan-*.md files).
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It can keep a small amount (2 MB) of its own private notes, separate from your folder.

## What you need first

Node.js 22+, a copy of the SandboxVille code, and a folder containing your own paper-book.tsv and/or price-forecasts.tsv files (your paper-trade records and forecast calls). It never writes to that folder and never places a real trade.

## How to add it

1. Unzip this download. You will get a folder called `the-desk/` with a `room.json` file inside (and a `view/` folder with its screen code).
2. Copy the whole `the-desk/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/the-desk/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/the-desk`
   This prints the door sign so you can read exactly what the room can touch before you trust it.
4. Run: `node harness/server.mjs --room ./rooms/the-desk --port 8150`
   (pick any free port number; 8150 is just an example)
5. Open the address it prints (something like `http://127.0.0.1:8150`) in your browser.
6. If the room asks for a folder (see "What you need first"), type the folder's path into the FILE ACCESS box and click "grant this folder". The room only ever sees files inside that one folder, and it can only read them, never change or delete them.
7. Click the consent button, then mount the room to start it.

## How to remove it

1. Close the browser tab and stop the server (press Ctrl+C in the terminal it is running in).
2. Delete the `the-desk/` folder from `rooms/` in your SandboxVille code.
3. If you had granted a folder, nothing was ever written into it, the room only ever read from it, so there is nothing to undo there.

## Things to try once it's running

- Grade yesterday's calls
- What's open on the paper book?
- What calls are due for grading?

