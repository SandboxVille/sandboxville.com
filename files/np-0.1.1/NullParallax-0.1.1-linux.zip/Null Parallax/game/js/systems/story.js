// The objective ladder: what the player should do next, in plain words,
// always on screen, with a waypoint marker in the world. The probe's own
// log voice (the console at the bottom left) says WHY; the objective line
// at the top says WHAT. Nothing here blocks movement -- the player can
// always walk away and explore; the ladder just waits.
//
//  0 WAKE      get up, walk to the console
//  1 CONSOLE   wake it (F)
//  2 FIX       sight three stars through the window -> "4.00 ly, impossible"
//  3 POWER     suit up, cut salvage, repair the power panel before you freeze
//  4 LIGHT     build a floodlight (teaches building and the dark)
//  5 COMMS     repair the antenna
//  6 SIGNAL    send the signal home -> the reply comes back in 11 seconds
//  7 CONTACT   a transponder: KESTREL-4, 260 m away. This ship. Go and look.
//  8 LEAVE     repair the thruster, refine fuel, jump
//  9 ADRIFT    systems 2-3 and sandbox: survive, build, measure
// 10 HELM      (P3) at the helm, a course plotted, the drive not yet lit
// 11 TRANSIT   (P3) the whole ship, flown by hand between the stars
// 12 THE CHART (P3, Act II) arrived at Sirius: sight three stars
// 13 ANTENNA   (P3, Act II) the burn cooked the antenna: repair it
// 14 MANIFEST  (P3, Act II) the manifest is legible: two aboard
// 15 TWO       (P3, Act II) the end of what is built: find the other one
import * as THREE from 'three';
import { S } from '../core/state.js';
import { JUMP_FUEL_COST, REPAIR_COST, TETHER_MAX } from '../core/constants.js';
import { JOURNAL } from '../journal-data.js';
import { CONSOLE_POS, HATCH_INT, HATCH_EXT, PANEL_POS, ANTENNA_POS, THRUSTER_POS, HARDPOINTS } from '../render/ship.js';
import { field, derelict, derelictPointWorld } from '../render/world.js';
import { remainingCost } from './repair.js';
import { PARTS, occupied, canAfford, costText } from './build.js';
import { say } from '../ui/hud.js';
import { on, emit } from '../core/events.js';
import { doAutosave } from './save-state.js';
import { unlockFragment } from './journal.js';
import { lastInputDevice, isLocked, tetherKey } from '../core/input.js';
import { learn } from './threats.js';
import { dOutOf } from '../render/world.js';
import * as audio from '../audio.js';
import * as flight from './flight.js';
import * as act2 from './act2.js';
import * as wreck from './derelict.js';
import { jumpReady } from './repair.js';
import * as landing from './landing.js';

export function setStep(n) {
  if (n <= S.P.storyStep) return;
  S.P.storyStep = n;
  emit('step', n);
  doAutosave(true);
}

function nearestChunk(type, from) {
  // playtest: once the close chunks were cut, the marker pointed at chunks past the end of the 60 m tether,
  // and the player hung at the end of the line with no idea why. While tethered, prefer what the tether reaches.
  let best = null, bd = Infinity, bestR = null, bdR = Infinity;
  for (const c of field.chunks) {
    if (c.hp <= 0 || (type && c.type !== type)) continue;
    const d = c.pos.distanceToSquared(from);
    if (d < bd) { bd = d; best = c; }
    if (c.pos.distanceTo(HATCH_EXT) < TETHER_MAX - 1.5 + c.radius && d < bdR) { bdR = d; bestR = c; }
  }
  return (S.mode === 'eva' && S.eva.tethered && bestR) ? bestR : best;
}
// W0: any target past the end of the line (the waypoint label and the KESTREL-4 scan mark say PAST YOUR LINE)
export const pastLine = (p, radius = 0) => S.mode === 'eva' && S.eva.tethered && !!p && p.distanceTo(HATCH_EXT) >= TETHER_MAX - 1.5 + radius;
const pastTether = c => !!c && pastLine(c.pos, c.radius);
function needTarget(rem) {
  // which resource to go and get, and where
  const tetherNote = ` IT IS PAST THE END OF YOUR TETHER: PRESS ${tetherKey()} TO UNCLIP FIRST.`;
  if (rem.salvage > S.P.res.salvage) { const c = nearestChunk('salvage', S.pos); return { text: `CUT ${rem.salvage - S.P.res.salvage} MORE SALVAGE: METAL PLATES WITH BLINKING LIGHTS. HOLD F ON ONE.`, target: c && c.pos, label: 'SALVAGE', tether: pastTether(c) ? tetherNote : '' }; }
  if (rem.ore > S.P.res.ore) { const c = nearestChunk('ore', S.pos); return { text: `CUT ${rem.ore - S.P.res.ore} MORE ORE: THE BROWN ROCKS. HOLD F ON ONE.`, target: c && c.pos, label: 'ORE', tether: pastTether(c) ? tetherNote : '' }; }
  return null;
}
const pad = () => lastInputDevice() === 'pad';

// returns { text, sub, target (ship-frame Vector3 | null), label, pastLine }
const HELM_CHAIR = new THREE.Vector3(-0.72, 0.75, -7.95);
export function objective() {
  const o0 = objectiveBase();
  // v0.5 campaign: on a planet the story waits in orbit; say so, and point at the way back
  const Lg = S.P.landing;
  const o = o0 && S.P.mode === 'campaign' && Lg && Lg.phase === 'landed' && !S.dying && !S.P.flight && !(S.mode === 'eva' && S.eva.oxygen < 30)
    ? { text: `ON ${(landing.planet() || { name: 'A PLANET' }).name}. EXPLORING HERE IS OPTIONAL AND THE STORY IS PAUSED. WHEN YOU ARE DONE, TAKE OFF AT THE HELM (G) TO CARRY ON.`, sub: o0.text ? `THEN: ${o0.text}` : '', target: S.mode === 'interior' ? HELM_CHAIR : HATCH_EXT, label: S.mode === 'interior' ? 'HELM' : 'SHIP' }
    : o0;
  return o && o.target && pastLine(o.target) ? { ...o, pastLine: true } : o;
}
function objectiveBase() {
  const P = S.P, step = P.storyStep;
  if (S.dying) return { text: '', sub: '' };
  const inside = S.mode === 'interior';
  // playtest: "SUIT OXYGEN 25%. GET BACK TO THE AIRLOCK" had no marker to the airlock, so a player low on air
  // far out in the field did not know which way home was. Low air or propellant now takes over the objective.
  // (far out, 30% is too late: turn back when the air left is under twice the trip home at an easy 4 m/s, plus 30 s)
  const airSecs = S.eva.oxygen / (100 / 300), homeSecs = S.mode === 'eva' ? S.pos.distanceTo(HATCH_EXT) / 4 : 0;
  // (when the story is already sending you home, as after the wreck, only the hard 30% line takes over)
  const farRule = airSecs < 2 * homeSecs + 30 && !wreck.swapOn();
  if (S.mode === 'eva' && !S.cycling && (S.eva.oxygen < 30 || farRule || S.eva.propellant < 12)) {
    const air = S.eva.oxygen < 30 || farRule;
    return { text: air ? `SUIT OXYGEN ${Math.round(S.eva.oxygen)}%. GET BACK TO THE AIRLOCK.` : `PROPELLANT ${Math.round(S.eva.propellant)}%. GET BACK TO THE AIRLOCK TO REFILL.`, sub: S.eva.tethered ? 'HOLD F TO REEL IN THE TETHER. IT NEEDS NO AIR OR PROPELLANT' : 'THE AIRLOCK REFILLS THE SUIT', target: HATCH_EXT, label: 'AIRLOCK' };
  }
  const goOut = () => ({ text: 'GO OUTSIDE: WALK TO THE AIRLOCK AT THE BACK OF THE SHIP, PRESS F.', sub: 'THE SUIT IS ON THE RACK IN THE AIRLOCK', target: HATCH_INT, label: 'AIRLOCK' });
  const repairObj = (key, pos, label, why) => {
    const rem = remainingCost(key);
    if (P.repair[key] >= 100) return null;
    if (inside) return goOut();
    const need = needTarget(rem);
    if (need) return { text: need.text, sub: need.tether ? need.tether.trim() : why, target: need.target, label: need.label };
    return { text: `FLY TO THE ${label} AND HOLD F TO REPAIR IT.`, sub: `${why} (${Math.round(P.repair[key])}%)`, target: pos, label };
  };
  switch (step) {
    case 0: return { text: 'GET UP. WALK TO THE CONSOLE AT THE FRONT OF THE SHIP.', sub: pad() ? 'LEFT STICK: WALK   RIGHT STICK: LOOK' : `W A S D: WALK   MOUSE: LOOK   SHIFT: RUN${isLocked() ? '' : '   (CLICK THE GAME TO CAPTURE THE MOUSE)'}`, target: CONSOLE_POS, label: 'CONSOLE' };
    case 1: return { text: pad() ? 'PRESS X TO WAKE THE CONSOLE.' : 'PRESS F TO WAKE THE CONSOLE.', sub: 'LOOK AT THE DESK UNDER THE WINDOW', target: CONSOLE_POS, label: 'CONSOLE' };
    case 2: {
      const n = S.locks.length;
      return { text: 'WHERE ARE YOU? SIGHT THREE STARS THROUGH THE WINDOW.', sub: `${n}/3 SIGHTED   ${pad() ? 'A: SIGHT   LT: ZOOM' : 'CLICK: SIGHT A STAR   RIGHT MOUSE: ZOOM'}`, target: null };
    }
    case 3: {
      const r = repairObj('power', PANEL_POS, 'POWER PANEL', 'MAIN POWER IS DOWN. THE CABIN IS FREEZING.');
      if (r) return r;
      return { text: 'POWER RESTORED.', sub: '', target: null };
    }
    case 4: {
      const def = PARTS.floodlight;
      if (inside) return { ...goOut(), sub: 'THE FABRICATOR CAN BUILD FROM OUTSIDE NOW' };
      if (!canAfford(def.cost)) {
        const need = needTarget({ salvage: def.cost.salvage, ore: def.cost.ore });
        if (need) return { text: need.text, sub: need.tether ? need.tether.trim() : `A FLOODLIGHT NEEDS ${costText(def.cost)}`, target: need.target, label: need.label };
      }
      const hp = HARDPOINTS.filter(h => !occupied(h.id)).sort((a, b) => a.pos.distanceTo(S.pos) - b.pos.distanceTo(S.pos))[0];
      return { text: S.buildMode ? 'AIM AT AN AMBER RING ON THE HULL AND CLICK TO BUILD THE FLOODLIGHT.' : `BUILD A FLOODLIGHT ON THE HULL: PRESS ${pad() ? 'Y' : 'B'} TO OPEN BUILD MODE.`, sub: 'LIGHT KEEPS THE DARK AWAY', target: hp ? hp.pos : null, label: 'HARDPOINT' };
    }
    case 5: {
      const r = repairObj('comms', ANTENNA_POS, 'ANTENNA', 'REPAIR THE ANTENNA ON TOP OF THE HULL SO YOU CAN CALL HOME');
      return r || { text: 'ANTENNA REPAIRED.', sub: '' };
    }
    // playtest: during the 26 s reply beat the line still said SEND THE SIGNAL HOME, so players sent it again
    case 6: if (P.flags.signalSent) return { text: 'SIGNAL SENT. LISTEN.', sub: 'WATCH THE LOG, BOTTOM LEFT', target: null };
      return { text: inside ? 'GO TO THE CONSOLE AND SEND THE SIGNAL HOME.' : 'GO INSIDE. SEND THE SIGNAL HOME FROM THE CONSOLE.', sub: 'CONSOLE > SHIP > SEND SIGNAL', target: inside ? CONSOLE_POS : HATCH_EXT, label: inside ? 'CONSOLE' : 'AIRLOCK' };
    case 7: {
      if (!derelict.group) return { text: 'SURVIVE.', sub: '' };
      const dpos = derelict.group.position;
      const d = Math.round(S.pos.distanceTo(dpos));
      if (inside) return { ...goOut(), text: 'A TRANSPONDER CALLS ITSELF KESTREL-4. THAT IS THIS SHIP. GO OUTSIDE AND LOOK.' };
      const k = tetherKey();
      const sub = S.eva.tethered && d > 50 ? `YOUR LINE IS ${TETHER_MAX} M. ${k} UNCLIPS. ${k} AT THE HATCH CLIPS BACK ON.` : (P.derelict.body ? 'THE FLIGHT RECORDER IS AN ORANGE BOX IN THE TORN EDGE' : 'CHECK THE SUIT. FIND THE FLIGHT RECORDER.');
      // playtest: close to the wreck the marker still pointed at its middle, so the suit and the recorder had to be found by circling it
      if (d < 45 && derelict.body && derelict.recorder) {
        if (!P.derelict.body) return { text: 'A SUIT IS FLOATING BY THE WRECK. FLY TO IT AND CHECK IT (F).', sub: 'IT IS TETHERED TO THE TORN END', target: derelictPointWorld(derelict.body), label: 'SUIT' };
        if (!P.derelict.looted) return { text: 'PULL THE FLIGHT RECORDER (F).', sub: 'AN ORANGE BOX WEDGED IN THE TORN EDGE', target: derelictPointWorld(derelict.recorder), label: 'RECORDER' };
      }
      return { text: `FLY TO THE OTHER KESTREL-4 (${S.mode === 'eva' && dOutOf(S.pos) > 0 ? '???' : d} M).`, sub, target: dpos, label: 'KESTREL-4' };
    }
    case 8: {
      // P3: the recorder stops mid-sentence; the rest is inside the wreck
      const w = wreck.objective(); if (w) return w;
      if (P.mode === 'campaign' && P.derelict.looted && !P.derelict.read) {
        if (inside) return { ...goOut(), text: 'THE RECORDER STOPS MID-SENTENCE. THE REST IS ON THEIR CONSOLE, IN THE OTHER SHIP. GO OUTSIDE.' };
        return { text: 'THE RECORDER STOPS MID-SENTENCE. THE REST IS ON THEIR CONSOLE: GO IN THROUGH THE BREAK.', sub: 'THE TORN END OF THE OTHER SHIP. PRESS F THERE. MAG BOOTS WILL HOLD YOU TO THE DECK', target: wreck.breakTarget(), label: 'THE BREAK' };
      }
      if (P.repair.thrusters < 50) {
        const r = repairObj('thrusters', THRUSTER_POS, 'THRUSTER', 'THE THRUSTER NEEDS 50% TO JUMP');
        if (r) return r;
      }
      if (P.res.fuel < JUMP_FUEL_COST) {
        const iceNeed = (JUMP_FUEL_COST - P.res.fuel) * 2;
        if (P.res.ice < iceNeed) { const c = nearestChunk('ice', S.pos); return { text: `CUT ${iceNeed - P.res.ice} MORE ICE (PALE BLUE CHUNKS). THE CONSOLE MAKES FUEL FROM IT.`, sub: pastTether(c) ? `IT IS PAST THE END OF YOUR TETHER: PRESS ${tetherKey()} TO UNCLIP FIRST.` : `FUEL ${P.res.fuel}/${JUMP_FUEL_COST}`, target: inside ? HATCH_INT : c && c.pos, label: inside ? 'AIRLOCK' : 'ICE' }; }
        return { text: 'MAKE FUEL AT THE CONSOLE: SHIP > REFINE.', sub: `FUEL ${P.res.fuel}/${JUMP_FUEL_COST}  (2 ICE = 1 FUEL)`, target: inside ? CONSOLE_POS : HATCH_EXT, label: inside ? 'CONSOLE' : 'AIRLOCK' };
      }
      return { text: inside ? 'READY. TAKE THE HELM: SIT IN THE LEFT CHAIR AT THE CONSOLE (F).' : 'READY. GO INSIDE AND TAKE THE HELM.', sub: 'OR CONSOLE > SHIP > TAKE THE HELM. WHATEVER IS OUT HERE WILL STILL BE HERE', target: inside ? flight.HELM_POS.clone().setY(0.9) : HATCH_EXT, label: inside ? 'HELM' : 'AIRLOCK' };
    }
    case 10: case 11: {
      const f = flight.objective();
      if (f) return f;
      break;
    }
    default: break;
  }
  // after the switch: the steps past 9, systems 2-3, and the sandbox
  {
    {
      if (P.flight) { const f = flight.objective(); if (f) return f; }
      const a2 = act2.objective(inside); if (a2) return a2;
      if (P.mode === 'sandbox') {
        // W0: FIRST SHIFT (plan 6.4) drives the sub-line until it is done
        const fs = P.place ? [] : firstShift(), next = fs.find(i => !i.done);
        return { text: `SANDBOX: DAY ${P.stats.sleeps + 1}. SURVIVE. BUILD. MEASURE.`, sub: next ? `FIRST SHIFT ${fs.filter(i => i.done).length}/${fs.length}: ${next.text}  //  MISSION (M)  //  THE CHART: N` : `${P.place ? 'AT ' + (P.place.name || 'HIP ' + P.place.hip) + '  //  ' : ''}${P.modules.length} MODULES  //  ${P.journalOrder.length}/${JOURNAL.length} LOG FRAGMENTS  //  THE CHART: N`, target: null };
      }
      if (!S.fixed) return { text: 'SIGHT THREE STARS TO FIND WHERE YOU ARE NOW.', sub: `${S.locks.length}/3`, target: inside ? CONSOLE_POS : null, label: 'WINDOW' };
      if (P.system < 3) {
        if (P.repair.thrusters < 50 || P.res.fuel < JUMP_FUEL_COST) return { text: `REPAIR THE THRUSTER TO 50% AND MAKE ${JUMP_FUEL_COST} FUEL, THEN JUMP.`, sub: `THRUSTER ${Math.round(P.repair.thrusters)}%  //  FUEL ${P.res.fuel}/${JUMP_FUEL_COST}  //  LOG ${P.journalOrder.length}/${JOURNAL.length}`, target: null };
        return { text: 'JUMP WHEN READY (CONSOLE > SHIP).', sub: `LOG ${P.journalOrder.length}/${JOURNAL.length}`, target: null };
      }
      if (P.journalOrder.length < JOURNAL.length) return { text: `RECOVER LOG FRAGMENTS: ${P.journalOrder.length}/${JOURNAL.length}. LOOK, MEASURE, GO WHERE YOU WERE NOT TOLD TO.`, sub: 'OR LEAVE: CONSOLE > SHIP > RUN', target: null };
      return { text: 'THE CONSOLE IS READY. CHOOSE: RUN, RESOLVE, OR COLLAPSE.', sub: '', target: inside ? CONSOLE_POS : null, label: 'CONSOLE' };
    }
  }
}

// W0: FIRST SHIFT, the optional sandbox checklist (plan 6.4). Items 7 (fly to the Body, W1) and
// 8 (park in orbit, W3) join when those waves land; this list only names what exists.
export function firstShift() {
  const P = S.P, F = P.flags;
  return [
    { text: 'SUIT UP', done: !!F.fs_suit },
    { text: 'CUT 3 SALVAGE PLATES', done: (F.fs_salvage || 0) >= 3 },
    { text: 'REFINE 1 FUEL', done: !!F.fs_fuel },
    { text: 'GET THE THRUSTER TO 50%', done: P.repair.thrusters >= 50 },
    { text: 'VISIT THE OTHER KESTREL-4 (ON FOOT)', done: !!F.fs_visit },
    { text: 'CROSS THE EDGE', done: !!F.edgeOpen },
  ];
}

// ---------------- story beats, driven by events ----------------
export function initStory() {
  on('eva', () => { if (S.P.mode === 'sandbox') S.P.flags.fs_suit = true; });
  on('harvested', key => { if (S.P.mode === 'sandbox' && key === 'salvage') S.P.flags.fs_salvage = (S.P.flags.fs_salvage || 0) + 1; });
  on('refined', () => { if (S.P.mode === 'sandbox') S.P.flags.fs_fuel = true; });
  on('consoleUse', () => {
    if (S.P.storyStep <= 1) {
      setStep(2);
      audio.powerUp();
      say('CONSOLE ONLINE. POSITION: UNKNOWN. LAST FIX: 11 DAYS AGO, NEAR EARTH.', { delay: 300, hold: 16000 });
      say('SIGHT THREE STARS THROUGH THE WINDOW. THE CONSOLE WILL WORK OUT WHERE YOU ARE.', { delay: 2600, hold: 20000 });
    } else emit('openShipMenu');
  });
  on('sighted', () => {
    if (S.locks.length === 2 && !S.P.flags.planetsLine) { S.P.flags.planetsLine = true; say('MOST STARS HAVE PLANETS. BILLIONS OF THEM, IN THIS GALAXY ALONE. NOT ONE HAS EVER ANSWERED ANYONE.', { delay: 1200, hold: 18000 }); }
  });
  on('fix', () => {
    if (S.P.storyStep === 2) {
      // playtest: these lines used to interleave with the fix readout (six lines in five seconds), which buried
      // the chapter's first real scare. They now wait for the readout to finish, and the ship holds its breath first.
      setTimeout(() => {
        say('THIS PROBE CANNOT HAVE FLOWN THAT FAR. NOT IN 11 DAYS. NOT IN 11 YEARS.', { hold: 22000 });
        setTimeout(() => audio.dip(1800), 3000);
        say('SOMETHING MOVED YOU WHILE YOU SLEPT.', { delay: 4600, hold: 24000 });
        say('MAIN POWER IS DOWN AND THE CABIN IS FREEZING. SUIT UP. THE POWER PANEL IS OUTSIDE.', { delay: 8600, hold: 24000 });
        setTimeout(() => setStep(3), 8600);
      }, 12500);
    }
  });
  on('repaired', key => {
    if (key === 'power') {
      S.P.unlocks.build = true;
      if (S.P.storyStep <= 3) {
        setStep(4);
        say('MAIN POWER RESTORED. LIGHTS. HEAT. THE FABRICATOR IS AWAKE.', { delay: 400, hold: 16000 });
        say('YOU CAN BUILD ON THE HULL NOW. START WITH LIGHT.', { delay: 3200, hold: 18000 });
      }
    }
    if (key === 'comms') {
      unlockFragment(S.P.system, 'comms');
      if (S.P.storyStep <= 5) { setStep(6); say('ANTENNA REPAIRED. THE LOG IS READABLE AGAIN (JOURNAL: J).', { delay: 400, hold: 16000 }); say('YOU CAN CALL HOME FROM THE CONSOLE.', { delay: 2800, hold: 16000 }); }
    }
    if (key === 'thrusters') say('THRUSTER REPAIRED.', { hold: 8000 });
  });
  on('built', part => {
    if (S.P.storyStep === 4) {
      setStep(5);
      say('LIGHT HOLDS THE DARK BACK. YOU WILL WANT MORE OF IT.', { delay: 800, hold: 14000 });
      say('NEXT: THE ANTENNA. IF ANYONE IS STILL LISTENING AT HOME, THEY NEED TO HEAR YOU.', { delay: 3600, hold: 18000 });
    }
    void part;
  });
  on('signal', first => {
    if (!first) { say('SIGNAL SENT. NO REPLY. THAT IS WHAT SHOULD HAPPEN.', { hold: 10000 }); return; }
    // playtest: the reply is the chapter's centrepiece, and it arrived tangled with a hull contact, the Listener and
    // repeat sends (nine lines in 16 s). Nothing else starts while it plays.
    S.quietUntil = performance.now() + 32000;
    { const rt = Math.round(2 * flight.hereD().length()); say(`TRANSMITTING. AT THE SPEED OF LIGHT, ANY REPLY FROM EARTH TAKES ${rt} YEAR${rt === 1 ? '' : 'S'}.`, { hold: 14000 }); }
    setTimeout(() => {
      audio.dip(1400);
      say('REPLY RECEIVED.', { delay: 1200, hold: 22000 });
      say('ELAPSED: 11 SECONDS.', { delay: 3400, hold: 22000 });
      say('IT IS YOUR OWN MESSAGE, WORD FOR WORD, FROM SOMETHING 1.6 MILLION KILOMETRES AWAY.', { delay: 6400, hold: 24000 });
      say('IT IS SIGNED: KESTREL-4, CREW 2.', { delay: 10400, hold: 26000 });
      setTimeout(() => { S.P.life.sanity = Math.max(5, S.P.life.sanity - 8); }, 10400);
      setTimeout(() => {
        say('TRANSPONDER CONTACT: KESTREL-4, 260 METRES. THAT IS THIS SHIP\'S NAME.', { hold: 22000 });
        unlockFragment(1, 'reply');
        setStep(7);
      }, 15400);
    }, 11000);
  });
  on('recorder', () => { S.P.life.sanity = Math.max(5, S.P.life.sanity - 10); if (S.P.storyStep === 7) { setStep(8); say('THE FIX, THE REPLY, THE SHIP. IT HAS ALL HAPPENED BEFORE. REPAIR THE THRUSTER. LEAVE.', { delay: 800, hold: 20000 }); } });
  on('derelictBody', () => { S.P.derelict.found = true; S.P.life.sanity = Math.max(5, S.P.life.sanity - 15); });
  on('jump', sys => { if (S.P.mode === 'campaign' && sys === 1) return; if (S.P.storyStep >= 8 || S.P.system >= 1) setStep(9); });
  on('helm', () => { if (S.P.mode === 'campaign' && S.P.flight && S.P.storyStep >= 8 && S.P.storyStep < 10) setStep(10); if (!S.P.flags.helmHint) { S.P.flags.helmHint = true; say(lastInputDevice() === 'pad' ? 'THE HELM. THE STICKS TURN THE WHOLE SHIP. HOLD RT TO BURN, LT TO BRAKE. HOLD A TO SWING THE NOSE ONTO THE MARKER.' : 'THE HELM. THE MOUSE TURNS THE WHOLE SHIP. HOLD W TO BURN, S TO BRAKE. HOLD SPACE TO SWING THE NOSE ONTO THE MARKER.', { delay: 600, hold: 18000 }); } });
  on('flightStart', () => { if (S.P.mode === 'campaign' && S.P.storyStep === 10) setStep(11); });
}

// a couple of things worth saying the first time they happen
export function nudges() {
  const P = S.P;
  if (S.mode === 'eva' && !P.flags.evaHint && !(P.landing && P.landing.phase === 'landed')) {
    P.flags.evaHint = true;
    say(pad() ? 'EVA: LEFT STICK FLIES, TRIGGERS UP/DOWN, BUMPERS ROLL. DAMPERS STOP YOU WHEN YOU LET GO.' : 'EVA: WASD FLY, SPACE/C UP AND DOWN, Q/E ROLL, SHIFT BOOST. DAMPERS STOP YOU WHEN YOU LET GO (V).', { hold: 16000 });
    say('WATCH THE O2 BAR. THE SUIT HOLDS ABOUT FIVE MINUTES OF AIR.', { delay: 3000, hold: 14000 });
    // W0 lesson (plan 6.3): the line and its gauge (the #status panel sits top left)
    if (learn('spacewalk')) say(`THE LINE IS ${TETHER_MAX} M. THE GAUGE IS TOP LEFT. ESC: HOW TO PLAY.`, { delay: 6200, hold: 16000 });
  }
}
void THREE; void REPAIR_COST;
