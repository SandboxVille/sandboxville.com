// All tunable numbers in one place. Pure data, no logic, so a balance pass
// never means hunting through game code. "P2" marks numbers new in the
// phase 2 build (movement rework, survival, threats, building).

export const SKY_R = 5000;
export const BASE_ZOOMS = [72, 36, 12, 4];
export const ZOOM5 = 1.4;
export const JUMP_FUEL_COST = 3;
export const UPGRADE_COST = { wideCone: 6, deepRange: 6, zoom5: 6, dreadPing: 4 };
export const STAY_TIMEOUT_MS = 6 * 60 * 1000;

// ---------- P2: movement ----------
export const EYE_H = 1.55;
export const WALK_SPEED = 2.7, SPRINT_MULT = 1.6, WALK_ACCEL = 16, WALK_FRICTION = 13;
export const MOUSE_BASE = 0.0022;            // radians per pixel at sensitivity 1
export const PAD_LOOK_RATE = 3.0;            // radians per second at full stick, sensitivity 1
export const EVA_ACCEL = 4.4, EVA_BOOST_MULT = 2.6, EVA_MAX_SPEED = 18;
export const EVA_DAMP_ASSIST = 1.9;          // per second, when dampers are on and no thrust input
export const EVA_DAMP_FREE = 0.03;           // per second, dampers off (near-true inertia)
export const ROLL_SPEED = 1.5;
export const TETHER_MAX = 60;
export const INTERACT_RADIUS = 3.0;
export const REEL_ACCEL = 9;
export const PLAYER_R = 0.35;
export const GIANT_R = 840;
export const BOUNDARY_R = 900;               // P2: the edge of the measurable space (ship frame, metres)
export const BOUNDARY_WARN = 560;

// ---------- P2: resources + costs ----------
export const REPAIR_COST = {                  // what each system costs to take from 0 to 100
  power: { salvage: 6, ore: 0 },
  comms: { salvage: 8, ore: 2 },
  thrusters: { salvage: 10, ore: 4 },
};
export const REPAIR_RATE = 22;                // repair points per second while holding F (if you can pay)
export const HARVEST_RATE = 1.15;             // chunk "health" removed per second of cutting
export const REFINE_ICE_PER_FUEL = 2;

// ---------- P2: survival ----------
export const OXY_MAX = 100, SUIT_POWER_MAX = 100, PROP_MAX = 100;
export const SUIT_O2_DRAIN = 100 / 300;       // 5 minutes of air per EVA at rest
export const SUIT_O2_EXERT = 0.22;            // extra per second while cutting/repairing/boosting
export const LAMP_DRAIN = 100 / 360;          // helmet lamp: 6 minutes of suit power
export const SUIT_HEAT_DRAIN = 100 / 1200;    // suit heater, always on outside
export const PROP_DRAIN_K = 0.45;
export const CABIN_START_C = 6;               // cabin temperature at wake
export const CABIN_TARGET_C = 19;             // heater target
export const CABIN_COLD_C = -60;              // what the hull falls toward with no heat
export const CABIN_LOSS = 1 / 1400;           // fraction of the gap lost per second without heat
export const CABIN_HEAT_RATE = 0.4;           // degrees per second per heater unit
export const WARMTH_DRAIN_BELOW_0 = 100 / 360; // body warmth lost per second when the air around you is below 0 C
export const RAD_DECAY = 0.06;                // dose recovered per second inside the ship
export const SANITY_DRAIN_ALONE = 0.01;       // slow constant drift from isolation (per second)
export const SANITY_REGEN_LIT = 0.06;         // per second inside a lit, warm cabin

// ---------- P2: threats ----------
export const LISTEN_DECAY = 2.4;              // attention lost per second
export const LISTEN_WARN = 40, LISTEN_COME = 75, LISTEN_KILL = 100;
export const UNLIT_RISE = 3.0, UNLIT_FALL = 14;
export const NEARER_WATCH_DEG = 28;
export const NULL_PULSE_GAP = [170, 280];     // seconds between radiation pulses after the null point is measured
export const NULL_PULSE_WARN = 20, NULL_PULSE_LEN = 14;

// beacon Morse timing (unchanged)
export const MORSE = { 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' };
export const MORSE_UNIT = 220;

export const SECRET_RADIUS = 3.4;
export const SAVE_VERSION = 5;

// ---------- P3: flying the whole ship between stars ----------
// Real special relativity with an impossible power source. The motion, the
// clocks (ship time vs Earth time), the aberration and Doppler shift of the
// sky are the real physics; what the fuel buys is the one thing the probe
// was never built to do. c = 1 light year per year throughout.
export const FLIGHT = {
  A_FULL: 11,               // proper acceleration at full throttle, ly/yr^2 (about 10.7 g)
  A_PLAN: 0.66,             // the nav plans braking as if you only had this share of full thrust (heat, turning)
  RAPIDITY_PER_FUEL: 1.5,   // what one unit of fuel buys (rapidity; 3 fuel = up to 97.8% of c and back to rest)
  W_BURN: 3 / 365.25,       // ship years per real second while the drive burns (3 days a second)
  COAST_SECONDS: 45,        // a coast takes about this long in real time, however long it is on the ship clock
  W_MAX: 0.12,              // ship years per real second, at most (about 44 days a second)
  W_TURN: 0.0004,           // while the ship must turn before it can burn (flip), time compression drops to about 3.5 hours a second
  HEAT_UP: 7, HEAT_DOWN: 3.5, // drive heat, % per real second at full throttle / radiated while cold
  SCRAM_TIME: 8, SCRAM_RESTART: 55,
  THROTTLE_RATE: 0.75,      // throttle change per second while W/S is held


  GAS_UP: 1.6,              // drive output rise per second while gas or brake is held (0 to 100% in 0.6 s)
  GAS_DOWN: 4.0,            // fall per second when you let go (100% to 0 in 0.25 s)
  PEDAL_DZ: 0.06, PEDAL_EXP: 1.4, // trigger dead zone and curve: output = ((v - dz) / (1 - dz)) ^ 1.4, fine control low down
  BRAKE_CONE: 0.35,         // rad (20 deg): the brake burn starts once the tail is this close to the motion
  BRAKE_FULL: 0.1,          // rad (6 deg): full brake burn inside this
  BRAKE_MIN_U: 2e-4,        // proper speed (about 60 km/s) below which there is nothing left to brake
  W_HOLD: 0.0004,           // at the brake point with the drive not burning, the nav holds the clock (about 3.5 hours a second)
  TURN_RATE: 0.5,           // rad/s, keys, stick and the align assist
  MOUSE_K: 0.45,            // the ship turns slower than your head
  ARRIVE_R: 0.15, ARRIVE_BETA: 0.2, // ly and fraction of c: close and slow enough to call it arrived
  FINAL_R: 0.3, FINAL_BETA: 0.6,   // inside this the nav computer takes the last of the braking
  DRIVE_NOISE: 7,           // what the Listener hears from a full burn, per second
  DRIFT_GRACE: 7,           // seconds of ADRIFT warnings before it is final
  SUPPLY_YEARS: 12,         // air, water and food for one person, in ship years. Slow is not safe out here.
  VOYAGER_C: 17.0 / 299792.458, // Voyager 1's speed as a fraction of c
};
export const HELM_EYE = [-0.72, 1.5, -8.42]; // the pilot's eye: left seat, close to the window, the status screen to the right
