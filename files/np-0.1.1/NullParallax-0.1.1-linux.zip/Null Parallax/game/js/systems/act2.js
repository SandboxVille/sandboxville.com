// ACT II: THE CHART (P3, the opening). Design doc SS2.1-2.2: "building a fix
// you can trust, and the risk of trusting it too much"; the Duplicate; and
// "the manifest lists more people than are aboard, and repairing COMMS does
// not clear the discrepancy, it just makes it legible."
//
//  12 THE CHART    you arrive 0.6 ly from Sirius, flown by hand. Sight three
//                  stars. Sirius locks three times: once blazing, twice as it
//                  looks from Earth. The fix agrees with the flight log, the
//                  first time two instruments have agreed since you woke.
//  13 THE ANTENNA  the burn cooked the antenna. Repair it (EVA, a new field).
//  14 THE MANIFEST the manifest is legible now: CREW 2, ABOARD. LIFE SIGNS: 2.
//                  Go and look. The other bunk is made. Two suits on the rack.
//  15 TWO ABOARD   the end of what is built: you have looked everywhere.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { on, emit } from '../core/events.js';
import { say, flash } from '../ui/hud.js';
import { setStep } from './story.js';
import { showCard } from './chapter.js';
import { unlockFragment } from './journal.js';
import { doAutosave } from './save-state.js';
import { CONSOLE_POS, HATCH_INT, HATCH_EXT, ANTENNA_POS, shipFx } from '../render/ship.js';
import { remainingCost } from './repair.js';
import { field } from '../render/world.js';
function nearestChunk(type) { let best = null, bd = Infinity; for (const c of field.chunks) { if (c.hp <= 0 || c.type !== type) continue; const d = c.pos.distanceToSquared(S.pos); if (d < bd) { bd = d; best = c; } } return best; }
import * as audio from '../audio.js';

const YR_DAYS = 365.25;
const A = () => S.P.act2;
export const inAct2 = () => S.P.mode === 'campaign' && S.P.system === 2 && S.P.storyStep >= 12;

function shipTime(y) { const d = y * YR_DAYS; return d < 700 ? `${Math.round(d)} DAYS` : `${y.toFixed(1)} YEARS`; }

// ---------------- arrival ----------------
on('arrived', info => {
  if (S.P.mode !== 'campaign' || !info || !info.dest || info.dest.kind !== 'system' || info.dest.n !== 2) return;
  const P = S.P, a = A();
  a.arrivedT = info.t; a.arrivedTau = info.tau; a.home = !!info.slipped || info.route === 'home'; a.dist = info.dist;
  // the long burn cooked the antenna
  P.repair.comms = Math.min(P.repair.comms, 35);
  P.flags.paidS_comms = Math.floor(35 / 100 * 8); P.flags.paidO_comms = Math.floor(35 / 100 * 2);
  setStep(12);
  const year = Math.floor(2026 + (P.stats.earthYears || 0));
  const lines = a.home ? [
    'YOU POINTED THE SHIP AT THE SUN AND HELD THE HEADING THE WHOLE WAY.',
    'YOU ARRIVED AT SIRIUS.',
    `ON EARTH, ${info.t.toFixed(1)} YEARS PASSED. IT IS ${year} THERE NOW. ON THE SHIP, ${shipTime(info.tau)}.`,
    'THE COURSE ON FILE WAS NEVER CLEARED. IT IS THE ONLY COURSE THIS SHIP WILL HOLD.',
  ] : [
    `YOU CROSSED ${info.dist.toFixed(2)} LIGHT YEARS IN ${shipTime(info.tau)} OF SHIP TIME.`,
    `ON EARTH, ${info.t.toFixed(1)} YEARS PASSED. IT IS ${year} THERE NOW. ANYONE WHO WAS WAITING FOR YOU HAS HAD TO DECIDE, EVERY YEAR, WHETHER TO KEEP WAITING.`,
    'SIRIUS IS 0.6 LIGHT YEARS AHEAD: THE BRIGHTEST STAR IN EARTH\'S SKY. FROM HERE IT OUTSHINES EVERYTHING ELSE IN THE SKY.',
    'THE COURSE WAS ON FILE BEFORE YOU WOKE. SOMEONE WANTED THE SHIP HERE.',
  ];
  setTimeout(() => showCard({ title: 'ACT II: THE CHART', lines }, () => {
    audio.dip(900);
    say('DECELERATION COMPLETE. HOLDING 0.6 LIGHT YEARS FROM SIRIUS.', { delay: 800, hold: 18000 });
    say('THE LONG BURN COOKED THE ANTENNA. COMMS 35%. THE LOG IS PARTLY UNREADABLE AGAIN.', { delay: 3600, hold: 20000 });
    say('BUILD A FIX YOU CAN TRUST: SIGHT THREE STARS THROUGH THE WINDOW.', { delay: 7200, hold: 22000 });
    unlockFragment(2, 'arrive');
    doAutosave(true);
  }), 1200);
});

// the fix: for once, two instruments agree
on('fix', sys => {
  if (sys !== 2 || !inAct2() || A().fixSaid) return;
  A().fixSaid = true;
  const a = A();
  setTimeout(() => {
    if (a.home) {
      say('FLIGHT LOG: COURSE SOL, HELD THE WHOLE WAY. FIX: 0.6 LY FROM SIRIUS. THEY DISAGREE BY EIGHT LIGHT YEARS.', { hold: 24000 });
      say('NEITHER IS FLAGGED.', { delay: 4200, hold: 20000 });
    } else {
      say(`FLIGHT LOG: ${a.dist ? a.dist.toFixed(2) : '8.85'} LY FLOWN FROM A POINT 4.00 LY FROM SOL. FIX: 8.00 LY FROM SOL. THE FLIGHT LOG AND THE FIX AGREE.`, { hold: 24000 });
      say('IT FEELS LIKE SOLID GROUND. YOU ALMOST DO NOT NOTICE THAT THE TWO ARRAYS STILL DISAGREE WITH EACH OTHER.', { delay: 4200, hold: 22000 });
    }
    unlockFragment(2, 'chart');
    setStep(13);
    say('REPAIR THE ANTENNA. THE LOG HAS BEEN RECEIVING SOMETHING SINCE THE BURN, AND COMMS CANNOT READ IT.', { delay: 9000, hold: 22000 });
  }, 13000);
});

on('duplicate', n => {
  if (!inAct2()) return;
  if (n === 2 && !A().dupSaid) { A().dupSaid = true; say('THE COPY IS SIRIUS AS SEEN FROM EARTH: THE SAME BRIGHTNESS, THE SAME BEARING. FROM HERE IT SHOULD LOOK LIKE THE ONE THAT OUTSHINES EVERYTHING.', { delay: 2600, hold: 22000 }); }
  if (n === 3 && !A().dup3) { A().dup3 = true; say('TWO COPIES OF HOME\'S SKY, PASTED INTO THIS ONE. ONE REAL STAR BETWEEN THEM. THE CATALOGUE IS NOT BUILT TO SAY WHICH.', { delay: 2600, hold: 22000 }); }
});

// ---------------- the manifest ----------------
on('repaired', key => {
  if (key !== 'comms' || !inAct2() || A().manifest) return;
  A().manifest = true;
  audio.dip(1500);
  setTimeout(() => {
    say('COMMS RESTORED. RECEIVED WHILE THE ANTENNA WAS DOWN: ONE FILE. A CREW MANIFEST, RE-ISSUED.', { hold: 22000 });
    say('CREW 1: AWAKE.', { delay: 3600, hold: 24000 });
    say('CREW 2: ABOARD.', { delay: 6000, hold: 24000 });
    say('LIFE SIGNS: 2.', { delay: 9000, hold: 26000 });
    setTimeout(() => { S.P.life.sanity = Math.max(5, S.P.life.sanity - 12); unlockFragment(2, 'manifest'); setStep(14); setOtherAboard(true); doAutosave(true); }, 9000);
  }, 1800);
});
// the world changes to match the paperwork: the other bunk is made, two suits
export function setOtherAboard(on) {
  if (shipFx.bunk2Made) shipFx.bunk2Made.visible = on;
  if (shipFx.bunk2Bare) shipFx.bunk2Bare.visible = !on;
  if (shipFx.suit2) shipFx.suit2.visible = on;
}
on('loaded', () => { setOtherAboard(!!(S.P.act2 && S.P.act2.manifest)); if (inAct2() && S.P.storyStep === 15) setTimeout(endChapter, 1600); });
on('newGame', () => setOtherAboard(false));

on('examined', id => {
  if (!inAct2() || S.P.storyStep < 14) return;
  const a = A();
  if (id === 'bunk2') a.sawBunk = true;
  if (id === 'hook') a.sawSuits = true;
  if (a.sawBunk && a.sawSuits && !a.searched) {
    a.searched = true;
    setTimeout(() => {
      say('YOU HAVE LOOKED IN EVERY ROOM. THERE ARE THREE ROOMS.', { hold: 22000 });
      say('LIFE SIGNS: 2.', { delay: 3400, hold: 24000 });
      unlockFragment(2, 'twoaboard');
      setStep(15);
      doAutosave(true);
      setTimeout(endChapter, 4000);
    }, 2600);
  }
});

// 2026-09-28 (David: "LIFE SIGNS: 2. THERE IS NOWHERE LEFT TO LOOK." read like a puzzle he was failing).
// Step 15 is the end of what is built: say so plainly, once, with a checkpoint save.
export function endChapter() {
  if (!inAct2() || S.P.storyStep !== 15 || A().endShown || S.dying) return;
  A().endShown = true;
  doAutosave(true);
  showCard({ title: 'TO BE CONTINUED', sub: 'END OF ACT II, PART ONE: TWO ABOARD  //  CHECKPOINT SAVED', lines: [
    'YOU SEARCHED EVERY ROOM. THE SHIP STILL COUNTS TWO.',
    'THIS IS THE END OF THE STORY SO FAR. YOU HAVE NOT MISSED ANYTHING: THERE IS NOTHING LEFT TO FIND ON THIS SHIP YET.',
    'THE NEXT CHAPTER FOLLOWS THE SECOND LIFE SIGN. IT IS COMING IN AN UPDATE.',
    'UNTIL THEN: KEEP EXPLORING, OR SAVE THIS GAME TO A SLOT (PAUSE MENU), QUIT TO TITLE AND CHOOSE SANDBOX TO FLY TO OTHER STARS.',
  ] }, () => {});
}
// ---------------- the objective line ----------------
export function objective(inside) {
  const P = S.P, step = P.storyStep;
  if (!inAct2()) return null;
  const goOut = { text: 'GO OUTSIDE: THE AIRLOCK IS AT THE BACK OF THE SHIP.', sub: '', target: HATCH_INT, label: 'AIRLOCK' };
  if (step === 12) return { text: 'BUILD A FIX YOU CAN TRUST: SIGHT THREE STARS THROUGH THE WINDOW.', sub: `${S.locks.length}/3 SIGHTED. SIRIUS IS THE ONE THAT OUTSHINES EVERYTHING.`, target: inside ? CONSOLE_POS : null, label: 'WINDOW' };
  if (step === 13) {
    if (P.repair.comms >= 100) return { text: 'ANTENNA REPAIRED. WAIT FOR THE LOG.', sub: '' };
    if (inside) return { ...goOut, text: 'REPAIR THE ANTENNA. IT IS ON TOP OF THE HULL. GO OUTSIDE.' };
    const rem = remainingCost('comms');
    const need = rem.salvage > P.res.salvage ? `CUT ${rem.salvage - P.res.salvage} MORE SALVAGE` : rem.ore > P.res.ore ? `CUT ${rem.ore - P.res.ore} MORE ORE` : null;
    // playtest: this was the only resource step with no marker; a new field with nothing pointing into it
    if (need) { const type = rem.salvage > P.res.salvage ? 'salvage' : 'ore'; const c = nearestChunk(type); return { text: `${need}. THE FIELD HERE IS NEW: SIRIUS LIGHTS IT FROM ONE SIDE.`, sub: `HOLD F ON A CHUNK: ${type === 'salvage' ? 'METAL PLATES WITH BLINKING LIGHTS' : 'THE BROWN ROCKS'}. TAB SCANS`, target: c ? c.pos : null, label: type.toUpperCase() }; }
    return { text: 'FLY TO THE ANTENNA AND HOLD F TO REPAIR IT.', sub: `COMMS ${Math.round(P.repair.comms)}%`, target: ANTENNA_POS, label: 'ANTENNA' };
  }
  if (step === 14) return { text: 'LIFE SIGNS: 2. FIND THE OTHER ONE.', sub: inside ? 'LOOK CLOSER (F) AT THE BUNKS AND THE SUIT RACK' : 'GO INSIDE', target: inside ? new THREE.Vector3(0.95, 0.9, -4.4) : HATCH_EXT, label: inside ? 'BUNKS' : 'AIRLOCK' };
  if (step === 15) return { text: 'TO BE CONTINUED. YOU HAVE REACHED THE END OF THE STORY SO FAR.', sub: 'NOTHING LEFT TO FIND YET. THE NEXT CHAPTER COMES IN AN UPDATE. SANDBOX: SAVE TO A SLOT, QUIT TO TITLE.', target: null };
  return null;
}
void emit; void flash; void HATCH_EXT;
