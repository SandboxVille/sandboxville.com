// All sound is procedural WebAudio: no samples, nothing to license.
// Exposes a small set of functions the rest of the game calls; keeps its own
// AudioContext/graph private to this module.

let ac = null, master = null, humGain = null, rumbleGain = null;
let duckTarget = 1, volMul = 0.9;
let gazeGain = null, gazeProximity = 0;
let heartbeatProximity = 0, heartbeatTimer = null;

function noiseBuffer(sec) {
  const b = ac.createBuffer(1, Math.max(1, ac.sampleRate * sec), ac.sampleRate);
  const d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return b;
}

export function isRunning() { return !!ac; }
export function now() { return ac ? ac.currentTime : 0; }

export function start() {
  if (ac) return;
  ac = new (window.AudioContext || window.webkitAudioContext)();
  const comp = ac.createDynamicsCompressor(); comp.connect(ac.destination);
  master = ac.createGain(); master.gain.value = volMul; master.connect(comp);
  humGain = ac.createGain(); humGain.gain.value = 0; humGain.connect(master);
  [55, 110.4, 165.2].forEach((f, i) => {
    const o = ac.createOscillator(); o.frequency.value = f;
    const g = ac.createGain(); g.gain.value = [0.02, 0.009, 0.004][i];
    o.connect(g); g.connect(humGain); o.start();
  });
  humGain.gain.linearRampToValueAtTime(1, ac.currentTime + 6);
  const nb = ac.createBufferSource(); nb.buffer = noiseBuffer(3); nb.loop = true;
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 70;
  rumbleGain = ac.createGain(); rumbleGain.gain.value = 0;
  nb.connect(lp); lp.connect(rumbleGain); rumbleGain.connect(master); nb.start();

  // gaze-following drone: two detuned tones, silent at rest, swell toward
  // whatever bearing is currently "unsettled" (null point / duplicate / drift).
  gazeGain = ac.createGain(); gazeGain.gain.value = 0; gazeGain.connect(master);
  [220, 233.1].forEach(f => {
    const o = ac.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    const g = ac.createGain(); g.gain.value = 0.5;
    o.connect(g); g.connect(gazeGain); o.start();
  });

  heartbeatLoop();
  buildBeds();
}

function thump(vol) {
  if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(52, t); o.frequency.exponentialRampToValueAtTime(34, t + 0.16);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.24);
}
// self-scheduling heartbeat: tempo and volume track proximity to the
// nearest unresolved bearing, fed once per frame by the game loop.
function heartbeatLoop() {
  if (!ac) return;
  const p = Math.max(0, Math.min(1, heartbeatProximity));
  const gap = 1600 - p * 1100; // 1.6s at rest -> 0.5s at closest
  const vol = 0.03 + p * 0.09;
  thump(vol);
  setTimeout(() => { thump(vol * 0.7); heartbeatTimer = setTimeout(heartbeatLoop, gap * 0.55); }, gap * 0.45);
}
export function setHeartbeatProximity(v) { heartbeatProximity = v; }
export function setGazeProximity(v) { gazeProximity = Math.max(0, Math.min(1, v)); if (gazeGain) gazeGain.gain.setTargetAtTime(gazeProximity * 0.05, ac.currentTime, 0.4); }

export function setRumble(v) { if (rumbleGain) rumbleGain.gain.setTargetAtTime(v, ac.currentTime, 0.15); }
export function humOverride(v, tau = 0.3) { if (humGain) humGain.gain.setTargetAtTime(v, ac.currentTime, tau); }

// master volume, 0..1 (settings slider). Independent of pause ducking.
export function setVolume(v) {
  volMul = Math.max(0, Math.min(1, v));
  if (master) master.gain.setTargetAtTime(volMul * duckTarget, ac.currentTime, 0.2);
}
export function getVolume() { return volMul; }

// pause ducking: lower everything while the menu is open, without touching the user's volume setting.
export function duck(active) {
  duckTarget = active ? 0.22 : 1;
  if (master) master.gain.setTargetAtTime(volMul * duckTarget, ac.currentTime, 0.5);
}

export function creak(pan) {
  if (!ac) return;
  const t = ac.currentTime, src = ac.createBufferSource(); src.buffer = noiseBuffer(1);
  const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 9;
  bp.frequency.setValueAtTime(260 + Math.random() * 120, t); bp.frequency.exponentialRampToValueAtTime(90, t + 0.9);
  const g = ac.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.5, t + 0.08); g.gain.exponentialRampToValueAtTime(0.001, t + 1.0);
  const p = ac.createStereoPanner(); p.pan.value = pan;
  src.connect(bp); bp.connect(g); g.connect(p); p.connect(master); src.start(t); src.stop(t + 1.1);
}

export function blip(freq = 880, vol = 0.05) {
  if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
  o.frequency.value = freq; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.14);
}

export function servo() {
  if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain(), f = ac.createBiquadFilter();
  o.type = 'sawtooth'; o.frequency.setValueAtTime(90, t); o.frequency.linearRampToValueAtTime(140, t + 0.35);
  f.type = 'lowpass'; f.frequency.value = 400; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.03, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
  o.connect(f); f.connect(g); g.connect(master); o.start(t); o.stop(t + 0.42);
}

// resource pickup chime: short, two-note, reads as a small "found something" beat.
export function pickup(kind) {
  if (!ac) return; const t = ac.currentTime;
  const f1 = kind === 'fuel' ? 660 : 520, f2 = kind === 'fuel' ? 990 : 780;
  [ [f1, 0], [f2, 0.07] ].forEach(([f, d]) => {
    const o = ac.createOscillator(), g = ac.createGain();
    o.frequency.value = f; g.gain.setValueAtTime(0.0001, t + d); g.gain.linearRampToValueAtTime(0.06, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.2);
    o.connect(g); g.connect(master); o.start(t + d); o.stop(t + d + 0.22);
  });
}

// COMMS-gated: a voice-shaped noise burst, bandpassed and formant-swept, never speech synthesis.
export function signalGhost(pan = 0) {
  if (!ac) return; const t = ac.currentTime;
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(2.2);
  const bp1 = ac.createBiquadFilter(); bp1.type = 'bandpass'; bp1.Q.value = 6;
  bp1.frequency.setValueAtTime(320, t); bp1.frequency.linearRampToValueAtTime(900, t + 0.9); bp1.frequency.linearRampToValueAtTime(500, t + 2.0);
  const bp2 = ac.createBiquadFilter(); bp2.type = 'bandpass'; bp2.Q.value = 10;
  bp2.frequency.setValueAtTime(1400, t); bp2.frequency.linearRampToValueAtTime(2200, t + 1.1); bp2.frequency.linearRampToValueAtTime(1600, t + 2.0);
  const g = ac.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.18, t + 0.3); g.gain.linearRampToValueAtTime(0.1, t + 1.4); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2);
  const p = ac.createStereoPanner(); p.pan.value = pan;
  src.connect(bp1); src.connect(bp2); bp1.connect(g); bp2.connect(g); g.connect(p); p.connect(master);
  src.start(t); src.stop(t + 2.3);
}

// dread-ping upgrade: a single soft cue, ~1.5s ahead of an occlusion/crossing event.
export function dreadPing() {
  if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.value = 1046.5;
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.035, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 1.2);
}

export function sting() {   // the one sub-bass event; it never repeats within a system
  if (!ac) return; const t = ac.currentTime;
  const o = ac.createOscillator(), g = ac.createGain();
  o.frequency.setValueAtTime(72, t); o.frequency.exponentialRampToValueAtTime(23, t + 6);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.7, t + 0.35); g.gain.exponentialRampToValueAtTime(0.0001, t + 7.5);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 7.6);
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(8); const lp = ac.createBiquadFilter(); lp.type = 'lowpass';
  lp.frequency.setValueAtTime(260, t); lp.frequency.exponentialRampToValueAtTime(35, t + 7);
  const ng = ac.createGain(); ng.gain.setValueAtTime(0.0001, t); ng.gain.exponentialRampToValueAtTime(0.35, t + 0.5); ng.gain.exponentialRampToValueAtTime(0.0001, t + 7.5);
  src.connect(lp); lp.connect(ng); ng.connect(master); src.start(t); src.stop(t + 7.8);
  humGain.gain.setTargetAtTime(0, t, 0.3); humGain.gain.setTargetAtTime(1.3, t + 9, 4);
}

export function fadeOut(sec = 2.5) { if (ac) master.gain.setTargetAtTime(0, ac.currentTime, sec); }

// a reading taken where nothing is catalogued: rises and is cut off hard,
// not decayed -- reads as "measured," not "heard."
export function nullPing() {
  if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(340, t); o.frequency.exponentialRampToValueAtTime(1180, t + 0.5);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.08, t + 0.45); g.gain.setValueAtTime(0.08, t + 0.5); g.gain.setValueAtTime(0.0001, t + 0.505);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.52);
}

// frame-slip accent: a very quiet, short filtered tick. Silent the first
// time it is used in play (caller simply does not invoke it for that one).
export function frameSlipTick() {
  if (!ac) return; const t = ac.currentTime;
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(0.08);
  const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 4; bp.frequency.value = 2600;
  const g = ac.createGain(); g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);
  src.connect(bp); bp.connect(g); g.connect(master); src.start(t); src.stop(t + 0.09);
}

// briefly pulls hum/rumble/gaze toward true silence and restores them --
// silence used as a deliberate cue ahead of a new dread beat.
export function dip(ms = 900) {
  if (!ac) return; const t = ac.currentTime, tau = 0.12;
  const h = humGain ? humGain.gain.value : 1, r = rumbleGain ? rumbleGain.gain.value : 0, gz = gazeProximity * 0.05;
  if (humGain) humGain.gain.setTargetAtTime(0, t, tau);
  if (rumbleGain) rumbleGain.gain.setTargetAtTime(0, t, tau);
  if (gazeGain) gazeGain.gain.setTargetAtTime(0, t, tau);
  setTimeout(() => {
    if (!ac) return; const t2 = ac.currentTime;
    if (humGain) humGain.gain.setTargetAtTime(h, t2, 0.5);
    if (rumbleGain) rumbleGain.gain.setTargetAtTime(r, t2, 0.5);
    if (gazeGain) gazeGain.gain.setTargetAtTime(gz, t2, 0.5);
  }, ms);
}

// v0.4: oxygen depletion -- a short airless collapse, distinct from sting()
// (the giant reveal) and from collapseTone() (the COLLAPSE ending). Death is
// not an ending; it is a reload, so this stays quick.
export function asphyxia() {
  if (!ac) return; const t = ac.currentTime;
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(180, t); o.frequency.exponentialRampToValueAtTime(20, t + 1.8);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.4, t + 0.15); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.0);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 2.1);
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(2.2);
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(500, t); lp.frequency.exponentialRampToValueAtTime(40, t + 1.8);
  const ng = ac.createGain(); ng.gain.setValueAtTime(0.0001, t); ng.gain.linearRampToValueAtTime(0.2, t + 0.2); ng.gain.exponentialRampToValueAtTime(0.0001, t + 2.0);
  src.connect(lp); lp.connect(ng); ng.connect(master); src.start(t); src.stop(t + 2.1);
}

// v0.4: metallic thermal tick, heard only when close to the hull on EVA.
export function hullTick() {
  if (!ac) return; const t = ac.currentTime;
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(0.05);
  const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 14; bp.frequency.value = 1800 + Math.random() * 900;
  const g = ac.createGain(); g.gain.setValueAtTime(0.045, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
  src.connect(bp); bp.connect(g); g.connect(master); src.start(t); src.stop(t + 0.13);
}

// v0.4: the tether reading zero tension for a moment. A soft, low creak --
// nothing is actually released, same "silent first time" pattern as v0.3's
// frame slip (caller simply skips the call on the very first occurrence).
export function tetherCreak() {
  if (!ac) return; const t = ac.currentTime;
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = 'triangle'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(60, t + 0.6);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.045, t + 0.15); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.72);
}

// v0.4: the shove from an unwatched approach closing to contact -- reuses
// the sting() budget conceptually but is its own, smaller cue so sting()
// itself (the giant reveal) stays the one unrepeated jolt per system.
export function shove() {
  if (!ac) return; const t = ac.currentTime;
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(90, t); o.frequency.exponentialRampToValueAtTime(28, t + 1.1);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.45, t + 0.06); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.3);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 1.35);
}

// CH1: the chapter-complete beat -- a soft, held settling tone, quieter and
// shorter than collapseTone() (which is an ending) and with none of sting()'s
// sub-bass jolt. It should read as "a held breath let out," not a climax.
export function chapterClose() {
  if (!ac) return; const t = ac.currentTime;
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(220, t); o.frequency.linearRampToValueAtTime(164, t + 3.5);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.09, t + 1.2); g.gain.exponentialRampToValueAtTime(0.0001, t + 5.5);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 5.6);
  humGain.gain.setTargetAtTime(0.5, t, 1.0); humGain.gain.setTargetAtTime(1.0, t + 4, 2.5);
}

// RESOLVE: unmodified plain fade is used by the caller (fadeOut). This is
// only for the new COLLAPSE ending -- a held, resolved note instead of a
// falling one; the emotional opposite of sting().
export function collapseTone() {
  if (!ac) return; const t = ac.currentTime;
  const o1 = ac.createOscillator(), o2 = ac.createOscillator(), g = ac.createGain();
  o1.type = 'sine'; o1.frequency.setValueAtTime(48, t); o1.frequency.linearRampToValueAtTime(96, t + 4);
  o2.type = 'sine'; o2.frequency.setValueAtTime(96.3, t); o2.frequency.linearRampToValueAtTime(192, t + 4);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.22, t + 3.2); g.gain.setValueAtTime(0.22, t + 5); g.gain.exponentialRampToValueAtTime(0.0001, t + 8);
  o1.connect(g); o2.connect(g); g.connect(master); o1.start(t); o2.start(t); o1.stop(t + 8.2); o2.stop(t + 8.2);
  humGain.gain.setTargetAtTime(0, t, 0.6); humGain.gain.setTargetAtTime(0.6, t + 5, 3);
}


// =====================================================================
// P2: continuous beds (thrusters, breathing, cutter, heater) and the three
// threats' signature sounds. Every bed is built once in start() and only
// its gain/pan/frequency move afterwards -- no node churn per frame.
// =====================================================================
let beds = null;
let ambienceMul = 1;
function bedNoise(sec = 2) { const n = ac.createBufferSource(); n.buffer = noiseBuffer(sec); n.loop = true; n.start(); return n; }
function buildBeds() {
  const B = {};
  // thruster hiss
  B.thrust = ac.createGain(); B.thrust.gain.value = 0; B.thrust.connect(master);
  { const n = bedNoise(); const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 0.8; n.connect(bp); bp.connect(B.thrust); B.thrustBp = bp; }
  // suit breathing: filtered noise, gain driven by a breath envelope each frame
  B.breath = ac.createGain(); B.breath.gain.value = 0; B.breath.connect(master);
  { const n = bedNoise(); const lp = ac.createBiquadFilter(); lp.type = 'bandpass'; lp.frequency.value = 520; lp.Q.value = 0.7; n.connect(lp); lp.connect(B.breath); B.breathF = lp; }
  // cutter: a buzzing saw + grit
  B.cutter = ac.createGain(); B.cutter.gain.value = 0; B.cutter.connect(master);
  { const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 96; const lfo = ac.createOscillator(); lfo.frequency.value = 13; const lg = ac.createGain(); lg.gain.value = 18; lfo.connect(lg); lg.connect(o.frequency); lfo.start();
    const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1500; bp.Q.value = 1.2; o.connect(bp); bp.connect(B.cutter); o.start();
    const n = bedNoise(); const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3000; const ng = ac.createGain(); ng.gain.value = 0.3; n.connect(hp); hp.connect(ng); ng.connect(B.cutter); }
  // heater / life support hum (only when the ship is powered)
  B.heater = ac.createGain(); B.heater.gain.value = 0; B.heater.connect(master);
  { const o = ac.createOscillator(); o.type = 'triangle'; o.frequency.value = 120; const g = ac.createGain(); g.gain.value = 0.4; o.connect(g); g.connect(B.heater); o.start();
    const n = bedNoise(); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 300; n.connect(lp); lp.connect(B.heater); }
  // THE LISTENER: a sub-bass presence, panned toward where it is
  B.listenPan = ac.createStereoPanner(); B.listenPan.connect(master);
  B.listen = ac.createGain(); B.listen.gain.value = 0; B.listen.connect(B.listenPan);
  [29, 43.7, 58.3].forEach((f, i) => { const o = ac.createOscillator(); o.frequency.value = f; const g = ac.createGain(); g.gain.value = [0.6, 0.35, 0.18][i]; o.connect(g); g.connect(B.listen); o.start(); });
  { const n = bedNoise(); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 90; const g = ac.createGain(); g.gain.value = 0.8; n.connect(lp); lp.connect(g); g.connect(B.listen); }
  // THE NEARER: a close, narrow drone that grows as it closes, panned to its bearing
  B.nearPan = ac.createStereoPanner(); B.nearPan.connect(master);
  B.near = ac.createGain(); B.near.gain.value = 0; B.near.connect(B.nearPan);
  [61, 61.9, 122.5].forEach((f, i) => { const o = ac.createOscillator(); o.type = i === 2 ? 'triangle' : 'sine'; o.frequency.value = f; const g = ac.createGain(); g.gain.value = i === 2 ? 0.15 : 0.5; o.connect(g); g.connect(B.near); o.start(); });
  // THE UNLIT: whispers -- three wandering formants over noise, drifting in the stereo field
  B.whisPan = ac.createStereoPanner(); B.whisPan.connect(master);
  B.whis = ac.createGain(); B.whis.gain.value = 0; B.whis.connect(B.whisPan);
  B.formants = [];
  { const n = bedNoise(3); [700, 1200, 2600].forEach(f => { const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = f; bp.Q.value = 14; const g = ac.createGain(); g.gain.value = 0.9; n.connect(bp); bp.connect(g); g.connect(B.whis); B.formants.push(bp); }); }
  // P3: THE DRIVE -- a deep roar you feel more than hear, and a thin whine as it heats
  B.drive = ac.createGain(); B.drive.gain.value = 0; B.drive.connect(master);
  [34, 51.2, 68.1].forEach((f, i) => { const o = ac.createOscillator(); o.type = i ? 'sawtooth' : 'sine'; o.frequency.value = f; const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 160; const g = ac.createGain(); g.gain.value = [0.7, 0.18, 0.08][i]; o.connect(lp); lp.connect(g); g.connect(B.drive); o.start(); });
  { const n = bedNoise(); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 220; const g = ac.createGain(); g.gain.value = 0.9; n.connect(lp); lp.connect(g); g.connect(B.drive); }
  B.whine = ac.createGain(); B.whine.gain.value = 0; B.whine.connect(master);
  { const o = ac.createOscillator(); o.type = 'sine'; o.frequency.value = 2310; const o2 = ac.createOscillator(); o2.frequency.value = 2317; o.connect(B.whine); o2.connect(B.whine); o.start(); o2.start(); }
  beds = B;
}
export function setDrive(throttle, heat) {
  if (!beds) return;
  beds.drive.gain.setTargetAtTime(Math.min(1, throttle || 0) * 0.16, T(), 0.25);
  const h = Math.max(0, (heat || 0) - 0.55) / 0.45;
  beds.whine.gain.setTargetAtTime(h * h * 0.006, T(), 0.3);
}
const T = () => ac.currentTime;
export function setThrust(v) { if (!beds) return; beds.thrust.gain.setTargetAtTime(Math.min(1, v) * 0.09, T(), 0.06); beds.thrustBp.frequency.setTargetAtTime(700 + v * 900, T(), 0.1); }
export function setCutter(on) { if (!beds) return; beds.cutter.gain.setTargetAtTime(on ? 0.05 : 0, T(), 0.05); }
export function setHeater(v) { if (!beds) return; beds.heater.gain.setTargetAtTime(v * 0.012, T(), 0.8); }
let breathPhase = 0;
export function updateBreath(dt, on, rate, depth) {
  if (!beds) return;
  if (!on) { beds.breath.gain.setTargetAtTime(0, T(), 0.2); return; }
  breathPhase += dt * rate * Math.PI * 2;
  const s = Math.sin(breathPhase);
  const env = s > 0 ? Math.pow(s, 1.6) * 1.0 : Math.pow(-s, 2.2) * 0.55;
  beds.breath.gain.setTargetAtTime(env * 0.05 * depth, T(), 0.05);
  beds.breathF.frequency.setTargetAtTime(s > 0 ? 620 : 420, T(), 0.2);
}
export function setListener(level, pan) { if (!beds) return; beds.listen.gain.setTargetAtTime(Math.min(1, level) * 0.5 * ambienceMul, T(), 0.4); beds.listenPan.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan || 0)), T(), 0.3); }
export function setNearer(level, pan) { if (!beds) return; beds.near.gain.setTargetAtTime(Math.min(1, level) * 0.12, T(), 0.2); beds.nearPan.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan || 0)), T(), 0.15); }
let whisT = 0;
export function setWhispers(level, dt) {
  if (!beds) return;
  beds.whis.gain.setTargetAtTime(Math.min(1, level) * 0.06 * ambienceMul, T(), 0.3);
  whisT += dt || 0.016;
  if (level > 0.02) {
    beds.formants.forEach((f, i) => f.frequency.setTargetAtTime([600, 1100, 2400][i] * (0.75 + 0.5 * Math.abs(Math.sin(whisT * (1.3 + i * 0.7) + i))), T(), 0.08));
    beds.whisPan.pan.setTargetAtTime(Math.sin(whisT * 0.37) * 0.9, T(), 0.2);
  }
}
export function setAmbience(v) { ambienceMul = Math.max(0, Math.min(1.5, v)); if (humGain) humGain.gain.setTargetAtTime(ambienceMul, T(), 0.5); }

// one-shots
export function footstep(k = 1) {
  if (!ac) return; const t = T();
  const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sine';
  o.frequency.setValueAtTime(95 + Math.random() * 20, t); o.frequency.exponentialRampToValueAtTime(48, t + 0.09);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.05 * Math.min(1.4, k), t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.14);
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(0.06); const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2400 + Math.random() * 800; bp.Q.value = 3;
  const ng = ac.createGain(); ng.gain.setValueAtTime(0.018 * k, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
  src.connect(bp); bp.connect(ng); ng.connect(master); src.start(t); src.stop(t + 0.07);
}
export function bump(k = 0.5) {
  if (!ac) return; const t = T();
  const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(30, t + 0.3);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.25 * k, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.36);
}
export function click(freq = 1800) { blip(freq, 0.02); }
export function clank() {
  if (!ac) return; const t = T();
  [220, 331, 497].forEach((f, i) => { const o = ac.createOscillator(), g = ac.createGain(); o.type = 'square'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.02, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5 - i * 0.1); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400; o.connect(lp); lp.connect(g); g.connect(master); o.start(t); o.stop(t + 0.5); });
  bump(0.5);
}
export function knock(pan = 0, n = 3) {
  if (!ac) return;
  for (let i = 0; i < n; i++) setTimeout(() => {
    if (!ac) return; const t = T();
    const o = ac.createOscillator(), g = ac.createGain(), p = ac.createStereoPanner(); p.pan.value = pan;
    o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.18);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.35, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
    o.connect(g); g.connect(p); p.connect(master); o.start(t); o.stop(t + 0.32);
  }, i * (380 + Math.random() * 200));
}
export function alarm() {
  if (!ac) return; const t = T();
  for (let i = 0; i < 4; i++) { const o = ac.createOscillator(), g = ac.createGain(); o.type = 'square'; o.frequency.value = i % 2 ? 620 : 880; g.gain.setValueAtTime(0.0001, t + i * 0.28); g.gain.linearRampToValueAtTime(0.025, t + i * 0.28 + 0.01); g.gain.setValueAtTime(0.025, t + i * 0.28 + 0.2); g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.28 + 0.25); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2000; o.connect(lp); lp.connect(g); g.connect(master); o.start(t + i * 0.28); o.stop(t + i * 0.28 + 0.27); }
}
export function geigerTick() {
  if (!ac) return; const t = T();
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(0.01); const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3000;
  const g = ac.createGain(); g.gain.setValueAtTime(0.06, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.01);
  src.connect(hp); hp.connect(g); g.connect(master); src.start(t); src.stop(t + 0.02);
}
// the Listener's answer: a long, descending call from very far away
export function listenerCall(pan = 0) {
  if (!ac) return; const t = T();
  const p = ac.createStereoPanner(); p.pan.value = pan; p.connect(master);
  [[180, 44], [271, 66]].forEach(([a, b], i) => {
    const o = ac.createOscillator(), g = ac.createGain(); o.type = i ? 'triangle' : 'sine';
    o.frequency.setValueAtTime(a, t); o.frequency.exponentialRampToValueAtTime(b, t + 4.5);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(i ? 0.03 : 0.09, t + 1.2); g.gain.exponentialRampToValueAtTime(0.0001, t + 5.2);
    o.connect(g); g.connect(p); o.start(t); o.stop(t + 5.3);
  });
  const src = ac.createBufferSource(); src.buffer = noiseBuffer(5); const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 5;
  bp.frequency.setValueAtTime(900, t); bp.frequency.exponentialRampToValueAtTime(200, t + 4.5);
  const ng = ac.createGain(); ng.gain.setValueAtTime(0.0001, t); ng.gain.linearRampToValueAtTime(0.05, t + 1); ng.gain.exponentialRampToValueAtTime(0.0001, t + 5);
  src.connect(bp); bp.connect(ng); ng.connect(p); src.start(t); src.stop(t + 5.1);
}
export function scanPing() {
  if (!ac) return; const t = T();
  const o = ac.createOscillator(), g = ac.createGain(); o.frequency.setValueAtTime(1600, t); o.frequency.exponentialRampToValueAtTime(400, t + 0.9);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.05, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + 1.15);
}
export function transmit() {
  if (!ac) return; const t = T();
  for (let i = 0; i < 18; i++) { const o = ac.createOscillator(), g = ac.createGain(); o.type = 'square'; o.frequency.value = 900 + (i * 137 % 7) * 110; g.gain.setValueAtTime(0.0001, t + i * 0.09); g.gain.linearRampToValueAtTime(0.018, t + i * 0.09 + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.09 + 0.08); const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2500; o.connect(lp); lp.connect(g); g.connect(master); o.start(t + i * 0.09); o.stop(t + i * 0.09 + 0.09); }
}
export function powerUp() {
  if (!ac) return; const t = T();
  const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(40, t); o.frequency.exponentialRampToValueAtTime(120, t + 2.5);
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(200, t); lp.frequency.exponentialRampToValueAtTime(1200, t + 2.5);
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.06, t + 0.4); g.gain.exponentialRampToValueAtTime(0.0001, t + 3.2);
  o.connect(lp); lp.connect(g); g.connect(master); o.start(t); o.stop(t + 3.3);
}
export function powerDown() {
  if (!ac) return; const t = T();
  const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(30, t + 1.6);
  const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 600;
  g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
  o.connect(lp); lp.connect(g); g.connect(master); o.start(t); o.stop(t + 1.9);
}

// CREW 2's sting (2026-09-28): a falling saw, a detuned screech over it and a noise slap, panned hard
// to one side; it goes through the master gain, so it respects the player's volume.
export function shadowSting() {
  if (!ac) return;
  const t = T(), pan = Math.random() < 0.5 ? -0.7 : 0.7;
  const p = ac.createStereoPanner(); p.pan.value = pan; p.connect(master);
  const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.2, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9); g.connect(p);
  const o = ac.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(170, t); o.frequency.exponentialRampToValueAtTime(34, t + 0.7); o.connect(g);
  const s1 = ac.createOscillator(), s2 = ac.createOscillator(), sg = ac.createGain(); s1.type = s2.type = 'square';
  s1.frequency.setValueAtTime(1760, t); s2.frequency.setValueAtTime(1864, t); s1.frequency.exponentialRampToValueAtTime(900, t + 0.5); s2.frequency.exponentialRampToValueAtTime(960, t + 0.5);
  sg.gain.setValueAtTime(0.0001, t); sg.gain.linearRampToValueAtTime(0.05, t + 0.01); sg.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
  s1.connect(sg); s2.connect(sg); sg.connect(p);
  const n = ac.createBufferSource(); n.buffer = noiseBuffer(0.25); const ng = ac.createGain();
  ng.gain.setValueAtTime(0.16, t); ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.25); n.connect(ng); ng.connect(p);
  o.start(t); o.stop(t + 0.95); s1.start(t); s2.start(t); s1.stop(t + 0.6); s2.stop(t + 0.6); n.start(t); n.stop(t + 0.26);
  o.onended = () => { for (const x of [o, s1, s2, n, g, sg, ng, p]) x.disconnect(); };
  setTimeout(() => bump(0.9), 120);
}
