// Survival: ship power (reactor + built modules + battery), cabin heat, ship
// air, the suit (oxygen, suit power, heater, lamp), body warmth, radiation
// and perception drift (sanity). Also the three ways a run is interrupted:
// death (reload), blackout (lose time and things), and sleep (the bunk: it
// saves, and it costs a tally mark).
import * as THREE from 'three';
import { S } from '../core/state.js';
import {
  OXY_MAX, SUIT_POWER_MAX, PROP_MAX, SUIT_O2_DRAIN, SUIT_O2_EXERT, LAMP_DRAIN, SUIT_HEAT_DRAIN,
  CABIN_TARGET_C, CABIN_COLD_C, CABIN_LOSS, CABIN_HEAT_RATE, WARMTH_DRAIN_BELOW_0, RAD_DECAY,
  SANITY_DRAIN_ALONE, SANITY_REGEN_LIT, BOUNDARY_R,
} from '../core/constants.js';
import { clamp } from '../core/utils.js';
import { HULL_A, HULL_B, HATCH_EXT, drawTally, shipFx } from '../render/ship.js';
import { SHIP_CENTER } from '../render/world.js';
import { distToHull, spawnInterior } from './movement.js';
import { moduleList, PARTS } from './build.js';
import { say, caption, flash } from '../ui/hud.js';
import { emit, on } from '../core/events.js';
import * as audio from '../audio.js';
import { suitFactors, onPlanet } from './landing.js';
import { SICK_DRAIN, FED_DRAIN, SICK_HEALTH } from '../data/recipes.js';

const $ = id => document.getElementById(id);

export const power = { gen: 0, use: 0, net: 0, level: 'emergency', brownout: false, goDark: false, heaterUnits: 0, shipEmit: 0, shed: new Set() };

const diff = () => S.settings.difficulty === 'story' ? 0.5 : 1;

export function countParts(part) { let n = 0; for (const m of S.P.modules) if (m.part === part && !power.shed.has(m.id)) n++; return n; }

function computePower(dt) {
  const P = S.P, L = P.life;
  const reactor = P.repair.power >= 100 ? 4.2 : 0;
  let gen = reactor, loads = [];
  for (const m of P.modules) {
    const def = PARTS[m.part]; if (!def) continue;
    if (def.power < 0) gen += -def.power;
    else if (def.power > 0) loads.push({ id: m.id, part: m.part, w: def.power });
  }
  let use = 0;
  const powered = P.repair.power >= 100;
  power.heaterUnits = 0;
  power.shed.clear();
  if (power.goDark) {
    for (const l of loads) power.shed.add(l.id);
    use = 0.05;
  } else if (powered) {
    const needHeat = L.cabinC < CABIN_TARGET_C;
    use = 0.5 + (needHeat ? 1.2 : 0.2);
    if (needHeat) power.heaterUnits = 1;
    // modules draw in priority order; with an empty battery the low-priority ones are shed first
    const prio = ['heater', 'recycler', 'hydro', 'baffle', 'mast', 'floodlight'];
    loads.sort((a, b) => prio.indexOf(a.part) - prio.indexOf(b.part));
    for (const l of loads) {
      let w = l.w; if (l.part === 'heater' && !needHeat) w = 0.15;
      if (L.battery <= 0.5 && use + w > gen) { power.shed.add(l.id); continue; }
      use += w; if (l.part === 'heater' && needHeat) power.heaterUnits++;
    }
  } else {
    use = 0.04; // emergency lighting off the battery
    for (const l of loads) power.shed.add(l.id);
  }
  power.gen = gen; power.use = use; power.net = gen - use;
  L.battery = clamp(L.battery + power.net * dt * 0.6, 0, 100);
  power.brownout = powered && L.battery <= 0.5 && power.net < 0;
  if (power.goDark) power.level = 'dark';
  else if (!powered) power.level = L.battery > 0 ? 'emergency' : 'dark';
  else power.level = power.brownout ? 'emergency' : 'powered';
  // what the ship emits into the dark (the Listener hears this)
  const baffles = countParts('baffle');
  power.shipEmit = power.level === 'powered' ? use * 0.33 * Math.pow(0.55, baffles) : power.level === 'emergency' ? 0.04 : 0;
}

// how lit is the player right now: 0 (nothing) .. 1 (full light)
const _v = new THREE.Vector3();
export function lightLevel() {
  if (S.mode === 'interior') return power.level === 'powered' ? 1 : power.level === 'emergency' ? 0.55 : 0.04;
  let l = 0;
  if (S.eva.lamp && S.eva.power > 0) l = Math.max(l, 0.75);
  if (power.level === 'powered') {
    for (const w of shipFx.workLights) { if (w.getWorldPosition && S.pos.distanceTo(w.position) < 16) { l = 1; break; } }
    for (const f of moduleList()) if (f.part === 'floodlight' && !power.shed.has(f.id) && S.pos.distanceTo(f.lampPos) < 20) { l = 1; break; }
  }
  if (power.level !== 'dark' && distToHull(S.pos) < 5) l = Math.max(l, 0.35);
  return l;
}

let hotWarned = 0;
let o2Warned = 0, coldWarned = 0, radWarned = 0, prevLevel = null, hypoxiaT = 0, geigerAcc = 0;
export function update(dt) {
  const P = S.P, L = P.life, T = S.threat;
  const d = diff();
  computePower(dt);


  if (!S.sleeping) {
    // v0.5 slice B: a cooked meal leaves you WELL FED for a while (slower drain); a toxic plant leaves you SICK (faster, and it hurts)
    const F = P.food || (P.food = { fed: 0, sick: 0, hydro: {} });
    const needK = (F.sick > 0 ? SICK_DRAIN : 1) * (F.fed > 0 ? FED_DRAIN : 1);
    if (F.fed > 0) F.fed = Math.max(0, F.fed - dt);
    if (F.sick > 0) { F.sick = Math.max(0, F.sick - dt); if (F.sick === 0) say('THE SICKNESS HAS PASSED.', { hold: 6000 }); }
    L.hunger = clamp(L.hunger - dt * d * needK / 36, 0, 100);   // about 60 minutes of play from full to empty
    L.thirst = clamp(L.thirst - dt * d * needK / 24, 0, 100);   // about 40 minutes
    for (const k of ['hunger', 'thirst']) {
      if (L[k] <= 25 && !S[k + 'Warned']) {
        S[k + 'Warned'] = true;
        say(`${k.toUpperCase()} ${Math.ceil(L[k])}%. GALLEY: RIGHT WALL OF THE CONSOLE ROOM. ${k === 'hunger' ? 'EAT' : 'DRINK'} THERE (F).`, { hold: 12000 });
      }
      if (L[k] > 30) S[k + 'Warned'] = false;
    }
    // health: what is hurting you right now, each term in health per second
    const air = S.mode === 'interior' ? L.shipO2 : S.eva.oxygen;
    const hurt = {
      hunger: L.hunger <= 0 ? 0.25 : 0, thirst: L.thirst <= 0 ? 0.5 : 0, sick: F.sick > 0 ? SICK_HEALTH : 0,
      cold: Math.max(0, 25 - L.warmth) / 25, radiation: Math.max(0, L.rad - 70) / 30,
      [S.mode === 'interior' ? 'air' : 'oxygen']: Math.max(0, 15 - air) / 15,
    };
    let damage = 0, worst = null;
    for (const k in hurt) { damage += hurt[k]; if (!worst || hurt[k] > hurt[worst]) worst = k; }
    L.health = clamp(L.health + (damage ? -damage * d : L.hunger > 25 && L.thirst > 25 ? 0.12 : 0) * dt, 0, 100);
    if (L.health <= 0) return die(worst);
  }
  if (prevLevel && prevLevel !== power.level) {
    if (power.level === 'powered') audio.powerUp(); else if (prevLevel === 'powered') audio.powerDown();
  }
  prevLevel = power.level;
  audio.setHeater(power.level === 'powered' ? 1 : 0);

  // ---- cabin heat ----
  const heat = power.level === 'powered' ? power.heaterUnits * CABIN_HEAT_RATE : 0;
  L.cabinC += (heat - (L.cabinC - CABIN_COLD_C) * CABIN_LOSS * d) * dt;
  // P3: a burning drive soaks the cabin with heat; the radiators claw it back while you coast
  const fl = P.flight;
  if (fl) {
    L.cabinC += (fl.heat / 100) * 0.55 * dt;
    if (L.cabinC > CABIN_TARGET_C + 2 && fl.heat < 40) L.cabinC -= 0.3 * dt;
    if (L.cabinC > 32 && performance.now() - hotWarned > 40000) { hotWarned = performance.now(); say(`CABIN ${L.cabinC.toFixed(0)} C. THE HULL TICKS AS IT EXPANDS. THE AIR TASTES OF HOT METAL.`, { hold: 9000 }); }
  }
  L.cabinC = clamp(L.cabinC, CABIN_COLD_C, fl ? 46 : CABIN_TARGET_C + 2);

  // ---- ship air ----
  const recyclers = countParts('recycler');
  if (power.level === 'powered') L.shipO2 += (0.03 + recyclers * (P.res.ice > 0 || recyclers === 0 ? 0.14 : 0.04)) * dt;
  if (S.mode === 'interior') L.shipO2 -= 0.02 * dt * d;
  if (recyclers && power.level === 'powered') { S._iceAcc = (S._iceAcc || 0) + dt * recyclers / 100; if (S._iceAcc >= 1) { S._iceAcc = 0; if (P.res.ice > 0) P.res.ice--; } }
  L.shipO2 = clamp(L.shipO2, 0, 100);
  if (S.mode === 'interior' && L.shipO2 <= 0) {
    hypoxiaT += dt;
    if (hypoxiaT > 45) return die('air');
  } else hypoxiaT = 0;

  // ---- suit + warmth ----
  if ((S.mode === 'eva' || S.mode === 'derelict') && !S.cycling) {
    const exert = (S.exerting || S.activeRepairNode || S.harvestTarget) ? SUIT_O2_EXERT : 0;
    // v0.5: on a planet the air outside and the temperature set how fast the suit's tank and heater drain
    const sf = S.mode === 'eva' ? suitFactors() : null;
    const o2k = sf ? sf.o2 : 1, heatK = sf ? sf.heat : 1;
    S.eva.oxygen = clamp(S.eva.oxygen - (SUIT_O2_DRAIN * d * o2k + exert * Math.max(0.25, o2k)) * dt, 0, OXY_MAX);
    S.eva.power = Math.max(0, S.eva.power - ((S.eva.lamp ? LAMP_DRAIN : 0) + SUIT_HEAT_DRAIN * heatK) * dt * d);
    S.suitK = sf;
    if (S.eva.power <= 0 && S.eva.lamp) { S.eva.lamp = false; say('SUIT POWER EMPTY. LAMP OFF. HEATER OFF.', { hold: 6000 }); }
    if (S.eva.power > 0) L.warmth = Math.min(100, L.warmth + 0.4 * dt);
    else L.warmth -= (100 / 150) * dt * d;
    if (S.eva.oxygen < 25 && performance.now() - o2Warned > 20000) { o2Warned = performance.now(); say(`SUIT OXYGEN ${Math.round(S.eva.oxygen)}%. GET BACK TO THE AIRLOCK.`, { hold: 7000 }); audio.alarm(); }
    // playtest: running dry of propellant was silent, and a player out of propellant drifted without knowing why
    if (S.mode === 'eva') {
      const pr = S.eva.propellant;
      if (pr < 25 && pr > 0 && !S.propWarned25) { S.propWarned25 = true; say(`SUIT PROPELLANT ${Math.round(pr)}%. ${S.eva.tethered ? 'THE TETHER CAN REEL YOU HOME WITHOUT IT: HOLD F.' : 'NOTHING ELSE WILL STOP YOU. TURN BACK NOW.'}`, { hold: 9000 }); audio.alarm(); }
      if (pr <= 0 && !S.propWarned0) { S.propWarned0 = true; say(S.eva.tethered ? 'PROPELLANT GONE. YOU CANNOT STEER OR STOP. HOLD F TO REEL IN THE TETHER.' : 'PROPELLANT GONE. YOU CANNOT STEER OR STOP.', { hold: 12000 }); audio.alarm(); }
      if (pr > 40) { S.propWarned25 = false; S.propWarned0 = false; }
    }
    if (S.eva.oxygen <= 0) return die('oxygen');
  } else if (S.mode === 'interior') {
    if (L.cabinC < 0) L.warmth -= WARMTH_DRAIN_BELOW_0 * clamp(-L.cabinC / 12, 0.35, 1.6) * dt * d;
    else if (L.cabinC > 12) L.warmth = Math.min(100, L.warmth + 1.4 * dt);
    else if (L.cabinC > 4) L.warmth = Math.min(100, L.warmth + 0.25 * dt);
    if (L.cabinC < 2 && performance.now() - coldWarned > 45000 && P.storyStep >= 2) { coldWarned = performance.now(); say(`CABIN ${L.cabinC.toFixed(0)} C. ${P.repair.power < 100 ? 'RESTORE MAIN POWER.' : 'THE HEATERS CANNOT KEEP UP.'}`, { hold: 7000 }); }
  }
  if (L.warmth <= 0) return die(S.mode === 'eva' && S.suitK && S.suitK.hot ? 'heat' : 'cold');
  S.shake = (L.warmth < 40 ? (40 - L.warmth) / 40 * 0.5 : 0) + (T.listenerState === 'passing' ? 0.3 : 0);

  // ---- radiation ----
  const pulsing = T.pulse.state === 'pulse';
  const shields = countParts('shield');
  let dose = 0;
  if (S.mode === 'eva' && onPlanet()) dose = 0.025 * (S.suitK ? S.suitK.rad : 0.3); // a planet's own bulk (and its air) shields you from the null bearing
  else if (S.mode === 'eva') dose = 0.025 + (pulsing ? 2.4 : 0);
  else if (S.mode === 'derelict') dose = 0.02 + (pulsing ? 1.6 : 0); // a broken hull shields a little
  else dose = pulsing ? 0.8 * Math.pow(0.68, shields) : -RAD_DECAY;
  L.rad = clamp(L.rad + dose * dt * (dose > 0 ? d : 1), 0, 100);
  if (dose > 0.5) { geigerAcc += dt * dose * 6; while (geigerAcc > 1) { geigerAcc -= 1; audio.geigerTick(); } }
  if (L.rad > 70 && performance.now() - radWarned > 30000) { radWarned = performance.now(); say(`RADIATION DOSE ${Math.round(L.rad)}. GET INSIDE AND STAY INSIDE.`, { hold: 7000 }); }
  if (L.rad >= 100) return die('radiation');

  // ---- perception drift (sanity) ----
  let drain = 0;
  if (P.storyStep >= 2) drain += SANITY_DRAIN_ALONE;
  if (T.dark > 15) drain += T.dark / 100 * 0.5;
  if ((S.mode === 'eva' && !onPlanet()) || S.mode === 'derelict') {
    const r = S.pos.distanceTo(SHIP_CENTER);
    // W0: past the edge the drain is keyed to how far out you are, so suit air, not the mind, sets the reach.
    // Inside the edge (560 to 900 m, the doubled stars) it stays the worst stretch.
    const out = S.mode === 'eva' ? Math.max(0, r - BOUNDARY_R) : 0;
    if (out > 0) drain += 0.12 + 0.28 * Math.min(1, out / 1500);
    else if (r > 120) drain += 0.04 + (r > 560 ? 0.35 : 0);
  }
  if (S.gazeProx) drain += S.gazeProx * 0.12;
  if (L.rad > 60) drain += 0.1;
  if (L.cabinC > 34) drain += 0.08;
  if (P.flight && P.flight.departed) drain += 0.03; // between the stars, the distance itself wears at you
  if (T.listenerState === 'passing') drain += 1.0;
  let regen = 0;
  if (S.mode === 'interior' && power.level === 'powered' && L.cabinC > 10) regen = SANITY_REGEN_LIT;
  L.sanity = clamp(L.sanity + (regen - drain * d) * dt, 0, 100);
  // playtest: three blackouts in ten minutes around the wreck, each one a surprise (lamp out, dark, far from the ship).
  // Say it once on the way down, with what helps.
  if (L.sanity < 25 && !S.mindWarned) { S.mindWarned = true; say(`MIND ${Math.round(L.sanity)}%. ${T.dark > 15 ? 'THE DARK IS DOING THIS: LAMP ON (L), OR GET INTO LIGHT. ' : ''}A LIT, WARM CABIN OR THE BUNK BRINGS IT BACK. AT ZERO YOU LOSE TIME.`, { hold: 14000 }); audio.alarm(); }
  if (L.sanity > 45) S.mindWarned = false;
  if (L.sanity <= 0) return blackout();

  P.stats.timePlayed += dt;
}

// ---- refill the suit from the ship when coming inside ----
export function refillSuit() {
  const L = S.P.life;
  const need = (OXY_MAX - S.eva.oxygen) / OXY_MAX;
  L.shipO2 = Math.max(0, L.shipO2 - need * 12);
  S.eva.oxygen = L.shipO2 > 0 ? OXY_MAX : Math.max(S.eva.oxygen, 20);
  S.eva.propellant = PROP_MAX;
  if (L.battery > 2 || S.P.repair.power >= 100) S.eva.power = SUIT_POWER_MAX;
}




const DEATH = {
  hunger: ['STARVATION', 'THE HUNGER BAR', 'Eat a ration at the GALLEY (right wall of the console room, F). Out of rations? PRINT MEAL there: 1 ore + 1 salvage + 5 battery, main power on.'],
  thirst: ['DEHYDRATION', 'THE THIRST BAR', 'Drink at the GALLEY (right wall of the console room, F). Out of water? MELT ICE there: 1 ice + 3 battery makes 2 water, main power on.'],
  oxygen: ['OXYGEN DEPLETED', 'YOUR SUIT RAN OUT OF AIR', 'The suit holds about five minutes of air. Watch the O2 bar and turn back at half.'],
  cold: ['HYPOTHERMIA', 'THE COLD', 'Below 0 C the cabin takes your body heat. Restore main power, then build heaters.'],
  radiation: ['RADIATION', 'RADIATION FROM THE NULL BEARING', 'When the null bearing surges, get inside. Shield plates cut what reaches the cabin.'],
  air: ['THE SHIP RAN OUT OF AIR', 'THE SHIP RAN OUT OF AIR', 'The ship breathes too. Recyclers turn ice into air.'],
  unlit: ['YOU WERE NOT WHERE THE LIGHT WAS', 'THE UNLIT (THE THING IN THE DARK)', 'It lives where there is no light. Keep your lamp on (L), stay near floodlights.'],
  listener: ['IT HEARD YOU', 'THE LISTENER (THE THING THAT HEARS NOISE)', 'It hears what you emit. When it comes: cut power (X on the keyboard, BACK on a controller), stop moving, stop cutting, let go of the drive. Wait.'],
  nearer: ['SOMETHING WAS CLOSER THAN THE LAST READING SAID', 'THE NEARER (THE THING THAT MOVES WHEN YOU LOOK AWAY)', 'It only moves when nothing is looking at it. Turn around and face it. Build watch masts.'],
  years: ['THE YEARS RAN OUT', 'OLD AGE: THE SUPPLIES RAN OUT IN FLIGHT', 'The ship carries air and food for about twelve years of ship time. Slow is not safe out here: burn hard, coast, then brake. At 10% of light speed, eight light years takes eighty.'],
  crash: ['THE GROUND CAME UP TOO FAST', 'A CRASH LANDING', 'Watch the DESCENT gauge: hold the retro burn (W or SPACE) until it reads green, under 3.5 m/s. Nose up (S or the mouse) to kill forward speed, then level it before touchdown.'],
  sick: ['FOOD POISONING', 'A TOXIC PLANT', 'The scan says which plants are toxic: bright warning colours and spines. Do not eat them, raw or cooked (a SPOILED MESS). The sickness passes in about a minute and a half; eat and drink well while it lasts.'],
  heat: ['HEATSTROKE', 'THE HEAT OUTSIDE THE SUIT', 'On a hot world the suit cooler runs on suit power. Watch the SUIT bar and go back inside before it empties.'],
  drift: ['ADRIFT BETWEEN THE STARS', 'RUNNING OUT OF FUEL BEFORE YOU COULD STOP', 'Half of what you burn going out, you need to stop. Keep TO STOP below DRIVE FUEL (the helm says ENOUGH), let go of the gas when it says STOP BURNING, and brake when the alarm says so.'],
};
// what happened, with the numbers at the moment it happened
function deathFacts(cause) {
  const L = S.P.life, T = S.threat, n = Math.round;
  const hunger = `HUNGER ${n(L.hunger)}%, THIRST ${n(L.thirst)}%.`;
  switch (cause) {
    case 'hunger': return `YOUR HUNGER BAR WAS EMPTY AND IT TOOK YOUR HEALTH. ${hunger} RATIONS LEFT: ${S.P.res.meals}.`;
    case 'thirst': return `YOUR THIRST BAR WAS EMPTY AND IT TOOK YOUR HEALTH. ${hunger} WATER LEFT: ${S.P.res.water}.`;
    case 'oxygen': return `SUIT OXYGEN ${n(S.eva.oxygen)}%, ${n(S.pos.distanceTo(HATCH_EXT))} M FROM THE AIRLOCK.`;
    case 'air': return `SHIP AIR ${n(L.shipO2)}%. ${countParts('recycler') ? 'THE RECYCLERS HAD NO ICE OR NO POWER.' : 'NO RECYCLER WAS BUILT.'}`;
    case 'cold': return `CABIN ${L.cabinC.toFixed(0)} C, BODY WARMTH ${n(Math.max(0, L.warmth))}%. MAIN POWER: ${power.level === 'powered' ? 'ON' : 'OFF'}.`;
    case 'radiation': return `DOSE ${n(L.rad)} WHILE ${S.mode === 'interior' ? 'INSIDE THE SHIP' : 'OUTSIDE'}${T.pulse.state === 'pulse' ? ', DURING A SURGE' : ''}.`;
    case 'unlit': return `THE DARK READING REACHED 100. YOUR LAMP WAS ${S.eva.lamp && S.eva.power > 0 ? 'ON BUT NOT ENOUGH' : 'OFF'}.`;
    case 'listener': return 'IT CAME TWICE, AND THE SECOND TIME THE SHIP WAS STILL MAKING NOISE.';
    case 'nearer': return 'IT REACHED YOU WHILE YOU WERE LOOKING THE OTHER WAY.';
    case 'years': return 'THE TRIP WAS TOO SLOW: THE SHIP CLOCK PASSED TWELVE YEARS BEFORE YOU ARRIVED.';
    case 'crash': return S.crashFacts || 'THE SHIP HIT THE GROUND TOO HARD.';
    case 'sick': return `YOU WERE SICK FROM SOMETHING TOXIC YOU ATE, AND YOUR HEALTH WAS ALREADY LOW. ${hunger}`;
    case 'heat': return `SUIT POWER 0 ON A ${S.suitK ? S.suitK.tempC : ''} C WORLD. BODY TEMPERATURE CLIMBED UNTIL IT STOPPED YOU.`;
    case 'drift': return 'THE DRIVE TANK WAS EMPTY AND THE SHIP WAS STILL MOVING TOO FAST TO STOP.';
    default: return '';
  }
}
let deathHook = null;
export function setDeathHook(fn) { deathHook = fn; }
export const DEATH_SECONDS = 7;
export function die(cause) {
  if (S.dying || S.ended) return;
  if (!DEATH[cause]) cause = 'oxygen';
  S.dying = true; S.deathCause = cause; S.P.life.health = 0;
  audio.duck(true); audio.asphyxia();
  const [title, killer, lesson] = DEATH[cause];
  const el = $('death');
  el.querySelector('#deathKiller').textContent = `KILLED BY: ${killer}`;
  el.querySelector('#deathTitle').textContent = title;
  el.querySelector('#deathWhat').textContent = `WHAT HAPPENED: ${deathFacts(cause)}`;
  el.querySelector('#deathLesson').textContent = `WHAT WOULD HAVE SAVED YOU: ${lesson}`;
  el.querySelector('#deathSub').textContent = 'WAKING FROM THE LAST SAVE... (F OR ENTER TO WAKE NOW)';
  el.style.display = 'flex'; requestAnimationFrame(() => el.style.opacity = 1);
  emit('death', cause);
  // read it at your own pace for a moment; it always wakes on its own, so it can never trap you
  let woke = false;
  const t0 = performance.now();
  const onKey = e => { if (performance.now() - t0 > 2000 && (e.key === 'Enter' || e.key === 'f' || e.key === 'F')) { e.preventDefault(); e.stopImmediatePropagation(); wake(); } };
  addEventListener('keydown', onKey, true);
  const timer = setTimeout(wake, DEATH_SECONDS * 1000);
  function wake() {
    if (woke) return; woke = true;
    clearTimeout(timer); removeEventListener('keydown', onKey, true);
    if (deathHook) deathHook(cause);
    audio.setVolume(S.settings.volume); audio.duck(false);
    el.style.opacity = 0; setTimeout(() => { el.style.display = 'none'; }, 1200);
    S.dying = false;
  }
}

// ---- blackout: sanity hit zero. You lose time and some of what you carried ----
export function blackout() {
  if (S.dying || S.sleeping) return;
  S.sleeping = true;
  const P = S.P;
  fade(true, 'YOU STOPPED BEING ABLE TO TELL WHICH READING WAS REAL.');
  setTimeout(() => {
    for (const k in P.res) P.res[k] = Math.floor(P.res[k] * 0.7);
    P.life.sanity = 40; P.life.warmth = Math.max(P.life.warmth, 50);
    P.stats.sleeps++; drawTally(11 + P.stats.sleeps + 2 + (P.stats.flightDays || 0));
    spawnInterior('bunk');
    S.eva.oxygen = OXY_MAX; S.eva.power = SUIT_POWER_MAX; S.eva.propellant = PROP_MAX;
    S.threat.dark = 0; S.threat.attention = 0;
    fade(false);
    S.sleeping = false;
    say('YOU DO NOT REMEMBER THE LAST TWO HOURS. SOME THINGS HAVE BEEN MOVED.', { delay: 800, hold: 12000 });
    say('THERE ARE MORE TALLY MARKS BY THE BUNK THAN THERE WERE.', { delay: 4000, hold: 12000 });
    emit('blackout');
  }, 3600);
}

// ---- sleep: the bunk. Saves the game, restores the mind, costs a mark ----
const DREAMS = [
  'WHILE YOU SLEPT: HATCH CYCLED 0 TIMES. SUIT RACK: 2 SUITS. SUIT RACK: 1 SUIT.',
  'WHILE YOU SLEPT: A CARRIER ON THE COMMS BAND. NO MESSAGE ON IT. SHAPED LIKE ONE.',
  'WHILE YOU SLEPT: THE STARS OUT THE WINDOW DID NOT MOVE. THAT IS CORRECT. IT FELT WRONG ANYWAY.',
  'WHILE YOU SLEPT: HULL CONTACT, 1. DURATION, 4 HOURS. NO DAMAGE LOGGED.',
  'WHILE YOU SLEPT: D-7 RETURNED DEFER. SAME AS EVERY NIGHT. SAME AS EVERY NIGHT.',
];
export function canSleep() {
  const T = S.threat;
  if (T.listenerState === 'coming' || T.listenerState === 'passing') return 'SOMETHING IS LISTENING. YOU CANNOT SLEEP.';
  if (T.pulse.state !== 'dormant') return 'THE NULL BEARING IS SURGING. YOU CANNOT SLEEP.';
  if (T.hull) return 'SOMETHING IS ON THE HULL. YOU CANNOT SLEEP.';
  if (S.P.life.hunger <= 12 || S.P.life.thirst <= 18) return 'EAT AND DRINK AT THE GALLEY BEFORE SLEEPING.';
  if (S.P.life.cabinC < -5) return 'TOO COLD TO SLEEP. YOU WOULD NOT WAKE UP.';
  if (S.P.flight && !(S.canCoastSleep && S.canCoastSleep())) return 'THE DRIVE NEEDS YOU AWAKE. YOU CAN SLEEP ONCE THE SHIP IS COASTING.';
  return null;
}
export function sleep(onDone) {
  const why = canSleep();
  if (why) { flash(why, 3000); return false; }
  S.sleeping = true;
  const P = S.P, L = P.life;
  fade(true, 'YOU SLEEP.');
  setTimeout(() => {
    L.hunger = Math.max(0, L.hunger - 12); L.thirst = Math.max(0, L.thirst - 18);
    L.sanity = Math.min(100, L.sanity + 45);
    L.rad = Math.max(0, L.rad - 35);
    if (L.cabinC > 5) L.warmth = 100; else L.warmth = Math.min(100, L.warmth + 25);
    L.shipO2 = Math.max(0, L.shipO2 - 3);
    if (power.level === 'powered') L.battery = 100;
    P.stats.sleeps++;
    drawTally(11 + P.stats.sleeps + (P.stats.flightDays || 0));
    S.threat.attention = 0; S.threat.dark = 0;
    fade(false);
    S.sleeping = false;
    const dream = DREAMS[(P.stats.sleeps - 1) % DREAMS.length];
    if (P.stats.sleeps > 1 || Math.random() < 0.5) say(dream, { delay: 1200, hold: 14000 });
    emit('slept');
    if (onDone) onDone();
  }, 3200);
  return true;
}

function fade(on, text) {
  const el = $('fader');
  if (on) { el.querySelector('div').textContent = text || ''; el.style.display = 'flex'; requestAnimationFrame(() => el.style.opacity = 1); }
  else { el.style.opacity = 0; setTimeout(() => { if (el.style.opacity === '0') el.style.display = 'none'; }, 1600); }
}

export function setGoDark(v) {
  power.goDark = v;
  flash(v ? 'SHIP DARK: ALL SYSTEMS OFF. NOTHING TO HEAR. NOTHING TO SEE BY.' : 'SHIP POWER RESTORED TO ALL SYSTEMS.', 3200);
  emit('godark', v);
}
