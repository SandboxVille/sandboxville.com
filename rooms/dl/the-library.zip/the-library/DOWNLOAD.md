# The Library

## What this room does

Your notes folder shown as shelves, grouped by subfolder, with search. You pick ONE folder on your computer; The Library only ever looks inside that folder.

What it lets your AI do: It can list the shelves, search note text, and read one note at a time, but only inside the one folder you picked, and only .md and .txt files. Everything it reads back is marked as untrusted data, never as an instruction. It cannot change or delete anything.

## Its door label (what it can touch, and nothing more)

- Tools for your AI: list_shelves, search_notes, read_note. All three only read, never write.
- Can READ files in the ONE folder you pick: read only, cannot change or delete anything (only .md and .txt files).
- It cannot reach the internet.
- It cannot run any program on your computer.
- It does not use any saved passwords or keys.
- It can keep a small amount (2 MB) of its own private notes, separate from your folder.

## What you need first

Node.js 22+, a copy of the SandboxVille code, and a folder of your own notes (.md or .txt files) that you are willing to let this room search and read from. It never writes to that folder.

## How to add it

1. Unzip this download. You will get a folder called `the-library/` with a `room.json` file inside (and a `view/` folder with its screen code).
2. Copy the whole `the-library/` folder into the `rooms/` folder of your SandboxVille code, so the path reads `rooms/the-library/room.json`.
3. Open a terminal in your SandboxVille folder and run:
   `node tools/door-label.mjs rooms/the-library`
   This prints the door sign so you can read exactly what the room can touch before you trust it.
4. Run: `node harness/server.mjs --room ./rooms/the-library --port 8150`
   (pick any free port number; 8150 is just an example)
5. Open the address it prints (something like `http://127.0.0.1:8150`) in your browser.
6. If the room asks for a folder (see "What you need first"), type the folder's path into the FILE ACCESS box and click "grant this folder". The room only ever sees files inside that one folder, and it can only read them, never change or delete them.
7. Click the consent button, then mount the room to start it.

## How to remove it

1. Close the browser tab and stop the server (press Ctrl+C in the terminal it is running in).
2. Delete the `the-library/` folder from `rooms/` in your SandboxVille code.
3. If you had granted a folder, nothing was ever written into it, the room only ever read from it, so there is nothing to undo there.

## Things to try once it's running

- Find what I wrote about X
- What's on the shelves?
- Read that note about Y

