// Small, stateless math/formatting helpers shared across modules. Nothing in
// this file reads or writes game state -- every function is pure given its
// arguments, which is what makes it safe for every other module to import.
import * as THREE from 'three';

export function dirFromRaDec(raDeg, decDeg) {
  const ra = THREE.MathUtils.degToRad(raDeg), dec = THREE.MathUtils.degToRad(decDeg);
  return new THREE.Vector3(Math.cos(dec) * Math.cos(ra), Math.sin(dec), -Math.cos(dec) * Math.sin(ra));
}

export function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function randomDir(rnd) {
  const z = rnd() * 2 - 1, a = rnd() * Math.PI * 2, r = Math.sqrt(1 - z * z);
  return new THREE.Vector3(r * Math.cos(a), z, r * Math.sin(a));
}

export function bvColor(bv) {
  const t = THREE.MathUtils.clamp((bv + 0.4) / 2.4, 0, 1);
  const blue = [0.62, 0.72, 1.0], white = [1.0, 0.97, 0.93], orange = [1.0, 0.76, 0.48], red = [1.0, 0.58, 0.38];
  const mix = (a, b, k) => a.map((v, i) => v + (b[i] - v) * k);
  if (t < 0.3) return mix(blue, white, t / 0.3);
  if (t < 0.6) return mix(white, orange, (t - 0.3) / 0.3);
  return mix(orange, red, (t - 0.6) / 0.4);
}

export const fmtRA = d => { const h = d / 15; const hh = Math.floor(h), mm = Math.round((h - hh) * 60); return `${hh}h${String(mm).padStart(2, '0')}m`; };
export function raDec(v) { const ra = (THREE.MathUtils.radToDeg(Math.atan2(-v.z, v.x)) + 360) % 360; const dec = THREE.MathUtils.radToDeg(Math.asin(v.y)); return [ra, dec]; }

// orientation helpers shared by movement (player body) and entities (the
// approach, which aims relative to the same camera basis)
const _e = new THREE.Euler(0, 0, 0, 'YXZ'), _q = new THREE.Quaternion();
export function localBasis(pitch, yaw, roll) {
  _e.set(pitch, yaw, roll, 'YXZ'); _q.setFromEuler(_e);
  return { f: new THREE.Vector3(0, 0, -1).applyQuaternion(_q), r: new THREE.Vector3(1, 0, 0).applyQuaternion(_q), u: new THREE.Vector3(0, 1, 0).applyQuaternion(_q) };
}
export function flatBasis(yaw) {
  _e.set(0, yaw, 0, 'YXZ'); _q.setFromEuler(_e);
  return { f: new THREE.Vector3(0, 0, -1).applyQuaternion(_q), r: new THREE.Vector3(1, 0, 0).applyQuaternion(_q) };
}

export const noiseGLSL = `
  float h(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
  float n3(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(h(i), h(i + vec3(1,0,0)), f.x), mix(h(i + vec3(0,1,0)), h(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(h(i + vec3(0,0,1)), h(i + vec3(1,0,1)), f.x), mix(h(i + vec3(0,1,1)), h(i + vec3(1,1,1)), f.x), f.y), f.z); }
  float fbm(vec3 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++) { s += a * n3(p); p *= 2.03; a *= 0.5; } return s; }`;

// ---------- P2: quaternion-based view basis (the camera orientation truth
// is S.q; these helpers turn it into forward/right/up vectors) ----------
const _vb = { f: new THREE.Vector3(), r: new THREE.Vector3(), u: new THREE.Vector3() };
export function basisFromQ(q, out) {
  const o = out || { f: new THREE.Vector3(), r: new THREE.Vector3(), u: new THREE.Vector3() };
  o.f.set(0, 0, -1).applyQuaternion(q); o.r.set(1, 0, 0).applyQuaternion(q); o.u.set(0, 1, 0).applyQuaternion(q);
  return o;
}
export function sharedBasis(q) { return basisFromQ(q, _vb); }
export function qFromYawPitch(yaw, pitch, roll, out) {
  _e.set(pitch, yaw, roll || 0, 'YXZ');
  return (out || new THREE.Quaternion()).setFromEuler(_e);
}
// yaw/pitch that best describe a quaternion's forward vector (roll dropped)
export function yawPitchFromQ(q) {
  const f = new THREE.Vector3(0, 0, -1).applyQuaternion(q);
  const pitch = Math.asin(THREE.MathUtils.clamp(f.y, -1, 1));
  const yaw = Math.atan2(-f.x, -f.z);
  return { yaw, pitch };
}
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export function fmtYearFromLy(ly, now = 2026) {
  const yr = Math.round(now - ly);
  if (yr > 0) return `AROUND THE YEAR ${yr}`;
  return `AROUND ${Math.abs(yr).toLocaleString('en-US')} BCE`;
}
