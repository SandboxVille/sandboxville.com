let e=null;function u(n){e=n}function r(){e&&e.refresh()}export{r as refreshPause,u as setPauseMenu};
