# The Terrarium

Skill: Watching and learning. Version 0.1.0.

## What this room does

A glass tank of small animals, each run by its own little circuit of spiking neurons. They eat, flee and change over generations.

What it lets your AI do: census, touch, scent - it can report on the tank and nudge what is inside, and never harm it.

## Its door sign (what it can touch, and nothing more)

SandboxVille shows you this exact sign before the room is placed:

```
=== The Terrarium  (io.github.sandboxville/terrarium v0.1.0) ===
This room can:
  + run its own animation
  + keep 4 MB of its own private notes
  + answer questions about itself (census)
  + let your AI act on it (touch, scent)
Nothing else: no internet, no files, no programs on your computer, no saved secrets, no other rooms.
SAFE: this room stays entirely inside its own glass box.
```

## How to add it

You do not need to unzip this file.

1. Put this zip file, just as it is, in the `add-rooms-here` folder inside your SandboxVille folder.
2. Start SandboxVille: double-click `Start SandboxVille.cmd` (Windows) or `Start SandboxVille.command` (Mac), or run `./start-sandboxville.sh` (Linux). In a terminal in your SandboxVille folder you can also run `node host/world-host.mjs --open`. If SandboxVille is already running, skip this step.
3. Your browser opens, already paired. Only that browser can place a room. An AI can never place, move or remove a room.
4. You spawn in your Lobby. Walk to a glowing EMPTY LOT sign and press E.
5. Pick The Terrarium. SandboxVille finds this zip by its fingerprint (sha256), checks it against its catalog and checks every file the room pins, then shows the door sign above.
6. Read the sign. If you are happy with it, press PLACE. The page reloads with the room in place.

## How to remove it

Walk to its door, press E to read the door sign, then press REMOVE ROOM. SandboxVille tells you what will happen, then you confirm.
The room and its own private notes move to the trash folder in your SandboxVille data folder (`~/.sandboxville/trash/`). Nothing is deleted for good until you empty that folder yourself.

Tools it gives your AI: census, touch, scent.

## Things to try once it is in

- How is the tank doing?
- Touch the glass
- Drop a scent and watch who turns

## License

Free to use with SandboxVille, for yourself. All rights reserved. See LICENSE.txt in this zip.
