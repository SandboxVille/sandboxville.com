// Unified input: keyboard, mouse (pointer lock, with a drag-to-look
// fallback), gamepad and touch all feed one place. The game loop reads
// continuous axes with axes() and one-shot actions with takeActions(), so
// no gameplay module ever has to know which device the player is holding.
import { S } from './state.js';

const keys = new Set();            // canonical lowercase key names currently held
const actions = [];                // one-shot action queue for this frame
let mdx = 0, mdy = 0;              // accumulated mouse look delta (pixels) since last frame
let dragLook = null;               // fallback drag-look state when pointer lock is unavailable
let locked = false;
let wantLock = false;
let lockFailed = false;
let lastDevice = 'kbm';
let lockErrors = 0;
let clickedSinceResume = false;
export function needsClick() { return !locked && !clickedSinceResume && lastDevice === 'kbm'; }
export function markResumed() { clickedSinceResume = false; }
export function lockSupported() { return !lockFailed; }
const touchMove = { x: 0, y: 0 };
const pad = { lx: 0, ly: 0, rx: 0, ry: 0, lt: 0, rt: 0, connected: false };
const padPrev = {};
let canvasEl = null;
const listeners = { lockLost: [] };

export function onLockLost(fn) { listeners.lockLost.push(fn); }
export function isLocked() { return locked; }
export function lastInputDevice() { return lastDevice; }
// W0: the one label for the key that unclips and clips the line (the rebound key; "B TWICE" on a pad)
export function tetherKey() { return lastDevice === 'pad' ? 'B TWICE' : String((S.settings.keybinds && S.settings.keybinds.cut) || 't').toUpperCase(); }
export function held(k) { return keys.has(k); }
export function push(a, data) { actions.push(data === undefined ? a : { a, data }); }

// keyboard remap: custom binds are normalized to their canonical action key
// before anything downstream sees them, so gamepad/touch never need to know.
function normalizeKey(k) {
  const kb = S.settings.keybinds || {};
  if (k === kb.interact) return 'f';
  if (k === kb.cut) return 't';
  if (k === kb.console) return 'r';
  if (k === kb.lamp) return 'l';
  if (k === kb.build) return 'b';
  return k;
}

export function requestLock() {
  if (!canvasEl || locked || lockFailed) return;
  wantLock = true;
  try {
    const p = canvasEl.requestPointerLock && canvasEl.requestPointerLock({ unadjustedMovement: false });
    if (p && p.catch) p.catch(() => { lockErrors++; if (lockErrors >= 3) lockFailed = true; });
  } catch (e) { lockErrors++; if (lockErrors >= 3) lockFailed = true; }
}
export function releaseLock() {
  wantLock = false;
  try { if (document.pointerLockElement) document.exitPointerLock(); } catch (e) { /* ignore */ }
}

export function initInput(canvas, { onKeyWhileAsleep, isMenuOpen }) {
  canvasEl = canvas;
  document.addEventListener('pointerlockchange', () => {
    const now = document.pointerLockElement === canvasEl;
    const was = locked; locked = now;
    if (was && !now && wantLock) { wantLock = false; listeners.lockLost.forEach(f => f()); }
  });
  document.addEventListener('pointerlockerror', () => { lockErrors++; if (lockErrors >= 3) lockFailed = true; });

  addEventListener('keydown', e => {
    lastDevice = 'kbm';
    if (!S.awake) { if (!e.repeat && onKeyWhileAsleep) onKeyWhileAsleep(e); return; }
    const k = normalizeKey(e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase());
    if (k === 'escape' || k === 'p') { if (!e.repeat) push('pause'); e.preventDefault(); return; }
    if (isMenuOpen && isMenuOpen()) return;
    if (k === 'tab' || k === ' ' || k === 'shift' || 'wasdqecfgv'.includes(k) || k.startsWith('arrow')) e.preventDefault();
    if (!keys.has(k) && !e.repeat) edgeKey(k);
    keys.add(k);
  });
  addEventListener('keyup', e => {
    const k = normalizeKey(e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase());
    keys.delete(k);
  });
  addEventListener('blur', () => keys.clear());

  canvas.addEventListener('mousemove', e => {
    if (locked) { mdx += e.movementX || 0; mdy += e.movementY || 0; lastDevice = 'kbm'; }
  });
  canvas.addEventListener('pointerdown', e => {
    if (!S.awake || (isMenuOpen && isMenuOpen())) return;
    if (e.pointerType === 'touch') { lastDevice = 'touch'; }
    if (e.button === 2) { keys.add('mouse2'); return; }
    clickedSinceResume = true;
    let noTap = false;
    if (!locked && e.pointerType === 'mouse' && e.button === 0 && !lockFailed) {
      // the first click captures the mouse; it never also sights. If the
      // lock is refused, dragging still looks around (fallback below).
      requestLock(); noTap = true;
    }
    if (locked) { push('primary'); return; }
    // drag-look fallback (touch, or pointer lock refused)
    dragLook = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: 0, noTap };
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  });
  canvas.addEventListener('pointermove', e => {
    if (!dragLook || e.pointerId !== dragLook.id || locked) return;
    const dx = e.clientX - dragLook.x, dy = e.clientY - dragLook.y;
    dragLook.x = e.clientX; dragLook.y = e.clientY; dragLook.moved += Math.abs(dx) + Math.abs(dy);
    mdx += dx; mdy += dy;
  });
  const endDrag = e => {
    if (e.button === 2) { keys.delete('mouse2'); return; }
    if (dragLook && e.pointerId === dragLook.id) {
      if (dragLook.moved < 8 && !dragLook.noTap) push('primary');
      dragLook = null;
    }
  };
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', () => { dragLook = null; });
  addEventListener('mouseup', e => { if (e.button === 2) keys.delete('mouse2'); });
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  addEventListener('wheel', e => {
    if (!S.awake || (isMenuOpen && isMenuOpen())) return;
    push(e.deltaY < 0 ? 'wheelUp' : 'wheelDown');
  }, { passive: true });

  addEventListener('gamepadconnected', () => { pad.connected = true; });
}

function edgeKey(k) {
  switch (k) {
    case 'f': push('interact'); break;
    case 't': push('cut'); break;
    case 'r': push('console'); break;
    case 'l': push('lamp'); break;
    case 'b': push('build'); break;
    case 'g': push('remove'); break;
    case 'tab': push('ping'); break;
    case 'v': push('dampers'); break;
    case 'o': push('view'); break;
    case 'x': push('godark'); break;
    case 'j': push('journal'); break;
    case 'm': push('mission'); break;
    case 'n': push('chart'); break;
    case 'enter': push('primary'); break;
    case 'z': push('sleep'); break;
    case 'k': push('name'); break;
    default:
      if (k.length === 1 && k >= '1' && k <= '9') push('num', +k);
  }
}

// touch controls: an on-screen joystick feeds touchMove; buttons inject the
// same canonical keys/actions a keyboard would.
export function initTouch(layer, base, knob, buttons, onPause) {
  let joyId = null, baseRect = null;
  addEventListener('pointerdown', e => { if (e.pointerType === 'touch') layer.classList.add('on'); }, { passive: true });
  base.addEventListener('pointerdown', e => { joyId = e.pointerId; baseRect = base.getBoundingClientRect(); base.setPointerCapture(e.pointerId); });
  base.addEventListener('pointermove', e => {
    if (e.pointerId !== joyId || !baseRect) return;
    const cx = baseRect.left + baseRect.width / 2, cy = baseRect.top + baseRect.height / 2;
    let dx = (e.clientX - cx) / (baseRect.width / 2), dy = (e.clientY - cy) / (baseRect.height / 2);
    const len = Math.hypot(dx, dy); if (len > 1) { dx /= len; dy /= len; }
    touchMove.x = dx; touchMove.y = dy;
    knob.style.left = `calc(50% + ${dx * 30}px)`; knob.style.top = `calc(50% + ${dy * 30}px)`;
  });
  const releaseJoy = e => { if (e.pointerId !== joyId) return; joyId = null; touchMove.x = 0; touchMove.y = 0; knob.style.left = '50%'; knob.style.top = '50%'; };
  base.addEventListener('pointerup', releaseJoy); base.addEventListener('pointercancel', releaseJoy);
  buttons.querySelectorAll('button[data-k]').forEach(b => {
    const k = b.dataset.k;
    b.addEventListener('pointerdown', e => { e.preventDefault(); if (!keys.has(k)) edgeKey(k); keys.add(k); b.classList.add('active'); });
    const rel = () => { keys.delete(k); b.classList.remove('active'); };
    b.addEventListener('pointerup', rel); b.addEventListener('pointercancel', rel); b.addEventListener('pointerleave', rel);
  });
  buttons.querySelectorAll('button[data-a]').forEach(b => {
    b.addEventListener('pointerdown', e => { e.preventDefault(); if (b.dataset.a === 'pause') onPause(); else push(b.dataset.a); });
  });
}

const dz = v => Math.abs(v) < 0.14 ? 0 : (v - Math.sign(v) * 0.14) / 0.86;
export function pollGamepads(isMenuOpen, onAnyWhileAsleep) {
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  pad.lx = pad.ly = pad.rx = pad.ry = pad.lt = pad.rt = 0;
  ['gp_up', 'gp_down', 'gp_rollL', 'gp_rollR', 'gp_boost', 'gp_interact', 'gp_zoom', 'gp_a'].forEach(k => keys.delete(k));
  for (const p of pads) {
    if (!p) continue;
    const pressed = i => !!(p.buttons[i] && (p.buttons[i].pressed || p.buttons[i].value > 0.5));
    const edge = i => { const k = p.index + ':' + i, now = pressed(i), was = padPrev[k]; padPrev[k] = now; return now && !was; };
    const anyPressed = p.buttons.some(b => b && b.pressed);
    if (anyPressed || Math.abs(p.axes[0] || 0) > 0.3 || Math.abs(p.axes[2] || 0) > 0.3) lastDevice = 'pad';
    if (!S.awake) { if (anyPressed && onAnyWhileAsleep) onAnyWhileAsleep(); for (let i = 0; i < 17; i++) edge(i); continue; }
    if (edge(9)) push('pause');
    if (isMenuOpen && isMenuOpen()) { for (let i = 0; i < 17; i++) edge(i); continue; }
    pad.lx = dz(p.axes[0] || 0); pad.ly = dz(p.axes[1] || 0);
    pad.rx = dz(p.axes[2] || 0); pad.ry = dz(p.axes[3] || 0);
    pad.lt = p.buttons[6] ? p.buttons[6].value : 0; pad.rt = p.buttons[7] ? p.buttons[7].value : 0;
    if (pad.lt > 0.3) keys.add('gp_down');
    if (pad.rt > 0.3) keys.add('gp_up');
    if (pressed(4)) keys.add('gp_rollL');
    if (pressed(5)) keys.add('gp_rollR');
    if (pressed(10)) keys.add('gp_boost');
    if (pressed(2)) keys.add('gp_interact');
    if (pressed(0)) keys.add('gp_a'); // P3: held A = align the ship at the helm
    if (edge(0)) push('primary');
    if (edge(2)) push('interact');
    if (edge(1)) push('back');
    if (edge(3)) push('build');
    if (edge(8)) push('godark');
    if (edge(11)) push('dampers');
    if (edge(12)) push('lamp');
    if (edge(13)) push('ping');
    if (edge(14)) push('padLeft');
    if (edge(15)) push('padRight');
    for (let i = 16; i < 17; i++) edge(i);
  }
}

// continuous axes for this frame, device-merged and clamped
export function axes() {
  const c = (v) => Math.max(-1, Math.min(1, v));
  const moveX = c((keys.has('d') ? 1 : 0) - (keys.has('a') ? 1 : 0) + pad.lx + touchMove.x);
  const moveF = c((keys.has('w') ? 1 : 0) - (keys.has('s') ? 1 : 0) - pad.ly - touchMove.y);
  const moveU = c((keys.has(' ') ? 1 : 0) - (keys.has('c') ? 1 : 0) + (keys.has('gp_up') ? pad.rt : 0) - (keys.has('gp_down') ? pad.lt : 0));
  const roll = c((keys.has('e') ? 1 : 0) - (keys.has('q') ? 1 : 0) + (keys.has('gp_rollR') ? 1 : 0) - (keys.has('gp_rollL') ? 1 : 0));
  const boost = keys.has('shift') || keys.has('gp_boost');
  const interactHeld = keys.has('f') || keys.has('gp_interact');
  const zoomHeld = keys.has('mouse2');
  const kLookX = (keys.has('arrowright') ? 1 : 0) - (keys.has('arrowleft') ? 1 : 0);
  const kLookY = (keys.has('arrowdown') ? 1 : 0) - (keys.has('arrowup') ? 1 : 0);
  return { moveX, moveF, moveU, roll, boost, interactHeld, zoomHeld, padRX: pad.rx, padRY: pad.ry, padRT: pad.rt, padLT: pad.lt, kLookX, kLookY };
}

export function takeMouse() { const r = { dx: mdx, dy: mdy }; mdx = 0; mdy = 0; return r; }
export function takeActions() { const a = actions.splice(0, actions.length); return a; }
export function clearHeld() { keys.clear(); mdx = mdy = 0; }
export const _keys = keys; // test/debug surface
