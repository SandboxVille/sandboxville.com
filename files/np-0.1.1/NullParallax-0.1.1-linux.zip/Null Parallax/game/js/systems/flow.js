// Flow: starting a new game (story or sandbox), loading into the world, and
// arriving at a new system after a jump. The dread schedulers start here,
// exactly once.
import { S, freshProgress } from '../core/state.js';
import { buildSystem } from './sensors.js';
import { spawnInterior } from './movement.js';
import { say } from '../ui/hud.js';
import { unlockFragment } from './journal.js';
import { doAutosave } from './save-state.js';
import { scheduleCreak, scheduleFrameSlip, scheduleTetherSlack } from './audio-hooks.js';
import { scheduleDread } from './entities.js';
import { buildField } from '../render/world.js';
import { rebuildModules } from './build.js';
import { resetTransient } from './threats.js';
import { drawTally, shipFx } from '../render/ship.js';
import { OXY_MAX, PROP_MAX, SUIT_POWER_MAX } from '../core/constants.js';
import { emit } from '../core/events.js';
import * as audio from '../audio.js';
import * as flight from './flight.js';
import { starPos, starName, starKind, starNote } from './catalogue.js';
import * as THREE from 'three';
import { ship } from '../render/scene.js';
import * as landing from './landing.js';

const $ = id => document.getElementById(id);

let schedStarted = false;
export function startSchedulers() { if (schedStarted) return; schedStarted = true; scheduleCreak(); scheduleDread(); scheduleFrameSlip(); scheduleTetherSlack(); }

// (re)build everything that depends on which system we are in
export function beginWorld(opts = {}) {
  buildSystem(S.P.system, opts);
  buildField(S.P.place ? 'p' + S.P.place.hip : S.P.system, S.P.harvested);
  flight.restoreLocal();
  rebuildModules();
  resetTransient();
  drawTally(11 + S.P.stats.sleeps + (S.P.stats.flightDays || 0));
  if (shipFx.secretGroup) shipFx.secretGroup.visible = !S.P.secretFound;
  if (shipFx.suitOnRack) shipFx.suitOnRack.visible = true;
  S.buildMode = false;
  S.eva.oxygen = OXY_MAX; S.eva.propellant = PROP_MAX; S.eva.power = SUIT_POWER_MAX;
  landing.restore(); // v0.5: back in orbit, or standing on the ground, as saved
}

function hideTitle() {
  const t = $('title'); if (!t) return;
  t.style.opacity = 0; setTimeout(() => { if (t.parentNode) t.remove(); }, 1600);
}

function eyesOpen() {
  const f = $('fader'); if (!f) return;
  f.querySelector('div').textContent = '';
  f.style.transition = 'none'; f.style.display = 'flex'; f.style.opacity = 1;
  setTimeout(() => { f.style.transition = 'opacity 3.5s ease'; f.style.opacity = 0.0; }, 700);
  setTimeout(() => { f.style.display = 'none'; f.style.transition = ''; }, 4400);
}

export function wake(mode = 'campaign') {
  if (S.awake) return; S.awake = true;
  audio.start(); audio.setVolume(S.settings.volume); audio.setAmbience(S.settings.ambience);
  S.P = freshProgress(); S.P.mode = mode;
  if (mode === 'sandbox') {
    S.P.storyStep = 9; S.P.repair.power = 100; S.P.unlocks.build = true; S.P.unlocks.mast = true; S.P.unlocks.baffle = true;
    Object.assign(S.P.res, { salvage: 8, ore: 6, ice: 6, fuel: 0 }); // (v0.5: it used to drop MEALS and WATER, which read 'undefined')
    S.P.life.cabinC = 16; S.P.life.battery = 80;
    S.P.flags.buildHint = false;
  }
  beginWorld();
  spawnInterior(mode === 'sandbox' ? 'console' : 'bunk');
  hideTitle();
  $('reticle').style.opacity = 1;
  if (mode === 'sandbox') {
    say('SANDBOX. KESTREL-4, ADRIFT. NO STORY AND NO END. SURVIVE AS LONG AS YOU CAN.', { delay: 1200, hold: 20000 });
    say('CUT RESOURCES FROM THE FIELD (HOLD F OUTSIDE). BUILD ON THE HULL (B). SLEEP IN THE BUNK TO SAVE.', { delay: 4400, hold: 24000 });
    say('THREE THINGS ARE OUT HERE. EACH HAS ONE RULE. THE MISSION PAGE (M) LISTS WHAT YOU HAVE LEARNED.', { delay: 8400, hold: 24000 });
  } else {
    eyesOpen();
    say('KESTREL-4 SURVEY PROBE. CREW: 2. AWAKE: 1.', { delay: 1600, hold: 18000 });
    say('CABIN 6 C. MAIN POWER DOWN. EMERGENCY LIGHTING ONLY.', { delay: 4200, hold: 18000 });
    say('GET TO THE CONSOLE.', { delay: 7200, hold: 16000 });
  }
  unlockFragment(1, 'arrive');
  startSchedulers();
  emit('newGame', mode);
  doAutosave(true);
}

// resume from a loaded save (title CONTINUE or pause LOAD)
export function resumeLoaded() {
  if (!S.awake) { S.awake = true; audio.start(); audio.setVolume(S.settings.volume); audio.setAmbience(S.settings.ambience); hideTitle(); }
  S.ended = false; S.dying = false; S.sleeping = false;
  beginWorld();
  spawnInterior(S.P.storyStep <= 1 ? 'bunk' : 'console');
  flight.resume();
  $('reticle').style.opacity = 1;
  startSchedulers();
  say(S.P.flight ? `RESUMING. IN TRANSIT: ${S.P.flight.label || ''}.` : `RESUMING. ${S.P.place ? (S.P.place.name || 'HIP ' + S.P.place.hip) : 'SYSTEM ' + S.P.system}. DAY ${S.P.stats.sleeps + 1}.`, { delay: 600, hold: 10000 });
}

export async function arriveAt(n, info = null) {
  S.P.system = n;
  S.P.repair.thrusters = Math.min(S.P.repair.thrusters, 20);
  if (info) {
    // the course history the chart draws
    const fromName = S.P.place ? (S.P.place.name || 'HIP ' + S.P.place.hip) : S.P.legs.length ? S.P.legs[S.P.legs.length - 1].to : '4.00 LY TOWARD ALPHA CENTAURI';
    const toName = info.dest && info.dest.kind === 'star' ? (info.name || 'HIP ' + info.dest.hip) : n === 2 ? 'SIRIUS' : 'SYSTEM ' + n;
    S.P.legs.push({ from: fromName, to: toName, dist: info.dist, tau: info.tau, t: info.t, toP: [info.pos.x, info.pos.y, info.pos.z], note: info.slipped ? 'COURSE SET FOR SOL. HEADING HELD. ARRIVED AT SIRIUS.' : '' });
  }
  if (info && info.dest && info.dest.kind === 'star') {
    S.P.place = { hip: info.dest.hip, x: info.pos.x, y: info.pos.y, z: info.pos.z, name: info.name || '' };
    if (!S.P.visited.includes(info.dest.hip)) S.P.visited.push(info.dest.hip);
  } else if (info) S.P.place = null;
  beginWorld({ keepOrientation: !!info });
  spawnInterior('console');
  if (info) {
    // after the brake burn the ship faces back the way it came; the nav turns it to face the star while the screen is dark
    const tgt = starPos(info.hip != null ? info.hip : 32349);
    if (tgt) {
      const dir = tgt.clone().sub(info.pos);
      if (dir.lengthSq() > 1e-12) {
        // put the star a little left of and above the window's centre bar, not behind it
        const v = new THREE.Vector3(-Math.sin(0.16) * Math.cos(0.07), Math.sin(0.07), -Math.cos(0.16) * Math.cos(0.07));
        ship.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), dir.normalize()).multiply(new THREE.Quaternion().setFromUnitVectors(v, new THREE.Vector3(0, 0, -1)));
      }
    }
    const f = $('fader');
    if (f) { f.querySelector('div').textContent = 'DECELERATION COMPLETE'; f.style.transition = 'none'; f.style.display = 'flex'; f.style.opacity = 1;
      setTimeout(() => { f.style.transition = 'opacity 1.6s ease'; f.style.opacity = 0; setTimeout(() => { f.style.display = 'none'; f.style.transition = ''; }, 1700); }, 900); }
  }
  if (info) {
    emit('arrived', info);
    if (info.dest && info.dest.kind === 'star') {
      const hip = info.dest.hip, sp = starPos(hip);
      const d = sp ? sp.distanceTo(info.pos) : 0.08;
      say(`ARRIVED: ${starName(hip)}. ${starKind(hip)}. ${d.toFixed(2)} LIGHT YEARS OUT.`, { delay: 1200, hold: 20000 });
      const note = starNote(hip); if (note) say(note, { delay: 4200, hold: 26000 });
      say(`THE SUN IS ${info.pos.length().toFixed(2)} LIGHT YEARS AWAY. ON EARTH IT IS ${Math.floor(2026 + (S.P.stats.earthYears || 0))}.`, { delay: 9000, hold: 22000 });
      unlockFragment(2, 'starbow');
    }
    doAutosave(true); return;
  }
  await say(`JUMP COMPLETE  //  SYSTEM ${n}`, { delay: 600 });
  await say('THE JUMP BURNED THE THRUSTER DOWN TO 20%. ATTITUDE REFERENCE LOST.', { delay: 900 });
  await say('SIGHT THREE STARS TO COMPUTE A FIX.', { delay: 1400, hold: 26000 });
  say('A TRANSPONDER IS STILL CALLING ITSELF KESTREL-4. IT IS HERE TOO. NOTHING TOWED IT.', { delay: 6000, hold: 22000 });
  unlockFragment(n, 'arrive');
  if (S.P.repair.comms >= 40) setTimeout(() => unlockFragment(n, 'comms'), 9000); // the log for this system is readable at once
  doAutosave(true);
}
