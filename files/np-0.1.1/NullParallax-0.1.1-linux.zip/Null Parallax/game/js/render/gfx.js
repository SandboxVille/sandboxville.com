// The GRAPHICS setting in one place: which finish, whether the Milky Way is
// drawn, and the per-frame look inputs (the starlight fill outside, the fear
// the finish reacts to). main.js calls initGraphics once after the world is
// built, setGraphics when the setting changes, and updateGraphics every frame.
import * as THREE from 'three';
import { S } from '../core/state.js';
import { ship } from './scene.js';
import { shipFx } from './ship.js';
import { post, setGraphicsLevel, LEVELS } from './post.js';
import { buildMilkyWay, milky } from './sky.js';

export const gfx = { level: 'medium', mw: true };

export function setGraphics(level) {
  gfx.level = LEVELS[level] ? level : 'medium';
  gfx.mw = gfx.level !== 'low';
  setGraphicsLevel(gfx.level);
  return gfx.level;
}

export function initGraphics(level) {
  buildMilkyWay();
  setGraphics(level);
}

const _q = new THREE.Quaternion(), _d = new THREE.Vector3();
const SKY_COLD = new THREE.Color(0x2a3550), GROUND_COLD = new THREE.Color(0x050608);
const HEMI_SKY = new THREE.Color(0x303848), HEMI_GROUND = new THREE.Color(0x0a0806);
let brightest = -1, brightestSys = null;

// ctx: { camW, fear }
export function updateGraphics(dt, ctx) {
  // the Milky Way rides with the eye, and only where the ordinary sky is drawn
  if (milky.mesh) {
    milky.mesh.position.copy(ctx.camW);
    milky.mesh.visible = gfx.mw && !!(S.sys.group && S.sys.group.visible);
  }
  post.fear = ctx.fear || 0;
  // outside, a faint cold fill from the brightest star in this sky, so the hull
  // and the wreck read as shapes against the black (the hemisphere light's
  // "sky" is turned to face that star; no new light is added)
  const h = shipFx.hemi;
  if (!h) return;
  if (S.mode !== 'interior' && S.sys.meta && S.sys.dirs) {
    if (brightestSys !== S.sys.currentData) {
      brightestSys = S.sys.currentData; brightest = -1; let m = 99;
      S.sys.meta.forEach((x, i) => { if (x.type === 'star' && !x.dup && x.hip !== 0 && x.mag < m) { m = x.mag; brightest = i; } });
    }
    if (brightest >= 0) _d.copy(S.sys.dirs[brightest]); else _d.set(0, 1, 0);
    _q.copy(ship.quaternion).invert();
    _d.applyQuaternion(_q);
    h.position.copy(_d);
    h.color.copy(SKY_COLD); h.groundColor.copy(GROUND_COLD);
    h.intensity = S.P.flight ? 0 : 0.55;
  } else {
    h.position.set(0, 1, 0);
    h.color.copy(HEMI_SKY); h.groundColor.copy(HEMI_GROUND);
  }
}
