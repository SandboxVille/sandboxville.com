// The pause menu. Tabs: MISSION (who you are, what the point is, what you
// have learned about the things out here), SHIP (the console: refine, send
// the signal, upgrades, jump, endings), JOURNAL, SAVE / LOAD, SETTINGS,
// CONTROLS, HOW TO PLAY (W0: ui/howto.js holds its text), QUIT. Mouse, keyboard and gamepad all work: the d-pad or arrow
// keys move between controls, A / Enter activates, B / Esc goes back.
import { JOURNAL, fragmentById, fragmentText, garble } from './journal-data.js';
import { slotSummary, storageAvailable, readSlot } from './save.js';
import { renderHowto, PAGES as HOWTO_PAGES } from './ui/howto.js';

const TABS = ['resume', 'mission', 'ship', 'chart', 'journal', 'save', 'settings', 'controls', 'howto', 'quit'];
const LABELS = { resume: 'RESUME', mission: 'MISSION', ship: 'SHIP', chart: 'CHART', journal: 'JOURNAL', save: 'SAVE / LOAD', settings: 'SETTINGS', controls: 'CONTROLS', howto: 'HOW TO PLAY', quit: 'QUIT' };

function bar(v) { const n = Math.round(Math.max(0, Math.min(100, v)) / 10); return '[' + '#'.repeat(n) + '.'.repeat(10 - n) + ']'; }
const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));

export function createPauseMenu(ctx) {
  const $ = id => document.getElementById(id);
  const root = $('pause'), tabsEl = $('pauseTabs'), bodyEl = $('pauseBody');
  let active = 'mission', open = false, journalTimer = null, journalOpenedAt = 0, listening = null, focusIdx = 0, confirmQuit = false, howtoPage = 0;

  // ---- key rebinding (keyboard only) ----
  function rebindKeyHandler(e) {
    if (!listening) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase();
    e.preventDefault(); e.stopPropagation();
    if (k === 'escape') { listening = null; render(); return; }
    const reserved = ['w', 'a', 's', 'd', 'q', 'e', ' ', 'shift', 'control', 'c', 'v', 'x', 'g', 'z', 'j', 'm', 'n', 'p', 'tab', 'enter', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    if (reserved.includes(k)) { flashMsg(`"${k.toUpperCase()}" IS ALREADY USED BY MOVEMENT OR ANOTHER ACTION`); return; }
    const kb = { ...ctx.getSettings().keybinds };
    if (Object.entries(kb).some(([a, v]) => v === k && a !== listening)) { flashMsg('THAT KEY IS BOUND TO ANOTHER ACTION'); return; }
    kb[listening] = k; ctx.setSettings({ keybinds: kb }); listening = null; render();
  }
  addEventListener('keydown', rebindKeyHandler, true);
  let msgT = null;
  function flashMsg(t) { const m = $('pauseMsg'); if (!m) return; m.textContent = t; clearTimeout(msgT); msgT = setTimeout(() => { m.textContent = ''; }, 3000); }

  function setActive(tab) {
    active = tab; confirmQuit = false;
    if (tab === 'journal') { journalOpenedAt = Date.now(); if (!journalTimer) journalTimer = setInterval(() => { if (active === 'journal') render(true); }, 1000); }
    else stopJournalTimer();
    render(); focusIdx = 0; focusFirstBody();
  }
  function stopJournalTimer() { if (journalTimer) { clearInterval(journalTimer); journalTimer = null; } }

  tabsEl.innerHTML = TABS.map(t => `<button data-tab="${t}">${LABELS[t]}</button>`).join('');
  tabsEl.querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
    if (b.dataset.tab === 'resume') { close(); return; }
    setActive(b.dataset.tab);
  }));

  // ---------------- tab bodies ----------------
  function renderMission() {
    const m = ctx.getMission();
    const threats = m.threats.map(t => `<div class="threat${t.learned ? '' : ' unknown'}"><b>${t.learned ? esc(t.name) : '???'}</b><div>${t.learned ? esc(t.rule) : esc(t.hint)}</div></div>`).join('');
    // W0: FIRST SHIFT, the sandbox checklist (optional)
    const fs = m.firstShift ? `<h3>FIRST SHIFT <span class="dim">(OPTIONAL. A FIRST DAY OUT HERE)</span></h3>${m.firstShift.map((it, i) => `<div class="fsItem${it.done ? ' done' : ''}">${it.done ? '[X]' : '[ ]'} ${i + 1}. ${esc(it.text)}</div>`).join('')}` : '';
    bodyEl.innerHTML = `${fs}
      <h3>WHO YOU ARE</h3><p>${esc(m.who)}</p>
      <h3>WHAT HAPPENED</h3><p>${esc(m.what)}</p>
      <h3>WHAT TO DO NOW</h3><p class="goal">${esc(m.now)}</p>
      <h3>THE POINT</h3><p>${esc(m.point)}</p>
      <h3>FIELD NOTES: THINGS OUT HERE</h3><p class="dim">Each one has a rule. You learn the rule by surviving it.</p>${threats}
      <h3>SURVIVAL</h3><p class="dim">${esc(m.survival)}</p>
      ${m.discoveries && m.discoveries.length ? `<h3>DISCOVERY LOG <span class="dim">(${m.discoveries.length} WORLDS. AT THE HELM, K NAMES ONE)</span></h3>${m.discoveries.map(d => `<div class="fsItem"><b>${esc(d.given)}</b> <span class="dim">${esc(d.name)}${d.landed ? ' // LANDED' : ''}</span><br><small class="dim">${esc(d.scan)}</small></div>`).join('')}` : ''}`;
  }
  function renderShip() {
    const r = ctx.getRepair(); const up = r.upgrades; const R = r.res;
    const powerOk = r.power >= 100;
    const upgradeRow = (key, label, cost, what) => `
      <div class="slotRow"><span>${up[key] ? '[X]' : '[ ]'} ${label} -- ${cost} SALVAGE<br><small class="dim">${what}</small></span>
      <button class="pbtn" data-buy="${key}" ${up[key] || !powerOk || R.salvage < cost ? 'disabled' : ''}>${up[key] ? 'OWNED' : 'BUY'}</button></div>`;
    const g = ctx.getShipStatus();
    bodyEl.innerHTML = `
      <h3>SHIP -- SYSTEM ${r.system}${r.mode === 'eva' ? ' (REMOTE LINK)' : ''}</h3>
      <div class="slotRow"><span>POWER &nbsp;&nbsp; ${bar(r.power)} ${Math.round(r.power)}%</span><span class="dim">panel, port side</span></div>
      <div class="slotRow"><span>COMMS &nbsp;&nbsp; ${bar(r.comms)} ${Math.round(r.comms)}%</span><span class="dim">antenna, top</span></div>
      <div class="slotRow"><span>THRUSTER ${bar(r.thrusters)} ${Math.round(r.thrusters)}%</span><span class="dim">engine, aft</span></div>
      <p class="dim">Repairs happen outside, by hand: fly to the part, hold F. They cost salvage and ore.</p>
      <p>SALVAGE ${R.salvage} &nbsp; ORE ${R.ore} &nbsp; ICE ${R.ice} &nbsp; FUEL ${R.fuel}</p>
      <p class="dim">POWER ${g.level.toUpperCase()} &nbsp; MAKES ${g.gen.toFixed(1)} / USES ${g.use.toFixed(1)} &nbsp; BATTERY ${Math.round(g.battery)}% &nbsp; CABIN ${g.cabinC.toFixed(0)} C &nbsp; AIR ${Math.round(g.shipO2)}%</p>
      <div class="rowBtns">
        <button class="pbtn" id="btnRefine" ${powerOk && R.ice >= 2 ? '' : 'disabled'}>REFINE 2 ICE INTO 1 FUEL</button>
        <button class="pbtn" id="btnSignal" ${r.comms >= 100 ? '' : 'disabled'}>SEND THE SIGNAL HOME${r.signalSent ? ' AGAIN' : ''}</button>
        <button class="pbtn" id="btnDark">${g.goDark ? 'RESTORE SHIP POWER' : 'GO DARK (ALL SYSTEMS OFF)'}</button>
      </div>
      <p class="dim">Sending the signal is the loudest thing you can do. Going dark makes the ship silent, and dark.</p>
      <h3>SCANNER UPGRADES ${powerOk ? '' : '(NEED MAIN POWER)'}</h3>
      ${upgradeRow('wideCone', 'WIDE CONE', 6, 'Easier to sight stars.')}
      ${upgradeRow('deepRange', 'DEEP RANGE', 6, 'See and sight fainter stars.')}
      ${upgradeRow('zoom5', '5TH ZOOM TIER', 6, 'Zoom much further.')}
      ${upgradeRow('dreadPing', 'DREAD PING', 4, 'A soft tone warns you before the sky does something.')}
      <h3>LEAVE</h3>
      ${r.here ? `<p class="dim">HERE: on the line toward ${esc(r.here.name)}, a real star ${r.here.distLy.toFixed(1)} light years from the Sun.${r.next ? ` NEXT JUMP: toward ${esc(r.next.name)}, ${r.next.distLy < 100 ? r.next.distLy.toFixed(1) : Math.round(r.next.distLy).toLocaleString('en-US')} light years from the Sun. ${r.next.distLy < 100 ? `Its light takes ${r.next.distLy.toFixed(1)} years to reach Earth.` : `The light you see from it left around the year ${Math.round(2026 - r.next.distLy)}.`}` : ''}</p>` : ''}
      <div class="rowBtns">
      ${r.flying ? `<button class="pbtn" id="btnJump">BACK TO THE HELM</button><span class="dim">the ship is under way</span>`
        : r.sandbox ? `<button class="pbtn" id="btnJump" ${r.canJump ? '' : 'disabled'}>TAKE THE HELM (PICK A STAR ON THE CHART)</button><span class="dim">needs THRUSTER 50%+ and FUEL</span>`
        : r.system === 1 ? `<button class="pbtn" id="btnJump" ${r.canJump ? '' : 'disabled'}>TAKE THE HELM${r.storyStep < 10 ? ' (ENDS CHAPTER 1)' : ''}</button><span class="dim">needs THRUSTER 50%+ and ${r.jumpFuelCost} FUEL. You fly it yourself.</span>`
        : r.system < 3 ? `<button class="pbtn" id="btnJump" ${r.canJump ? '' : 'disabled'}>JUMP TO THE NEXT SYSTEM</button><span class="dim">needs THRUSTER 50%+ and ${r.jumpFuelCost} FUEL. The drive cannot cross 1,300 light years. The console offers to jump anyway.</span>` : ''}
      ${r.system === 3 ? `<button class="pbtn" id="btnResolve" ${r.canResolve ? '' : 'disabled'}>HOLD AND FACE IT -- RESOLVE</button>` : ''}
      ${r.system === 3 ? `<button class="pbtn" id="btnRun" ${r.canJump ? '' : 'disabled'}>JUMP AND LEAVE -- RUN</button>` : ''}
      ${r.system === 3 && r.canCollapse ? `<button class="pbtn" id="btnCollapse">HOLD THE MEASUREMENT -- COLLAPSE</button>` : ''}
      </div>`;
    bodyEl.querySelectorAll('[data-buy]').forEach(b => b.addEventListener('click', () => { ctx.buyUpgrade(b.dataset.buy); render(); }));
    const on = (id, fn) => { const b = $(id); if (b) b.addEventListener('click', fn); };
    on('btnRefine', () => { ctx.refineFuel(); render(); });
    on('btnSignal', () => { ctx.sendSignal(); close(); });
    on('btnDark', () => { ctx.toggleDark(); render(); });
    on('btnJump', () => { ctx.doJump(); close(); });
    on('btnResolve', () => { ctx.doResolve(); close(); });
    on('btnRun', () => { ctx.doJump(); close(); });
    on('btnCollapse', () => { ctx.doCollapse(); close(); });
  }
  // ---- P3: THE CHART ----
  let chartDrag = null;
  function renderChart() {
    const d = ctx.getChart(); const v = ctx.chartView;
    if (v.sel === null && d.rows.length) v.sel = d.rows[0].hip;
    const sel = d.rows.find(r => r.hip === v.sel) || null;
    const fmtD = x => x < 10 ? x.toFixed(2) : x.toFixed(1);
    const row = r => `<button class="pbtn star${r.hip === v.sel ? ' on' : ''}${d.sandbox && !r.reach ? ' far' : ''}" data-star="${r.hip}">${esc(r.hip === 0 ? 'SOL' : r.name)} <span class="dim">${fmtD(r.d)} LY${r.visited ? ' // VISITED' : ''}</span></button>`;
    let plot = '';
    if (sel) {
      if (d.flying) plot = '<p class="dim">THE SHIP IS UNDER WAY.</p>';
      else if (!d.sandbox) plot = '<p class="dim">COURSES ARE SET AT THE HELM. THE NAV COMPUTER HOLDS ONE COURSE ON FILE.</p>';
      else if (sel.hip === 0) plot = '<p class="warn">NO COURSE TO THE SUN WILL HOLD. THE NAV COMPUTER WILL NOT SAY WHY.</p>';
      else if (d.thrusters < 50) plot = '<p class="dim">THE THRUSTER NEEDS 50% (REPAIR IT OUTSIDE).</p>';
      else if (d.fuel < 1) plot = '<p class="dim">NO FUEL. REFINE ICE AT THE CONSOLE (SHIP > REFINE).</p>';
      else if (!sel.reach) plot = `<p class="warn">OUT OF REACH WITH ${d.fuel} FUEL: THE SHIP WOULD RUN OUT OF SUPPLIES ON THE WAY. MORE FUEL MEANS A FASTER TRIP.</p>`;
      else plot = `<button class="pbtn" id="btnPlot">PLOT A COURSE AND TAKE THE HELM</button>`;
    }
    const est = sel && sel.est ? `<div>AT FULL BURN WITH ${d.fuel} FUEL: TOP SPEED ${(sel.est.beta * 100).toFixed(1)}% C. SHIP ${sel.est.tau * 365.25 < 700 ? Math.round(sel.est.tau * 365.25) + ' DAYS' : sel.est.tau.toFixed(1) + ' YEARS'}, EARTH ${sel.est.t.toFixed(1)} YEARS.</div>` : '';
    bodyEl.innerHTML = `<h3>THE CHART <span class="dim">REAL STARS WITHIN 25 LIGHT YEARS OF THE SHIP</span></h3>
      <div class="chartWrap"><canvas id="chartCanvas" width="560" height="340"></canvas>
      <div id="chartInfo">${sel ? `<h4>${esc(sel.hip === 0 ? 'SOL, THE SUN' : sel.name)}</h4>
        <div class="dim">${esc(sel.kind)}${sel.hip ? `  //  HIP ${sel.hip}` : ''}</div>
        <div>${fmtD(sel.d)} LIGHT YEARS FROM YOU. ${sel.hip === 0 ? '' : `${fmtD(sel.fromSol)} FROM THE SUN.`}</div>
        <div>${esc(ctx.lightLines(sel))}</div>${est}
        ${sel.note ? `<p>${esc(sel.note)}</p>` : ''}${plot}` : '<p class="dim">No catalogued star within 25 light years.</p>'}</div></div>
      <div class="chartList">${d.rows.slice(0, 48).map(row).join('')}</div>
      <h3>COURSE HISTORY</h3>${d.history.map(h => `<div class="${h.odd ? 'warn' : ''}">${esc(h.text)}</div>`).join('')}
      <p class="dim">${esc(d.missing)}</p>
      <p class="dim small">DRAG THE CHART TO TURN IT. WHEEL ZOOMS. SOURCE: ${esc(d.source)}</p>`;
    const cv = $('chartCanvas');
    const draw = () => ctx.drawChart(cv, d);
    draw();
    cv.addEventListener('pointerdown', e => { chartDrag = { x: e.clientX, y: e.clientY }; try { cv.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } });
    cv.addEventListener('pointermove', e => { if (!chartDrag) return; v.yaw += (e.clientX - chartDrag.x) * 0.01; v.pitch = Math.max(-1.4, Math.min(1.4, v.pitch + (e.clientY - chartDrag.y) * 0.01)); chartDrag = { x: e.clientX, y: e.clientY }; draw(); });
    cv.addEventListener('pointerup', () => { chartDrag = null; });
    cv.addEventListener('wheel', e => { v.zoom = Math.max(0.5, Math.min(4, v.zoom * (e.deltaY < 0 ? 1.15 : 0.87))); draw(); e.preventDefault(); }, { passive: false });
    bodyEl.querySelectorAll('[data-star]').forEach(b => b.addEventListener('click', () => { v.sel = Number(b.dataset.star); const keep = b.dataset.star; render(true); const again = bodyEl.querySelector(`[data-star="${keep}"]`); if (again) again.focus(); }));
    const pb = $('btnPlot'); if (pb) pb.addEventListener('click', () => { if (ctx.plotCourse(v.sel)) close(); else render(); });
  }
  function renderJournal() {
    const ids = ctx.getJournalIds(); const comms = ctx.getCommsRepair();
    if (!ids.length) { bodyEl.innerHTML = `<h3>JOURNAL</h3><p class="dim">No fragments recovered yet.</p>`; return; }
    const stats = Object.assign({}, ctx.getLiveStats(), { openSeconds: Math.floor((Date.now() - journalOpenedAt) / 1000) });
    const rows = ids.slice().reverse().map(id => {
      const f = fragmentById(id); if (!f) return '';
      const raw = fragmentText(f, stats);
      return `<div class="frag">${esc(comms >= 60 ? raw : garble(raw, id))}</div>`;
    }).join('');
    bodyEl.innerHTML = `<h3>JOURNAL &nbsp;(${ids.length}/${JOURNAL.length})</h3>${rows}` + (comms < 60 ? '<p class="dim">The antenna is broken: some words are unreadable until COMMS is repaired.</p>' : '');
  }
  function renderSave() {
    if (!storageAvailable()) { bodyEl.innerHTML = `<h3>SAVE / LOAD</h3><p class="dim">SAVE UNAVAILABLE: this browser is blocking local storage. Progress lasts this session only.</p>`; return; }
    const row = n => {
      const sum = slotSummary(n);
      const txt = sum ? esc(sum.text) : 'empty';
      return `<div class="slotRow"><span class="${sum && sum.damaged ? 'warn' : 'dim'}">SLOT ${n}: ${txt}</span>
        <span><button class="pbtn" data-save="${n}" ${ctx.canSave() ? '' : 'disabled'}>SAVE</button><button class="pbtn" data-load="${n}" ${sum && !sum.damaged ? '' : 'disabled'}>LOAD</button></span></div>`;
    };
    const autoSum = slotSummary('auto');
    bodyEl.innerHTML = `<h3>SAVE / LOAD</h3>${[1, 2, 3].map(row).join('')}
      <div class="slotRow"><span class="${autoSum && autoSum.damaged ? 'warn' : 'dim'}">AUTOSAVE: ${autoSum ? esc(autoSum.text) : 'empty'}</span>
      <button class="pbtn" data-load="auto" ${autoSum && !autoSum.damaged ? '' : 'disabled'}>LOAD</button></div>
      <p class="dim">The game autosaves at the airlock, after every repair and build, and when you sleep in the bunk. A damaged save is kept aside, never loaded, and never breaks the game.${ctx.canSave() ? '' : (ctx.saveBlockReason ? ' ' + ctx.saveBlockReason() : ' You cannot save while something is hunting you.')}</p>`;
    bodyEl.querySelectorAll('[data-save]').forEach(b => b.addEventListener('click', () => { const ok = ctx.saveSlot(Number(b.dataset.save)); flashMsg(ok ? 'SAVED' : 'SAVE FAILED (STORAGE FULL OR BLOCKED)'); render(); }));
    bodyEl.querySelectorAll('[data-load]').forEach(b => b.addEventListener('click', () => {
      const slot = b.dataset.load === 'auto' ? 'auto' : Number(b.dataset.load);
      const r = readSlot(slot);
      if (r.status !== 'ok') { flashMsg('THAT SAVE IS DAMAGED AND CANNOT BE LOADED'); render(); return; }
      ctx.loadSlot(slot, r.data); close();
    }));
  }
  function renderSettings() {
    const s = ctx.getSettings(); const kb = s.keybinds;
    const range = (id, label, min, max, val, fmt) => `<div class="row"><span>${label} &nbsp;<b>${fmt(val)}</b></span><input type="range" id="${id}" min="${min}" max="${max}" value="${val}"></div>`;
    const tog = (id, label, on, a = 'ON', b = 'OFF') => `<div class="slotRow"><span>${label}</span><button class="pbtn" id="${id}">${on ? a : b}</button></div>`;
    const rebind = (action, label) => `<div class="slotRow"><span>${label}: <b>${String(kb[action]).toUpperCase()}</b></span><button class="pbtn" data-rebind="${action}">${listening === action ? 'PRESS A KEY...' : 'REBIND'}</button></div>`;
    bodyEl.innerHTML = `
      <h3>CONTROLS</h3>
      ${range('sSens', 'MOUSE SENSITIVITY', 20, 400, Math.round(s.sensitivity * 100), v => v + '%')}
      ${range('sPad', 'GAMEPAD LOOK SPEED', 30, 300, Math.round(s.padLook * 100), v => v + '%')}
      ${tog('sInv', 'INVERT LOOK Y', s.invertY)}
      ${range('sFov', 'FIELD OF VIEW', 55, 100, Math.round(s.fov), v => v + ' DEG')}
      ${tog('sBob', 'HEAD BOB', s.headBob)}
      <h3>SOUND</h3>
      ${range('sVol', 'MASTER VOLUME', 0, 100, Math.round(s.volume * 100), v => v + '%')}
      ${range('sAmb', 'AMBIENCE (HUM, DRONES)', 0, 150, Math.round(s.ambience * 100), v => v + '%')}
      ${tog('sSubs', 'SUBTITLES FOR SOUNDS', s.subtitles)}
      <h3>GRAPHICS</h3>
      <div class="slotRow"><span>GRAPHICS <span class="dim">(low = fastest; medium = glow, grain and grade; high = sharper, stronger glow)</span></span><span>${['low', 'medium', 'high'].map(q => `<button class="pbtn${s.quality === q ? ' on' : ''}" data-q="${q}">${q.toUpperCase()}</button>`).join('')}</span></div>
      <div class="slotRow"><span>VIEW <span class="dim">(key O; the shoulder view snaps back to the helmet when something is hunting you)</span></span><span>${['helmet', 'shoulder'].map(q => `<button class="pbtn${(s.view || 'helmet') === q ? ' on' : ''}" data-v="${q}">${q.toUpperCase()}</button>`).join('')}</span></div>
      <h3>GAME</h3>
      <div class="slotRow"><span>DIFFICULTY <span class="dim">(story halves every drain)</span></span><span>${['story', 'survival'].map(q => `<button class="pbtn${s.difficulty === q ? ' on' : ''}" data-d="${q}">${q.toUpperCase()}</button>`).join('')}</span></div>
      <h3>KEYS</h3>
      ${rebind('interact', 'USE / HOLD TO CUT OR REPAIR')}${rebind('build', 'BUILD MODE')}${rebind('lamp', 'HELMET LAMP')}${rebind('cut', 'TETHER (UNCLIP / CLIP ON AT THE HATCH)')}${rebind('console', 'OPEN SHIP CONSOLE')}
      <p class="dim">Settings save automatically and apply right away.</p>`;
    const inp = (id, fn) => { const e = $(id); if (e) e.addEventListener('input', ev => { fn(+ev.target.value); const lab = e.previousElementSibling.querySelector('b'); if (lab) lab.textContent = e.previousElementSibling.textContent.includes('DEG') ? ev.target.value + ' DEG' : ev.target.value + '%'; }); };
    inp('sSens', v => ctx.setSettings({ sensitivity: v / 100 }));
    inp('sPad', v => ctx.setSettings({ padLook: v / 100 }));
    inp('sFov', v => ctx.setSettings({ fov: v }));
    inp('sVol', v => ctx.setSettings({ volume: v / 100 }));
    inp('sAmb', v => ctx.setSettings({ ambience: v / 100 }));
    const click = (id, fn) => { const e = $(id); if (e) e.addEventListener('click', () => { fn(); render(); }); };
    click('sInv', () => ctx.setSettings({ invertY: !s.invertY }));
    click('sBob', () => ctx.setSettings({ headBob: !s.headBob }));
    click('sSubs', () => ctx.setSettings({ subtitles: !s.subtitles }));
    bodyEl.querySelectorAll('[data-q]').forEach(b => b.addEventListener('click', () => { ctx.setSettings({ quality: b.dataset.q }); render(); }));
    bodyEl.querySelectorAll('[data-v]').forEach(b => b.addEventListener('click', () => { ctx.setSettings({ view: b.dataset.v }); render(); }));
    bodyEl.querySelectorAll('[data-d]').forEach(b => b.addEventListener('click', () => { ctx.setSettings({ difficulty: b.dataset.d }); render(); }));
    bodyEl.querySelectorAll('[data-rebind]').forEach(b => b.addEventListener('click', () => { listening = b.dataset.rebind; render(); }));
  }
  function renderControls() {
    bodyEl.innerHTML = `
      <h3>KEYBOARD + MOUSE</h3>
      <p><b>walk / fly</b>: W A S D &nbsp; <b>look</b>: mouse (click the game to capture it) or arrow keys<br>
      <b>run (inside)</b>: Shift &nbsp; <b>boost (outside)</b>: Shift<br>
      <b>up / down (outside)</b>: Space / C &nbsp; <b>roll</b>: Q / E &nbsp; <b>dampers on/off</b>: V<br>
      <b>use / hold to cut or repair</b>: F &nbsp; <b>sight a star</b>: left click &nbsp; <b>zoom</b>: hold right mouse, wheel<br>
      <b>build mode</b>: B (outside) &nbsp; <b>pick part</b>: 1-9 / wheel &nbsp; <b>take back</b>: G<br>
      <b>helmet lamp</b>: L &nbsp; <b>scan for resources</b>: Tab &nbsp; <b>tether</b>: T (unclip; at the hatch, clip back on)<br>
      <b>go dark (ship silent)</b>: X &nbsp; <b>journal</b>: J &nbsp; <b>mission</b>: M &nbsp; <b>the chart</b>: N &nbsp; <b>menu</b>: Esc</p>
      <h3>AT THE HELM (THE LEFT CHAIR AT THE CONSOLE)</h3>
      <p><b>turn the ship</b>: mouse, A / D, arrow keys &nbsp; <b>roll</b>: Q / E &nbsp; <b>align with the marker</b>: hold Space<br>
      <b>gas (hold to burn)</b>: W (or Shift) &nbsp; <b>brake (hold: turns tail first, then burns)</b>: S (or C) &nbsp; <b>cut the drive and go silent</b>: X &nbsp; <b>pick a course</b>: 1 / 2 &nbsp; <b>stand up</b>: F<br>
      gamepad: sticks turn, RT gas, LT brake (both analog), hold A to align, X stands, Back goes dark. Touch: pad turns, UP aligns, BST gas, DN brake.</p>
      <h3>INSIDE THE OTHER SHIP</h3>
      <p>mag boots: walk with W A S D, look with the mouse, F to look closer, hold F to read, F at the break or the broken window to leave.</p>
      <p class="dim">New to this? HOW TO PLAY (the next tab) explains each part in plain words.</p>
      <h3>GAMEPAD</h3>
      <p><b>move</b>: left stick &nbsp; <b>look</b>: right stick &nbsp; <b>up / down</b>: RT / LT &nbsp; <b>roll</b>: LB / RB<br>
      <b>use / hold to cut or repair</b>: X &nbsp; <b>sight / build</b>: A &nbsp; <b>build mode</b>: Y &nbsp; <b>back / tether</b>: B (twice)<br>
      <b>lamp</b>: d-pad up &nbsp; <b>scan</b>: d-pad down &nbsp; <b>pick part</b>: d-pad left/right &nbsp; <b>boost</b>: L3 &nbsp; <b>dampers</b>: R3<br>
      <b>go dark</b>: Back / View &nbsp; <b>menu</b>: Start</p>
      <h3>TOUCH</h3><p>left pad moves, drag anywhere to look, tap to sight; buttons on the right.</p>`;
  }
  // W0: HOW TO PLAY. The text lives in ui/howto.js; this only draws it and remembers the page.
  function renderHowtoTab() {
    bodyEl.innerHTML = renderHowto(howtoPage, ctx.getHowto ? ctx.getHowto() : { flags: {}, tetherKey: 'T', pad: false });
    bodyEl.querySelectorAll('[data-howto]').forEach(b => b.addEventListener('click', () => {
      howtoPage = Math.max(0, Math.min(HOWTO_PAGES.length - 1, Number(b.dataset.howto)));
      render(); const again = bodyEl.querySelector(`[data-howto="${howtoPage}"]`); if (again) again.focus();
    }));
  }
  function renderQuit() {
    bodyEl.innerHTML = `<h3>QUIT TO TITLE</h3><p>Progress since the last save is lost. The autosave is usually recent (airlock, repairs, builds, sleep).</p>
      <div class="rowBtns"><button class="pbtn" id="btnQuitYes">QUIT TO TITLE</button><button class="pbtn" id="btnQuitNo">STAY</button></div>`;
    $('btnQuitYes').addEventListener('click', () => ctx.onQuit());
    $('btnQuitNo').addEventListener('click', () => setActive('mission'));
  }

  function render(soft) {
    tabsEl.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.tab === active));
    const scroll = bodyEl.scrollTop;
    if (active === 'mission') renderMission();
    else if (active === 'ship') renderShip();
    else if (active === 'chart') renderChart();
    else if (active === 'journal') renderJournal();
    else if (active === 'save') renderSave();
    else if (active === 'settings') renderSettings();
    else if (active === 'controls') renderControls();
    else if (active === 'howto') renderHowtoTab();
    else if (active === 'quit') renderQuit();
    if (soft) bodyEl.scrollTop = scroll;
  }

  // ---- gamepad / keyboard navigation inside the menu ----
  function focusables() { return [...root.querySelectorAll('button:not([disabled]), input[type=range]')]; }
  function focusFirstBody() { const f = focusables(); const i = f.findIndex(e => bodyEl.contains(e)); focusIdx = i >= 0 ? i : 0; if (f[focusIdx]) f[focusIdx].focus({ preventScroll: active === 'chart' }); if (active === 'chart') bodyEl.scrollTop = 0; }
  function moveFocus(d) { const f = focusables(); if (!f.length) return; const cur = f.indexOf(document.activeElement); focusIdx = ((cur < 0 ? 0 : cur + d) + f.length) % f.length; f[focusIdx].focus(); }
  function adjust(d) {
    const el = document.activeElement;
    if (el && el.type === 'range') { el.value = +el.value + d * Math.max(1, Math.round((el.max - el.min) / 40)); el.dispatchEvent(new Event('input')); return true; }
    return false;
  }
  function tabStep(d) { const i = TABS.indexOf(active); let n = (i + d + TABS.length) % TABS.length; if (TABS[n] === 'resume') n = (n + d + TABS.length) % TABS.length; setActive(TABS[n]); }
  addEventListener('keydown', e => {
    if (!open || listening) return;
    if (e.key === 'ArrowDown') { moveFocus(1); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { moveFocus(-1); e.preventDefault(); }
    else if (e.key === 'ArrowLeft') { if (!adjust(-1)) tabStep(-1); e.preventDefault(); }
    else if (e.key === 'ArrowRight') { if (!adjust(1)) tabStep(1); e.preventDefault(); }
  });
  const padPrev = {};
  function pollPad() {
    if (!open) return;
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (const p of pads) {
      if (!p) continue;
      const pr = i => !!(p.buttons[i] && p.buttons[i].pressed);
      const edge = i => { const k = p.index + ':' + i, n = pr(i), w = padPrev[k]; padPrev[k] = n; return n && !w; };
      if (edge(13)) moveFocus(1);
      if (edge(12)) moveFocus(-1);
      if (edge(14)) { if (!adjust(-1)) tabStep(-1); }
      if (edge(15)) { if (!adjust(1)) tabStep(1); }
      if (edge(4)) tabStep(-1);
      if (edge(5)) tabStep(1);
      if (edge(0)) { const el = document.activeElement; if (el && el.tagName === 'BUTTON' && root.contains(el)) el.click(); }
      if (edge(1)) close();
      edge(9);
    }
  }
  setInterval(pollPad, 50);

  function openMenu(tab) {
    if (open) { setActive(tab || active); return; }
    open = true; root.classList.add('open'); setActive(tab || 'mission'); ctx.onOpen && ctx.onOpen();
  }
  function close() { if (!open) return; open = false; listening = null; root.classList.remove('open'); stopJournalTimer(); ctx.onResume(); }
  $('pauseCloseBtn').addEventListener('click', close);

  return {
    toggle() { open ? close() : openMenu('mission'); },
    isOpen: () => open,
    close, open: openMenu,
    refresh: () => { if (open) render(true); },
  };
}
