// Everything outside the hull that is not the sky: the salvage field, the
// derelict (a second KESTREL-4), the boundary shell at the edge of the
// measurable space, and the visual bodies of the threats. All positions are
// in the ship frame (metres) unless noted.
import * as THREE from 'three';
import { scene, ship } from './scene.js';
import { mulberry32, randomDir } from '../core/utils.js';
import { rockTex, stencil, hullPlate, glowSprite, hullSet } from './textures.js';
import { bakeRoot } from './bake.js';
import { BOUNDARY_R } from '../core/constants.js';

export const SHIP_CENTER = new THREE.Vector3(0, 1.1, -3.5);
export const DERELICT_POS = new THREE.Vector3(150, -38, -205);

// ---------------- salvage field ----------------
export const field = { chunks: [], meshes: {}, group: null, system: 0 };

function lumpyGeo(seed, detail = 1, amt = 0.28) {
  const geo = new THREE.IcosahedronGeometry(1, detail);
  const p = geo.attributes.position, rnd = mulberry32(seed);
  const offs = new Map();
  for (let i = 0; i < p.count; i++) {
    const key = `${p.getX(i).toFixed(3)},${p.getY(i).toFixed(3)},${p.getZ(i).toFixed(3)}`;
    if (!offs.has(key)) offs.set(key, 1 - amt / 2 + rnd() * amt);
    const k = offs.get(key);
    p.setXYZ(i, p.getX(i) * k, p.getY(i) * k * 0.85, p.getZ(i) * k);
  }
  geo.computeVertexNormals();
  return geo;
}
function plateGeo() {
  const g = new THREE.BoxGeometry(1.8, 0.14, 1.1, 3, 1, 2);
  const p = g.attributes.position, rnd = mulberry32(77);
  for (let i = 0; i < p.count; i++) p.setY(i, p.getY(i) + (rnd() - 0.5) * 0.12 + Math.abs(p.getX(i)) * 0.08);
  g.computeVertexNormals();
  return g;
}

const TYPES = {
  salvage: { hp: 1.3, yield: [1, 2] },
  ore: { hp: 1.8, yield: [1, 2] },
  ice: { hp: 1.5, yield: [1, 2] },
};

// cluster layout per system: [center, radius, {type: count}]
function layoutFor(system) {
  const L = [
    [new THREE.Vector3(24, 1, 9), 8, { salvage: 9, ore: 4 }],       // the near wreck field (tutorial)
    [new THREE.Vector3(-34, -12, -42), 13, { ice: 12, ore: 3 }],    // ice drift, port side
    [new THREE.Vector3(38, 26, -78), 11, { ore: 10, salvage: 3 }],  // ore cluster, high and ahead
    [DERELICT_POS.clone().add(new THREE.Vector3(-18, 6, 22)), 16, { salvage: 8, ice: 3 }], // debris trail from the derelict
    [new THREE.Vector3(-90, 40, 60), 16, { ice: 6, ore: 6, salvage: 2 }],
  ];
  if (system === 2) L.push([new THREE.Vector3(120, -60, 120), 20, { ore: 10, ice: 6, salvage: 6 }]);
  if (system === 3) L.push([new THREE.Vector3(-150, 80, -160), 24, { salvage: 12, ore: 6 }]);
  return L;
}

export function buildField(system, harvested) {
  disposeField();
  // P3: a sandbox place is 'p<HIP>': its own field, seeded by the star
  const seedN = typeof system === 'number' ? system : 7 + (parseInt(String(system).slice(1), 10) || 0);
  const rnd = mulberry32(4242 + seedN * 131);
  field.system = system;
  field.group = new THREE.Group(); ship.add(field.group);
  const chunks = [];
  let id = 0;
  const add = (type, pos) => {
    const t = TYPES[type];
    const size = type === 'salvage' ? 0.8 + rnd() * 0.9 : 0.6 + rnd() * 1.1;
    const maxHp = t.hp * (0.8 + size * 0.5);
    const key = system + ':' + id;
    const left = harvested && key in harvested ? harvested[key] : maxHp;
    chunks.push({
      id: id++, key, type, pos, size, radius: size * 1.05, maxHp, hp: left,
      axis: randomDir(rnd), spin: (rnd() - 0.5) * 0.25, rot: new THREE.Quaternion().setFromAxisAngle(randomDir(rnd), rnd() * 6.28),
      scale: new THREE.Vector3(size * (0.8 + rnd() * 0.5), size * (0.7 + rnd() * 0.4), size * (0.8 + rnd() * 0.5)),
      yieldN: t.yield[0] + Math.floor(rnd() * (t.yield[1] - t.yield[0] + 1)),
    });
  };
  for (const [c, r, counts] of layoutFor(system)) {
    for (const [type, n] of Object.entries(counts)) for (let i = 0; i < n; i++) add(type, c.clone().add(randomDir(rnd).multiplyScalar(r * Math.cbrt(rnd()))));
  }
  for (let i = 0; i < 24; i++) {
    const d = randomDir(rnd).multiplyScalar(40 + rnd() * 160);
    add(['ore', 'ice', 'salvage'][Math.floor(rnd() * 3)], d.add(SHIP_CENTER));
  }
  field.chunks = chunks;

  const matFor = {
    ore: new THREE.MeshStandardMaterial({ map: rockTex(3, '#5a4c40', 'rgba(200,170,120,0.5)'), roughness: 0.95, metalness: 0.15, emissive: 0x0d0906 }),
    ice: new THREE.MeshStandardMaterial({ map: rockTex(8, '#9fb6c8', 'rgba(255,255,255,0.7)'), roughness: 0.25, metalness: 0.1, emissive: 0x061018, transparent: true, opacity: 0.92 }),
    salvage: new THREE.MeshStandardMaterial({ map: hullPlate(19), color: 0xb0a898, roughness: 0.5, metalness: 0.4, emissive: 0x0a0806 }),
  };
  const geoFor = { ore: lumpyGeo(5, 1, 0.45), ice: lumpyGeo(9, 1, 0.3), salvage: plateGeo() };
  for (const type of ['ore', 'ice', 'salvage']) {
    const list = chunks.filter(c => c.type === type);
    const im = new THREE.InstancedMesh(geoFor[type], matFor[type], Math.max(1, list.length));
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    list.forEach((c, i) => { c.inst = i; c.mesh = im; });
    field.meshes[type] = im;
    field.group.add(im);
  }
  // a few blinking debris markers on salvage pieces, so the wreck field can be found in the dark
  const spriteMat = new THREE.SpriteMaterial({ map: glowSprite(), color: 0xff7a30, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  field.blinkers = [];
  chunks.filter(c => c.type === 'salvage').slice(0, 14).forEach((c, i) => {
    const s = new THREE.Sprite(spriteMat.clone()); s.scale.set(0.9, 0.9, 1); field.group.add(s);
    field.blinkers.push({ s, c, phase: i * 0.77 });
  });
  updateFieldMatrices(0);
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3();
export function updateFieldMatrices(dt) {
  for (const c of field.chunks) {
    if (c.spin && dt) { _q.setFromAxisAngle(c.axis, c.spin * dt); c.rot.premultiply(_q); }
    const k = c.hp <= 0 ? 0 : 0.35 + 0.65 * (c.hp / c.maxHp);
    _s.copy(c.scale).multiplyScalar(k);
    _m.compose(c.pos, c.rot, _s);
    c.mesh.setMatrixAt(c.inst, _m);
  }
  for (const t in field.meshes) field.meshes[t].instanceMatrix.needsUpdate = true;
  const now = performance.now() / 1000;
  for (const b of field.blinkers || []) {
    b.s.visible = b.c.hp > 0;
    b.s.position.copy(b.c.pos).addScaledVector(new THREE.Vector3(0, 1, 0), b.c.size * 0.8);
    b.s.material.opacity = (Math.sin(now * 2.4 + b.phase) > 0.6) ? 0.95 : 0.12;
  }
}

export function disposeField() {
  if (!field.group) return;
  ship.remove(field.group);
  field.group.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } });
  field.group = null; field.chunks = []; field.meshes = {}; field.blinkers = [];
}

// ---------------- the derelict: a second KESTREL-4, broken in two ----------------
export const derelict = { group: null, halves: [], body: null, recorder: null, spin: 0.012 };
export function buildDerelict() {
  const g = new THREE.Group(); g.position.copy(DERELICT_POS); ship.add(g);
  derelict.group = g;
  // gfx pass: the same plating as your hull, burned and pitted, with real relief
  const hs = hullSet(31, 4, 1.6, 1);
  const mat = new THREE.MeshStandardMaterial({ map: hs.map, color: 0x8a8a92, roughness: 1.0, roughnessMap: hs.roughnessMap, metalness: 0.35, normalMap: hs.normalMap, side: THREE.DoubleSide, emissive: 0x060608 });
  const inner = new THREE.MeshStandardMaterial({ color: 0x16171b, roughness: 0.9, metalness: 0.3, side: THREE.BackSide });
  derelict.hullMat = mat; // P3: lit by the crowded sky ahead when it keeps pace at near light speed
  const R = 3.3;
  const half = (len, capAtNeg, offset, rot) => {
    const h = new THREE.Group(); h.position.copy(offset); h.rotation.set(rot.x, rot.y, rot.z); g.add(h);
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(R, R, len, 40, Math.ceil(len / 0.5), true), mat); cyl.rotation.x = Math.PI / 2; h.add(cyl);
    const cylIn = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.1, R - 0.1, len, 40, Math.ceil(len / 0.5), true), inner); cylIn.rotation.x = Math.PI / 2; h.add(cylIn);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(R, 40, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat);
    cap.rotation.x = capAtNeg ? -Math.PI / 2 : Math.PI / 2; cap.position.z = capAtNeg ? -len / 2 : len / 2; h.add(cap);
    // torn edge: jagged plates around the open end
    for (let i = 0; i < 9; i++) {
      const a = i / 9 * Math.PI * 2;
      const p = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.8 + (i % 3) * 0.5), mat);
      p.position.set(Math.cos(a) * R, Math.sin(a) * R, (capAtNeg ? 1 : -1) * (len / 2 + 0.3));
      p.rotation.set(0.4 * (i % 2 ? 1 : -1), 0, a + Math.PI / 2); h.add(p);
    }
    const name = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 1.2), new THREE.MeshStandardMaterial({ map: stencil('KESTREL-4', { w: 1024, h: 220, font: 'bold 150px monospace', worn: 1.2, seed: 99 }), transparent: true, roughness: 0.7 }));
    name.position.set(R + 0.02, 1.2, 0); name.rotation.y = Math.PI / 2; h.add(name);
    derelict.halves.push({ group: h, len, r: R });
    return h;
  };
  const fore = half(9, true, new THREE.Vector3(0, 0, -8), new THREE.Euler(0.05, 0.1, 0.2));
  const aft = half(8, false, new THREE.Vector3(1.5, 2.5, 7), new THREE.Euler(-0.25, -0.3, 0.9));
  // interior glimpsed at the break: a bunk, a stripped frame, loose cable
  const bunkMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2e, roughness: 0.8 });
  const b1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.1, 1.9), bunkMat); b1.position.set(-1.2, -1.4, 2.2); fore.add(b1); b1.userData.glimpse = true;
  const cable = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 5, 5), bunkMat); cable.position.set(0.5, 0.5, 3.8); cable.rotation.set(1.1, 0.3, 0.4); fore.add(cable); cable.userData.glimpse = true;
  // the body: a suit, floating, tethered to the fore half by a line
  const suitMat = new THREE.MeshStandardMaterial({ color: 0x8f897c, roughness: 0.85 });
  const body = new THREE.Group(); body.position.set(0.6, -0.4, 1.0); g.add(body);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.6, 4, 10), suitMat); body.add(torso);
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), suitMat); helm.position.y = 0.62; body.add(helm);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 8, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.05, metalness: 1 }));
  visor.position.set(0, 0.64, 0.1); body.add(visor);
  [[-0.35, 0.1, 0.4], [0.35, 0.05, -0.5]].forEach(([x, y, r]) => { const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.5, 3, 6), suitMat); a.position.set(x, y, 0); a.rotation.z = r; body.add(a); });
  [[-0.14, -0.7, 0.15], [0.14, -0.75, -0.2]].forEach(([x, y, r]) => { const l = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.55, 3, 6), suitMat); l.position.set(x, y, 0); l.rotation.z = r; body.add(l); });
  body.rotation.set(0.6, 0.4, 2.2);
  const tapeTex = stencil('CREW 1', { w: 256, h: 64, font: 'bold 34px monospace', color: 'rgba(30,30,30,0.9)', worn: 0.1 });
  const tape = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.08), new THREE.MeshBasicMaterial({ map: tapeTex, transparent: true }));
  tape.position.set(0, 0.2, 0.29); body.add(tape);
  derelict.body = body;
  const tether = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0.6, -0.4, 1.0), new THREE.Vector3(-0.5, -2.8, -3.5)]);
  g.add(new THREE.Line(tether, new THREE.LineBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0.35 })));
  // flight recorder: an orange box wedged in the fore half's torn edge
  const rec = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 0.35), new THREE.MeshStandardMaterial({ color: 0xd06020, roughness: 0.6, emissive: 0x200800 }));
  rec.position.set(-1.8, 1.6, -3.0); g.add(rec);
  derelict.recorder = rec;
  // one dying lamp inside the fore half, so it reads as a place, not a rock
  const dl = new THREE.PointLight(0xff4020, 14, 14, 1.6); dl.position.set(0, 0, -3); fore.add(dl);
  derelict.lamp = dl;
  // baked ambient occlusion on the plates (the hull shells themselves are hollow: not occluders)
  derelict.bake = bakeRoot(g, [], { aoDist: 1.0, aoStrength: 0.75, skipOccluder: o => o.geometry.type === 'CylinderGeometry' && o.geometry.parameters.radiusTop > 2 || o.geometry.type === 'SphereGeometry' && o.geometry.parameters.radius > 2 });
  g.traverse(o => { if (o.isMesh && o.material.vertexColors && !o.geometry.attributes.color) o.geometry.setAttribute('color', new THREE.BufferAttribute(new Float32Array(o.geometry.attributes.position.count * 3).fill(1), 3)); });
  return g;
}
export function updateDerelict(dt) {
  if (!derelict.group) return;
  derelict.group.rotation.y += derelict.spin * dt;
  derelict.group.rotation.x += derelict.spin * 0.4 * dt;
  if (derelict.lamp) derelict.lamp.intensity = Math.random() < 0.03 ? 0 : (derelict.lampLevel != null ? derelict.lampLevel : 14);
}
// world (ship-frame) position of a derelict part
export function derelictPointWorld(obj) { return obj.getWorldPosition(new THREE.Vector3()).applyMatrix4(new THREE.Matrix4().copy(ship.matrixWorld).invert()); }

// ---------------- the boundary: where the measurement stops ----------------
export const boundary = { lattice: null, printed: null, center: SHIP_CENTER };
// W0: how far a ship-frame point is past the edge of measured space (0 inside it)
export function dOutOf(p) { return Math.max(0, p.distanceTo(SHIP_CENTER) - BOUNDARY_R); }
export function buildBoundary() {
  const geo = new THREE.WireframeGeometry(new THREE.IcosahedronGeometry(BOUNDARY_R - 1, 5));
  const lat = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0, depthWrite: false }));
  lat.position.copy(SHIP_CENTER); ship.add(lat);
  boundary.lattice = lat;
}
// the printed sky: the same star directions, drawn ON the boundary shell.
// Near the ship it lies exactly under the real sky and cannot be seen. Fly
// toward the edge and the two stop agreeing.
export function buildPrintedSky(starGeo, starMat) {
  if (boundary.printed) { scene.remove(boundary.printed); boundary.printed.material.dispose(); boundary.printed = null; }
  const mat = starMat.clone();
  mat.uniforms = THREE.UniformsUtils.clone(starMat.uniforms);
  mat.uniforms.uFade.value = 0;
  const pts = new THREE.Points(starGeo, mat);
  pts.scale.setScalar((BOUNDARY_R - 3) / 5000);
  pts.frustumCulled = false;
  scene.add(pts);
  boundary.printed = pts;
}

// ---------------- the Listener's body: a vast absence crossing the sky ----------------
export const listenerBody = { mesh: null, lights: null };
export function buildListenerBody(skyGroup) {
  const geo = new THREE.SphereGeometry(1, 40, 20);
  geo.scale(1, 0.22, 0.32);
  const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0x000000, depthWrite: true }));
  m.scale.setScalar(2200);
  m.visible = false; m.renderOrder = 2;
  const lightsGeo = new THREE.BufferGeometry();
  const arr = [];
  for (let i = 0; i < 44; i++) { const x = -0.9 + i * 0.042; const row = i % 2; arr.push(x, -0.19 - row * 0.012 + Math.sin(i * 1.7) * 0.006, 0.24 + row * 0.02); }
  lightsGeo.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
  const lights = new THREE.Points(lightsGeo, new THREE.PointsMaterial({ color: 0xa01208, size: 3.5, sizeAttenuation: false, transparent: true, opacity: 0.95, toneMapped: false }));
  m.add(lights);
  skyGroup.add(m);
  listenerBody.mesh = m; listenerBody.lights = lights;
}

// ---------------- hallucinations: the second crew member, the unlit shapes ----------------
export const figure = { mesh: null };
export function buildFigure() {
  const g = new THREE.Group();
  const mat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0 });
  const bodyM = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 1.0, 4, 10), mat); bodyM.position.y = 0.85; g.add(bodyM);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), mat); head.position.y = 1.62; g.add(head);
  g.visible = false; ship.add(g);
  figure.mesh = g; figure.mat = mat;
}
export const unlitShapes = [];
export function buildUnlitShapes() {
  const mat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0 });
  for (let i = 0; i < 5; i++) {
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(0.6, 5 + i * 0.7, 4, 8), mat.clone());
    m.visible = false; ship.add(m); unlitShapes.push({ mesh: m, ang: i / 5 * Math.PI * 2, bob: i * 1.3 });
  }
}
